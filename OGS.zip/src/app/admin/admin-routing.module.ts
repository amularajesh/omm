import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";

import { AdminComponent } from "./admin.component";

const routes: Routes = [
  {
    path: "",
    component: AdminComponent,
    children: [
      { path: "", redirectTo: "home", pathMatch: 'full' },
      {
        path: "home", loadChildren: () => import("./home/home.module").then((m) => m.HomeModule)
      },
      {
        path: "charges", loadChildren: () => import("./charges/charges.module").then((m) => m.ChargesModule)
      },
      {
        path: "customer-order", loadChildren: () => import("./customer-order/customer-order.module").then((m) => m.CustomerOrderModule)
      },
      {
        path: "dashboard", loadChildren: () => import("./dashboard/dashboard.module").then((m) => m.DashboardModule)
      },
      {
        path: "feedback", loadChildren: () => import("./feedback/feedback.module").then((m) => m.FeedbackModule)
      },
      {
        path: "enquiry", loadChildren: () => import("./enquiry/enquiry.module").then((m) => m.EnquiryModule)
      },
      {
        path: "inventory", loadChildren: () => import("./inventory/inventory.module").then((m) => m.InventoryModule)
      },
      {
        path: "masters", loadChildren: () => import("./masters/masters.module").then((m) => m.MastersModule)
      },
      {
        path: "profile", loadChildren: () => import("./profile/profile.module").then((m) => m.ProfileModule)
      },
      {
        path: "payments", loadChildren: () => import("./payments/payments.module").then((m) => m.PaymentsModule)
      },
      {
        path: "reports", loadChildren: () => import("./reports/reports.module").then((m) => m.ReportsModule)
      },
      {
        path: "users", loadChildren: () => import("./users/users.module").then((m) => m.UsersModule)
      }
    ]
  }
];

/**
 * Admin Routing Module
 * @export
 * @class AdminRoutingModule
 */
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule { }
