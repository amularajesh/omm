import { Component, OnInit } from '@angular/core';
import { Classes } from '../app.component';

import { AuthenticationService } from '../core/Auth/authentication.service';
import { AppService } from '../core/Services/app.service';

/**
 * Admin Component
 * @export
 * @class AdminComponent
 * @implements {OnInit}
 */
@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.scss'],
})
export class AdminComponent implements OnInit {
  /**
   * Creates an instance of AdminComponent.
   * @param {AppService} appService
   * @param {AuthenticationService} authService
   */
  constructor(
    private appService: AppService,
    public authService: AuthenticationService,
  ) { }

  /**
   * Life Cycle Hook Initialization
   */
  ngOnInit(): void { }

  /**
   * apply classes to the sidebar dynamically
   * @return {*}
   */
  getClasses(): Classes {
    const classes = {
      'pinned-sidebar': this.appService.getSidebarStat().isSidebarPinned,
      'toggled-sidebar': this.appService.getSidebarStat().isSidebarToggled,
    };
    return classes;
  }

  /**
   * handle side bar in small devices
   */
  toggleSidebar() {
    document.getElementById('mobileArrow')?.click();
  }
}
