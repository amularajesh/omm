import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PrintingEmbroideryFilmchargesComponent } from './printing-embroidery-filmcharges.component';

describe('PrintingEmbroideryFilmchargesComponent', () => {
  let component: PrintingEmbroideryFilmchargesComponent;
  let fixture: ComponentFixture<PrintingEmbroideryFilmchargesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PrintingEmbroideryFilmchargesComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PrintingEmbroideryFilmchargesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
