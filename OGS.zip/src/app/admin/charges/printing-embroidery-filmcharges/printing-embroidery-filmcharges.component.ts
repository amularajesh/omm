import { Location } from "@angular/common";
import { Component, OnInit, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";

import { SnackbarModalComponent } from "src/app/core/Dialogues/snackbar-modal/snackbar-modal.component";
import { ChargesService } from "src/app/core/Services/charges.service";
import { LoaderService } from "src/app/core/Services/loader.service";
import { MastersService } from "src/app/core/Services/masters.service";
import { ValidationService } from "src/app/core/Services/validation.service";

/**
 * Printing Embroidery Film Charges Component
 * @export
 * @class PrintingEmbroideryFilmchargesComponent
 * @implements {OnInit}
 */
@Component({
  selector: "app-printing-embroidery-filmcharges",
  templateUrl: "./printing-embroidery-filmcharges.component.html",
  styleUrls: ["./printing-embroidery-filmcharges.component.scss"],
})
export class PrintingEmbroideryFilmchargesComponent implements OnInit {
  /**
   * Get Snackbar Modal Component
   * @type {SnackbarModalComponent}
   */
  @ViewChild("snackbarModalComponent") snackbarModalComponent!: SnackbarModalComponent;

  /**
   * Get Is Admin Or Manager Flag
   */
  isAdminOrManager = false;

  /**
   * Get Printing Charges List
   */
  printingChargesList: any;

  /**
   * Get Printing Charges Records Count
   */
  printingChargesRecordsCount = 0;

  /**
   * Get Print Modes List
   */
  printModesList: any;

  /**
   * Get Print Types List
   */
  printTypesList: any;

  /**
   * Get Edit Printing Charges Details
   */
  editPrintingChargesDetails: any;

  /**
   * Get Is Update Printing Charge Flag
   */
  isUpdatePrintingCharge = false;

  /**
   * Get Selected Print Mode
   * @type {*}
   */
  selectedPrintMode: any;

  /**
   * Get Selected Print Type
   * @type {*}
   */
  selectedPrintType: any;

  /**
   * Default Page Number
   */
  currentPage = 1;

  /**
   * Search Term
   */
  searchTerm = "";

  /**
   * Default Sorting Key
   */
  sortingKeyColumn = "printMode";

  /**
   * Default Sort Order
   */
  sortingOrder = true;

  /**
   * Create Printing Charges Form Declaration
   */
  createPrintingChargesForm!: FormGroup;

  /**
   * Get Printing Charges Form Validations
   */
  createPrintingChargesValidation = this.validationService.createPrintCharges;
  createPrintingChargesPatterns = this.validationService.patterns;

  /**
   * Creates an instance of PrintingEmbroideryFilmchargesComponent.
   * @param {ValidationService} validationService
   * @param {FormBuilder} formBuilder
   * @param {MastersService} mastersService
   * @param {ChargesService} chargesService
   * @param {Location} location
   * @param {LoaderService} loaderService
   */
  constructor(
    private validationService: ValidationService,
    private formBuilder: FormBuilder,
    private mastersService: MastersService,
    private chargesService: ChargesService,
    private location: Location,
    private loaderService: LoaderService,
  ) {
    if (localStorage.getItem('userTypeId') == '1' || localStorage.getItem('userTypeId') == '4') {
      this.isAdminOrManager = true;
    }
  }

  /**
   * Life Cycle Hook Initialization
   */
  ngOnInit(): void {
    this.getPrintChargesList();
    this.getPrintModesList();
    this.createPrintingChargesFormValidations();
  }

  /**
   * Initialize Create Printing Charges Form Validations
   */
  createPrintingChargesFormValidations() {
    if (this.editPrintingChargesDetails) {
      this.onChangePrintMode(this.editPrintingChargesDetails?.printModeId);
    }
    this.createPrintingChargesForm = this.formBuilder.group({
      printmodeSelect: [
        this.editPrintingChargesDetails?.printModeId || "",
        [Validators.required],
      ],
      printTypeSelect: [
        this.editPrintingChargesDetails?.printTypeId || "",
        [Validators.required],
      ],
      printCharge: [
        +this.editPrintingChargesDetails?.printingCharge || "",
        [
          Validators.required,
          Validators.minLength(
            this.createPrintingChargesValidation.printCharge.minLength
          ),
          Validators.maxLength(
            this.createPrintingChargesValidation.printCharge.maxLength
          ),
          Validators.pattern(this.createPrintingChargesPatterns?.chargeInput),
        ],
      ],
    });
  }

  /**
   * Create Printing Charges Form Controls Initialized
   * @readonly
   */
  get createPrintingChargesFormControls() {
    return this.createPrintingChargesForm.controls;
  }

  /**
   * This method is used to Get Print Charges List
   */
  getPrintChargesList() {
    this.chargesService.GetPrintingCharges().subscribe({
      next: (res: any) => {
        this.printingChargesList = res?.result;
        this.printingChargesRecordsCount = res?.result?.length;
      },
      error: (res: any) => {
        this.printingChargesList = [];
        this.printingChargesRecordsCount = 0;
      },
    });
  }

  /**
   * This method is used to Get Print Modes List
   */
  getPrintModesList() {
    this.mastersService.getPrintModes().subscribe({
      next: (res: any) => {
        this.printModesList = res.result;
      },
      error: (res: any) => {
        this.printModesList = [];
      },
    });
  }

  /**
   * This method will fired when user selects the print mode
   * @param {*} event
   */
  onChangePrintMode(event: any) {
    if (event?.target) {
      this.createPrintingChargesFormControls["printTypeSelect"].setValue("");
      this.createPrintingChargesFormControls[
        "printTypeSelect"
      ].markAsUntouched({ onlySelf: true });
    }
    this.printTypesList = [];
    let printModeValue = event?.target ? +event?.target.value : +event;
    for (const element of this.printModesList) {
      if (+element.printModeId === printModeValue) {
        this.selectedPrintMode = element;
        this.chargesService.getPrintTypesByModeId(this.selectedPrintMode.printModeId?.toString()).subscribe({
          next: (res: any) => {
            this.printTypesList = res.result;
            if (this.editPrintingChargesDetails) {
              this.onChangePrintType(this.editPrintingChargesDetails?.printTypeId);
            }
          },
          error: (err: any) => {
            this.printTypesList = [];
          }
        });
      }
    }
  }

  /**
   * This method will fired when user selects the print type
   * @param {*} event
   */
  onChangePrintType(event: any) {
    let printModeValue = event?.target ? +event?.target.value : +event;
    for (const element of this.printTypesList) {
      if (+element.printTypeId === printModeValue) {
        this.selectedPrintType = element;
      }
    }
  }

  /**
   * This method is used to get the Printing Charges details by Id
   * @param {*} printingCharge
   */
  onClickEditPrintingCharge(printingCharge: any) {
    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    /* To call the service to get the edit printing charges details by passing id */
    this.chargesService.getPrintingChargesById(printingCharge?.printingChargesId?.toString()).subscribe({
      next: (res: any) => {
        /* Disable the loader */
        this.loaderService.isLoading.next(false);

        this.editPrintingChargesDetails = res?.result;
        this.isUpdatePrintingCharge = true;
        this.createPrintingChargesFormValidations();
      },
      error: (err: any) => {
        /* Disable the loader */
        this.loaderService.isLoading.next(false);

        this.editPrintingChargesDetails = "";
        this.isUpdatePrintingCharge = false;
        this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
      }
    });
  }

  /**
   * This method is used to reset the printing charges form
   */
  onClickReset() {
    this.createPrintingChargesForm.reset();
    this.isUpdatePrintingCharge = false;
    this.editPrintingChargesDetails = "";
    this.createPrintingChargesFormValidations();
  }

  /**
   * This method is used to change the pagination controls
   * @param {*} event
   */
  onPageChange(event: any) {
    this.currentPage = event;
  }

  /**
   * This method is used to sort column
   * @param key : value of which column based we need to sort the rows
   */
  sort(key: string) {
    const componentName = this.location.path();
    let value = key;
    sessionStorage.setItem(`${componentName}_property`, value);
    this.sortingKeyColumn = key;
    if (sessionStorage.getItem(componentName + "_order") == "desc") {
      this.sortingOrder = false;
    } else {
      this.sortingOrder = true;
    }
  }

  /**
   * This method is used to show search results
   */
  navigateToSearchResult() {
    this.currentPage = 1;
  }

  /**
   * This method is used to submit the printing charges form
   * @return {*}
   */
  onSubmitPrintingChargesForm(): any {
    /** This will return false if form fields are invalid and stop the service calling */
    if (this.createPrintingChargesForm.invalid) {
      this.validationService.validateAllFormFields(
        this.createPrintingChargesForm
      );
      return;
    }

    /* Prepare the request payload */
    const obj: any = {
      printModeId: this.selectedPrintMode?.printModeId?.toString(),
      printTypeId: this.selectedPrintType?.printTypeId?.toString(),
      printingCharge: this.createPrintingChargesForm.controls["printCharge"].value?.toString(),
    };

    if (this.isUpdatePrintingCharge) {
      obj["printingChargesId"] = this.editPrintingChargesDetails?.printingChargesId?.toString();
    }

    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    if (!this.isUpdatePrintingCharge) {
      /* To call the service to add the printing charges by passing data object */
      this.chargesService.addPrintingCharges(obj).subscribe({
        next: (res: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', '');
          this.getPrintChargesList();
          this.onClickReset();
        },
        error: (err: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
        }
      });
    } else {
      /* To call the service to edit the printing charges by passing data object */
      this.chargesService.editPrintingCharges(obj).subscribe({
        next: (res: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', '');
          this.getPrintChargesList();
          this.onClickReset();
        },
        error: (err: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
        }
      });
    }
  }
}
