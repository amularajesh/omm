import { Location } from "@angular/common";
import { Component, OnInit, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";

import { SnackbarModalComponent } from "src/app/core/Dialogues/snackbar-modal/snackbar-modal.component";
import { ChargesService } from "src/app/core/Services/charges.service";
import { LoaderService } from "src/app/core/Services/loader.service";
import { MastersService } from "src/app/core/Services/masters.service";
import { ValidationService } from "src/app/core/Services/validation.service";

/**
 * Steam Iron Charges Component
 * @export
 * @class SteamIronChargesComponent
 * @implements {OnInit}
 */
@Component({
  selector: 'app-steam-iron-charges',
  templateUrl: './steam-iron-charges.component.html',
  styleUrls: ['./steam-iron-charges.component.scss']
})
export class SteamIronChargesComponent implements OnInit {
  /**
   * Get Snackbar Modal Component
   * @type {SnackbarModalComponent}
   */
  @ViewChild("snackbarModalComponent") snackbarModalComponent!: SnackbarModalComponent;

  /**
   * Selected Age Group
   */
  selectedAgeGroup = 0;

  /**
   * Get Is Admin Or Manager Flag
   */
  isAdminOrManager = false;

  /**
    * Get Steam Iron charges List
   * @type {*}
   */
  steamIronChargesList: any;

  /**
   * Get Steam Iron Records Count
   */
  steamIronChargesRecordsCount = 0;

  /**
   * Get Is Update Steam Iron Flag
   */
  updateSteamIronCharges = false;

  /**
   * Get Dress Item List
   * @type {*}
   */
  dressItemsList: any;

  /**
   * Get Steam Iron Details
   * @type {*}
   */
  editSteamIronChargesDetails: any;

  /**
   * Default Sorting Key
   */
  sortingKeyColumn = "dressItem";

  /**
   * Default Sort Order
   */
  sortingOrder = true;

  /**
   * Default Page Number
   */
  currentPage = 1;

  /**
   * Search Term
   */
  searchTerm = "";

  /**
   * Create steam iron Form Declaration
   * @type {FormGroup}
   */
  createStreamIronChargesForm!: FormGroup;

  /**
   * Get steam iron Form Validations
   */
  steamIronChargesValidation = this.validationService?.createSteamIronCharges;

  /**
   * Get steam iron Form Patterns
   */
  steamIronPattern = this.validationService?.patterns;

  /**
   * Creates an instance of SteamIronChargesComponent.
   * @param {ValidationService} validationService
   * @param {FormBuilder} formBuilder
   * @param {MastersService} mastersService
   * @param {ChargesService} chargesService
   * @param {Location} location
   * @param {LoaderService} loaderService
   */
  constructor(
    private validationService: ValidationService,
    private formBuilder: FormBuilder,
    private mastersService: MastersService,
    private chargesService: ChargesService,
    private location: Location,
    private loaderService: LoaderService
  ) {
    if (localStorage.getItem('userTypeId') == '1' || localStorage.getItem('userTypeId') == '4') {
      this.isAdminOrManager = true;
    }
  }

  /**
   * Life Cycle Hook Initialization
   */
  ngOnInit(): void {
    this.getDressItems();
    this.createSteamIronFormValidations();
    this.getSteamIronChargesList();
  }

  /**
   * Initialize Create Steam Iron Charges Form Validations
   */
  createSteamIronFormValidations() {
    this.createStreamIronChargesForm = this.formBuilder.group({
      dressItem: [
        this.editSteamIronChargesDetails?.dressItemId || "",
        [Validators.required],
      ],
      ageGroup: [this.editSteamIronChargesDetails?.ageGroup?.toString() || "0"],
      charge: [
        this.editSteamIronChargesDetails?.steamIronCharge || "",
        [
          Validators.required,
          Validators.minLength(this.steamIronChargesValidation.charge.minLength),
          Validators.maxLength(this.steamIronChargesValidation.charge.maxLength),
          Validators.pattern(this.steamIronPattern?.chargeInput),
        ],
      ],
    });

    if (this.editSteamIronChargesDetails) {
      this.onChangeAgeGroup(this.editSteamIronChargesDetails?.ageGroup)
    }
  }

  /**
   * Create Steam Iron Form Controls  Initialized
   * @readonly
   */
  get createSteamIronChargesFormControls() {
    return this.createStreamIronChargesForm.controls;
  }

  /**
   * This method is used to get Dress Items List
   */
  getDressItems() {
    this.mastersService.getDressItems().subscribe({
      next: (res: any) => {
        this.dressItemsList = res?.result;
      },
      error: () => {
        this.dressItemsList = [];
      },
    });
  }

  /**
   * This method is used to Get  Steam Iron Charges List
   */
  getSteamIronChargesList() {
    this.chargesService.getSteamIronCharges().subscribe({
      next: (res: any) => {
        this.steamIronChargesList = res.result;
        this.steamIronChargesRecordsCount = this.steamIronChargesList.length;
      },
      error: () => {
        this.steamIronChargesList = [];
        this.steamIronChargesRecordsCount = 0;
      },
    });
  }

  /**
   * This method is used to reset Steam Iron charges form
   */
  onClickReset() {
    this.createStreamIronChargesForm.reset();
    this.editSteamIronChargesDetails = "";
    this.updateSteamIronCharges = false;
    this.createSteamIronFormValidations();
  }

  /**
   * This method will fired when user selects the Dress Item
   * @param {*} event
   */
  onChangeDressItem(event: any) {
    if (event?.target?.value == '') {
      this.createSteamIronChargesFormControls['dressItem']?.markAsUntouched({ onlySelf: true });
    }
  }

  /**
   * This method will fired when user changes age group radio
   * @param {*} event
   */
  onChangeAgeGroup(event: any) {
    let ageGroupValue = event?.target ? +event?.target.value : +event;
    this.selectedAgeGroup = +ageGroupValue;
  }

  /**
   * This method is used to sort column
   * @param key : value of which column based we need to sort the rows
   */
  sort(key: string) {
    const componentName = this.location.path();
    let value = key;
    sessionStorage.setItem(`${componentName}_property`, value);
    this.sortingKeyColumn = key;
    if (sessionStorage.getItem(componentName + "_order") == "desc") {
      this.sortingOrder = false;
    } else {
      this.sortingOrder = true;
    }
  }

  /**
   * This method is used to show search results
   */
  navigateToSearchResult() {
    this.currentPage = 1;
  }

  /**
   * This method is used to change the pagination controls
   * @param {*} event
   */
  onPageChange(event: any) {
    this.currentPage = event;
  }

  /**
   * This method is used to get the Steam Iron Charges details by Id
   * @param {*} steamIronCharge
   */
  onClickEditSteamIronCharge(steamIronCharge: any) {

    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    /* To call the service to get the edit Steam Iron charges details by passing id */
    this.chargesService.getSteamIronChargesById(steamIronCharge?.steamIronChargesId).subscribe({
      next: (res: any) => {
        /* Disable the loader */
        this.loaderService.isLoading.next(false);

        this.editSteamIronChargesDetails = res?.result;
        this.updateSteamIronCharges = true;
        this.createSteamIronFormValidations();
      },
      error: (err: any) => {
        /* Disable the loader */
        this.loaderService.isLoading.next(false);

        this.editSteamIronChargesDetails = "";
        this.updateSteamIronCharges = false;
        this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
      }
    });
  }

  /**
   * This method is used to submit the Steam Iron charges form
   * @return {*}
   */
  onSubmitSteamIronChargesForm(): any {
    /** This will return false if form fields are invalid and stop the service calling */
    if (this.createStreamIronChargesForm.invalid) {
      this.validationService.validateAllFormFields(this.createStreamIronChargesForm);
      return;
    }

    /* Prepare the request payload */
    const obj: any = {
      dressItemId: this.createSteamIronChargesFormControls["dressItem"]?.value,
      AgeGroup: this.selectedAgeGroup,
      steamIronCharge: this.createSteamIronChargesFormControls["charge"]?.value?.toString(),
    };

    if (this.updateSteamIronCharges) {
      obj["steamIronChargesId"] = this.editSteamIronChargesDetails?.steamIronChargesId;
    }

    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    if (!this.updateSteamIronCharges) {
      this.chargesService.addSteamIronCharges(obj).subscribe({
        next: (res: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', '');
          this.getSteamIronChargesList();
          this.onClickReset();
        },
        error: (err: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
        }
      });
    } else {
      this.chargesService.editSteamIronCharges(obj).subscribe({
        next: (res: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', '');
          this.getSteamIronChargesList();
          this.onClickReset();
          this.updateSteamIronCharges = false;
        },
        error: (err: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
        }
      });
    }
  }
}
