import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SteamIronChargesComponent } from './steam-iron-charges.component';

describe('SteamIronChargesComponent', () => {
  let component: SteamIronChargesComponent;
  let fixture: ComponentFixture<SteamIronChargesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SteamIronChargesComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SteamIronChargesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
