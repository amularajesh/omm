import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CollarKnittingChargesComponent } from './collar-knitting-charges.component';

describe('CollarKnittingChargesComponent', () => {
  let component: CollarKnittingChargesComponent;
  let fixture: ComponentFixture<CollarKnittingChargesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CollarKnittingChargesComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CollarKnittingChargesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
