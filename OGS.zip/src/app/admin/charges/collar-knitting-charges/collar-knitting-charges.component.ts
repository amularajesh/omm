import { Location } from "@angular/common";
import { Component, OnInit, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";

import { SnackbarModalComponent } from "src/app/core/Dialogues/snackbar-modal/snackbar-modal.component";
import { ChargesService } from "src/app/core/Services/charges.service";
import { LoaderService } from "src/app/core/Services/loader.service";
import { ValidationService } from "src/app/core/Services/validation.service";

/**
 * Collar Knitting Charges Component
 * @export
 * @class CollarKnittingChargesComponent
 * @implements {OnInit}
 */
@Component({
  selector: "app-collar-knitting-charges",
  templateUrl: "./collar-knitting-charges.component.html",
  styleUrls: ["./collar-knitting-charges.component.scss"],
})
export class CollarKnittingChargesComponent implements OnInit {
  /**
   * Get Snackbar Modal Component
   * @type {SnackbarModalComponent}
   */
  @ViewChild("snackbarModalComponent") snackbarModalComponent!: SnackbarModalComponent;

  /**
   * Get Is Admin Or Manager Flag
   */
  isAdminOrManager = false;

  /**
   * Get Collar Knitting Charges List
   * @type {*}
   */
  collarKnittingChargesList: any;

  /**
   * Get Collar Knitting Charges Records Count
   */
  collarKnittingChargesRecordsCount = 0;

  /**
   * Get Is Update CollarKnitting Flag
   */
  updateCollarKnitting = false;

  /**
   * Get Collar Types List
   * @type {*}
   */
  collarTypesList: any;

  /**
   * Get Collar Knitting Charges Details
   * @type {*}
   */
  editCollarKnittingChargesDetails: any;

  /**
   * Default Sorting Key
   */
  sortingKeyColumn = "collarType";

  /**
   * Default Sort Order
   */
  sortingOrder = true;

  /**
   * Default Page Number
   */
  currentPage = 1;

  /**
   * Search Term
   */
  searchTerm = "";

  /**
   * Create PrintingCharges Form Declaration
   * @type {FormGroup}
   */
  createCollarKnittingForm!: FormGroup;

  /**
   * Get PrintingCharges Form Validations
   */
  collarKnittingValidation = this.validationService?.createCollarKnittingCharges;

  /**
   * Get Patterns
   */
  collarKnittingPattern = this.validationService?.patterns;

  /**
   * Creates an instance of CollarKnittingChargesComponent.
   * @param {ValidationService} validationService
   * @param {FormBuilder} formBuilder
   * @param {ChargesService} chargesService
   * @param {LoaderService} loaderService
   * @param {Location} location
   */
  constructor(
    private validationService: ValidationService,
    private formBuilder: FormBuilder,
    private chargesService: ChargesService,
    private loaderService: LoaderService,
    private location: Location
  ) {
    if (localStorage.getItem('userTypeId') == '1' || localStorage.getItem('userTypeId') == '4') {
      this.isAdminOrManager = true;
    }
  }

  /**
   * Life Cycle Hook Initialization
   */
  ngOnInit(): void {
    this.getCollarTypes();
    this.createCollarKnittingFormValidations();
    this.getCollarKnittingChargesList();
  }

  /**
   * Initialize Create Collar Knitting Charges Form Validations
   */
  createCollarKnittingFormValidations() {
    this.createCollarKnittingForm = this.formBuilder.group({
      collarTypeSelect: [
        this.editCollarKnittingChargesDetails?.collarTypeId || "",
        [Validators.required],
      ],
      charge: [
        this.editCollarKnittingChargesDetails?.collarKnittingCharge || "",
        [
          Validators.required,
          Validators.minLength(this.collarKnittingValidation.charge.minLength),
          Validators.maxLength(this.collarKnittingValidation.charge.maxLength),
          Validators.pattern(this.collarKnittingPattern?.chargeInput)
        ]
      ]
    });
  }

  /**
   * Create Collar Knitting Charges Form Controls  Initialized
   * @readonly
   */
  get createCollarKnittingFormControls() {
    return this.createCollarKnittingForm.controls;
  }

  /**
   * This method is used to get Collar Types List
   */
  getCollarTypes() {
    this.chargesService.getCollarTypes().subscribe({
      next: (res: any) => {
        this.collarTypesList = res?.result;
      },
      error: (err: any) => {
        this.collarTypesList = [];
      },
    });
  }

  /**
   * This method is used to Get collar Knitting Charges List
   */
  getCollarKnittingChargesList() {
    this.chargesService.getCollarKnittingCharges().subscribe({
      next: (res: any) => {
        this.collarKnittingChargesList = res.result;
        this.collarKnittingChargesRecordsCount = this.collarKnittingChargesList.length;
      },
      error: (err: any) => {
        this.collarKnittingChargesList = [];
        this.collarKnittingChargesRecordsCount = 0;
      },
    });
  }

  /**
   * This method is used to reset collar knitting charges form
   */
  onClickReset() {
    this.createCollarKnittingForm.reset();
    this.editCollarKnittingChargesDetails = "";
    this.updateCollarKnitting = false;
    this.createCollarKnittingFormValidations();
  }

  /**
   * This method will fired when user selects the collar TYpe
   * @param {*} event
   */
  onChangeCollarType(event: any) {
    if (event?.target.value == '') {
      this.createCollarKnittingFormControls["collarTypeSelect"].markAsUntouched({ onlySelf: true });
    }
  }

  /**
   * This method is used to sort column
   * @param key : value of which column based we need to sort the rows
   */
  sort(key: string) {
    const componentName = this.location.path();
    let value = key;
    sessionStorage.setItem(`${componentName}_property`, value);
    this.sortingKeyColumn = key;
    if (sessionStorage.getItem(componentName + "_order") == "desc") {
      this.sortingOrder = false;
    } else {
      this.sortingOrder = true;
    }
  }

  /**
   * This method is used to show search results
   */
  navigateToSearchResult() {
    this.currentPage = 1;
  }

  /**
   * This method is used to change the pagination controls
   * @param {*} event
   */
  onPageChange(event: any) {
    this.currentPage = event;
  }

  /**
   * This method is used to get the collar Knitting Charges details by Id
   * @param {*} collarKnittingCharge
   */
  onClickEditCollarKnittingCharge(collarKnittingCharge: any) {
    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    /* To call the service to get the edit collar knitting charges details by passing id */
    this.chargesService.getCollarKnittingChargesById(collarKnittingCharge?.collarKnittingChargesId).subscribe({
      next: (res: any) => {
        /* Disable the loader */
        this.loaderService.isLoading.next(false);

        this.editCollarKnittingChargesDetails = res?.result;
        this.updateCollarKnitting = true;
        this.createCollarKnittingFormValidations();
      },
      error: (err: any) => {
        /* Disable the loader */
        this.loaderService.isLoading.next(false);

        this.editCollarKnittingChargesDetails = "";
        this.updateCollarKnitting = false;
        this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
      },
    });
  }

  /**
   * This method is used to submit the collar knitting charges form
   * @return {*}
   */
  onSubmitCollarKnittingChargesForm(): any {
    /** This will return false if form fields are invalid and stop the service calling */
    if (this.createCollarKnittingForm.invalid) {
      this.validationService.validateAllFormFields(this.createCollarKnittingForm);
      return;
    }

    /* Prepare the request payload */
    const obj: any = {
      collarTypeId: this.createCollarKnittingFormControls["collarTypeSelect"]?.value,
      collarKnittingCharge: this.createCollarKnittingFormControls["charge"]?.value?.toString(),
    };

    if (this.updateCollarKnitting) {
      obj["collarKnittingChargesId"] = this.editCollarKnittingChargesDetails?.collarKnittingChargesId;
    }


    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    if (!this.updateCollarKnitting) {
      this.chargesService.addCollarKnittingCharges(obj).subscribe({
        next: (res: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', '');
          this.getCollarKnittingChargesList();
          this.onClickReset();
        },
        error: (err: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
        },
      });
    } else {
      this.chargesService.editCollarKnittingCharges(obj).subscribe({
        next: (res: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', '');
          this.getCollarKnittingChargesList();
          this.onClickReset();
          this.updateCollarKnitting = false;
        },
        error: (err: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
        },
      });
    }
  }
}
