import { Location } from '@angular/common';
import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { SnackbarModalComponent } from 'src/app/core/Dialogues/snackbar-modal/snackbar-modal.component';
import { ChargesService } from 'src/app/core/Services/charges.service';
import { LoaderService } from 'src/app/core/Services/loader.service';
import { MastersService } from 'src/app/core/Services/masters.service';
import { ValidationService } from 'src/app/core/Services/validation.service';

/**
 * Tds Component
 * @export
 * @class TdsComponent
 * @implements {OnInit}
 */
@Component({
  selector: 'app-tds',
  templateUrl: './tds.component.html',
  styleUrls: ['./tds.component.scss'],
})
export class TdsComponent implements OnInit {
  /**
   * Get Snackbar Modal Component
   * @type {SnackbarModalComponent}
   */
  @ViewChild("snackbarModalComponent") snackbarModalComponent!: SnackbarModalComponent;

  /**
   * Search Term
   */
  searchTerm = '';

  /**
   * Get Is Admin Or Manager Flag
   */
  isAdminOrManager = false;

  /**
   * Get Steam Iron charges List
   */
  TdsList: any;

  /**
   * Get Steam Iron Records Count
   */
  TdsRecordsCount = 0;
  /**
   * Get unit type List
   */
  unitTypeList: any = [];

  /**
   * Get unit name List
   */
  unitNameList: any = [];

  /**
   * Selected Unit Type
   */
  selectedUnitType: any;

  /**
   * Selected Unit Name
   */
  selectedUnitName: any;

  /**
   * Create Tds Form Declaration
   */
  createTdsForm!: FormGroup;

  /**
   * Get tds Form Validations
   */
  createTdsValidation = this.validationService.createTds;

  /**
   * Get Financial Years List
   */
  financialYearsList: any;

  /**
   * Selected Financial Year
   */
  selectedFinancialId: any;

  /**
   * Get Patterns
   * @private
   */
  private patterns = this.validationService.patterns;

  /**
   * Get Tds Details
   * @type {*}
   */
  editTdsDetails: any;

  /**
   * Get updateTds
   */
  updateTds = false;

  /**
   * Default Sorting Key
   */
  sortingKeyColumn = 'financialYear';

  /**
   * Default Sort Order
   */
  sortingOrder = true;

  /**
   * Declaring Current Page
   */
  currentPage = 1;

  /**
   * Get TDS Type
   * @type {*}
   */
  tdsType: any = 0;

  /**
   * Creates an instance of TdsComponent.
   * @param {ValidationService} validationService
   * @param {FormBuilder} formBuilder
   * @param {ChargesService} chargesService
   * @param {MastersService} mastersService
   * @param {Location} location
   * @param {LoaderService} loaderService
   */
  constructor(
    private validationService: ValidationService,
    private formBuilder: FormBuilder,
    private chargesService: ChargesService,
    private mastersService: MastersService,
    private location: Location,
    private loaderService: LoaderService,
  ) { }

  /**
   * Life Cycle Hook Initialization
   */
  ngOnInit(): void {
    this.createTdsFormValidations();
    this.getFinancialYearsList();
    this.getUnitTypesList();
    this.getTds();
  }

  /**
   * Initialize Create Tds Form Validations
   */
  createTdsFormValidations() {
    this.createTdsForm = this.formBuilder.group({
      orgType: ['0'],
      financialYearSelect: ['', [Validators.required]],
      TdsInput: [
        '',
        [
          Validators.required,
          Validators.minLength(this.createTdsValidation.TdsInput.minLength),
          Validators.maxLength(this.createTdsValidation.TdsInput.maxLength),
          Validators.pattern(this.patterns.points),
        ],
      ],
      unitTypeSelect: ['', [Validators.required]],
      unitNameSelect: ['', [Validators.required]],
      panNumber: ['', [Validators.required]],
    });
  }

  /**
   * Create Tds Form Controls Initialized
   * @readonly
   */
  get createTdsFormControls() {
    return this.createTdsForm.controls;
  }

  /**
   * This method is used to get the states List
   */
  getFinancialYearsList() {
    this.chargesService.getFinancialYears().subscribe({
      next: (res: any) => {
        this.financialYearsList = res.result;
      },
      error: (err: any) => {
        this.financialYearsList = [];
      },
    });
  }

  /**
   * This method is used to get unit types list
   */
  getUnitTypesList() {
    this.mastersService.getUnitTypes().subscribe({
      next: (res: any) => {
        this.unitTypeList = res.result;
      },
      error: (err: any) => {
        this.unitTypeList = [];
      },
    });
  }

  /**
   * This method will fired when user selects unit type
   * @param {*} event
   */
  UnitTypeChange(event: any) {
    this.unitNameList = [];
    this.createTdsFormControls['unitNameSelect'].setValue('');
    this.createTdsFormControls['unitNameSelect'].markAsUntouched({
      onlySelf: true,
    });
    this.createTdsFormControls['panNumber'].setValue('');
    this.createTdsFormControls['panNumber'].markAsUntouched({ onlySelf: true });
    let unitTypeValue = event?.target ? +event.target?.value : event;
    for (const element of this.unitTypeList) {
      if (+element.unitTypeId === +unitTypeValue) {
        this.selectedUnitType = element;
        this.mastersService.getUnitName(this.selectedUnitType.unitTypeId?.toString()).subscribe({
          next: (res: any) => {
            this.unitNameList = res.result;
          },
          error: (err: any) => {
            this.unitNameList = [];
          }
        });
      }
    }
  }

  /**
   * This method is used to change the unit name
   * @param {*} event
   */
  UnitNameChange(event: any) {
    let unitNameValue = event?.target ? +event.target?.value : event;
    for (const element of this.unitNameList) {
      if (+element.unitNameId === +unitNameValue) {
        this.selectedUnitName = element;
        this.mastersService
          .getUnitNameById(this.selectedUnitName.unitNameId?.toString())
          .subscribe({
            next: (res: any) => {
              if (res?.result?.panNumber !== null) {
                this.createTdsFormControls['panNumber'].setValue(res?.result?.panNumber);
              } else if (this.tdsType === 0) {
                this.snackbarModalComponent.onOpenSnackbarModal(false, 'PanNumber Not Available For This Unit Name', '', '', '');
              }
            },
            error: (err: any) => {
              this.createTdsFormControls['panNumber'].setValue('');
              this.createTdsFormControls['panNumber'].markAsUntouched({ onlySelf: true });
              this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
            },
          });
      }
    }
  }

  /**
   * This method used to reset tds form
   */
  onClickReset() {
    this.tdsType = 0;
    this.createTdsFormControls['orgType']?.enable({ onlySelf: true });
    this.createTdsForm.reset();
    this.createTdsFormValidations();
    this.updateTds = false;
  }

  /**
   * This method will fired when user selects the financial year
   * @param {*} event
   */
  onChangeFinancialYear(event: any) {
    this.selectedFinancialId = event.target.value;
    this.updateTds = false;

    this.createTdsFormControls['unitTypeSelect'].setValue('');
    this.createTdsFormControls['unitTypeSelect'].markAsUntouched({
      onlySelf: true,
    });

    this.unitNameList = [];
    this.createTdsFormControls['unitNameSelect'].setValue('');
    this.createTdsFormControls['unitNameSelect'].markAsUntouched({
      onlySelf: true,
    });

    this.createTdsFormControls['panNumber'].setValue('');
    this.createTdsFormControls['panNumber'].markAsUntouched({ onlySelf: true });

    this.createTdsFormControls['TdsInput'].setValue('');
    this.createTdsFormControls['TdsInput'].markAsUntouched({ onlySelf: true });
  }

  /**
   * This method is used to submit the Tds form
   * @return {*}
   */
  onSubmitTdsForm(): any {
    if (this.tdsType === 1) {
      this.createTdsFormControls['unitTypeSelect']?.setValidators(null);
      this.createTdsFormControls['unitTypeSelect']?.updateValueAndValidity();

      this.createTdsFormControls['unitNameSelect']?.setValidators(null);
      this.createTdsFormControls['unitNameSelect']?.updateValueAndValidity();

      this.createTdsFormControls['panNumber']?.setValidators(null);
      this.createTdsFormControls['panNumber']?.updateValueAndValidity();
    } else {
      this.createTdsFormControls['unitTypeSelect']?.setValidators([
        Validators?.required,
      ]);
      this.createTdsFormControls['unitTypeSelect']?.updateValueAndValidity();

      this.createTdsFormControls['unitNameSelect']?.setValidators([
        Validators?.required,
      ]);
      this.createTdsFormControls['unitNameSelect']?.updateValueAndValidity();

      this.createTdsFormControls['panNumber']?.setValidators([
        Validators?.required,
      ]);
      this.createTdsFormControls['panNumber']?.updateValueAndValidity();
    }
    if (this.createTdsForm.invalid) {
      /** This will return false if form fields are invalid and stop the service calling */
      this.validationService.validateAllFormFields(this.createTdsForm);
      return;
    }

    /* Prepare the request payload */
    const obj = {
      tds: this.createTdsForm.controls['TdsInput'].value || '',
      financialYear: this.selectedFinancialId,
      unitNameId: +this.selectedUnitName?.unitNameId,
      typeId: this.tdsType,
    };
    const agentObj = {
      tds: this.createTdsForm.controls['TdsInput'].value || '',
      financialYear: this.selectedFinancialId,
      typeId: this.tdsType,
    };

    const editObj = {
      tdsId: this.editTdsDetails?.tdsId,
      tds: this.createTdsForm.controls['TdsInput'].value || this.editTdsDetails?.tds,
      financialYear: this.selectedFinancialId || this.editTdsDetails?.financialYearId,
      unitNameId: +this.selectedUnitName?.unitNameId || this.editTdsDetails?.unitNameId,
      typeId: this.tdsType,
    };

    const editAgentObj = {
      tdsId: this.editTdsDetails?.tdsId,
      tds: this.createTdsForm.controls['TdsInput'].value || this.editTdsDetails?.tds,
      financialYear: this.selectedFinancialId || this.editTdsDetails?.financialYearId,
      typeId: this.tdsType,
      // unitNameId:
      //   +this.selectedUnitName?.unitNameId || this.editTdsDetails?.unitNameId,
    };


    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    if (!this.updateTds) {
      /* To call the service to add the tds by passing the data object */
      this.chargesService.addTds(this.tdsType === 1 ? agentObj : obj).subscribe({
        next: (res: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', '');
          this.onClickReset();
          this.getTds();
          this.getUnitTypesList();
          this.getFinancialYearsList();
        },
        error: (err: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
        },
      });
    } else {
      /* To call the service to add the tds by passing the data object */
      this.chargesService.editTds(this.tdsType === 1 ? editAgentObj : editObj).subscribe({
        next: (res: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', '');
          this.onClickReset();
          this.getTds();
          this.getUnitTypesList();
          this.getFinancialYearsList();
          // this.createTdsFormControls['orgType']?.enable({ onlySelf: true });
        },
        error: (err: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
        },
      });
    }
  }

  /**
   * Get Tds List
   */
  getTds() {
    /* To call the service to get tds */
    this.chargesService.GetTds().subscribe({
      next: (res: any) => {
        this.TdsList = res?.result;
        this.TdsRecordsCount = this.TdsList?.length;
      },
      error: (err: any) => {
        this.TdsList = [];
        this.TdsRecordsCount = 0;
      },
    });
  }

  /**
   * This method is used to sort column
   * @param key : value of which column based we need to sort the rows
   */
  sort(key: string) {
    const componentName = this.location.path();
    let value = key;
    sessionStorage.setItem(`${componentName}_property`, value);
    this.sortingKeyColumn = key;
    if (sessionStorage.getItem(componentName + '_order') == 'desc') {
      this.sortingOrder = false;
    } else {
      this.sortingOrder = true;
    }
  }

  /**
   * This method is used to show search results
   */
  navigateToSearchResult() {
    this.currentPage = 1;
  }

  /**
   * This method is used to change the pagination controls
   * @param {*} event
   */
  onPageChange(event: any) {
    this.currentPage = event;
  }

  /**
   * This method is used to update value and validity
   * @param {*} formControls
   */
  onUpdateValueAndValidity(formControls: any, controls: any) {
    controls?.forEach((control: any) => {
      formControls[control].setValue("");
      formControls[control].markAsUntouched({ onlySelf: true });
      formControls[control].updateValueAndValidity({ onlySelf: true });
    });
  }

  /**
   * This method is used to get the tds details by Id
   * @param {*}
   */
  onClickEditTds(tds: any) {
    /* To call the service to get the edit Steam Iron charges details by passing id */
    this.chargesService.GetTdsById(tds?.tdsId).subscribe({
      next: (res: any) => {
        this.editTdsDetails = res?.result;
        this.updateTds = true;
        this.createTdsFormValidations();
        this.createTdsFormControls['financialYearSelect']?.setValue(this.editTdsDetails?.financialYearId);
        this.createTdsFormControls['TdsInput']?.setValue(this.editTdsDetails?.tds);
        if (
          this.editTdsDetails?.unitType === null &&
          this.editTdsDetails?.unitName === null
        ) {
          this.tdsType = 1;
          this.createTdsFormControls['orgType']?.setValue('1');
          this.createTdsFormControls['orgType']?.disable({ onlySelf: true });
        } else if (
          this.editTdsDetails?.unitType !== null &&
          this.editTdsDetails?.unitName !== null
        ) {
          this.tdsType = 0;
          this.createTdsFormControls['orgType']?.setValue('0');
          this.createTdsFormControls['orgType']?.disable({ onlySelf: true });
          this.createTdsFormControls['unitTypeSelect']?.setValue(this.editTdsDetails?.unitTypeId?.toString());
          // Set Unit Name based on Unit Type
          this.mastersService.getUnitName(this.editTdsDetails?.unitTypeId?.toString()).subscribe({
            next: (unitNameRes: any) => {
              this.unitNameList = unitNameRes.result;
              this.createTdsFormControls['unitNameSelect'].setValue(this.editTdsDetails?.unitNameId?.toString());

              // Set Pan based on Unit Name
              this.mastersService.getUnitNameById(this.editTdsDetails?.unitNameId?.toString()).subscribe({
                next: (panRes: any) => {
                  this.createTdsFormControls['panNumber'].setValue(panRes?.result?.panNumber);
                },
                error: (panErr: any) => {
                  this.createTdsFormControls['panNumber'].setValue('');
                  this.snackbarModalComponent.onOpenSnackbarModal(false, panErr?.error?.result?.message, '', '', '');
                },
              });
            },
            error: (unitNameErr: any) => {
              this.unitNameList = [];
              this.snackbarModalComponent.onOpenSnackbarModal(false, unitNameErr?.error?.result?.message, '', '', '');
            },
          });
        }
      },
      error: (err: any) => {
        this.editTdsDetails = '';
        this.updateTds = false;
        this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
      },
    });
  }

  /**
   * method Fired on change of orgType
   */
  orgTypeChange(event: any) {
    this.createTdsFormControls['orgType']?.enable({ onlySelf: true });
    let value = +event?.target.value;
    this.tdsType = value;
    this.onUpdateValueAndValidity(this.createTdsFormControls,
      ['financialYearSelect', 'TdsInput', 'unitTypeSelect', 'unitNameSelect', 'panNumber']
    );
    this.updateTds = false;
  }
}
