import { Location } from "@angular/common";
import { Component, OnInit, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";

import { SnackbarModalComponent } from "src/app/core/Dialogues/snackbar-modal/snackbar-modal.component";
import { ChargesService } from "src/app/core/Services/charges.service";
import { LoaderService } from "src/app/core/Services/loader.service";
import { ValidationService } from "src/app/core/Services/validation.service";

/**
 * Fusing Charges Component
 * @export
 * @class FusingChargesComponent
 * @implements {OnInit}
 */
@Component({
  selector: 'app-fusing-charges',
  templateUrl: './fusing-charges.component.html',
  styleUrls: ['./fusing-charges.component.scss']
})
export class FusingChargesComponent implements OnInit {
  /**
   * Get Snackbar Modal Component
   * @type {SnackbarModalComponent}
   */
  @ViewChild("snackbarModalComponent") snackbarModalComponent!: SnackbarModalComponent;

  /**
   * Get Is Admin Or Manager Flag
   */
  isAdminOrManager = false;

  /**
   * Get Fusing Charges List
   * @type {*}
   */
  fusingChargesList: any;

  /**
   * Get Fusing Charges Records Count
   */
  fusingChargesRecordsCount = 0;

  /**
   * Get Is Update Fusing Flag
   */
  updateFusingCharges = false;

  /**
   * Get Fusing Types List
   * @type {*}
   */
  fusingTypesList: any;

  /**
   * Get Fusing Charges Details
   * @type {*}
   */
  editFusingChargesDetails: any;

  /**
   * Default Sorting Key
   */
  sortingKeyColumn = "fusingType";

  /**
   * Default Sort Order
   */
  sortingOrder = true;

  /**
   * Default Page Number
   */
  currentPage = 1;

  /**
   * Search Term
   */
  searchTerm = "";

  /**
   * Create PrintingCharges Form Declaration
   * @type {FormGroup}
   */
  createFusingChargeForm!: FormGroup;

  /**
   * Get PrintingCharges Form Validations
   */
  fusingChargesValidation = this.validationService?.createFusingCharges;

  /**
   * Get Patterns
   */
  fusingChargePattern = this.validationService?.patterns;

  /**
   * Creates an instance of FusingChargesComponent.
   * @param {ValidationService} validationService
   * @param {FormBuilder} formBuilder
   * @param {ChargesService} chargesService
   * @param {Location} location
   * @param {LoaderService} loaderService
   */
  constructor(
    private validationService: ValidationService,
    private formBuilder: FormBuilder,
    private chargesService: ChargesService,
    private location: Location,
    private loaderService: LoaderService,
  ) {
    if (localStorage.getItem('userTypeId') == '1' || localStorage.getItem('userTypeId') == '4') {
      this.isAdminOrManager = true;
    }
  }

  /**
   * Life Cycle Hook Initialization
   */
  ngOnInit(): void {
    this.getFusingTypes();
    this.createFusingChargeFormValidations();
    this.getFusingChargesList();
  }

  /**
   * Initialize Create Fusing Charges Form Validations
   */
  createFusingChargeFormValidations() {
    this.createFusingChargeForm = this.formBuilder.group({
      fusingTypeSelect: [
        this.editFusingChargesDetails?.fusingTypeId || "",
        [Validators.required],
      ],
      charge: [
        this.editFusingChargesDetails?.fusingCharge || "",
        [
          Validators.required,
          Validators.minLength(this.fusingChargesValidation.charge.minLength),
          Validators.maxLength(this.fusingChargesValidation.charge.maxLength),
          Validators.pattern(this.fusingChargePattern?.chargeInput)
        ]
      ]
    });
  }

  /**
   * Create fusingCharges Form Controls  Initialized
   * @readonly
   */
  get createFusingChargesFormControls() {
    return this.createFusingChargeForm.controls;
  }

  /**
   * This method is used to get fusing Types List
   */
  getFusingTypes() {
    this.chargesService.getFusingTypes().subscribe({
      next: (res: any) => {
        this.fusingTypesList = res?.result;
      },
      error: (err: any) => {
        this.fusingTypesList = [];
      },
    });
  }

  /**
   * This method is used to Get fusing Charges List
   */
  getFusingChargesList() {
    this.chargesService.getFusingCharges().subscribe({
      next: (res: any) => {
        this.fusingChargesList = res.result;
        this.fusingChargesRecordsCount = this.fusingChargesList.length;
      },
      error: (err: any) => {
        this.fusingChargesList = [];
        this.fusingChargesRecordsCount = 0;
      },
    });
  }

  /**
   * This method is used to reset fusing charges form
   */
  onClickReset() {
    this.createFusingChargeForm.reset();
    this.editFusingChargesDetails = "";
    this.updateFusingCharges = false;
    this.createFusingChargeFormValidations();
  }

  /**
   * This method will fired when user selects the fusing TYpe
   * @param {*} event
   */
  onChangeFusingType(event: any) {
    if (event?.target.value == '') {
      this.createFusingChargesFormControls['fusingTypeSelect'].markAsUntouched({ onlySelf: true });
    }
  }

  /**
   * This method is used to sort column
   * @param key : value of which column based we need to sort the rows
   */
  sort(key: string) {
    const componentName = this.location.path();
    let value = key;
    sessionStorage.setItem(`${componentName}_property`, value);
    this.sortingKeyColumn = key;
    if (sessionStorage.getItem(componentName + "_order") == "desc") {
      this.sortingOrder = false;
    } else {
      this.sortingOrder = true;
    }
  }

  /**
   * This method is used to show search results
   */
  navigateToSearchResult() {
    this.currentPage = 1;
  }

  /**
   * This method is used to change the pagination controls
   * @param {*} event
   */
  onPageChange(event: any) {
    this.currentPage = event;
  }

  /**
   * This method is used to get the fusing Charges details by Id
   * @param {*} fusingCharge
   */
  onClickEditFusingCharge(fusingCharge: any) {
    /* To call the service to get the edit fusing charges details by passing id */
    this.chargesService
      .geFusingChargesById(
        fusingCharge?.fusingChargesId
      )
      .subscribe({
        next: (res: any) => {
          this.editFusingChargesDetails = res?.result;
          this.updateFusingCharges = true;
          this.createFusingChargeFormValidations();
        },
        error: (err: any) => {
          this.editFusingChargesDetails = "";
          this.updateFusingCharges = false;
          this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
        },
      });
  }

  /**
   * This method is used to submit the fusing charges form
   * @return {*}
   */
  onSubmitFusingChargesForm(): any {
    /** This will return false if form fields are invalid and stop the service calling */
    if (this.createFusingChargeForm.invalid) {
      this.validationService.validateAllFormFields(this.createFusingChargeForm);
      return;
    }

    /* Prepare the request payload */
    const obj: any = {
      fusingTypeId: this.createFusingChargesFormControls['fusingTypeSelect'].value,
      fusingCharge: this.createFusingChargesFormControls["charge"]?.value?.toString(),
    };

    if (this.updateFusingCharges) {
      obj["fusingChargesId"] = this.editFusingChargesDetails?.fusingChargesId;
    }

    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    if (!this.updateFusingCharges) {
      this.chargesService.addFusingCharges(obj).subscribe({
        next: (res: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', '');
          this.getFusingChargesList();
          this.onClickReset();
        },
        error: (err: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
        },
      });
    } else {
      this.chargesService.editFusingCharges(obj).subscribe({
        next: (res: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', '');
          this.getFusingChargesList();
          this.onClickReset();
          this.updateFusingCharges = false;
        },
        error: (err: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
        }
      });
    }
  }
}
