import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FusingChargesComponent } from './fusing-charges.component';

describe('FusingChargesComponent', () => {
  let component: FusingChargesComponent;
  let fixture: ComponentFixture<FusingChargesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FusingChargesComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FusingChargesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
