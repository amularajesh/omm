import { Location } from "@angular/common";
import { Component, OnInit, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";

import { SnackbarModalComponent } from "src/app/core/Dialogues/snackbar-modal/snackbar-modal.component";
import { ChargesService } from "src/app/core/Services/charges.service";
import { LoaderService } from "src/app/core/Services/loader.service";
import { MastersService } from "src/app/core/Services/masters.service";
import { ValidationService } from "src/app/core/Services/validation.service";

/**
 * Stitching Charges Component
 * @export
 * @class StitchingChargesComponent
 * @implements {OnInit}
 */
@Component({
  selector: "app-stiching-charges",
  templateUrl: "./stiching-charges.component.html",
  styleUrls: ["./stiching-charges.component.scss"],
})
export class StichingChargesComponent implements OnInit {
  /**
   * Get Snackbar Modal Component
   * @type {SnackbarModalComponent}
   */
  @ViewChild("snackbarModalComponent") snackbarModalComponent!: SnackbarModalComponent;

  /**
   * Get Is Admin Or Manager Flag
   */
  isAdminOrManager = false;

  /**
   * Declaring sorting order variable
   */
  sortingOrder = true;

  /**
   * sorting order column key
   */
  sortingKeyColumn = "dressItem";

  /**
   * variable declare to hide abd show model and pocket type
   */
  ModelNo = false;
  pocketType = false;

  /**
   * variable to know edit active or not
   */
  updateStitchingCharges = false;

  /**
   * StitchingCharge vars
   * @type {*}
   */
  StitchingChargeDressItemId: any;
  StitchingChargeDressItemName = "";

  /**
   * StitchingCharge Patterns type  vars
   * @type {*}
   */
  StitchingChargePatternTypeId: any;
  StitchingChargePatternTypeName = "";

  /**
   * Records Count
   */
  recordsCount = 0;

  /**
   * StitchingChargesList
   */
  StitchingChargesList: any[] = [];

  /**
   * StitchingChargeDressItemsList
   */
  StitchingChargeDressItemsList: any[] = [];

  /**
   * StitchingChargePatternList
   */
  StitchingChargePatternList: any[] = [];

  /**
   * StitchingChargeModelNoList
   */
  StitchingChargeModelNoList: any[] = [];

  /**
   * StitchingChargePocketList
   */
  StitchingChargePocketList: any[] = [];

  /**
   * StitchingChargesData
   */
  StitchingChargesData: any;

  /**
   * Default Page Number
   */
  currentPage = 1;

  /**
   * Search Term
   */
  searchTerm = "";

  /**
   * Create StitchingCharges Form Declaration
   */
  createStitchingChargesForm!: FormGroup;

  /**
   * Get StitchingCharges Form Validations
   */
  StitchingChargesValidation = this.validationService.createStichingCharges;
  StitchingChargesPattern = this.validationService?.patterns;

  /**
   * Creates an instance of StitchingChargesComponent.
   * @param {ValidationService} validationService
   * @param {FormBuilder} formBuilder
   * @param {ChargesService} chargesService
   * @param {MastersService} mastersService
   * @param {Location} location
   * @param {LoaderService} loaderService
   */
  constructor(
    private validationService: ValidationService,
    private formBuilder: FormBuilder,
    private chargesService: ChargesService,
    private mastersService: MastersService,
    private location: Location,
    private loaderService: LoaderService,
  ) {
    if (localStorage.getItem('userTypeId') == '1' || localStorage.getItem('userTypeId') == '4') {
      this.isAdminOrManager = true;
    }
  }

  /**
   * Life Cycle Hook Initialization
   */
  ngOnInit(): void {
    this.createStitchingChargesFormValidations();
    this.getStitchingChargesDressItemsList();
    this.getStitchingChargesList();
  }

  /**
   * This method is used to get Stitching chargesList
   */
  getStitchingChargesList() {
    this.chargesService.getStitchingCharges().subscribe({
      next: (res: any) => {
        this.StitchingChargesList = res.result;
        this.recordsCount = this.StitchingChargesList.length;
      },
      error: (err: any) => {
        this.StitchingChargesList = [];
      },
    });
  }

  /**
   * This method is used to get StitchingChargesDressItems list
   */
  getStitchingChargesDressItemsList() {
    this.mastersService.getDressItems().subscribe({
      next: (res: any) => {
        this.StitchingChargeDressItemsList = res.result;
      },
      error: (err: any) => {
        this.StitchingChargeDressItemsList = [];
      },
    });
  }

  /**
   * This method used to reset StitchingCharges form
   */
  resetStitchingChargesForm() {
    this.StitchingChargesData = "";
    this.StitchingChargeModelNoList = [];
    this.StitchingChargePocketList = [];
    this.StitchingChargePatternList = [];
    this.createStitchingChargesForm.reset();
    this.createStitchingChargesFormValidations();

    this.updateStitchingCharges = false;
    this.ModelNo = false;
    this.pocketType = false;
  }

  /**
   * This method is used to update value and validity
   * @param {*} formControls
   */
  onUpdateValueAndValidity(formControls: any, controls: any) {
    controls?.forEach((control: any) => {
      formControls[control].setValue("");
      formControls[control].markAsUntouched({ onlySelf: true });
      formControls[control].updateValueAndValidity({ onlySelf: true });
    });
  }

  /**
   * Initialize Create StitchingCharges Validations
   */
  createStitchingChargesFormValidations() {
    this.createStitchingChargesForm = this.formBuilder.group({
      chargeInput: [
        this.StitchingChargesData?.stitchingRate || "",
        [
          Validators.required,
          Validators.minLength(
            this.StitchingChargesValidation.chargeInput.minLength
          ),
          Validators.maxLength(
            this.StitchingChargesValidation.chargeInput.maxLength
          ),
          Validators.pattern(this.StitchingChargesPattern?.chargeInput),
        ],
      ],

      DressItemSelect: [
        this.StitchingChargesData?.dressItemId || "",
        [Validators.required],
      ],

      PatternTypeSelect: [
        this.StitchingChargesData?.patterTypeId?.toString() || "",
        [Validators.required],
      ],
      ModelNo: [this.StitchingChargesData?.modelId || "", []],
      PocketType: [this.StitchingChargesData?.pocketTypeId?.toString() || "", []],
    });
  }

  /**
   * Create StitchingCharges Controls Initialized
   * @readonly
   */
  get createStitchingChargesFormControls() {
    return this.createStitchingChargesForm.controls;
  }

  /**
   * This method will fired when user selects the StitchingChargeDressItem
   * @param {*} event
   */
  StitchingChargeDressItemChange(event: any) {
    if (event.target) {
      this.StitchingChargesData = "";
    }
    this.StitchingChargeDressItemId = this.createStitchingChargesFormControls["DressItemSelect"]?.value;
    this.ModelNo = false;
    this.pocketType = false;
    this.StitchingChargePatternList = [];
    this.StitchingChargeModelNoList = [];
    this.StitchingChargePocketList = [];
    this.onUpdateValueAndValidity(this.createStitchingChargesFormControls, ["PatternTypeSelect", 'ModelNo', 'PocketType', 'chargeInput']);

    for (const element of this.StitchingChargeDressItemsList) {
      if (element.dressItemId === Number(this.StitchingChargeDressItemId)) {
        this.StitchingChargeDressItemName = element.dressItemName;
      }
    }
    let stitchingDressItemId = this.StitchingChargesData ? this.StitchingChargesData?.dressItemId : this.StitchingChargeDressItemId;
    this.getStitchingChargesPatternList(stitchingDressItemId);
    this.getStitchingChargesModelList(stitchingDressItemId);
    this.getStitchingChargesPocketList(stitchingDressItemId);

  }

  /**
   * This method is used to get StitchingChargesPatterns list
   * @param {*} dressItemId
   */
  getStitchingChargesPatternList(dressItemId: any) {
    this.chargesService.getStitchingPatternTypesByDressItemId(Number(dressItemId)).subscribe({
      next: (res: any) => {
        this.StitchingChargePatternList = res.result;
        if (this.StitchingChargesData?.patternType?.includes("Special")) {
          this.ModelNo = true;
          this.pocketType = false;
        } else if (this.createStitchingChargesFormControls["PatternTypeSelect"]?.value) {
          this.ModelNo = false;
          this.pocketType = true;
        }
      },
      error: (err: any) => {
        this.StitchingChargePatternList = [];
      },
    });
  }

  /**
   * This method is used to get StitchingChargesModel list
   * @param {*} dressItemId
   */
  getStitchingChargesModelList(dressItemId: any) {
    this.chargesService.getModelsByDressItemId(Number(dressItemId)).subscribe({
      next: (res: any) => {
        this.StitchingChargeModelNoList = res.result;
      },
      error: () => {
        this.StitchingChargeModelNoList = [];
        this.onUpdateValueAndValidity(this.createStitchingChargesFormControls, ['ModelNo']);
      },
    });
  }

  /**
   * This method is used to get StitchingChargesModel list
   * @param {*} dressItemId
   */
  getStitchingChargesPocketList(dressItemId: any) {
    this.chargesService.getPocketTypesByDressItemId(Number(dressItemId)).subscribe({
      next: (res: any) => {
        this.StitchingChargePocketList = res.result;
      },
      error: () => {
        this.StitchingChargePocketList = [];
        this.onUpdateValueAndValidity(this.createStitchingChargesFormControls, ['PocketType']);
      },
    });
  }

  /**
   * This method will fired when user selects the StitchingCharge Pattern Type
   * @param {*} event
   */
  StitchingChargePatternTypeChange(event: any) {
    this.StitchingChargePatternTypeId = this.createStitchingChargesFormControls["PatternTypeSelect"]?.value;

    for (const element of this.StitchingChargePatternList) {
      if (element.patternTypeId === Number(this.StitchingChargePatternTypeId)) {
        this.StitchingChargePatternTypeName = element.patternType;
      }

      const pocketTypePatternsList = ['Special Pattern', 'Normal'];
      if (!pocketTypePatternsList.includes(this.StitchingChargePatternTypeName)) {
        this.ModelNo = true;
        this.pocketType = false;
        this.createStitchingChargesForm.get("ModelNo")?.setValidators([Validators.required]);
        this.createStitchingChargesForm.get("ModelNo")?.updateValueAndValidity();
        this.createStitchingChargesForm.get("PocketType")?.setValidators(null);
        this.createStitchingChargesForm.get("PocketType")?.updateValueAndValidity();
      } else {
        this.ModelNo = false;
        if (this.StitchingChargeDressItemName?.toLowerCase() === 'pinofers') {
          this.pocketType = false;
          this.createStitchingChargesForm.get("PocketType")?.setValidators(null);
          this.createStitchingChargesForm.get("PocketType")?.updateValueAndValidity();
        } else {
          this.pocketType = true;
          this.createStitchingChargesForm.get("PocketType")?.setValidators([Validators.required]);
          this.createStitchingChargesForm.get("PocketType")?.updateValueAndValidity();
        }
        this.createStitchingChargesForm.get("ModelNo")?.setValidators(null);
        this.createStitchingChargesForm.get("ModelNo")?.updateValueAndValidity();
      }
    }
  }

  /**
   * This method is used edit StitchingCharges
   * @param {*} StitchingCharge
   */
  onClickEditStitchingCharges(StitchingCharge: any) {

    const StitchingChargesId = StitchingCharge.stitchingRateId;
    this.updateStitchingCharges = true;

    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    this.chargesService.getStitchingChargeById(StitchingChargesId).subscribe({
      next: (res: any) => {
        /* Disable the loader */
        this.loaderService.isLoading.next(false);

        this.StitchingChargesData = res.result;
        if (this.StitchingChargesData) {
          this.StitchingChargeDressItemChange(
            this.StitchingChargesData?.dressItemId
          );
        }
        this.createStitchingChargesFormValidations();
      },
      error: (err: any) => {
        /* Disable the loader */
        this.loaderService.isLoading.next(false);

        this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
      }
    });
  }

  /**
   * This method is used to change the pagination controls
   * @param {*} event
   */
  onPageChange(event: any) {
    this.currentPage = event;
  }

  /**
   * Create StitchingCharges Form Submit
   */
  onCreateStitchingChargesFormSubmit() {

    /** This will return false if form fields are invalid and stop the service calling */
    if (this.createStitchingChargesForm.invalid) {
      this.validationService.validateAllFormFields(
        this.createStitchingChargesForm
      );
      return;
    }

    const obj = {
      stitchingRateId: 0,
      dressItemId:
        Number(
          this.createStitchingChargesFormControls["DressItemSelect"]?.value
        ) || 0,
      patterTypeId:
        Number(
          this.createStitchingChargesFormControls["PatternTypeSelect"]?.value
        ) || 0,
      modelId:
        Number(this.createStitchingChargesFormControls["ModelNo"]?.value) || 0,
      pocketTypeId:
        Number(this.createStitchingChargesFormControls["PocketType"]?.value) ||
        0,
      stitchingRate:
        Number(this.createStitchingChargesFormControls["chargeInput"]?.value) ||
        0,
    };

    const updateStitchingChargesObj = {
      stitchingRateId: this.StitchingChargesData?.stitchingRateId || 0,
      dressItemId:
        Number(
          this.createStitchingChargesFormControls["DressItemSelect"]?.value
        ) || 0,
      patterTypeId:
        Number(
          this.createStitchingChargesFormControls["PatternTypeSelect"]?.value
        ) || 0,
      modelId:
        this.ModelNo === true
          ? Number(this.createStitchingChargesFormControls["ModelNo"]?.value) ||
          0
          : 0,
      pocketTypeId:
        Number(this.createStitchingChargesFormControls["PocketType"]?.value) ||
        0,
      stitchingRate:
        Number(this.createStitchingChargesFormControls["chargeInput"]?.value) ||
        0,
    };

    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    if (this.updateStitchingCharges === false) {
      this.chargesService.addStitchingCharges(obj).subscribe({
        next: (res: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', '');
          this.getStitchingChargesList();
          this.updateStitchingCharges = false;
          this.ModelNo = false;
          this.pocketType = false;

          this.resetStitchingChargesForm();
        },
        error: (err: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
        }
      });
    } else {
      this.chargesService.editStitchingCharges(updateStitchingChargesObj).subscribe({
        next: (res: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', '');
          this.getStitchingChargesList();
          this.updateStitchingCharges = false;
          this.ModelNo = false;
          this.pocketType = false;
          this.resetStitchingChargesForm();
        },
        error: (err: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
        }
      });
    }
  }

  /**
   * This method is used to show search results
   */
  navigateToSearchResult() {
    this.currentPage = 1;
  }

  /**
   * This method fired on model no change
   * @param {*} event
   */
  StitchingChargeModelChange(event: any) {
    this.createStitchingChargesForm.get("ModelNo")?.markAsTouched();
    this.createStitchingChargesForm.get("PocketType")?.setValidators(null);
    this.createStitchingChargesForm.get("ModelNo")?.updateValueAndValidity();
  }

  /**
   * This method fired on Pocket change
   * @param {*} event
   */
  PocketTypeChange(event: any) {
    this.createStitchingChargesForm.get("PocketType")?.markAsTouched();
    this.createStitchingChargesForm.get("ModelNo")?.setValidators(null);
    this.createStitchingChargesForm.get("PocketType")?.updateValueAndValidity();
  }

  /**
   * This method is used to sort column
   * @param key : value of which column based we need to sort the rows
   */
  sort(key: string) {
    const componentName = this.location.path();
    let value = key;
    sessionStorage.setItem(`${componentName}_property`, value);
    this.sortingKeyColumn = key;
    if (sessionStorage.getItem(componentName + "_order") == "desc") {
      this.sortingOrder = false;
    } else {
      this.sortingOrder = true;
    }
  }
}
