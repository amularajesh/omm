import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StichingChargesComponent } from './stiching-charges.component';

describe('StichingChargesComponent', () => {
  let component: StichingChargesComponent;
  let fixture: ComponentFixture<StichingChargesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StichingChargesComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(StichingChargesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
