import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { MatTooltipModule } from "@angular/material/tooltip";
import { Ng2SearchPipeModule } from "ng2-search-filter";
import { AutosizeModule } from "ngx-autosize";
import { NgxPaginationModule } from "ngx-pagination";

import { ComponentModule } from "src/app/core/Modules/component.module";
import { ChargesRoutingModule } from "./charges-routing.module";
import { ChargesComponent } from "./charges.component";
import { CollarKnittingChargesComponent } from "./collar-knitting-charges/collar-knitting-charges.component";
import { CuttingChargesComponent } from "./cutting-charges/cutting-charges.component";
import { PrintingEmbroideryFilmchargesComponent } from "./printing-embroidery-filmcharges/printing-embroidery-filmcharges.component";
import { StichingChargesComponent } from "./stiching-charges/stiching-charges.component";
import { TdsComponent } from "./tds/tds.component";
import { FusingChargesComponent } from './fusing-charges/fusing-charges.component';
import { SteamIronChargesComponent } from './steam-iron-charges/steam-iron-charges.component';

/**
 * Charges Module
 * @export
 * @class ChargesModule
 */
@NgModule({
  declarations: [
    ChargesComponent,
    StichingChargesComponent,
    CuttingChargesComponent,
    TdsComponent,
    CollarKnittingChargesComponent,
    PrintingEmbroideryFilmchargesComponent,
    FusingChargesComponent,
    SteamIronChargesComponent
  ],
  imports: [
    CommonModule,
    ChargesRoutingModule,
    NgxPaginationModule,
    Ng2SearchPipeModule,
    AutosizeModule,
    MatTooltipModule,
    ReactiveFormsModule,
    FormsModule,
    ComponentModule
  ],
})
export class ChargesModule { }
