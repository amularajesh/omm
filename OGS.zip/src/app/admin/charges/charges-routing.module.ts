import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";

import { ChargesComponent } from "./charges.component";
import { CollarKnittingChargesComponent } from "./collar-knitting-charges/collar-knitting-charges.component";
import { CuttingChargesComponent } from "./cutting-charges/cutting-charges.component";
import { PrintingEmbroideryFilmchargesComponent } from "./printing-embroidery-filmcharges/printing-embroidery-filmcharges.component";
import { StichingChargesComponent } from "./stiching-charges/stiching-charges.component";
import { TdsComponent } from "./tds/tds.component";
import { FusingChargesComponent } from "./fusing-charges/fusing-charges.component";
import { SteamIronChargesComponent } from "./steam-iron-charges/steam-iron-charges.component";

const routes: Routes = [
  {
    path: "",
    component: ChargesComponent,
    children: [
      { path: '', redirectTo: `${localStorage.getItem('chargesModule')}`, pathMatch: 'full' },
      { path: "collarknittingcharges", component: CollarKnittingChargesComponent },
      { path: "cuttingcharges", component: CuttingChargesComponent },
      { path: "tds", component: TdsComponent },
      { path: "stichingcharges", component: StichingChargesComponent },
      { path: "printingembroideryfilmcharges", component: PrintingEmbroideryFilmchargesComponent },
      { path: "fusingcharges", component: FusingChargesComponent },
      { path: "steamironcharges", component: SteamIronChargesComponent },


    ]
  }
];

/**
 * Charges Routing Module
 * @export
 * @class ChargesRoutingModule
 */
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ChargesRoutingModule { }
