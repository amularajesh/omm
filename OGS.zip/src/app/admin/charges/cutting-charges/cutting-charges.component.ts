import { Location } from "@angular/common";
import { Component, OnInit, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";

import { SnackbarModalComponent } from "src/app/core/Dialogues/snackbar-modal/snackbar-modal.component";
import { ChargesService } from "src/app/core/Services/charges.service";
import { LoaderService } from "src/app/core/Services/loader.service";
import { MastersService } from "src/app/core/Services/masters.service";
import { ValidationService } from "src/app/core/Services/validation.service";

/**
 * Cutting Charges Component
 * @export
 * @class CuttingChargesComponent
 * @implements {OnInit}
 */
@Component({
  selector: "app-cutting-charges",
  templateUrl: "./cutting-charges.component.html",
  styleUrls: ["./cutting-charges.component.scss"],
})
export class CuttingChargesComponent implements OnInit {
  /**
   * Get Snackbar Modal Component
   * @type {SnackbarModalComponent}
   */
  @ViewChild("snackbarModalComponent") snackbarModalComponent!: SnackbarModalComponent;

  /**
   * Get Is Admin Or Manager Flag
   */
  isAdminOrManager = false;

  /**
   * Default sorting order variable declare
   */
  sortingOrder = true;

  /**
   * Sorting order column key
   */
  sortingKeyColumn = "dressItem";

  /**
   * variable declare to hide abd show model input
   */
  ModelNo = false;

  /**
   * variable to know edit active or not
   */
  updateCuttingCharges = false;

  /**
   * Cutting Charge vars
   * @type {*}
   */
  CuttingChargeDressItemId: any;

  CuttingChargeDressItemName = "";

  /**
   * CuttingCharge Patterns type  vars
   * @type {*}
   */
  CuttingChargePatternTypeId: any;

  CuttingChargePatternTypeName = "";

  /**
   * Records Count
   */
  recordsCount = 0;

  /**
   * Get Cutting Charges List
   */
  CuttingChargesList: any[] = [];

  /**
   * CuttingChargeDressItemsList
   */
  CuttingChargeDressItemsList: any[] = [];

  /**
   * CuttingChargePatternList
   */
  CuttingChargePatternList: any[] = [];
  /**
   * CuttingChargeModelsList
   */
  CuttingChargeModelsList: any[] = [];

  /**
   * CuttingChargesData
   */
  CuttingChargesData: any;

  /**
   * Default Page Number
   */
  currentPage = 1;

  /**
   * Search Term
   */
  searchTerm = "";

  /**
   * Create CuttingCharges Form Declaration
   */
  createCuttingChargesForm!: FormGroup;

  /**
   * Get CuttingCharges Form Validations
   */
  CuttingChargesValidation = this.validationService.createCuttingCharges;
  CuttingChargesPatterns = this.validationService.patterns;

  /**
   * Creates an instance of CuttingChargesComponent.
   * @param {LoaderService} loaderService
   * @param {ValidationService} validationService
   * @param {FormBuilder} formBuilder
   * @param {ChargesService} chargesService
   * @param {MastersService} mastersService
   * @param {Location} location
   */
  constructor(
    private loaderService: LoaderService,
    private validationService: ValidationService,
    private formBuilder: FormBuilder,
    private chargesService: ChargesService,
    private mastersService: MastersService,
    private location: Location
  ) {
    if (localStorage.getItem('userTypeId') == '1' || localStorage.getItem('userTypeId') == '4') {
      this.isAdminOrManager = true;
    }
  }

  /**
   * Life Cycle Hook Initialization
   */
  ngOnInit(): void {
    this.createCuttingChargesFormValidations();
    this.getCuttingChargesDressItemsList();
    this.getCuttingChargesList();
  }

  /**
   * This method is used to getCuttingChargesList
   */
  getCuttingChargesList() {
    this.chargesService.getCuttingCharges().subscribe({
      next: (res: any) => {
        this.CuttingChargesList = res.result;
        this.recordsCount = this.CuttingChargesList.length;
      },
      error: (err: any) => {
        this.CuttingChargesList = [];
        this.recordsCount = 0;
      },
    });
  }

  /**
   * This method is used to get CuttingChargesDressItems list
   */
  getCuttingChargesDressItemsList() {
    this.mastersService.getDressItems().subscribe({
      next: (res: any) => {
        this.CuttingChargeDressItemsList = res.result;
      },
      error: (err: any) => {
        this.CuttingChargeDressItemsList = [];
      },
    });
  }

  /**
   * This method used to reset CuttingCharges form
   */
  resetCuttingChargesForm() {
    this.createCuttingChargesForm.reset();
    this.createCuttingChargesFormValidations();
    this.createCuttingChargesFormControls["chargeInput"]?.setValue("");
    this.createCuttingChargesFormControls["DressItemSelect"]?.setValue("");
    this.createCuttingChargesFormControls["PatternTypeSelect"]?.setValue("");
    this.createCuttingChargesFormControls["ModelNo"]?.setValue("");

    this.updateCuttingCharges = false;
    this.ModelNo = false;
  }

  /**
   * Initialize Create CuttingCharges Validations
   */

  createCuttingChargesFormValidations() {
    this.createCuttingChargesForm = this.formBuilder.group({
      chargeInput: [
        this.CuttingChargesData?.cuttingRate || "",
        [
          Validators.required,
          Validators.minLength(
            this.CuttingChargesValidation.chargeInput.minLength
          ),
          Validators.maxLength(
            this.CuttingChargesValidation.chargeInput.maxLength
          ),
          Validators.pattern(this.CuttingChargesPatterns?.chargeInput),
        ],
      ],

      DressItemSelect: [
        this.CuttingChargesData?.dressItemId || "",
        [Validators.required],
      ],

      PatternTypeSelect: [
        this.CuttingChargesData?.patterTypeId || "",
        [Validators.required],
      ],
      ModelNo: [this.CuttingChargesData?.modelId || "", []],
    });
  }

  /**
   * Create CuttingCharges Controls Initialized
   * @readonly
   */
  get createCuttingChargesFormControls() {
    return this.createCuttingChargesForm.controls;
  }

  /**
   * This method will fired when user selects the CuttingChargeDressItem
   * @param {*} event
   */
  CuttingChargeDressItemChange(event: any) {
    if (event.target) {
      this.CuttingChargesData = "";
    }
    this.CuttingChargeDressItemId = this.createCuttingChargesFormControls[
      "DressItemSelect"
    ]?.value;

    for (const element of this.CuttingChargeDressItemsList) {
      if (element.dressItemId === Number(this.CuttingChargeDressItemId)) {
        this.CuttingChargeDressItemName = element.CuttingChargeDressItemName;
      }
    }
    this.updateCuttingCharges = false;
    this.ModelNo = false;
    this.CuttingChargePatternList = [];
    this.createCuttingChargesFormControls["PatternTypeSelect"].setValue("");
    this.createCuttingChargesFormControls["PatternTypeSelect"].markAsUntouched({
      onlySelf: true,
    });

    this.CuttingChargeModelsList = [];
    this.createCuttingChargesFormControls["ModelNo"].setValue("");
    this.createCuttingChargesFormControls["ModelNo"].markAsUntouched({
      onlySelf: true,
    });

    this.createCuttingChargesFormControls["chargeInput"].setValue("");
    this.createCuttingChargesFormControls["chargeInput"].markAsUntouched({
      onlySelf: true,
    });
    if (this.CuttingChargesData) {
      this.getCuttingChargesPatternList(this.CuttingChargesData?.dressItemId);
      this.getCuttingChargesModelNoList(this.CuttingChargesData?.dressItemId);
    } else {
      this.getCuttingChargesPatternList(this.CuttingChargeDressItemId);
      this.getCuttingChargesModelNoList(this.CuttingChargeDressItemId);
    }
  }

  /**
   * This method is used to get CuttingChargesPatterns list
   */
  getCuttingChargesPatternList(dressItemId: any) {
    this.chargesService.getCuttingPatternTypesByDressItemId(Number(dressItemId)).subscribe({
      next: (res: any) => {
        this.CuttingChargePatternList = res.result;
        if (this.CuttingChargesData) {
          this.updateCuttingCharges = true;
          this.createCuttingChargesFormControls["PatternTypeSelect"].setValue(this.CuttingChargesData?.patterTypeId);
          if (this.CuttingChargesData.patternType.includes("Special")) {
            this.ModelNo = true;
          } else {
            this.ModelNo = false;
          }
        }
      },
      error: (err: any) => {
        this.CuttingChargePatternList = [];
      }
    });
  }

  /**
   * This method is used to get CuttingChargesPatterns list
   */
  getCuttingChargesModelNoList(dressItemId: any) {
    this.chargesService.getModelsByDressItemId(Number(dressItemId)).subscribe({
      next: (res: any) => {
        this.CuttingChargeModelsList = res.result;
        if (this.CuttingChargesData) {
          this.createCuttingChargesFormControls["ModelNo"].setValue(this.CuttingChargesData?.modelId);
        }
      },
      error: (err: any) => {
        this.CuttingChargeModelsList = [];
      }
    });
  }

  /**
   * This method will fired when user selects the CuttingCharge Pattern Type
   * @param {*} event
   */
  CuttingChargePatternTypeChange(event: any) {
    this.CuttingChargePatternTypeId = this.createCuttingChargesFormControls["PatternTypeSelect"]?.value;

    this.createCuttingChargesFormControls["ModelNo"].setValue("");
    this.createCuttingChargesFormControls["ModelNo"].markAsUntouched({
      onlySelf: true,
    });

    for (const element of this.CuttingChargePatternList) {
      console.log(
        element.patternTypeId === Number(this.CuttingChargePatternTypeId)
      );
      console.log(element);

      if (element.patternTypeId === Number(this.CuttingChargePatternTypeId)) {
        this.CuttingChargePatternTypeName = element.patternType;
        if (this.CuttingChargePatternTypeName.includes('Special')) {
          this.ModelNo = true;
          this.createCuttingChargesForm
            .get("ModelNo")
            ?.setValidators([
              Validators.required,
              Validators.minLength(
                this.CuttingChargesValidation.ModelNo.minLength
              ),
              Validators.maxLength(
                this.CuttingChargesValidation.ModelNo.maxLength
              ),
            ]);
          this.createCuttingChargesForm
            .get("ModelNo")
            ?.updateValueAndValidity();
        } else {
          this.ModelNo = false;
          this.createCuttingChargesForm.get("ModelNo")?.setValidators(null);
          this.createCuttingChargesForm
            .get("ModelNo")
            ?.updateValueAndValidity();
        }
        // // Update the form control
        // this.createCuttingChargesForm.get("ModelNo")?.updateValueAndValidity();
      }
    }
  }

  /**
   * This method is used edit CuttingCharges
   */
  onClickEditCuttingCharges(CuttingCharge: any) {
    const CuttingChargesId = CuttingCharge.cuttingRateId;

    this.updateCuttingCharges = true;
    this.chargesService.getCuttingChargeById(CuttingChargesId).subscribe({
      next: (res: any) => {
        this.CuttingChargesData = res.result;

        if (this.CuttingChargesData) {
          this.CuttingChargeDressItemChange(
            this.CuttingChargesData?.dressItemId
          );
        }
        this.createCuttingChargesFormValidations();
      },
      error: (err: any) => {
        this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
      }
    });
  }

  /**
   * This method is used to change the pagination controls
   * @param {*} event
   */
  onPageChange(event: any) {
    this.currentPage = event;
  }

  /**
   * Create CuttingCharges Form Submit
   */
  onCreateCuttingChargesFormSubmit() {
    /** This will return false if form fields are invalid and stop the service calling */
    if (this.createCuttingChargesForm.invalid) {
      this.validationService.validateAllFormFields(this.createCuttingChargesForm);
      return;
    }

    const obj = {
      cuttingRateId: 0,
      dressItemId: Number(this.createCuttingChargesFormControls["DressItemSelect"]?.value) || 0,
      patterTypeId: Number(this.createCuttingChargesFormControls["PatternTypeSelect"]?.value) || 0,
      modelId: Number(this.createCuttingChargesFormControls["ModelNo"]?.value) || 0,
      cuttingRate: Number(this.createCuttingChargesFormControls["chargeInput"]?.value) || 0,
    };

    const updateCuttingChargesObj = {
      cuttingRateId: this.CuttingChargesData?.cuttingRateId || 0,
      dressItemId: Number(this.createCuttingChargesFormControls["DressItemSelect"]?.value) || 0,
      patterTypeId: Number(this.createCuttingChargesFormControls["PatternTypeSelect"]?.value) || 0,
      modelId: this.ModelNo === true ? Number(this.createCuttingChargesFormControls["ModelNo"]?.value) || 0 : 0,
      cuttingRate: Number(this.createCuttingChargesFormControls["chargeInput"]?.value) || 0,
    };

    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    if (this.updateCuttingCharges == false) {
      this.chargesService.addCuttingCharges(obj).subscribe({
        next: (res: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', '');
          this.getCuttingChargesList();
          this.updateCuttingCharges = false;
          this.resetCuttingChargesForm();
        },
        error: (err: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
        }
      });
    } else {
      this.chargesService.editCuttingCharges(updateCuttingChargesObj).subscribe({
        next: (res: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', '');
          this.getCuttingChargesList();
          this.updateCuttingCharges = false;
          this.resetCuttingChargesForm();
        },
        error: (err: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
        }
      });
    }
  }

  /**
   * This method is used to show search results
   */
  navigateToSearchResult() {
    this.currentPage = 1;
  }

  /**
   * Method is fired on change of model no
   * @param {*} event
   */
  CuttingChargeModelChange(event: any) {
    if (this.createCuttingChargesFormControls["ModelNo"]?.value != "") {
      this.createCuttingChargesForm.get("ModelNo")?.markAsTouched();
      this.createCuttingChargesForm.get("ModelNo")?.setValidators(null);
      this.createCuttingChargesForm.get("ModelNo")?.updateValueAndValidity();
    }
  }

  /**
   * This method is used to sort column
   * @param key : value of which column based we need to sort the rows
   */
  sort(key: string) {
    const componentName = this.location.path();
    let value = key;
    sessionStorage.setItem(`${componentName}_property`, value);
    this.sortingKeyColumn = key;
    if (sessionStorage.getItem(componentName + "_order") == "desc") {
      this.sortingOrder = false;
    } else {
      this.sortingOrder = true;
    }
  }
}
