import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CuttingChargesComponent } from './cutting-charges.component';

describe('CuttingChargesComponent', () => {
  let component: CuttingChargesComponent;
  let fixture: ComponentFixture<CuttingChargesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CuttingChargesComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CuttingChargesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
