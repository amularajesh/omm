import { Component, OnInit } from '@angular/core';

/**
 * Charges Component
 * @export
 * @class ChargesComponent
 * @implements {OnInit}
 */
@Component({
  selector: 'app-charges',
  templateUrl: './charges.component.html',
  styleUrls: ['./charges.component.scss']
})
export class ChargesComponent implements OnInit {
  /**
   * Creates an instance of ChargesComponent.
   */
  constructor() { }

  /**
   * Life Cycle Hook Initialization
   */
  ngOnInit(): void { }
}
