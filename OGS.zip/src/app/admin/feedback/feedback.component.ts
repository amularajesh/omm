import { Component, OnInit } from '@angular/core';

/**
 * Feedback Component
 * @export
 * @class FeedbackComponent
 * @implements {OnInit}
 */
@Component({
  selector: 'app-feedback',
  templateUrl: './feedback.component.html',
  styleUrls: ['./feedback.component.scss']
})
export class FeedbackComponent implements OnInit {
  /**
   * Creates an instance of FeedbackComponent.
   */
  constructor() { }

  /**
   * Life Cycle Hook Initialization
   */
  ngOnInit(): void { }
}
