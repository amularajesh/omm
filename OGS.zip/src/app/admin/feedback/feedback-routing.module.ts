import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";

import { FeedbackComponent } from "./feedback.component";

const routes: Routes = [
  {
    path: "",
    component: FeedbackComponent,
    children: [
      { path: '', redirectTo: `${localStorage.getItem('feedbackModule')}`, pathMatch: 'full' },
      { path: "", component: FeedbackComponent, pathMatch: "full" },
      {
        path: "customerFeedback",
        loadChildren: () => import("./feed-back/feed-back.module").then((m) => m.feedBackModule)
      },
    ]
  }
];

/**
 * Feedback Routing Module
 * @export
 * @class FeedbackRoutingModule
 */
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class FeedbackRoutingModule { }
