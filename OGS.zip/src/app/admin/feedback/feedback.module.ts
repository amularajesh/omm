import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';


import { FeedBackComponent } from './feed-back/feed-back.component';
import { FeedbackRoutingModule } from './feedback-routing.module';
import { FeedbackComponent } from './feedback.component';

/**
 * Feedback Module
 * @export
 * @class FeedbackModule
 */
@NgModule({
  declarations: [
    FeedbackComponent,
    FeedBackComponent,
  
  ],
  imports: [
    CommonModule,
    FeedbackRoutingModule
  ]
})
export class FeedbackModule { }
