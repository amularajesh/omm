import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

import { SnackbarModalComponent } from 'src/app/core/Dialogues/snackbar-modal/snackbar-modal.component';
import { CustomersService } from 'src/app/core/Services/customers.service';
import { LoaderService } from 'src/app/core/Services/loader.service';
import { MastersService } from 'src/app/core/Services/masters.service';
import { ValidationService } from 'src/app/core/Services/validation.service';

/**
 * Add FeedBack Component
 * @export
 * @class AddFeedBackComponent
 * @implements {OnInit}
 */
@Component({
  selector: 'app-add-feed-back',
  templateUrl: './add-feed-back.component.html',
  styleUrls: ['./add-feed-back.component.scss']
})
export class AddFeedBackComponent implements OnInit {
  /**
   * Get Snackbar Modal Component
   * @type {SnackbarModalComponent}
   */
  @ViewChild("snackbarModalComponent") snackbarModalComponent!: SnackbarModalComponent;

  /**
   *Get Order List
   *
   * @type {any[]}
   * @memberof AddFeedBackComponent
   */
  OrderNoList: any[] = [];

  /**
   * Dropdown settings for Order List
   */
  dropdownSettingsForOrderList = {
    idField: 'orderId',
    textField: 'orderNo',
    // itemsShowLimit: 2,
    allowSearchFilter: true,
    clearSearchFilter: true,
    enableCheckAll: false,
    defaultOpen: false,
  };

  /**
   * Selected OrderNos
   * @type {*}
   */
  selectedOrderNos: any = [];

  /**
  * Get Dress Items List
  * @type {*}
  */
  organizationTypesList: any = [];

  /**
   * Get States List
   * @type {*}
   */
  statesList: any;

  /**
   * Get Districts List
   * @type {*}
   */
  districtsList: any;

  /**
   * Get Mandals List
   * @type {*}
   */
  mandalsList: any;

  /**
   * Get Towns list
   * @type {*}
   */
  townsList: any;

  /**
   * Get schools list
   * @type {any[]}
   */
  SchoolList: any[] = [];

  /**
   * Get Satisfied Radio Value
   */
  satisfied = '';

  /**
   * Get financial years List
   * @type {*}
   */
  financialYearsList: any;

  /**
   * Creates an instance of AddFeedBackComponent.
   * @param {Router} router
   * @param {FormBuilder} formBuilder
   * @param {ValidationService} validationService
   * @param {MastersService} mastersService
   * @param {CustomersService} customerService
   * @param {LoaderService} loaderService
   */
  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private validationService: ValidationService,
    private mastersService: MastersService,
    private customerService: CustomersService,
    private loaderService: LoaderService,
  ) { }

  /**
   * Declaring feed back search Form
   * @type {FormGroup}
   */
  addFeedBackForm!: FormGroup;

  /**
   * Get feedback Form Validations
   */
  addFeedBackValidation = this.validationService?.addFeedback;
  addFeedBackValidationPattern = this.validationService?.patterns;

  /**
   * Get Location Validations
   */
  locationValidation = this.validationService.locationSelect;

  /**
   * Life Cycle Hook Initialization
   */
  ngOnInit(): void {
    this.addFeedBackFormValidation();
    this.getStates();
    this.getFinancialYears();
  }

  /**
   * This method for initialize form validations
   */
  addFeedBackFormValidation() {
    this.addFeedBackForm = this.formBuilder.group({
      stateSelect: ['', [Validators.required]],
      districtSelect: ['', [Validators.required]],
      mandalSelect: ['', [Validators.required]],
      townSelect: ['', [Validators.required]],
      financialYear: ["", [Validators.required]],
      organizationSelect: ['', [Validators.required]],
      OrderNo: ['', [Validators.required]],
      FeedBack: [
        '',
        [
          Validators.required,
          Validators.minLength(this.addFeedBackValidation?.FeedBack.minLength),
          Validators.maxLength(this.addFeedBackValidation?.FeedBack.maxLength),
        ],
      ],
      PhoneNo: [
        '',
        [
          Validators.minLength(this.addFeedBackValidation?.PhoneNo.minLength),
          Validators.maxLength(this.addFeedBackValidation?.PhoneNo.maxLength),
          Validators.pattern(this.addFeedBackValidationPattern?.mobileNo),
        ]
      ],
      satisfied: ['', Validators.required],
    });
  }

  /**
   * feedback Controls Initialized
   * @readonly
   */
  get addFeedBackFormControls() {
    return this.addFeedBackForm.controls;
  }

  /**
   * This method fired on click of reset
   */
  reset() {
    this.districtsList = [];
    this.mandalsList = [];
    this.townsList = [];
    this.SchoolList = [];
    this.OrderNoList = [];
    this.satisfied = '';
    this.addFeedBackForm.reset();
    this.addFeedBackFormValidation();
  }

  /**
   * This method is used to update value and validity
   * @param {*} formControls
   */
  onUpdateValueAndValidity(formControls: any, controls: any) {
    controls?.forEach((control: any) => {
      formControls[control].setValue("");
      formControls[control].markAsUntouched({ onlySelf: true });
      formControls[control].updateValueAndValidity({ onlySelf: true });
    });
  }

  /**
   * This method is used to get the financial years list
   */
  getFinancialYears() {
    this.customerService.GetFinancialYears().subscribe({
      next: (res: any) => {
        this.financialYearsList = res.result;
      },
      error: () => {
        this.financialYearsList = [];
      }
    });
  }

  /**
   * This method is used to get states list
   */
  getStates() {
    this.mastersService.getStates().subscribe({
      next: (res: any) => {
        this.statesList = res.result;
      },
      error: () => {
        this.statesList = [];
      }
    });
  }

  /**
   * This Method Used To Navigate feedback list page.
   */
  navigate() {
    this.router.navigate(['/admin/feedback/customerFeedback/feedbacklist']);
  }

  /**
   * This method will fired when user selects the OrderNo
   * @param {*} item
   */
  onOrderSelect(item: any) {
    this.selectedOrderNos.push(item);
    this.selectedOrderNos = Array.from(
      this.selectedOrderNos
        .reduce((m: any, t: any) => m.set(t.orderId, t), new Map())
        .values()
    );
  }

  /**
   * This method will fired when user de-selects the OrderNo
   * @param {*} item
   */
  onOrderDeSelect(item: any) {
    for (let index = 0; index < this.selectedOrderNos.length; index++) {
      if (this.selectedOrderNos[index].orderId == item.orderId) {
        this.selectedOrderNos.splice(index, 1); // 2nd parameter means remove one item only
      }
    }
  }

  /**
   * This method will fired when user selects state
   * @param {*} event
   */
  onChangeState(event: any) {
    this.onUpdateValueAndValidity(this.addFeedBackFormControls,
      ['districtSelect', 'mandalSelect', 'townSelect', 'organizationSelect', 'OrderNo', 'PhoneNo']);
    this.districtsList = [];
    this.mandalsList = [];
    this.townsList = [];
    this.SchoolList = [];
    this.OrderNoList = [];
    if (event?.target?.value == '') {
      this.addFeedBackFormControls['stateSelect'].markAsUntouched({ onlySelf: true });
      return;
    }

    /* To call the service to get the districts details by passing stateId */
    this.mastersService.getDistrictsByStateId(event?.target?.value).subscribe({
      next: (res: any) => {
        this.districtsList = res.result;
      },
      error: () => {
        this.districtsList = [];
      }
    });
  }

  /**
   * This method will fired when user selects  district
   * @param {*} event
   */
  onChangeDistrict(event: any) {
    this.onUpdateValueAndValidity(this.addFeedBackFormControls, ['mandalSelect', 'townSelect', 'organizationSelect', 'OrderNo', 'PhoneNo']);
    this.mandalsList = [];
    this.townsList = [];
    this.SchoolList = [];
    this.OrderNoList = [];
    if (event?.target?.value == '') {
      this.addFeedBackFormControls['districtSelect'].markAsUntouched({ onlySelf: true });
      return;
    }

    /* To call the service to get the mandals details by passing districtId */
    this.mastersService.getMandalsByDistrictId(event?.target?.value).subscribe({
      next: (res: any) => {
        this.mandalsList = res.result;
      },
      error: () => {
        this.mandalsList = [];
      }
    });
  }

  /**
   * This method will fired when user selects mandal
   * @param {*} event
   */
  onChangeMandal(event: any) {
    this.onUpdateValueAndValidity(this.addFeedBackFormControls, ['townSelect', 'organizationSelect', 'OrderNo', 'PhoneNo']);
    this.townsList = [];
    this.SchoolList = [];
    this.OrderNoList = [];
    if (event?.target?.value == '') {
      this.addFeedBackFormControls['mandalSelect'].markAsUntouched({ onlySelf: true });
      return;
    }

    /* To call the service to get the town details by passing mandalId */
    this.mastersService.getTownsByMandalId(event?.target?.value).subscribe({
      next: (res: any) => {
        this.townsList = res.result;
      },
      error: () => {
        this.townsList = [];
      }
    });
  }

  /**
   * This method will fired when user selects town
   * @param {*} event
   */
  onChangeTown(event: any) {
    this.onUpdateValueAndValidity(this.addFeedBackFormControls, ['organizationSelect', 'OrderNo', 'PhoneNo']);
    this.SchoolList = [];
    this.OrderNoList = [];
    if (event?.target?.value == '') {
      this.addFeedBackFormControls['townSelect'].markAsUntouched({ onlySelf: true });
      return;
    }

    /* To call the service to get the organization details by passing townId */
    this.customerService.getOrganizationByTownId(event?.target?.value).subscribe({
      next: (res: any) => {
        this.SchoolList = res.result;
      },
      error: () => {
        this.SchoolList = [];
      }
    });
  }

  /**
   * This method will fired when user selects financial year
   * @param {*} event
   */
  onChangeFinancialYear(event: any) {
    this.onUpdateValueAndValidity(this.addFeedBackFormControls, ["organizationSelect", "OrderNo", 'PhoneNo']);
    this.OrderNoList = [];
    if (event?.target?.value == '') {
      this.addFeedBackFormControls["financialYear"].markAsUntouched({ onlySelf: true });
    }
  }

  /**
   * This method will fired when user selects organization
   * @param {*} event
   */
  onChangeOrganization(event: any) {
    this.OrderNoList = [];
    this.onUpdateValueAndValidity(this.addFeedBackFormControls, ["OrderNo", 'PhoneNo']);

    if (!this.addFeedBackFormControls['financialYear'].value) {
      this.onUpdateValueAndValidity(this.addFeedBackFormControls, ["organizationSelect"]);
      this.snackbarModalComponent.onOpenSnackbarModal(false, "Please Select Financial Year", '', '', '');
      return;
    }

    this.customerService.getOrderNo(+event.target?.value, this.addFeedBackFormControls['financialYear'].value).subscribe({
      next: (res: any) => {
        this.OrderNoList = res.result?.orderNos;
        this.addFeedBackFormControls['PhoneNo'].setValue(res.result?.phoneNo);
      },
      error: () => {
        this.OrderNoList = [];
        this.addFeedBackFormControls['PhoneNo'].setValue('');
      }
    });
  }

  /**
   * This method is used to change the radio 
   * @param {*} event
   */
  radioChange(event: any) {
    this.satisfied = event.target.value;
    this.addFeedBackFormControls['satisfied'].markAsTouched({ onlySelf: true });
  }

  /**
   * This method fired on click Add button
   */
  Submit() {
    /** This will return false if form fields are invalid and stop the service calling */
    if (this.addFeedBackForm.invalid) {
      this.validationService.validateAllFormFields(this.addFeedBackForm);
      if (this.addFeedBackFormControls['satisfied']?.value == '') {
        this.snackbarModalComponent.onOpenSnackbarModal(false, "Please Select Satisfied Option", '', '', '');
        return;
      }
      return;
    }

    if (this.selectedOrderNos.length > 10) {
      this.snackbarModalComponent.onOpenSnackbarModal(false, "Please Select upto 10 Order No's.", '', '', '');
      return;
    }
    const orderList = [];
    for (const item of this.selectedOrderNos) {
      orderList.push(item?.orderId);
    }

    /* Prepare the request payload */
    const finalObj = {
      feedbackId: 0,
      feedback: this.addFeedBackFormControls['FeedBack']?.value,
      schoolId: +this.addFeedBackFormControls['organizationSelect']?.value || 0,
      orderId: 0,
      orderNo: 0,
      userId: 0,
      isSatisfy: this.satisfied === '0',
      phoneNo: this.addFeedBackFormControls['PhoneNo']?.value || '',
      state: this.addFeedBackFormControls['stateSelect']?.value || '',
      district: this.addFeedBackFormControls['districtSelect']?.value || '',
      mandal: this.addFeedBackFormControls['mandalSelect']?.value || '',
      town: this.addFeedBackFormControls['townSelect']?.value || '',
      orderList: orderList,
    };

    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    this.customerService.AddFeedBack(finalObj).subscribe({
      next: (res: any) => {
        /* Disable the loader */
        this.loaderService.isLoading.next(false);

        this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', 'add-feedback');
      },
      error: (err: any) => {
        /* Disable the loader */
        this.loaderService.isLoading.next(false);

        this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
      }
    });
  }
}
