import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-feed-back',
  templateUrl: './edit-feed-back.component.html',
  styleUrls: ['./edit-feed-back.component.scss']
})
export class EditFeedBackComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
