import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { FeedBackComponent } from "./feed-back.component";
import { AddFeedBackComponent } from "./add-feed-back/add-feed-back.component";
import { EditFeedBackComponent } from "./edit-feed-back/edit-feed-back.component";
import { FeedbacklistComponent } from "./feedbacklist/feedbacklist.component";

const routes: Routes = [
  {
    path: "",
    component: FeedBackComponent,
    children: [
      { path: "", redirectTo: "feedbacklist", pathMatch: "full" },
      {
        path: "addfeedback",
        component: AddFeedBackComponent,
      },
      {
        path: "editfeedback",
        component: EditFeedBackComponent,
      },
      {
        path: "feedbacklist",
        component: FeedbacklistComponent,
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class feedBackRoutingModule {}
