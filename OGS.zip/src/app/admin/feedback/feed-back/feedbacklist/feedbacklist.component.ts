import { DatePipe, Location } from "@angular/common";
import { Component, OnInit, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup } from "@angular/forms";
import { MatDialog, MatDialogConfig } from "@angular/material/dialog";
import { Router } from "@angular/router";

import { ModalComponent } from "src/app/core/Dialogues/Modal/modal.component";
import { SnackbarModalComponent } from "src/app/core/Dialogues/snackbar-modal/snackbar-modal.component";
import { CustomersService } from "src/app/core/Services/customers.service";
import { LoaderService } from "src/app/core/Services/loader.service";
import { MastersService } from "src/app/core/Services/masters.service";
import { ValidationService } from "src/app/core/Services/validation.service";

@Component({
  selector: "app-feedbacklist",
  templateUrl: "./feedbacklist.component.html",
  styleUrls: ["./feedbacklist.component.scss"],
})
export class FeedbacklistComponent implements OnInit {
  /**
   * Get Snackbar Modal Component
   * @type {SnackbarModalComponent}
   */
  @ViewChild("snackbarModalComponent") snackbarModalComponent!: SnackbarModalComponent;

  /**
   * Declare Sorting Key Column
   */
  sortingKeyColumn = "schoolName";

  /**
   * Declare Sorting Order Flag
   */
  sortingOrder = false;

  /**
   * Records Count
   */
  recordsCount = 0;

  /**
   * Default Page Number
   */
  currentPage = 1;

  /**
   * Search Term
   */
  searchTerm = "";

  /**
  * Get Feedback List
  * @type {*}
  */
  feedbackList: any[] = [];

  /**
   * Get Order List
   * @type {any[]}
   */
  orderNosList: any[] = [];

  /**
   * Get States List
   * @type {*}
   */
  statesList: any;

  /**
   * Get Districts List
   */
  districtsList: any;

  /**
   * Get Mandals List
   * @type {*}
   */
  mandalsList: any;

  /**
   * Get Towns List
   * @type {*}
   */
  townsList: any;

  /**
   * Get Organizations List
   * @type {*}
   */
  organizationList: any;

  /**
   * Get financial years List
   * @type {*}
   */
  financialYearsList: any;

  /**
   * Declare From Date
   * @type {Date}
   */
  fromDate: Date;

  /**
   * Declare Min Date
   * @type {Date}
   */
  inwardFabricMinDate: Date;

  /**
   * Declaring feed back search Form
   * @type {FormGroup}
   */
  addFeedBackForm!: FormGroup;

  /**
   * Get feedback Form Validations
   */
  addFeedBackValidation = this.validationService?.addFeedback;

  /**
   * Get Location Validations
   */
  locationValidation = this.validationService.locationSelect;

  /**
   * Creates an instance of FeedbackListComponent.
   * @param {Router} router
   * @param {FormBuilder} formBuilder
   * @param {ValidationService} validationService
   * @param {MastersService} mastersService
   * @param {CustomersService} customerService
   * @param {LoaderService} loader
   * @param {DatePipe} datePipe
   * @param {Location} location
   * @param {MatDialog} matDialog
   */
  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private validationService: ValidationService,
    private mastersService: MastersService,
    private customerService: CustomersService,
    private loader: LoaderService,
    private datePipe: DatePipe,
    private location: Location,
    private matDialog: MatDialog
  ) {
    this.fromDate = new Date();
    const lastMonth = new Date(this.fromDate);

    if (lastMonth.getMonth() % 2 !== 0) {
      lastMonth.setMonth(lastMonth.getMonth() - 1);
      lastMonth.setDate(lastMonth.getDate() - 1);
    } else {
      lastMonth.setMonth(lastMonth.getMonth() - 1);
    }
    this.inwardFabricMinDate = lastMonth;
  }

  /**
   * Life Cycle Hook Initialization
   */
  ngOnInit(): void {
    this.addFeedBackFormValidation();
    this.getStates();
    this.getTowns();
    this.getFinancialYears();
    this.Submit();
  }

  /**
   * This method for initialize form validations
   */
  addFeedBackFormValidation() {
    this.addFeedBackForm = this.formBuilder.group({
      stateSelect: [""],
      districtSelect: [""],
      mandalSelect: [""],
      townSelect: [""],
      financialYear: [""],
      organizationType: [''],
      organizationSelect: [""],
      OrderNo: [""],
      satisfied: ["2"],
      fromDate: [""]
    });
  }

  /**
   * feedback Controls Initialized
   * @readonly
   */
  get addFeedBackFormControls() {
    return this.addFeedBackForm.controls;
  }

  /**
   * This method is used to get the financial List
   */
  getFinancialYears() {
    this.customerService.GetFinancialYears().subscribe({
      next: (res: any) => {
        this.financialYearsList = res.result;
      },
      error: (err: any) => {
        this.financialYearsList = [];
      },
    });
  }

  /**
   * This method is used to update value and validity
   * @param {*} formControls
   */
  onUpdateValueAndValidity(formControls: any, controls: any) {
    controls?.forEach((control: any) => {
      formControls[control].setValue("");
      formControls[control].markAsUntouched({ onlySelf: true });
      formControls[control].updateValueAndValidity({ onlySelf: true });
    });
  }

  /**
   * This method is used To navigate to add feedback page.
   */
  onNavigateToAddFeedback() {
    this.router.navigate(["/admin/feedback/customerFeedback/addfeedback"]);
  }

  /**
   * This method is used to get states list
   */
  getStates() {
    this.mastersService.getStates().subscribe({
      next: (res: any) => {
        this.statesList = res.result;
      },
      error: () => {
        this.statesList = [];
      }
    });
  }

  /**
   * This method is used to get towns list
   */
  getTowns() {
    this.mastersService.getTowns().subscribe({
      next: (res: any) => {
        this.townsList = res.result;
      },
      error: () => {
        this.townsList = [];
      }
    });
  }

  /**
   * This method will fired when user selects the state
   * @param {*} event
   */
  onChangeState(event: any) {
    this.onUpdateValueAndValidity(this.addFeedBackFormControls, ['districtSelect', 'mandalSelect', 'townSelect', 'organizationSelect', 'OrderNo']);
    this.districtsList = [];
    this.mandalsList = [];
    this.townsList = [];
    this.organizationList = [];
    this.orderNosList = [];

    if (event?.target?.value == '') {
      this.addFeedBackFormControls["stateSelect"].markAsUntouched({ onlySelf: true });
      return;
    }

    /* To call the service to get the districts list by passing stateId */
    this.mastersService.getDistrictsByStateId(event?.target?.value?.toString()).subscribe({
      next: (res: any) => {
        this.districtsList = res.result;
      },
      error: () => {
        this.districtsList = [];
      }
    });
  }

  /**
   * This method will fired when user selects the district
   * @param {*} event
   */
  onChangeDistrict(event: any) {
    this.onUpdateValueAndValidity(this.addFeedBackFormControls, ['mandalSelect', 'townSelect', 'organizationSelect', 'OrderNo']);
    this.mandalsList = [];
    this.townsList = [];
    this.organizationList = [];
    this.orderNosList = [];

    if (event.target?.value == '') {
      this.addFeedBackFormControls["districtSelect"].markAsUntouched({ onlySelf: true });
      return;
    }

    /* To call the service to get the mandals list by passing districtId */
    this.mastersService.getMandalsByDistrictId(event?.target?.value?.toString()).subscribe({
      next: (res: any) => {
        this.mandalsList = res.result;
      },
      error: () => {
        this.mandalsList = [];
      }
    });
  }

  /**
   * This method will fired when user selects the mandal
   * @param {*} event
   */
  onChangeMandal(event: any) {
    this.onUpdateValueAndValidity(this.addFeedBackFormControls, ['townSelect', 'organizationSelect', 'OrderNo']);
    this.townsList = [];
    this.organizationList = [];
    this.orderNosList = [];

    if (event.target?.value == '') {
      this.addFeedBackFormControls["mandalSelect"].markAsUntouched({ onlySelf: true });
      return;
    }

    /* To call the service to get the towns list by passing mandalId */
    this.mastersService.getTownsByMandalId(event.target?.value?.toString()).subscribe({
      next: (res: any) => {
        this.townsList = res.result;
      },
      error: () => {
        this.townsList = [];
      }
    });
  }

  /**
   * This method will fired when user selects the city for districts mandal
   * @param {*} event
   */
  onChangeTown(event: any) {
    this.organizationList = [];
    this.onUpdateValueAndValidity(this.addFeedBackFormControls, ["organizationSelect"]);
    if (event.target?.value != '') {
      this.customerService.getOrganizationByTownId(event.target?.value?.toString()).subscribe({
        next: (res: any) => {
          this.organizationList = res.result;
        },
        error: () => {
          this.organizationList = [];
        }
      });
    }
  }

  /**
   * This method will fired when user selects the organization
   * @param {*} event
   */
  onChangeOrganization(event: any) {
    this.orderNosList = [];
    this.onUpdateValueAndValidity(this.addFeedBackFormControls, ["OrderNo"]);
    if (!this.addFeedBackFormControls['financialYear'].value) {
      this.onUpdateValueAndValidity(this.addFeedBackFormControls, ["organizationSelect"]);
      this.snackbarModalComponent.onOpenSnackbarModal(false, "Please Select Financial Year", '', '', '');
      return;
    }
    if (event.target?.value != '') {
      this.customerService.getOrderNo(+event.target?.value, this.addFeedBackFormControls['financialYear'].value).subscribe({
        next: (res: any) => {
          this.orderNosList = res.result?.orderNos;
        },
        error: () => {
          this.orderNosList = [];
        }
      });
    }
  }

  /**
   * This method will fired when user selects financial year
   * @param {*} event
   */
  FinancialYearChange(event: any) {
    this.onUpdateValueAndValidity(this.addFeedBackFormControls, ["organizationSelect"]);
    if (event?.target?.value == '') {
      this.addFeedBackFormControls["financialYear"].markAsUntouched({ onlySelf: true });
    }
  }

  /**
   * This method fired on change of from date
   * @param {Date} newValue
   */
  fromDateChange(newValue: Date) { }

  /**
   * This method is used to sort column
   * @param key : value of which column based we need to sort the rows
   */
  sort(key: string) {
    const componentName = this.location.path();
    let value = key;
    sessionStorage.setItem(`${componentName}_property`, value);
    this.sortingKeyColumn = key;

    if (sessionStorage.getItem(componentName + "_order") == "desc") {
      this.sortingOrder = false;
    } else {
      this.sortingOrder = true;
    }
  }

  /**
   * This method is used to change the pagination controls
   * @param {*} event
   */
  onPageChange(event: any) {
    this.currentPage = event;
  }

  /**
   * This method is used to change the school
   * @param {*} event
   */
  schoolChangeEvent(event: any) {
    if (this.addFeedBackFormControls['organizationSelect']?.value) {
      document.getElementById('organizationSelect')?.classList.add('isSelected');
    }
  }

  /**
   * method call on change of order No
   * @param {*} event
   */
  orderNoChange(event: any) { }

  /**
   * This method fired on click Add button
   */
  Submit() {

    const finalObj = {
      stateId: +this.addFeedBackFormControls["stateSelect"]?.value || 0,
      districtId: +this.addFeedBackFormControls["districtSelect"]?.value || 0,
      mandalId: +this.addFeedBackFormControls["mandalSelect"]?.value || 0,
      townId: this.addFeedBackFormControls["townSelect"]?.value || 0,
      schoolId: +this.addFeedBackFormControls["organizationSelect"]?.value || 0,
      orderId: +this.addFeedBackFormControls["OrderNo"]?.value || 0,
      isSatisfy: +this.addFeedBackFormControls["satisfied"]?.value,
      feedbackDate:
        this.datePipe.transform(
          this.addFeedBackFormControls["fromDate"].value,
          "yyyy-MM-dd"
        ) || "",
    };

    this.customerService
      .SearchFeedBack(finalObj)
      .subscribe({
        next: (res: any) => {
          /* Disable the loader if response is success */
          this.loader.isLoading.next(false);
          this.feedbackList = res?.result;
          this.recordsCount = this.feedbackList?.length;
          this.currentPage = 1;
        },
        error: (err: any) => {
          /* Disable the loader if response is error */
          this.loader.isLoading.next(false);
          this.feedbackList = [];
          this.currentPage = 1;
        },
      });

  }

  /**
   * method fired on click of view 
   * @param {*} model
   */
  ViewMethod(model: any) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.data = {
      name: "feedback",
      title: "Address Details",
      payload: model,
      mandal: model?.mandal,
      town: model?.town,
      district: model?.district,
      feedback: model?.feedback,
      state: model?.state,
      organization: model?.schoolName,

      cancelButtonText: "OK",
    };
    this.matDialog.open(ModalComponent, dialogConfig);
  }
}
