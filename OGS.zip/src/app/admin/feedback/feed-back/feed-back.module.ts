import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";

import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { BsDatepickerModule } from "ngx-bootstrap/datepicker";
import { NgxPaginationModule } from "ngx-pagination";
import { ComponentModule } from "src/app/core/Modules/component.module";
import { OrderModule } from "ngx-order-pipe";
import { MatTooltipModule } from "@angular/material/tooltip";
import { feedBackRoutingModule } from "./feed-back-routing.module";
import { FeedbacklistComponent } from "./feedbacklist/feedbacklist.component";
import { AddFeedBackComponent } from "./add-feed-back/add-feed-back.component";
import { EditFeedBackComponent } from "./edit-feed-back/edit-feed-back.component";
import { NgMultiSelectDropDownModule } from "ng-multiselect-dropdown";
import { AutosizeModule } from "ngx-autosize";
import { Ng2SearchPipeModule } from "ng2-search-filter";

@NgModule({
  declarations: [
    FeedbacklistComponent,
    AddFeedBackComponent,
    EditFeedBackComponent,
  ],
  imports: [
    CommonModule,
    feedBackRoutingModule,
    FormsModule,
    MatTooltipModule,
    ReactiveFormsModule,
    NgxPaginationModule,
    ComponentModule,
    OrderModule,
    BsDatepickerModule.forRoot(),
    NgMultiSelectDropDownModule,
    AutosizeModule,
    Ng2SearchPipeModule
  ],
})
export class feedBackModule { }
