import { Location } from "@angular/common";
import { ChangeDetectorRef, Component, OnInit, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";

import { SnackbarModalComponent } from "src/app/core/Dialogues/snackbar-modal/snackbar-modal.component";
import { LoaderService } from "src/app/core/Services/loader.service";
import { MastersService } from "src/app/core/Services/masters.service";
import { ValidationService } from "src/app/core/Services/validation.service";

/**
 * Mandal Component
 * @export
 * @class MandalComponent
 * @implements {OnInit}
 */
@Component({
  selector: "app-mandal",
  templateUrl: "./mandal.component.html",
  styleUrls: ["./mandal.component.scss"]
})
export class MandalComponent implements OnInit {
  /**
   * Get Snackbar Modal Component
   * @type {SnackbarModalComponent}
   */
  @ViewChild("snackbarModalComponent") snackbarModalComponent!: SnackbarModalComponent;

  /**
   * Get Is Admin Or Manager Flag
   */
  isAdminOrManager = false;

  /**
   * Default Sorting Key
   */
  sortingKeyColumn = "stateName";

  /**
   * Default Sort Order
   */
  sortingOrder = true;

  /**
   * Get Is Update Mandal Flag
   */
  isUpdateMandal = false;

  /**
   * Get Mandals Records Count
   */
  mandalsRecordsCount = 0;

  /**
   * Get Mandals List
   * @type {*}
   */
  mandalsList: any;

  /**
   * Get States List
   * @type {*}
   */
  statesList: any;

  /**
   * Get Districts List
   * @type {*}
   */
  districtsList: any;

  /**
   * Get Edit Mandal Details
   * @type {*}
   */
  editMandalDetails: any;

  /**
   * Default Page Number
   */
  currentPage = 1;

  /**
   * Search Term
   */
  searchTerm = "";

  /**
   * Create mandal Form Declaration
   * @type {FormGroup}
   */
  createMandalForm!: FormGroup;

  /**
   * Get Mandal Form Validations
   */
  createMandalValidation = this.validationService.createMandal;

  /**
   * Get Location Validations
   */
  locationValidation = this.validationService.locationSelect;

  /**
   * Creates an instance of MandalComponent.
   * @param {LoaderService} loaderService
   * @param {ValidationService} validationService
   * @param {Location} location
   * @param {FormBuilder} formBuilder
   * @param {MastersService} mastersService
   * @param {ChangeDetectorRef} cdr
   */
  constructor(
    private loaderService: LoaderService,
    private validationService: ValidationService,
    private location: Location,
    private formBuilder: FormBuilder,
    private mastersService: MastersService,
    private cdr: ChangeDetectorRef
  ) {
    if (localStorage.getItem('userTypeId') == '1' || localStorage.getItem('userTypeId') == '4') {
      this.isAdminOrManager = true;
    }
  }

  /**
   * Life Cycle Hook Initialization
   */
  ngOnInit(): void {
    this.createMandalFormValidations();
    this.getMandalsList();
    this.getSatesList();
  }

  /**
   * Initialize Create mandal Validations
   */
  createMandalFormValidations() {
    this.createMandalForm = this.formBuilder.group({
      stateSelect: [this.editMandalDetails?.stateId || "", [Validators.required]],
      districtSelect: [this.editMandalDetails?.districtId || "", [Validators.required]],
      MandalName: [
        this.editMandalDetails?.mandalName || "",
        [
          Validators.required,
          Validators.minLength(this.createMandalValidation.MandalName.minLength),
          Validators.maxLength(this.createMandalValidation.MandalName.maxLength),
        ]
      ]
    });

    if (this.editMandalDetails) {
      this.onChangeState(this.editMandalDetails?.stateId);
    }
  }

  /**
   * Create mandal Form Controls Initialized
   * @readonly
   */
  get createMandalFormControls() {
    return this.createMandalForm.controls;
  }

  /**
   * This method used to reset mandal form
   */
  onClickReset() {
    this.createMandalForm.reset();
    this.districtsList = [];
    this.editMandalDetails = '';
    this.isUpdateMandal = false;
    this.createMandalFormValidations();
  }

  /**
   * This method is used to update value and validity
   * @param {*} formControls
   */
  onUpdateValueAndValidity(formControls: any, controls: any) {
    controls?.forEach((control: any) => {
      formControls[control].setValue("");
      formControls[control].markAsUntouched({ onlySelf: true });
      formControls[control].updateValueAndValidity({ onlySelf: true });
    });
  }

  /**
   * This method is used to get states list
   */
  getSatesList() {
    this.mastersService.getStates().subscribe({
      next: (res: any) => {
        this.statesList = res.result;
      },
      error: () => {
        this.statesList = [];
      }
    });
  }

  /**
   * This method is used to get mandals list
   */
  getMandalsList() {
    this.mastersService.getMandals().subscribe({
      next: (res: any) => {
        this.mandalsList = res.result;
        this.mandalsRecordsCount = this.mandalsList.length;
      },
      error: () => {
        this.mandalsList = [];
        this.mandalsRecordsCount = 0;
      },
    });
  }

  /**
   * This method will fired when user selects the mandal
   * @param {*} event
   */
  onChangeState(event: any) {
    if (event?.target) {
      this.onUpdateValueAndValidity(this.createMandalFormControls, ['districtSelect']);
      this.districtsList = [];
    }
    const stateValue = event?.target ? event.target?.value : event;
    const eventFlag = event?.target;

    if (event?.target?.value == '') {
      this.createMandalFormControls["stateSelect"]?.markAsUntouched({ onlySelf: true });
      return;
    }

    /* To call the service to get districts by state id */
    this.mastersService.getDistrictsByStateId(stateValue).subscribe({
      next: (res: any) => {
        this.districtsList = res.result;
        if (!eventFlag) {
          setTimeout(() => {
            this.createMandalFormControls["districtSelect"].setValue(this.editMandalDetails?.districtId);
            this.cdr.detectChanges();
          }, 50);
        }
      },
      error: () => {
        this.districtsList = [];
      }
    });
  }

  /**
   * This method will fired when user selects the mandal
   * @param {*} event
   */
  onChangeDistrict(event: any) {
    if (event?.target?.value == '') {
      this.createMandalFormControls["districtSelect"]?.markAsUntouched({ onlySelf: true });
    }
  }

  /**
   * This method is used to edit mandal
   * @param {*} mandal
   */
  onClickEditMandal(mandal: any) {
    this.mastersService.getMandalById(mandal.mandalId).subscribe({
      next: (res: any) => {
        this.isUpdateMandal = true;
        this.editMandalDetails = res.result;
        this.createMandalFormValidations();
      },
      error: (err: any) => {
        this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
      }
    });
  }

  /**
   * This method is used to change the pagination controls
   * @param {*} event
   */
  onPageChange(event: any) {
    this.currentPage = event;
  }

  /**
   * This method is used to show search results
   */
  navigateToSearchResult() {
    this.currentPage = 1;
  }

  /**
   * This method is used to sort column
   * @param key : value of which column based we need to sort the rows
   */
  sort(key: string) {
    const componentName = this.location.path();
    let value = key;
    sessionStorage.setItem(`${componentName}_property`, value);
    this.sortingKeyColumn = key;

    if (sessionStorage.getItem(componentName + "_order") == "desc") {
      this.sortingOrder = false;
    } else {
      this.sortingOrder = true;
    }
  }

  /**
   * Create mandal Form Submit
   * @return {*}
   */
  onCreateMandalFormSubmit(): any {
    /** This will return false if form fields are invalid and stop the service calling */
    if (this.createMandalForm.invalid) {
      this.validationService.validateAllFormFields(this.createMandalForm);
      return;
    }

    /* Prepare the request payload */
    const obj = {
      mandalId: this.isUpdateMandal ? this.editMandalDetails?.mandalId : '0',
      mandalName: this.createMandalFormControls["MandalName"].value.trim(),
      stateId: this.createMandalFormControls["stateSelect"]?.value,
      districtId: this.createMandalFormControls["districtSelect"]?.value,
      status: this.isUpdateMandal ? this.editMandalDetails?.status : '0',
    };

    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    if (this.isUpdateMandal === false) {
      /* To call the service to add the mandal by passing obj */
      this.mastersService.addMandal(obj).subscribe({
        next: (res: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', '');
          this.getMandalsList();
          this.onClickReset();
        },
        error: (err: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
        }
      });
    } else {
      /* To call the service to edit the mandal by passing obj */
      this.mastersService.editMandal(obj).subscribe({
        next: (res: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', '');
          this.getMandalsList();
          this.onClickReset();
        },
        error: (err: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
        }
      });
    }
  }
}
