import { Location } from "@angular/common";
import { Component, OnInit, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";

import { SnackbarModalComponent } from "src/app/core/Dialogues/snackbar-modal/snackbar-modal.component";
import { LoaderService } from "src/app/core/Services/loader.service";
import { MastersService } from "src/app/core/Services/masters.service";
import { ValidationService } from "src/app/core/Services/validation.service";

/**
 * District Component
 * @export
 * @class DistrictComponent
 * @implements {OnInit}
 */
@Component({
  selector: "app-district",
  templateUrl: "./district.component.html",
  styleUrls: ["./district.component.scss"]
})
export class DistrictComponent implements OnInit {
  /**
   * Get Snackbar Modal Component
   * @type {SnackbarModalComponent}
   */
  @ViewChild("snackbarModalComponent") snackbarModalComponent!: SnackbarModalComponent;

  /**
   * Get Is Admin Or Manager Flag
   */
  isAdminOrManager = false;

  /**
   * Get Districts List
   */
  districtsList: any;

  /**
   * Get Districts Records Count
   */
  districtsRecordsCount = 0;

  /**
   * Get Edit District Details
   */
  editDistrictDetails: any;

  /**
   * Get Is Update District Flag
   */
  isUpdateDistrict = false;

  /**
   * Get Selected State
   * @type {*}
   */
  selectedState: any;

  /**
   * Default Page Number
   */
  currentPage = 1;

  /**
   * Search Term
   */
  searchTerm = "";

  /**
   * Default Sorting Key
   */
  sortingKeyColumn = "stateName";

  /**
   * Default Sort Order
   */
  sortingOrder = true;

  /**
   * Create district Form Declaration
   */
  createDistrictForm!: FormGroup;

  /**
   * Get district Form Validations
   */
  createDistrictValidation = this.validationService.createDistrict;

  /**
   * Get Location Validations
   */
  locationValidation = this.validationService.locationSelect;

  /**
   * Get district Form Patterns
   */
  createDistrictPatterns = this.validationService.patterns;

  /**
   * States List
   */
  statesList: any;

  /**
   * Creates an instance of DistrictComponent.
   * @param {Router} router
   * @param {LoaderService} loaderService
   * @param {Location} location
   * @param {ValidationService} validationService
   * @param {FormBuilder} formBuilder
   * @param {MastersService} mastersService
   */
  constructor(
    private router: Router,
    private loaderService: LoaderService,
    private location: Location,
    private validationService: ValidationService,
    private formBuilder: FormBuilder,
    private mastersService: MastersService
  ) {
    if (localStorage.getItem('userTypeId') == '1' || localStorage.getItem('userTypeId') == '4') {
      this.isAdminOrManager = true;
    }
  }

  /**
   * Life Cycle Hook Initialization
   */
  ngOnInit(): void {
    this.createDistrictFormValidations();
    this.getDistrictsList();
    this.getStateList();
  }

  /**
   * Initialize Create district Validations
   */
  createDistrictFormValidations() {
    if (this.editDistrictDetails) {
      this.onChangeState(this.editDistrictDetails?.stateId);
    }
    this.createDistrictForm = this.formBuilder.group({
      DistrictName: [
        this.editDistrictDetails?.districtName || "",
        [
          Validators.required,
          Validators.minLength(this.createDistrictValidation.DistrictName.minLength),
          Validators.maxLength(this.createDistrictValidation.DistrictName.maxLength),
          Validators.pattern(this.createDistrictPatterns.name)
        ]
      ],
      stateSelect: [this.editDistrictDetails?.stateId || "", [Validators.required]],
    });
  }

  /**
   * Create District Form Controls Initialized
   * @readonly
   */
  get createDistrictFormControls() {
    return this.createDistrictForm.controls;
  }

  /**
   * This method is used to get the districts list
   */
  getDistrictsList() {
    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    /* To call the service to get the districts list */
    this.mastersService.getDistricts().subscribe({
      next: (res: any) => {
        /* Disable the loader if response is success */
        this.loaderService.isLoading.next(false);
        this.districtsList = res.result;
        this.districtsRecordsCount = this.districtsList.length;
      },
      error: (err: any) => {
        /* Disable the loader if response is error */
        this.loaderService.isLoading.next(false);
        this.districtsList = [];
        this.districtsRecordsCount = 0;
      },
    });
  }

  /**
   * This method is used to get the states List
   */
  getStateList() {
    this.mastersService.getStates().subscribe({
      next: (res: any) => {
        this.statesList = res?.result;
      },
      error: (err: any) => {
        this.statesList = [];
      }
    });
  }

  /**
   * This method used to reset district form
   */
  onClickReset() {
    this.createDistrictForm.reset();
    this.isUpdateDistrict = false;
    this.editDistrictDetails = '';
    this.createDistrictFormValidations();
  }

  /**
   * This method will fired when user selects the State
   * @param {*} event
   */
  onChangeState(event: any) {
    if (event?.target?.value == '') {
      this.createDistrictFormControls["stateSelect"].markAsUntouched({ onlySelf: true });
      this.selectedState = '';
      return;
    }
    let stateValue = event?.target ? event?.target?.value : event;
    for (const element of this.statesList) {
      if (+(element.stateId) === (+stateValue)) {
        this.selectedState = element;
      }
    }
  }

  /**
   * This method is used edit district
   * @param {*} district
   */
  onClickEditDistrict(district: any) {
    this.mastersService.getDistrictById(district?.districtId?.toString()).subscribe({
      next: (res: any) => {
        this.editDistrictDetails = res?.result;
        this.isUpdateDistrict = true;
        this.createDistrictFormValidations();
      },
      error: (err: any) => {
        this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
      },
    });
  }

  /**
   * This method is used to change the pagination controls
   * @param {*} event
   */
  onPageChange(event: any) {
    this.currentPage = event;
  }

  /**
   * This method is used to sort column
   * @param key : value of which column based we need to sort the rows
   */
  sort(key: string) {
    const componentName = this.location.path();
    let value = key;
    sessionStorage.setItem(`${componentName}_property`, value);
    this.sortingKeyColumn = key;
    if (sessionStorage.getItem(componentName + "_order") == "desc") {
      this.sortingOrder = false;
    } else {
      this.sortingOrder = true;
    }
  }

  /**
   * This method is used to show search results
   */
  navigateToSearchResult() {
    this.currentPage = 1;
  }

  /**
   * This method is used to submit the district form
   * @return {*}
   */
  onSubmitDistrictForm(): any {
    /** This will return false if form fields are invalid and stop the service calling */
    if (this.createDistrictForm.invalid) {
      this.validationService.validateAllFormFields(this.createDistrictForm);
      return;
    }

    /* Prepare the request payload */
    const obj = {
      districtId: this.editDistrictDetails?.districtId || 0,
      districtName: this.createDistrictForm.controls["DistrictName"].value?.toString()?.trim(),
      status: this.editDistrictDetails ? 1 : 0,
      stateId: this.selectedState?.stateId,
      stateName: this.selectedState?.stateName?.toString(),
    };

    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    if (!this.isUpdateDistrict) {
      /* To call the service to add the district by passing the data object */
      this.mastersService.addDistrict(obj).subscribe({
        next: (res: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', '');
          this.getDistrictsList();
          this.onClickReset();
        },
        error: (err: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
        }
      });
    } else {
      /* To call the service to edit the district by passing the data object */
      this.mastersService.editDistrict(obj).subscribe({
        next: (res: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', '');
          this.getDistrictsList();
          this.onClickReset();
        },
        error: (err: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
        }
      });
    }
  }
}
