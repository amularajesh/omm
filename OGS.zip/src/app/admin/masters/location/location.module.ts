import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatTooltipModule } from '@angular/material/tooltip';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { AutosizeModule } from 'ngx-autosize';
import { NgxPaginationModule } from 'ngx-pagination';

import { ComponentModule } from 'src/app/core/Modules/component.module';
import { DistrictComponent } from './district/district.component';
import { LocationRoutingModule } from './location-routing.module';
import { LocationComponent } from './location.component';
import { MandalComponent } from './mandal/mandal.component';
import { TownComponent } from './town/town.component';

/**
 * Location Module
 * @export
 * @class LocationModule
 */
@NgModule({
  declarations: [
    LocationComponent,
    DistrictComponent,
    MandalComponent,
    TownComponent
  ],
  imports: [
    CommonModule,
    LocationRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    MatTooltipModule,
    AutosizeModule,
    NgxPaginationModule,
    Ng2SearchPipeModule,
    ComponentModule
  ]
})
export class LocationModule { }
