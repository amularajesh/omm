import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { DistrictComponent } from './district/district.component';
import { LocationComponent } from './location.component';
import { MandalComponent } from './mandal/mandal.component';
import { TownComponent } from './town/town.component';

const routes: Routes = [
  {
    path: '', component: LocationComponent,
    children: [
      { path: '', component: LocationComponent, pathMatch: 'full' },
      { path: 'district', component: DistrictComponent },
      { path: 'mandal', component: MandalComponent },
      { path: 'town', component: TownComponent }
    ]
  }
];

/**
 * Location Routing Module
 * @export
 * @class LocationRoutingModule
 */
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LocationRoutingModule { }
