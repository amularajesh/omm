import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { AppService } from 'src/app/core/Services/app.service';

/**
 * Location Component
 * @export
 * @class LocationComponent
 * @implements {OnInit}
 */
@Component({
  selector: 'app-location',
  templateUrl: './location.component.html',
  styleUrls: ['./location.component.scss']
})
export class LocationComponent implements OnInit {
  /**
   * Get Location DropdownItems
   * @type {*}
   */
  locationDropdownItems: any;


  /**
   * Creates an instance of LocationComponent.
   * @param {Router} router
   * @param {AppService} appService
   */
  constructor(
    private router: Router,
    private appService: AppService
  ) {
    this.appService.menuItems.subscribe((items: any) => {
      this.locationDropdownItems = items
        .filter((menu: any) => menu.menuName === 'Masters')
        .map((menu: any) => menu.groupList
          .filter((group: any) => group.groupingName === 'Location')
          .flatMap((group: any) => group.subMenuList
            .filter((submenu: any) => submenu.checked === true)
          )
        ).reduce((acc: any, current: any) => acc.concat(current), []);
      if (this.locationDropdownItems.length > 0) {
        if (document.getElementById('locationSelect')) {
          const selectedEle = document.getElementById('locationSelect') as HTMLSelectElement;
          selectedEle.value = this.locationDropdownItems[0].submenuName;
        }
        if (this.router.routerState.snapshot.url === '/admin/home') {
          this.router.navigate(['/admin/home']);
        } else {
          this.onSelectNavigate(this.locationDropdownItems[0].submenuName);
        }
      }
    });
  }

  /**
   * Life Cycle Hook Initialization
   */
  ngOnInit(): void { }

  /**
   * This method is used to navigate to the selected location dropdown item
   * @param {*} event
   */
  onSelectNavigate(event: any) {
    const selectedValue = event?.target ? event.target.value : event;
    const selectedElement = this.locationDropdownItems.filter((item: any) => item.submenuName === selectedValue);
    this.router.navigate([selectedElement[0].link]);
  }
}
