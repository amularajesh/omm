import { Location } from "@angular/common";
import { ChangeDetectorRef, Component, OnInit, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";

import { SnackbarModalComponent } from "src/app/core/Dialogues/snackbar-modal/snackbar-modal.component";
import { LoaderService } from "src/app/core/Services/loader.service";
import { MastersService } from "src/app/core/Services/masters.service";
import { ValidationService } from "src/app/core/Services/validation.service";

/**
 * Town Component
 * @export
 * @class TownComponent
 * @implements {OnInit}
 */
@Component({
  selector: "app-town",
  templateUrl: "./town.component.html",
  styleUrls: ["./town.component.scss"],
})
export class TownComponent implements OnInit {
  /**
   * Get Snackbar Modal Component
   * @type {SnackbarModalComponent}
   */
  @ViewChild("snackbarModalComponent") snackbarModalComponent!: SnackbarModalComponent;

  /**
   * Get Is Admin Or Manager Flag
   */
  isAdminOrManager = false;

  /**
   * Get Towns List
   * @type {*}
   */
  TownsList: any;

  /**
   * Declare Sorting Order Flag
   */
  sortingOrder = false;

  /**
   * Declare Sorting Key Column
   */
  sortingKeyColumn = "townName";

  /**
   * Get Is Update City
   */
  isUpdateCity = false;

  /**
   * Records Count
   */
  recordsCount = 0;

  /**
   * Get States List
   * @type {*}
   */
  statesList: any;

  /**
   * Get Districts List
   */
  districtsList: any;

  /**
   * Get Mandals List
   */
  mandalsList: any;

  /**
   * Get Edit Town Details
   * @type {*}
   */
  editTownDetails: any;

  /**
   * Default Page Number
   */
  currentPage = 1;

  /**
   * Search Term
   */
  searchTerm = "";

  /**
   * Create City Form Declaration
   * @type {FormGroup}
   */
  createCityForm!: FormGroup;

  /**
   * Get City Form Validations
   */
  createCityValidation = this.validationService.createCity;

  /**
   * Get Location Validations
   */
  locationValidation = this.validationService.locationSelect;

  /**
   * Creates an instance of TownComponent.
   * @param {LoaderService} loaderService
   * @param {ValidationService} validationService
   * @param {FormBuilder} formBuilder
   * @param {MastersService} mastersService
   * @param {Location} location
   * @param {ChangeDetectorRef} cdr
   */
  constructor(
    private loaderService: LoaderService,
    private validationService: ValidationService,
    private formBuilder: FormBuilder,
    private mastersService: MastersService,
    private location: Location,
    private cdr: ChangeDetectorRef,
  ) {
    if (localStorage.getItem('userTypeId') == '1' || localStorage.getItem('userTypeId') == '4') {
      this.isAdminOrManager = true;
    }
  }

  /**
   * Life Cycle Hook Initialization
   */
  ngOnInit(): void {
    this.createCityFormValidations();
    this.getTownsList();
    this.getStates();
  }

  /**
   * Create city Controls Initialized
   * @readonly
   */
  get createCityFormControls() {
    return this.createCityForm.controls;
  }

  /**
   * Initialize Create City Form Validations
   */
  createCityFormValidations() {
    this.createCityForm = this.formBuilder.group({
      stateSelect: [this.editTownDetails?.stateId || "", [Validators.required]],
      districtSelect: [this.editTownDetails?.districtId || "", [Validators.required]],
      mandalSelect: [this.editTownDetails?.mandalId || "", [Validators.required]],
      CityName: [
        this.editTownDetails?.townName || "",
        [
          Validators.required,
          Validators.minLength(this.createCityValidation.CityName.minLength),
          Validators.maxLength(this.createCityValidation.CityName.maxLength)
        ]
      ]
    });

    if (this.editTownDetails) {
      this.onChangeState(this.editTownDetails?.stateId);
    }
  }

  /**
   * This method used to reset city form
   */
  onClickReset() {
    this.createCityForm.reset();
    this.editTownDetails = "";
    this.isUpdateCity = false;
    this.districtsList = [];
    this.mandalsList = [];
    this.createCityFormValidations();
  }

  /**
   * This method is used to update value and validity
   * @param {*} formControls
   */
  onUpdateValueAndValidity(formControls: any, controls: any) {
    controls?.forEach((control: any) => {
      formControls[control].setValue("");
      formControls[control].markAsUntouched({ onlySelf: true });
      formControls[control].updateValueAndValidity({ onlySelf: true });
    });
  }

  /**
   * This method is used to get towns list
   */
  getTownsList() {
    this.mastersService.getTowns().subscribe({
      next: (res: any) => {
        this.TownsList = res.result;
        this.recordsCount = this.TownsList.length;
      },
      error: () => {
        this.TownsList = [];
        this.recordsCount = 0;
      }
    });
  }

  /**
   * This method is used to get states list
   */
  getStates() {
    this.mastersService.getStates().subscribe({
      next: (res: any) => {
        this.statesList = res.result;
      },
      error: () => {
        this.statesList = [];
      }
    });
  }

  /**
   * This method will fired when user selects the state
   * @param {*} event
   */
  onChangeState(event: any) {
    if (event?.target) {
      this.districtsList = [];
      this.mandalsList = [];
      this.onUpdateValueAndValidity(this.createCityFormControls, ['districtSelect', 'mandalSelect']);
    }
    const stateValue = event?.target ? +event.target?.value : +event;
    const eventFlag = event?.target;

    if (event?.target?.value == '') {
      this.createCityFormControls["stateSelect"]?.markAsUntouched({ onlySelf: true });
      return;
    }

    /* To call the service to get the districts details by passing stateId */
    this.mastersService.getDistrictsByStateId(stateValue).subscribe({
      next: (res: any) => {
        this.districtsList = res.result;
        if (!eventFlag) {
          setTimeout(() => {
            this.createCityFormControls["districtSelect"].setValue(this.editTownDetails?.districtId);
            this.onChangeDistrict(this.editTownDetails?.districtId);
            this.cdr.detectChanges();
          }, 50);
        }
      },
      error: () => {
        this.districtsList = [];
      }
    });
  }

  /**
   * This method will fired when user selects district
   * @param {*} event
   */
  onChangeDistrict(event: any) {
    if (event?.target) {
      this.mandalsList = [];
      this.onUpdateValueAndValidity(this.createCityFormControls, ['mandalSelect']);
    }

    const districtValue = event?.target ? event.target?.value : event;
    const eventFlag = event?.target;

    if (event?.target?.value == '') {
      this.createCityFormControls["districtSelect"]?.markAsUntouched({ onlySelf: true });
      return;
    }

    this.mastersService.getMandalsByDistrictId(districtValue).subscribe({
      next: (res: any) => {
        this.mandalsList = res.result;
        if (!eventFlag) {
          setTimeout(() => {
            this.createCityFormControls["mandalSelect"].setValue(this.editTownDetails?.mandalId);
            this.cdr.detectChanges();
          }, 50);
        }
      },
      error: () => {
        this.mandalsList = [];
      }
    });
  }

  /**
   * This method is used for navigate to create course page when user clicked on edit user
   */
  onClickEditUser(user: any) {
    this.mastersService.getTownById(user.townId).subscribe({
      next: (res: any) => {
        this.isUpdateCity = true;
        this.editTownDetails = res.result;
        this.createCityFormValidations();
      },
      error: (err: any) => {
        this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
      }
    });
  }

  /**
   * This method is used to change the pagination controls
   * @param {*} event
   */
  onPageChange(event: any) {
    this.currentPage = event;
  }

  /**
   * This method is used to show search results
   */
  navigateToSearchResult() {
    this.currentPage = 1;
  }

  /**
   * This method is used to sort column
   * @param key : value of which column based we need to sort the rows
   */
  sort(key: string) {
    const componentName = this.location.path();
    let value = key;
    sessionStorage.setItem(`${componentName}_property`, value);
    this.sortingKeyColumn = key;
    if (sessionStorage.getItem(componentName + "_order") == "desc") {
      this.sortingOrder = false;
    } else {
      this.sortingOrder = true;
    }
  }

  /**
   * Create mandal Form Submit
   * @return {*}
   */
  onCreateCityFormSubmit(): any {
    /** This will return false if form fields are invalid and stop the service calling */
    if (this.createCityForm.invalid) {
      this.validationService.validateAllFormFields(this.createCityForm);
      return;
    }

    /* Prepare the request payload */
    const obj = {
      townId: this.isUpdateCity ? this.editTownDetails?.townId?.toString() : "0",
      townName: this.createCityFormControls["CityName"]?.value?.toString()?.trim(),
      stateId: this.createCityFormControls["stateSelect"].value,
      districtId: this.createCityFormControls["districtSelect"].value,
      mandalId: this.createCityFormControls["mandalSelect"].value,
      status: this.isUpdateCity ? this.editTownDetails?.status?.toString() : "0"
    };

    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    if (!this.isUpdateCity) {
      /* To call the service to add the town by passing the data object */
      this.mastersService.addTown(obj).subscribe({
        next: (res: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', '');
          this.getTownsList();
          this.onClickReset();
        },
        error: (err: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
        },
      });
    } else {
      /* To call the service to update the town by passing the data object */
      this.mastersService.editTown(obj).subscribe({
        next: (res: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', '');
          this.getTownsList();
          this.editTownDetails = [];
          this.onClickReset();
        },
        error: (err: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
        }
      });
    }
  }
}
