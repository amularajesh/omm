import { Location } from "@angular/common";
import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

import { SnackbarModalComponent } from "src/app/core/Dialogues/snackbar-modal/snackbar-modal.component";
import { LoaderService } from 'src/app/core/Services/loader.service';
import { MastersService } from 'src/app/core/Services/masters.service';
import { ValidationService } from 'src/app/core/Services/validation.service';

/**
 * Agent Component
 * @export
 * @class AgentComponent
 * @implements {OnInit}
 */
@Component({
  selector: 'app-agent',
  templateUrl: './agent.component.html',
  styleUrls: ['./agent.component.scss']
})
export class AgentComponent implements OnInit {
  /**
   * Get Snackbar Modal Component
   * @type {SnackbarModalComponent}
   */
  @ViewChild("snackbarModalComponent") snackbarModalComponent!: SnackbarModalComponent;

  /**
   * Get Is Admin Or Manager Flag
   */
  isAdminOrManager = false;

  /**
   * Records Count
   */
  recordsCount = 0;

  /**
   * Get Agents List
   */
  agentsList: any;

  /**
   * Get Edit Agent Details
   */
  editAgentDetails: any;

  /**
   * Get Is Update Agent Flag 
   */
  updateAgent = false;

  /**
   * Default Page Number
   */
  currentPage = 1;

  /**
   * Search Term
   */
  searchTerm = '';

  /**
   * Default Sorting Key
   */
  sortingKeyColumn = "firstName";

  /**
   * Default Sort Order
   */
  sortingOrder = true;

  /**
   * Create agent Form Declaration
   */
  createAgentForm!: FormGroup;

  /**
   * Get agent Form Validations
   */
  createAgentValidation = this.validationService.createAgent;

  /**
   * Get Patterns
   * @private
   */
  private patterns = this.validationService.patterns;

  /**
   * Creates an instance of AgentComponent.
   * @param {Router} router
   * @param {LoaderService} loaderService
   * @param {ValidationService} validationService
   * @param {FormBuilder} formBuilder
   * @param {MastersService} mastersService
   * @param {Location} location
   */
  constructor(
    private router: Router,
    private loaderService: LoaderService,
    private validationService: ValidationService,
    private formBuilder: FormBuilder,
    private mastersService: MastersService,
    private location: Location
  ) {
    if (localStorage.getItem('userTypeId') == '1' || localStorage.getItem('userTypeId') == '4') {
      this.isAdminOrManager = true;
    }
  }

  /**
   * Life Cycle Hook Initialization
   */
  ngOnInit(): void {
    this.createAgentFormValidations();
    this.getAgentsList();
  }

  /**
   * This method is used to get Agents List
   */
  getAgentsList() {
    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    /* To call the service to get the agents list */
    this.mastersService.getAgents().subscribe({
      next: (res: any) => {
        /* Disable the loader if response is success */
        this.loaderService.isLoading.next(false);
        this.agentsList = res.result;
        this.recordsCount = this.agentsList.length;
      },
      error: (err: any) => {
        /* Disable the loader if response is error */
        this.loaderService.isLoading.next(false);
        this.agentsList = [];
        this.recordsCount = 0;
      }
    });
  }

  /**
   * This method is used to reset the agent form
   */
  onClickReset() {
    this.createAgentForm.reset();
    this.editAgentDetails = '';
    this.updateAgent = false;
    this.createAgentFormValidations();
  }

  /**
   * Initialize Create Company Validations
   */
  createAgentFormValidations() {
    this.createAgentForm = this.formBuilder.group({
      FirstName: [
        this.editAgentDetails?.firstName || '',
        [
          Validators.required,
          Validators.minLength(this.createAgentValidation.FirstName.minLength),
          Validators.maxLength(this.createAgentValidation.FirstName.maxLength),
        ],
      ],

      LastName: [
        this.editAgentDetails?.lastName || '',
        [
          Validators.required,
          Validators.minLength(this.createAgentValidation.LastName.minLength),
          Validators.maxLength(this.createAgentValidation.LastName.maxLength),
        ],
      ],

      Commission: [
        this.editAgentDetails?.commission || '',
        [
          Validators.required,
          Validators.minLength(this.createAgentValidation.Commission.minLength),
          Validators.maxLength(this.createAgentValidation.Commission.maxLength),
          Validators.pattern(this.patterns.points),
        ],
      ],
      agentAddress: [this.editAgentDetails?.address || '',
      [
        Validators.required,
        Validators.minLength(this.createAgentValidation.agentAddress.minLength),
        Validators.maxLength(this.createAgentValidation.agentAddress.maxLength),
      ]],
    });
  }

  /**
   * Create company Controls Initialized
   * @readonly
   */
  get createAgentFormControls() {
    return this.createAgentForm.controls;
  }



  /**
   * This method is used to edit agent
   * @param {*} agent
   */
  onClickEditAgent(agent: any) {
    this.mastersService.getAgentById(agent?.agentId?.toString()).subscribe({
      next: (res: any) => {
        this.updateAgent = true;
        this.editAgentDetails = res.result;
        this.createAgentFormValidations();
      },
      error: (err: any) => {
        this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
      },
    });
  }

  /**
   * This method is used to sort column
   * @param key : value of which column based we need to sort the rows
   */
  sort(key: string) {
    const componentName = this.location.path();
    let value = key;
    sessionStorage.setItem(`${componentName}_property`, value);
    this.sortingKeyColumn = key;
    if (sessionStorage.getItem(componentName + "_order") == "desc") {
      this.sortingOrder = false;
    } else {
      this.sortingOrder = true;
    }
  }

  /**
   * This method is used to change the pagination controls
   * @param {*} event
   */
  onPageChange(event: any) {
    this.currentPage = event;
  }

  /**
   * This method is used to show search results
   */
  navigateToSearchResult() {
    this.currentPage = 1;
  }

  /**
   * This method is used to submit Agent Form
   * @return {*}
   */
  onSubmitAgentForm(): any {
    /** This will return false if form fields are invalid and stop the service calling */
    if (this.createAgentForm.invalid) {
      this.validationService.validateAllFormFields(this.createAgentForm);
      return;
    }

    /* Prepare the request payload */
    const obj = {
      firstName: this.createAgentForm.controls['FirstName'].value?.trim() || '',
      lastName: this.createAgentForm.controls['LastName'].value?.trim() || '',
      commission: this.createAgentForm.controls['Commission'].value || '',
      address: this.createAgentForm.controls['agentAddress'].value?.trim() || '',
    };

    const updateAgent = {
      agentId: this.editAgentDetails?.agentId || '',
      firstName: this.createAgentForm.controls['FirstName'].value?.trim() || '',
      lastName: this.createAgentForm.controls['LastName'].value?.trim() || '',
      commission: this.createAgentForm.controls['Commission'].value || '',
      address: this.createAgentForm.controls['agentAddress'].value?.trim() || '',
      status: '1',
    };

    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    if (!this.updateAgent) {
      /* To call the service to add the agent by passing data object */
      this.mastersService.addAgent(obj).subscribe({
        next: (res: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', '');
          this.getAgentsList();
          this.onClickReset();
        },
        error: (err: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
        }
      });
    } else {
      /* To call the service to edit the agent by passing data object */
      this.mastersService.editAgent(updateAgent).subscribe({
        next: (res: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', '');
          this.getAgentsList();
          this.onClickReset();
        },
        error: (err: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
        }
      });
    }
  }
}
