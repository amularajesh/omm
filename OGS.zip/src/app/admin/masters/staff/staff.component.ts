import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { AppService } from 'src/app/core/Services/app.service';

/**
 * Staff Component
 * @export
 * @class StaffComponent
 * @implements {OnInit}
 */
@Component({
  selector: 'app-staff',
  templateUrl: './staff.component.html',
  styleUrls: ['./staff.component.scss']
})
export class StaffComponent implements OnInit {
  /**
   * Get Staff DropdownItems
   * @type {*}
   */
  staffDropdownItems: any;

  /**
   * Creates an instance of StaffComponent.
   * @param {Router} router
   * @param {AppService} appService
   * @memberof StaffComponent
   */
  constructor(
    private router: Router,
    private appService: AppService
  ) {
    this.appService.menuItems.subscribe((items: any) => {
      this.staffDropdownItems = items
        .filter((menu: any) => menu.menuName === 'Masters')
        .map((menu: any) => menu.groupList
          .filter((group: any) => group.groupingName === 'Staff/Incharge')
          .flatMap((group: any) => group.subMenuList
            .filter((submenu: any) => submenu.checked === true)
          )
        ).reduce((acc: any, current: any) => acc.concat(current), []);
      if (this.staffDropdownItems.length > 0) {
        if (document.getElementById('staffSelect')) {
          const selectedEle = document.getElementById('staffSelect') as HTMLSelectElement;
          selectedEle.value = this.staffDropdownItems[0].submenuName;
        }
        if (this.router.routerState.snapshot.url === '/admin/home') {
          this.router.navigate(['/admin/home']);
        } else {
          this.onSelectNavigate(this.staffDropdownItems[0].submenuName);
        }
      }
    });
  }

  /**
   * Life Cycle Hook Initilization
   */
  ngOnInit(): void { }

  /**
   * This method is used to navigate to the selected staff dropdown item
   * @param {*} event
   */
  onSelectNavigate(event: any) {
    const selectedValue = event?.target ? event.target.value : event;
    const selectedElement = this.staffDropdownItems.filter((item: any) => item.submenuName === selectedValue);
    this.router.navigate([selectedElement[0].link]);
  }
}
