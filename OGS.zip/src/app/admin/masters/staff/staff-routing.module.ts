import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AgentComponent } from './agent/agent.component';
import { StaffInchargeComponent } from './staff-incharge/staff-incharge.component';
import { StaffComponent } from './staff.component';

const routes: Routes = [
  {
    path: '', component: StaffComponent,
    children: [
      { path: '', component: StaffComponent, pathMatch: 'full' },
      { path: 'agent', component: AgentComponent },
      { path: 'staffincharge', component: StaffInchargeComponent }
    ]
  }
];

/**
 * Staff Routing Module
 * @export
 * @class StaffRoutingModule
 */
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class StaffRoutingModule { }
