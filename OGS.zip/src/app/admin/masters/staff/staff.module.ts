import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatTooltipModule } from '@angular/material/tooltip';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { AutosizeModule } from 'ngx-autosize';
import { NgxPaginationModule } from 'ngx-pagination';

import { ComponentModule } from 'src/app/core/Modules/component.module';
import { AgentComponent } from './agent/agent.component';
import { StaffInchargeComponent } from './staff-incharge/staff-incharge.component';
import { StaffRoutingModule } from './staff-routing.module';
import { StaffComponent } from './staff.component';

/**
 * Staff Module
 * @export
 * @class StaffModule
 */
@NgModule({
  declarations: [
    StaffComponent,
    AgentComponent,
    StaffInchargeComponent
  ],
  imports: [
    CommonModule,
    StaffRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    MatTooltipModule,
    AutosizeModule,
    NgxPaginationModule,
    Ng2SearchPipeModule,
    ComponentModule
  ]
})
export class StaffModule { }
