
import { Location } from "@angular/common";
import { Component, OnInit, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";

import { SnackbarModalComponent } from "src/app/core/Dialogues/snackbar-modal/snackbar-modal.component";
import { LoaderService } from "src/app/core/Services/loader.service";
import { MastersService } from "src/app/core/Services/masters.service";
import { ValidationService } from "src/app/core/Services/validation.service";

/**
 * Staff Incharge Component
 * @export
 * @class StaffInchargeComponent
 * @implements {OnInit}
 */
@Component({
  selector: "app-staff-incharge",
  templateUrl: "./staff-incharge.component.html",
  styleUrls: ["./staff-incharge.component.scss"]
})
export class StaffInchargeComponent implements OnInit {
  /**
   * Get Snackbar Modal Component
   * @type {SnackbarModalComponent}
   */
  @ViewChild("snackbarModalComponent") snackbarModalComponent!: SnackbarModalComponent;

  /**
   * Get Is Admin Or Manager Flag
   */
  isAdminOrManager = false;

  /**
   * Employee Type
   */
  employeeType = '1';

  /**
   * Records Count
   */
  recordsCount = 0;

  /**
   * Staff List
   */
  staffList: any[] = [];

  /**
   * Staff Data
   */
  staffData: any;

  /**
   * Get Is Update Staff Flag
   */
  updateStaff = false;

  /**
   * Declaring variable to store staff id
   * @type {*}
   */
  staffId: any;

  /**
   * Default Page Number
   */
  currentPage = 1;

  /**
   * Search Term
   */
  searchTerm = "";

  /**
   * Default Sorting Key
   */
  sortingKeyColumn = "firstName";

  /**
   * Default Sort Order
   */
  sortingOrder = true;

  /**
   * Create staff Form Declaration
   */
  createStaffForm!: FormGroup;

  /**
   * Get staff Form Validations
   */
  createStaffValidation = this.validationService.createStaffIncharge;

  /**
   * Get Patterns
   * @private
   */
  private patterns = this.validationService.patterns;

  /**
   * Creates an instance of StaffInchargeComponent.
   * @param {LoaderService} loaderService
   * @param {ValidationService} validationService
   * @param {FormBuilder} formBuilder
   * @param {Location} location
   * @param {MastersService} mastersService
   */
  constructor(
    private loaderService: LoaderService,
    private validationService: ValidationService,
    private formBuilder: FormBuilder,
    private location: Location,
    private mastersService: MastersService
  ) {
    if (localStorage.getItem('userTypeId') == '1' || localStorage.getItem('userTypeId') == '4') {
      this.isAdminOrManager = true;
    }
  }

  /**
   * Life Cycle Hook Initialization
   */
  ngOnInit(): void {
    this.createStaffFormValidations();
    this.getStaffsList();
  }

  /**
   * This method is used to get districts list
   */
  getStaffsList() {
    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    /* To call the service to get the districts list */
    this.mastersService.getStaffs().subscribe({
      next: (res: any) => {
        /* Disable the loader if response is success */
        this.loaderService.isLoading.next(false);
        this.staffList = res.result;
        this.recordsCount = this.staffList.length;
      },
      error: (err: any) => {
        /* Disable the loader if response is error */
        this.loaderService.isLoading.next(false);
        this.staffList = [];
        this.recordsCount = 0;
      },
    });
  }

  /**
   * This method used to reset staff form
   */
  onClickReset() {
    this.createStaffForm.reset();
    this.staffData = "";
    this.createStaffFormControls["FirstName"].setValue("");
    this.createStaffFormControls["LastName"].setValue("");
    this.createStaffFormControls["MobileNo"].setValue("");
    this.createStaffFormControls["agentAddress"].setValue("");
    this.createStaffFormControls["isStaff"].setValue("1");
    this.updateStaff = false;
    this.createStaffFormValidations();
  }

  /**
   * Initialize Create Company Validations
   */
  createStaffFormValidations() {
    this.createStaffForm = this.formBuilder.group({
      FirstName: [
        this.staffData?.firstName || "",
        [
          Validators.required,
          Validators.minLength(this.createStaffValidation.FirstName.minLength),
          Validators.maxLength(this.createStaffValidation.FirstName.maxLength),
        ],
      ],

      LastName: [
        this.staffData?.lastName || "",
        [
          Validators.required,
          Validators.minLength(this.createStaffValidation.LastName.minLength),
          Validators.maxLength(this.createStaffValidation.LastName.maxLength),
        ],
      ],

      MobileNo: [
        this.staffData?.phoneNo || "",
        [
          Validators.minLength(this.createStaffValidation.mobileNo.minLength),
          Validators.maxLength(this.createStaffValidation.mobileNo.maxLength),
          Validators.pattern(this.patterns.mobileNo),
        ],
      ],

      agentAddress: [this.staffData?.address || ""],
      isStaff: [this.staffData?.isStaff || "1"],
    });
    if (this.staffData) {
      this.onChangeEmployeeType(this.staffData?.isStaff);
    }
  }

  /**
   * Create company Controls Initialized
   * @readonly
   */
  get createStaffFormControls() {
    return this.createStaffForm.controls;
  }

  /**
   * This method is used edit Company
   */
  onClickEditStaff(staff: any) {
    this.staffData = staff;
    this.staffId = staff.staffId;
    this.mastersService.getStaffById(staff.staffId).subscribe({
      next: (res: any) => {
        this.updateStaff = true;
        this.staffData = res.result;
        this.createStaffFormValidations();
      },
      error: (err: any) => {
        this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
      }
    });
  }

  /**
   * This method is used to sort column
   * @param key : value of which column based we need to sort the rows
   */
  sort(key: string) {
    const componentName = this.location.path();
    let value = key;
    sessionStorage.setItem(`${componentName}_property`, value);
    this.sortingKeyColumn = key;
    if (sessionStorage.getItem(componentName + "_order") == "desc") {
      this.sortingOrder = false;
    } else {
      this.sortingOrder = true;
    }
  }

  /**
   * This method is used to change the pagination controls
   * @param {*} event
   */
  onPageChange(event: any) {
    this.currentPage = event;
  }

  /**
   * This method is used to show search results
   */
  navigateToSearchResult() {
    this.currentPage = 1;
  }

  /**
   * This method is used to change employee type
   * @param {*} event
   */

  onChangeEmployeeType(event: any) {
    this.employeeType = event?.target ? event.target.value : event;
  }

  /**
   * Create staff Form Submit
   * @return {*}
   */
  onCreateStaffFormSubmit(): any {
    /** This will return false if form fields are invalid and stop the service calling */
    if (this.createStaffForm.invalid) {
      this.validationService.validateAllFormFields(this.createStaffForm);
      return;
    }

    /* Prepare the request payload */
    const obj = {
      staffId: "",
      firstName: this.createStaffForm.controls["FirstName"].value?.trim() || "",
      lastName: this.createStaffForm.controls["LastName"].value?.trim() || "",
      phoneNo: this.createStaffForm.controls["MobileNo"].value?.trim() || "",
      address: this.createStaffForm.controls["agentAddress"].value?.trim() || "",
      isStaff: this.employeeType.toString(),
      status: "",
    };

    const updateStaff = {
      staffId: this.staffId || "",
      firstName: this.createStaffForm.controls["FirstName"].value?.trim() || "",
      lastName: this.createStaffForm.controls["LastName"].value?.trim() || "",
      phoneNo: this.createStaffForm.controls["MobileNo"].value?.trim() || "",
      address: this.createStaffForm.controls["agentAddress"].value?.trim() || "",
      isStaff: this.employeeType.toString(),
      status: "1",
    };

    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    if (this.updateStaff === false) {
      /* To call the service to add the staff by passing the data object */
      this.mastersService.addStaff(obj).subscribe({
        next: (res: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', '');
          this.getStaffsList();
          this.onClickReset();
        },
        error: (err: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
        },
      });
    } else {
      /* To call the service to update the staff by passing the data object */
      this.mastersService.editStaff(updateStaff).subscribe({
        next: (res: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', '');
          this.getStaffsList();
          this.staffData = [];
          this.updateStaff = false;
          this.onClickReset();
        },
        error: (err: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
        }
      });
    }
  }
}
