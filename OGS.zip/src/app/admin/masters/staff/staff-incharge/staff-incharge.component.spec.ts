import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StaffInchargeComponent } from './staff-incharge.component';

describe('StaffInchargeComponent', () => {
  let component: StaffInchargeComponent;
  let fixture: ComponentFixture<StaffInchargeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StaffInchargeComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(StaffInchargeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
