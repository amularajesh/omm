import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";

import { MastersComponent } from "./masters.component";

const routes: Routes = [
  {
    path: "",
    component: MastersComponent,
    children: [
      { path: '', redirectTo: `${localStorage.getItem('mastersModule')}`, pathMatch: 'full' },
      {
        path: 'location',
        loadChildren: () => import('./location/location.module').then((m) => m.LocationModule)
      },
      {
        path: 'dressItem',
        loadChildren: () => import('./dress-item/dress-item.module').then((m) => m.DressItemModule)
      },
      {
        path: 'staff',
        loadChildren: () => import('./staff/staff.module').then((m) => m.StaffModule)
      },
      {
        path: 'companyUnits',
        loadChildren: () => import('./company-units/company-units.module').then((m) => m.CompanyUnitsModule)
      },
      {
        path: 'others',
        loadChildren: () => import('./others/others.module').then((m) => m.OthersModule)
      }
    ]
  }
];

/**
 * Masters Routing Module
 * @export
 * @class MastersRoutingModule
 */
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MastersRoutingModule { }
