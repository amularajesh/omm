import { Component, OnInit } from '@angular/core';

/**
 * Masters Component
 * @export
 * @class MastersComponent
 * @implements {OnInit}
 */
@Component({
  selector: 'app-masters',
  templateUrl: './masters.component.html',
  styleUrls: ['./masters.component.scss']
})
export class MastersComponent implements OnInit {
  /**
   * Creates an instance of MastersComponent.
   */
  constructor() { }

  /**
   * Life Cycle Hook Initialization
   */
  ngOnInit(): void { }
}
