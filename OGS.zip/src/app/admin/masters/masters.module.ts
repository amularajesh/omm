import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { MatTooltipModule } from "@angular/material/tooltip";
import { Ng2SearchPipeModule } from "ng2-search-filter";
import { AutosizeModule } from "ngx-autosize";
import { NgxPaginationModule } from "ngx-pagination";

import { ComponentModule } from "src/app/core/Modules/component.module";
import { MastersRoutingModule } from "./masters-routing.module";
import { MastersComponent } from "./masters.component";

/**
 * Masters Module
 * @export
 * @class MastersModule
 */
@NgModule({
  declarations: [
    MastersComponent
  ],
  imports: [
    CommonModule,
    MastersRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    MatTooltipModule,
    AutosizeModule,
    NgxPaginationModule,
    Ng2SearchPipeModule,
    ComponentModule
  ]
})
export class MastersModule { }
