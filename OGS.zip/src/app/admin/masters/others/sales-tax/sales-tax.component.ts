import { Location } from "@angular/common";
import { Component, OnInit, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";

import { SnackbarModalComponent } from "src/app/core/Dialogues/snackbar-modal/snackbar-modal.component";
import { LoaderService } from "src/app/core/Services/loader.service";
import { MastersService } from "src/app/core/Services/masters.service";
import { ValidationService } from "src/app/core/Services/validation.service";

/**
 * Sales Tax Component
 * @export
 * @class SalesTaxComponent
 * @implements {OnInit}
 */
@Component({
  selector: "app-sales-tax",
  templateUrl: "./sales-tax.component.html",
  styleUrls: ["./sales-tax.component.scss"],
})
export class SalesTaxComponent implements OnInit {
  /**
   * Get Snackbar Modal Component
   * @type {SnackbarModalComponent}
   */
  @ViewChild("snackbarModalComponent") snackbarModalComponent!: SnackbarModalComponent;

  /**
   * Get Is Admin Or Manager Flag
   */
  isAdminOrManager = false;

  /**
   * Records Count
   */
  recordsCount = 0;

  /**
   * salesTaxList
   * @type {any[]}
   */
  salesTaxList: any[] = [];

  /**
   * SalesTax Data
   * @type {*}
   */
  SalesTaxData: any;

  /**
   * Declare variable to know edit click or not
   */
  isUpdateSalesTax = false;

  /**
   * Declaring variable to store SalesTax id
   * @type {*}
   */
  SalesTaxId: any;

  /**
   * Default Page Number
   */
  currentPage = 1;

  /**
   * Default Sorting Key
   */
  sortingKeyColumn = "salesTaxName";

  /**
   * Default Sort Order
   */
  sortingOrder = true;

  /**
   * Search Term
   */
  searchTerm = "";

  /**
   * Create SalesTax Form Declaration
   * @type {FormGroup}
   */
  createSalesTaxForm!: FormGroup;

  /**
   * Get SalesTax Form Validations
   */
  createSalesTaxValidation = this.validationService.createSalesTax;

  /**
   * Get Patterns
   */
  createSalesTaxValidationPattern = this.validationService.patterns;

  /**
   * States List
   * @type {SalesTaxMode[]}
   */
  statesList: any;

  /**
   * Selected SalesTax
   */
  selectedSalesTax = "";

  /**
   * Creates an instance of SalesTaxComponent.
   * @param {Router} router
   * @param {LoaderService} loaderService
   * @param {Location} location
   * @param {ValidationService} validationService
   * @param {FormBuilder} formBuilder
   * @param {MastersService} mastersService
   */
  constructor(
    private router: Router,
    private loaderService: LoaderService,
    private location: Location,
    private validationService: ValidationService,
    private formBuilder: FormBuilder,
    private mastersService: MastersService
  ) {
    if (localStorage.getItem('userTypeId') == '1' || localStorage.getItem('userTypeId') == '4') {
      this.isAdminOrManager = true;
    }
  }

  /**
   * Life Cycle Hook Initialization
   */
  ngOnInit(): void {
    this.createSalesTaxFormValidations();
    this.getSalesTax();
  }

  /**
   * This method is used to get sales Tax list
   */
  getSalesTax() {
    /* To call the service to get the Sales Tax list */
    this.mastersService.getSalesTax().subscribe({
      next: (res: any) => {
        this.salesTaxList = res.result;
        this.recordsCount = this.salesTaxList.length;
      },
      error: (err: any) => {
        this.salesTaxList = [];
        this.recordsCount = 0;
      },
    });
  }

  /**
   * This method used to reset SalesTax form
   */
  resetSalesTaxForm() {
    this.createSalesTaxForm.reset();
    this.isUpdateSalesTax = false;
    this.createSalesTaxFormValidations();
    this.createSalesTaxForm.controls["SalesTaxName"]?.setValue("");
  }

  /**
   * Initialize Create SalesTax Validations
   */
  createSalesTaxFormValidations() {
    this.createSalesTaxForm = this.formBuilder.group({
      SalesTaxName: [
        +this.SalesTaxData?.salesTaxName || "",
        [
          Validators.required,
          Validators.minLength(
            this.createSalesTaxValidation.SalesTaxName.minLength
          ),
          Validators.maxLength(
            this.createSalesTaxValidation.SalesTaxName.maxLength
          ),
          Validators.pattern(this.createSalesTaxValidationPattern?.salesTax),
        ],
      ],
    });
  }

  /**
   * Create SalesTax Controls Initialized
   * @readonly
   */
  get createSalesTaxFormControls() {
    return this.createSalesTaxForm.controls;
  }

  /**
   * This Method Used To Navigation based on selection of previlage
   * @param {*} event
   * @memberof SalesTaxComponent
   */
  navigateToRoute(event: any) {
    const selectedValue = event.target.value;

    if (selectedValue === "Transport") {
      this.router.navigate(["/admin/masters/transport"]);
    } else if (selectedValue === "SalesTax") {
      this.router.navigate(["/admin/masters/salestax"]);
    }
  }

  /**
   * This method is used edit SalesTax
   */
  onClickEditUnit(user: any) {
    this.SalesTaxId = user.salesTaxId;
    this.isUpdateSalesTax = true;
    this.mastersService.getSalesTaxById(user.salesTaxId).subscribe({
      next: (res: any) => {
        this.SalesTaxData = res.result;
        this.createSalesTaxFormValidations();
      },
      error: (err: any) => {
        this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
      },
    });
  }

  /**
   * This method is used to sort column
   * @param key : value of which column based we need to sort the rows
   */
  sort(key: string) {
    const componentName = this.location.path();
    let value = key;
    sessionStorage.setItem(`${componentName}_property`, value);
    this.sortingKeyColumn = key;
    if (sessionStorage.getItem(componentName + "_order") == "desc") {
      this.sortingOrder = false;
    } else {
      this.sortingOrder = true;
    }
  }

  /**
   * This method is used to change the pagination controls
   * @param {*} event
   */
  onPageChange(event: any) {
    this.currentPage = event;
  }

  /**
   * Create SalesTax Form Submit
   */
  onCreateCompanyFormSubmit() {
    /** This will return false if form fields are invalid and stop the service calling */
    if (this.createSalesTaxForm.invalid) {
      this.validationService.validateAllFormFields(this.createSalesTaxForm);
      return;
    }

    const obj = {
      salesTaxId: 0,
      salesTaxName:
        this.createSalesTaxForm.controls["SalesTaxName"].value?.toString()?.trim() ||
        "",
      status: 0,
    };

    const updateSalesTaxObj = {
      salesTaxId: Number(this.SalesTaxData?.salesTaxId) || 0,
      salesTaxName:
        this.createSalesTaxForm.controls["SalesTaxName"].value?.toString()?.trim() ||
        "",
      status: Number(this.SalesTaxData?.status) || 1,
    };

    if (this.isUpdateSalesTax === false) {
      /* Enable the loader */
      this.loaderService.isLoading.next(true);

      /* To call the service to add the sales tax by passing data object*/
      this.mastersService.addSalesTax(obj).subscribe({
        next: (res: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);
          this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', '');
          this.getSalesTax();
          this.resetSalesTaxForm();
        },
        error: (err: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);
          this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
        },
      });
    } else {
      /* Enable the loader */
      this.loaderService.isLoading.next(true);

      /* To call the service to update the sales tax by passing data object */
      this.mastersService.editSalesTax(updateSalesTaxObj).subscribe({
        next: (res: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);
          this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', '');
          this.isUpdateSalesTax = false;
          this.getSalesTax();
          this.resetSalesTaxForm();
        },
        error: (err: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);
          this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
        },
      });
    }
  }

  /**
   * This method is used to show search results
   */
  navigateToSearchResult() {
    this.currentPage = 1;
  }
}
