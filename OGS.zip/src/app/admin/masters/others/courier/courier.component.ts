import { Location } from "@angular/common";
import { Component, OnInit, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";

import { SnackbarModalComponent } from "src/app/core/Dialogues/snackbar-modal/snackbar-modal.component";
import { LoaderService } from "src/app/core/Services/loader.service";
import { MastersService } from "src/app/core/Services/masters.service";
import { ValidationService } from "src/app/core/Services/validation.service";

@Component({
  selector: 'app-courier',
  templateUrl: './courier.component.html',
  styleUrls: ['./courier.component.scss']
})
export class CourierComponent implements OnInit {
  /**
   * Get Snackbar Modal Component
   * @type {SnackbarModalComponent}
   */
  @ViewChild("snackbarModalComponent") snackbarModalComponent!: SnackbarModalComponent;

  /**
   * Get Is Admin Or Manager Flag
   */
  isAdminOrManager = false;

  sortingOrder = true;
  sortingKeyColumn = "courierName";
  /**
   * Get Couriers List
   */
  couriersList: any[] = [];

  /**
   * Couriers Records Count
   */
  couriersRecordsCount = 0;

  /**
   * Get Edit Courier Details
   */
  editCourierDetails: any;

  /**
   * Get Is Update Courier Flag
   */
  isUpdateCourier = false;

  /**
   * Declaring variable to store district id
   * @type {*}
   * @memberof DistrictComponent
   */
  courierId: any;

  /**
   * Default Page Number
   */
  currentPage = 1;

  /**
   * Search Term
   */
  searchTerm = "";

  /**
   * Create district Form Declaration
   */
  createCourierForm!: FormGroup;

  /**
   * Get district Form Validations
   */
  createCourierValidation = this.validationService.createCourier;

  /**
   * Get Patterns
   * @private
   */
  private patterns = this.validationService.patterns;

  /**
   * Creates an instance of CourierComponent.
   * @param {Router} router
   * @param {LoaderService} loaderService
   * @param {ValidationService} validationService
   * @param {FormBuilder} formBuilder
   * @param {MastersService} mastersService
   */
  constructor(
    private router: Router,
    private loaderService: LoaderService,
    private validationService: ValidationService,
    private formBuilder: FormBuilder,
    private mastersService: MastersService,
    private location: Location
  ) {
    if (localStorage.getItem('userTypeId') == '1' || localStorage.getItem('userTypeId') == '4') {
      this.isAdminOrManager = true;
    }
  }

  /**
   * Life Cycle Hook Initialization
   */
  ngOnInit(): void {
    this.createCourierFormValidations();
    this.getCouriersList();
  }

  /**
   * This method is used to get the Couriers list
   */
  getCouriersList() {
    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    /* To call the service to get the colors list */
    this.mastersService.getCouriers().subscribe({
      next: (res: any) => {
        /* Disable the loader if response is success */
        this.loaderService.isLoading.next(false);
        this.couriersList = res.result;
        this.couriersRecordsCount = this.couriersList.length;
      },
      error: (err: any) => {
        this.loaderService.isLoading.next(false);
        this.couriersList = [];
        this.couriersRecordsCount = 0;
      },
    });
  }

  /**
   * This method used to reset colors form
   */
  resetColorsForm() {
    this.createCourierForm.reset();
    this.editCourierDetails = "";
    this.isUpdateCourier = false;
    this.createCourierFormValidations();
    this.createCourierFormControls["CourierName"].setValue("");
  }

  /**
   * Initialize Create Company Validations
   */
  createCourierFormValidations() {
    this.createCourierForm = this.formBuilder.group({
      CourierName: [
        this.editCourierDetails?.courierName || "",
        [
          Validators.required,
          Validators.minLength(
            this.createCourierValidation.CourierName.minLength
          ),
          Validators.maxLength(
            this.createCourierValidation.CourierName.maxLength
          ),
          Validators.pattern(this.patterns.courierName),
        ],
      ],
    });
  }

  /**
   * Create company Controls Initialized
   * @readonly
   */
  get createCourierFormControls() {
    return this.createCourierForm.controls;
  }

  /**
   * This method is used to get the courier details by clicking on edit icon
   * @param {*} courier
   */
  onClickEditCourier(courier: any) {
    this.courierId = courier.courierId;
    this.mastersService.getCourierById(courier.courierId).subscribe({
      next: (res: any) => {
        this.isUpdateCourier = true;
        this.editCourierDetails = res.result;
        this.createCourierFormValidations();
      },
      error: (err: any) => {
        this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
      },
    });
  }

  /**
   * This method is used to change the pagination controls
   * @param {*} event
   */
  onPageChange(event: any) {
    this.currentPage = event;
  }

  /**
   * This method is used to show search results
   */
  navigateToSearchResult() {
    this.currentPage = 1;
  }

  /**
   * This method is used to submit the Color Form
   * @return {*}
   */
  onColorFormSubmit(): any {
    /** This will return false if form fields are invalid and stop the service calling */
    if (this.createCourierForm.invalid) {
      this.validationService.validateAllFormFields(this.createCourierForm);
      return;
    }

    /* Prepare the request payload */
    const obj = {
      courierName: this.createCourierForm.controls["CourierName"].value?.trim() || "",
    };

    /* Prepare the request payload */
    const isUpdateCourier = {
      courierId: this.courierId || "",
      courierName: this.createCourierForm.controls["CourierName"].value?.trim() || "",
      status: "1",
    };

    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    if (!this.isUpdateCourier) {
      /* To call the service to add the color*/
      this.mastersService.addCourier(obj).subscribe({
        next: (res: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', '');
          this.getCouriersList();
          this.resetColorsForm();
        },
        error: (err: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
        },
      });
    } else {
      /* To call the service to update the color*/
      this.mastersService.editCourier(isUpdateCourier).subscribe({
        next: (res: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', '');
          this.getCouriersList();
          this.resetColorsForm();
        },
        error: (err: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
        },
      });
    }
  }

  /**
   * This method is used to sort column
   * @param key : value of which column based we need to sort the rows
   */
  sort(key: string) {
    const componentName = this.location.path();
    let value = key;
    sessionStorage.setItem(`${componentName}_property`, value);
    this.sortingKeyColumn = key;

    if (sessionStorage.getItem(componentName + "_order") == "desc") {
      this.sortingOrder = false;
    } else {
      this.sortingOrder = true;
    }
  }

}
