import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { AppService } from 'src/app/core/Services/app.service';

/**
 * Others Component
 * @export
 * @class OthersComponent
 * @implements {OnInit}
 */
@Component({
  selector: 'app-others',
  templateUrl: './others.component.html',
  styleUrls: ['./others.component.scss']
})
export class OthersComponent implements OnInit {

  /**
   * Get Others DropdownItems
   * @type {*}
   */
  othersDropdownItems: any;

  /**
   * Creates an instance of OthersComponent.
   * @param {Router} router
   * @param {AppService} appService
   */
  constructor(
    private router: Router,
    private appService: AppService
  ) {
    this.appService.menuItems.subscribe((items: any) => {
      this.othersDropdownItems = items
        .filter((menu: any) => menu.menuName === 'Masters')
        .map((menu: any) => menu.groupList
          .filter((group: any) => group.groupingName === 'Others')
          .flatMap((group: any) => group.subMenuList
            .filter((submenu: any) => submenu.checked === true)
          )
        ).reduce((acc: any, current: any) => acc.concat(current), []);
      if (this.othersDropdownItems.length > 0) {
        if (document.getElementById('othersSelect')) {
          const selectedEle = document.getElementById('othersSelect') as HTMLSelectElement;
          selectedEle.value = this.othersDropdownItems[0].submenuName;
        }
        if (this.router.routerState.snapshot.url === '/admin/home') {
          this.router.navigate(['/admin/home']);
        } else {
          this.onSelectNavigate(this.othersDropdownItems[0].submenuName);
        }
      }
    });
  }

  /**
   * Life Cycle Hook Initilization
   */
  ngOnInit(): void { }


  /**
   * This method is used to navigate to the selected others dropdown item
   * @param {*} event
   */
  onSelectNavigate(event: any) {
    const selectedValue = event?.target ? event.target.value : event;
    const selectedElement = this.othersDropdownItems.filter((item: any) => item.submenuName === selectedValue);
    this.router.navigate([selectedElement[0].link]);
  }
}
