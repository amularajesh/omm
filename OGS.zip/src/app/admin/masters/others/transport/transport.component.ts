import { Location } from "@angular/common";
import { Component, OnInit, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";

import { SnackbarModalComponent } from "src/app/core/Dialogues/snackbar-modal/snackbar-modal.component";
import { LoaderService } from "src/app/core/Services/loader.service";
import { MastersService } from "src/app/core/Services/masters.service";
import { ValidationService } from "src/app/core/Services/validation.service";

/**
 * Transport Component
 * @export
 * @class TransportComponent
 * @implements {OnInit}
 */
@Component({
  selector: "app-transport",
  templateUrl: "./transport.component.html",
  styleUrls: ["./transport.component.scss"]
})
export class TransportComponent implements OnInit {
  /**
   * Get Snackbar Modal Component
   * @type {SnackbarModalComponent}
   */
  @ViewChild("snackbarModalComponent") snackbarModalComponent!: SnackbarModalComponent;

  /**
   * Get Is Admin Or Manager Flag
   */
  isAdminOrManager = false;

  /**
   * Get Is Update Transport Flag
   */
  isUpdateTransport = false;

  /**
   * Get Edit Transport Details
   * @type {*}
   */
  editTransportDetails: any;

  /**
   * Transport List Records Count
   */
  transportListRecordsCount = 0;

  /**
   * Get Transport List
   */
  transportList: any[] = [];

  /**
   * Default Page Number
   */
  currentPage = 1;

  /**
   * Default Sorting Key
   */
  sortingKeyColumn = "transportName";

  /**
   * Default Sort Order
   */
  sortingOrder = true;

  /**
   * Search Term
   */
  searchTerm = "";

  /**
   * Create Transport Form Declaration
   */
  createAccessoriesForm!: FormGroup;

  /**
   * Get Transport Form Validations
   */
  createTransportValidation = this.validationService.createTransport;

  /**
   * Get Patterns
   * @private
   */
  private patterns = this.validationService.patterns;

  /**
   * Creates an instance of TransportComponent.
   * @param {Router} router
   * @param {Location} location
   * @param {ValidationService} validationService
   * @param {FormBuilder} formBuilder
   * @param {MastersService} mastersService
   */
  constructor(
    private router: Router,
    private location: Location,
    private validationService: ValidationService,
    private formBuilder: FormBuilder,
    private mastersService: MastersService,
    private loaderService: LoaderService
  ) {
    if (localStorage.getItem('userTypeId') == '1' || localStorage.getItem('userTypeId') == '4') {
      this.isAdminOrManager = true;
    }
  }

  /**
   * Life Cycle Hook Initialization
   */
  ngOnInit(): void {
    this.createTransportFormValidations();
    this.getTransportList();
  }

  /**
   * This method is used to get transport list
   */
  getTransportList() {
    this.mastersService.getTransports().subscribe({
      next: (res: any) => {
        this.transportList = res.result;
        this.transportListRecordsCount = this.transportList.length;
      },
      error: (err: any) => {
        this.transportList = [];
        this.transportListRecordsCount = 0;
      }
    });
  }

  /**
   * This method used to reset Transport form
   */
  resetTransportForm() {
    this.createAccessoriesForm.reset();
    this.createTransportFormValidations();
    this.createTransportFormControls["TransportName"]?.setValue("");
    this.createTransportFormControls["MobileNo"]?.setValue("");
    this.createTransportFormControls["transportAddress"]?.setValue("");
    this.isUpdateTransport = false;
  }

  /**
   * Initialize Create Transport Validations
   */
  createTransportFormValidations() {
    this.createAccessoriesForm = this.formBuilder.group({
      TransportName: [
        this.editTransportDetails?.transportName || "",
        [
          Validators.required,
          Validators.minLength(this.createTransportValidation.TransportName.minLength),
          Validators.maxLength(this.createTransportValidation.TransportName.maxLength)
        ]
      ],
      MobileNo: [
        this.editTransportDetails?.contactNumber || "",
        [
          Validators.minLength(this.createTransportValidation.mobileNo.minLength),
          Validators.maxLength(this.createTransportValidation.mobileNo.maxLength),
          Validators.pattern(this.patterns.mobileNo)
        ]
      ],
      transportAddress: [this.editTransportDetails?.address || ""]
    });
  }

  /**
   * Create Transport Controls Initialized
   * @readonly
   */
  get createTransportFormControls() {
    return this.createAccessoriesForm.controls;
  }

  /**
   * This Method Used To Navigation based on selection of privilege
   * @param {*} event
   * @memberof DistrictComponent
   */
  navigateToRoute(event: any) {
    const selectedValue = event.target.value;

    if (selectedValue === "Transport") {
      this.router.navigate(["/admin/masters/transport"]);
    } else if (selectedValue === "SalesTax") {
      this.router.navigate(["/admin/masters/salestax"]);
    }
  }

  /**
   * This method is used edit Transport
   */
  onClickEditUser(user: any) {
    const TransportId = user.transportId;
    this.isUpdateTransport = true;
    this.mastersService.getTransportById(TransportId).subscribe({
      next: (res: any) => {
        this.editTransportDetails = res.result;
        this.createTransportFormValidations();
      },
      error: (err: any) => {
        this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
      },
    });
  }

  /**
   * This method is used to sort column
   * @param key : value of which column based we need to sort the rows
   */
  sort(key: string) {
    const componentName = this.location.path();
    let value = key;
    sessionStorage.setItem(`${componentName}_property`, value);
    this.sortingKeyColumn = key;
    if (sessionStorage.getItem(componentName + "_order") == "desc") {
      this.sortingOrder = false;
    } else {
      this.sortingOrder = true;
    }
  }

  /**
   * This method is used to change the pagination controls
   * @param {*} event
   */
  onPageChange(event: any) {
    this.currentPage = event;
  }

  /**
   * This method is used to show search results
   */
  navigateToSearchResult() {
    this.currentPage = 1;
  }

  /**
   * This method is used to submit the Create Transport Form
   * @return {*}
   */
  onCreateUserFormSubmit(): any {
    /** This will return false if form fields are invalid and stop the service calling */
    if (this.createAccessoriesForm.invalid) {
      this.validationService.validateAllFormFields(this.createAccessoriesForm);
      return;
    }

    /* Prepare the request payload */
    const obj = {
      transportId: 0,
      transportName: this.createTransportFormControls["TransportName"]?.value?.toString()?.trim() || "",
      contactNumber: this.createTransportFormControls["MobileNo"]?.value?.toString() || "",
      address: this.createTransportFormControls["transportAddress"]?.value?.toString()?.trim() || "",
      status: "0",
    };

    /* Prepare the request payload */
    const updateTransportObj = {
      transportId: this.editTransportDetails?.transportId || 0,
      transportName: this.createTransportFormControls["TransportName"]?.value?.toString()?.trim() || "",
      contactNumber: this.createTransportFormControls["MobileNo"]?.value?.toString() || "",
      address: this.createTransportFormControls["transportAddress"]?.value?.toString()?.trim() || "",
      status: this.editTransportDetails?.status || "1",
    };

    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    if (!this.isUpdateTransport) {
      this.mastersService.addTransport(obj).subscribe({
        next: (res: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', '');
          this.getTransportList();
          this.resetTransportForm();
        },
        error: (err: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
        }
      });
    } else {
      this.mastersService.editTransport(updateTransportObj).subscribe({
        next: (res: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', '');
          this.getTransportList();
          this.resetTransportForm();
        },
        error: (err: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
        }
      });
    }
  }
}
