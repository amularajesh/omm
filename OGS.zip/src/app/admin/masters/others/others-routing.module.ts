import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { OthersComponent } from './others.component';
import { SalesTaxComponent } from './sales-tax/sales-tax.component';
import { TransportComponent } from './transport/transport.component';
import { CourierComponent } from './courier/courier.component';
import { FusingTypeComponent } from './fusing-type/fusing-type.component';

const routes: Routes = [
  {
    path: '', component: OthersComponent,
    children: [
      { path: '', component: OthersComponent, pathMatch: 'full' },
      { path: 'transport', component: TransportComponent },
      { path: 'salestax', component: SalesTaxComponent },
      { path: 'courier', component: CourierComponent },
      { path: 'fusingtype', component: FusingTypeComponent }


    ]
  }
];

/**
 * Others Routing Module
 * @export
 * @class OthersRoutingModule
 */
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class OthersRoutingModule { }
