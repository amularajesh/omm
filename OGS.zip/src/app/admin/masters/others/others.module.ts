import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatTooltipModule } from '@angular/material/tooltip';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { AutosizeModule } from 'ngx-autosize';
import { NgxPaginationModule } from 'ngx-pagination';

import { ComponentModule } from 'src/app/core/Modules/component.module';
import { OthersRoutingModule } from './others-routing.module';
import { OthersComponent } from './others.component';
import { SalesTaxComponent } from './sales-tax/sales-tax.component';
import { TransportComponent } from './transport/transport.component';
import { CourierComponent } from './courier/courier.component';
import { FusingTypeComponent } from './fusing-type/fusing-type.component';


/**
 * Others Module
 * @export
 * @class OthersModule
 */
@NgModule({
  declarations: [
    OthersComponent,
    SalesTaxComponent,
    TransportComponent,
    CourierComponent,
    FusingTypeComponent
  ],
  imports: [
    CommonModule,
    OthersRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    MatTooltipModule,
    AutosizeModule,
    NgxPaginationModule,
    Ng2SearchPipeModule,
    ComponentModule
  ]
})
export class OthersModule { }
