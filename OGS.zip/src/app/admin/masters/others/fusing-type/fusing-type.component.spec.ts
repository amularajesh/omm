import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FusingTypeComponent } from './fusing-type.component';

describe('FusingTypeComponent', () => {
  let component: FusingTypeComponent;
  let fixture: ComponentFixture<FusingTypeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FusingTypeComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FusingTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
