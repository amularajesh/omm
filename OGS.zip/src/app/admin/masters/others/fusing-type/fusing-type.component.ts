import { Location } from "@angular/common";
import { Component, OnInit, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";

import { SnackbarModalComponent } from "src/app/core/Dialogues/snackbar-modal/snackbar-modal.component";
import { LoaderService } from "src/app/core/Services/loader.service";
import { MastersService } from "src/app/core/Services/masters.service";
import { ValidationService } from "src/app/core/Services/validation.service";

@Component({
  selector: 'app-fusing-type',
  templateUrl: './fusing-type.component.html',
  styleUrls: ['./fusing-type.component.scss']
})
export class FusingTypeComponent implements OnInit {
  /**
   * Get Snackbar Modal Component
   * @type {SnackbarModalComponent}
   */
  @ViewChild("snackbarModalComponent") snackbarModalComponent!: SnackbarModalComponent;

  /**
   * Get Is Admin Or Manager Flag
   */
  isAdminOrManager = false;

  /**
   * Get Sorting Order
   */
  sortingOrder = true;
  sortingKeyColumn = "fusingTypeName";
  /**
   * Get Fusing Type List
   */
  fusingTypesList: any[] = [];

  /**
   * Fusing Type Records Count
   */
  fusingTypeRecordsCount = 0;

  /**
   * Get Edit Fusing Type Details
   */
  editFusingTypeDetails: any;

  /**
   * Get Is Update Fusing Type Flag
   */
  isUpdateFusing = false;

  /**
   * Declaring variable to store district id
   * @type {*}
   * @memberof FusingTypeComponent
   */
  fusingTypeId: any;

  /**
   * Default Page Number
   */
  currentPage = 1;

  /**
   * Search Term
   */
  searchTerm = "";

  /**
   * Create Fusing Type Form Declaration
   */
  createFusingTypeForm!: FormGroup;

  /**
   * Get Fusing Type Form Validations
   */
  createFusingTypeValidation = this.validationService.createFusingType;

  /**
   * Get Patterns
   * @private
   */
  private patterns = this.validationService.patterns;

  /**
   * Creates an instance of FusingTypeComponent.
   * @param {Router} router
   * @param {LoaderService} loaderService
   * @param {ValidationService} validationService
   * @param {FormBuilder} formBuilder
   * @param {MastersService} mastersService
   */
  constructor(
    private router: Router,
    private loaderService: LoaderService,
    private validationService: ValidationService,
    private formBuilder: FormBuilder,
    private mastersService: MastersService,
    private location: Location
  ) {
    if (localStorage.getItem('userTypeId') == '1' || localStorage.getItem('userTypeId') == '4') {
      this.isAdminOrManager = true;
    }
  }

  /**
   * Life Cycle Hook Initialization
   */
  ngOnInit(): void {
    this.createFusingTypeFormValidations();
    this.getFusingList();
  }

  /**
   * This method is used to get the Fusing Type list
   */
  getFusingList() {
    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    /* To call the service to get the Fusing Type list */
    this.mastersService.getFusingTypes().subscribe({
      next: (res: any) => {
        /* Disable the loader if response is success */
        this.loaderService.isLoading.next(false);
        this.fusingTypesList = res.result;
        this.fusingTypeRecordsCount = this.fusingTypesList.length;
      },
      error: (err: any) => {
        this.loaderService.isLoading.next(false);
        this.fusingTypesList = [];
        this.fusingTypeRecordsCount = 0;
      },
    });
  }

  /**
   * This method used to reset Fusing Type form
   */
  resetFusingForm() {
    this.createFusingTypeForm.reset();
    this.editFusingTypeDetails = "";
    this.isUpdateFusing = false;
    this.createFusingTypeFormValidations();
    this.createFusingTypeFormControls["FusingTypeName"].setValue("");
  }

  /**
   * Initialize Create Fusing Type Validations
   */
  createFusingTypeFormValidations() {
    this.createFusingTypeForm = this.formBuilder.group({
      FusingTypeName: [
        this.editFusingTypeDetails?.fusingTypeName || "",
        [
          Validators.required,
          Validators.minLength(
            this.createFusingTypeValidation.FusingTypeName.minLength
          ),
          Validators.maxLength(
            this.createFusingTypeValidation.FusingTypeName.maxLength
          ),
          Validators.pattern(this.patterns.alphaNumeric),
        ],
      ],
    });
  }

  /**
   * Create Fusing Type Controls Initialized
   * @readonly
   */
  get createFusingTypeFormControls() {
    return this.createFusingTypeForm.controls;
  }

  /**
   * This method is used to get the Fusing Type details by clicking on edit icon
   * @param {*} fusing
   */
  onClickEditFusing(fusing: any) {
    this.fusingTypeId = fusing.fusingTypeId;
    this.mastersService.getFusingTypeById(fusing.fusingTypeId).subscribe({
      next: (res: any) => {
        this.isUpdateFusing = true;
        this.editFusingTypeDetails = res.result;
        this.createFusingTypeFormValidations();
      },
      error: (err: any) => {
        this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
      },
    });
  }

  /**
   * This method is used to change the pagination controls
   * @param {*} event
   */
  onPageChange(event: any) {
    this.currentPage = event;
  }

  /**
   * This method is used to show search results
   */
  navigateToSearchResult() {
    this.currentPage = 1;
  }

  /**
   * This method is used to submit the Fusing Type Form
   * @return {*}
   */
  onFusingFormSubmit(): any {
    /** This will return false if form fields are invalid and stop the service calling */
    if (this.createFusingTypeForm.invalid) {
      this.validationService.validateAllFormFields(this.createFusingTypeForm);
      return;
    }

    /* Prepare the request payload */
    const obj = {
      fusingTypeName: this.createFusingTypeForm.controls["FusingTypeName"].value?.trim() || "",
    };

    /* Prepare the request payload */
    const isUpdateFusing = {
      fusingTypeId: this.fusingTypeId || "",
      fusingTypeName: this.createFusingTypeForm.controls["FusingTypeName"].value?.trim() || "",
      status: "1",
    };

    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    if (!this.isUpdateFusing) {
      /* To call the service to add the color*/
      this.mastersService.addFusingType(obj).subscribe({
        next: (res: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', '');
          this.getFusingList();
          this.resetFusingForm();
        },
        error: (err: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
        },
      });
    } else {
      /* To call the service to update the color*/
      this.mastersService.editFusingType(isUpdateFusing).subscribe({
        next: (res: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', '');
          this.getFusingList();
          this.resetFusingForm();
        },
        error: (err: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
        },
      });
    }
  }

  /**
   * This method is used to sort column
   * @param key : value of which column based we need to sort the rows
   */
  sort(key: string) {
    const componentName = this.location.path();
    let value = key;
    sessionStorage.setItem(`${componentName}_property`, value);
    this.sortingKeyColumn = key;

    if (sessionStorage.getItem(componentName + "_order") == "desc") {
      this.sortingOrder = false;
    } else {
      this.sortingOrder = true;
    }
  }

}
