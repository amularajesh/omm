import { Location } from "@angular/common";
import { Component, OnInit, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";

import { SnackbarModalComponent } from "src/app/core/Dialogues/snackbar-modal/snackbar-modal.component";
import { LoaderService } from "src/app/core/Services/loader.service";
import { MastersService } from "src/app/core/Services/masters.service";
import { ValidationService } from "src/app/core/Services/validation.service";

/**
 * Company Component
 * @export
 * @class CompanyComponent
 * @implements {OnInit}
 */
@Component({
  selector: 'app-company',
  templateUrl: './company.component.html',
  styleUrls: ['./company.component.scss']
})
export class CompanyComponent implements OnInit {
  /**
   * Get Snackbar Modal Component
   * @type {SnackbarModalComponent}
   */
  @ViewChild("snackbarModalComponent") snackbarModalComponent!: SnackbarModalComponent;

  /**
   * Get Is Admin Or Manager Flag
   */
  isAdminOrManager = false;

  /**
   * Records Count
   */
  recordsCount = 0;

  /**
   * Get Company List
   */
  companiesList: any[] = [];

  /**
   * District Data
   */
  districtData: any;

  /**
   * Declare variable to know edit click or not
   */
  isUpdateCompany = false;

  /**
   * Declaring variable to store company id
   * @type {*}
   */
  companyId: any;

  /**
   * Default Sorting Key
   */
  sortingKeyColumn = "companyName";

  /**
   * Default Sort Order
   */
  sortingOrder = true;

  /**
   * Default Page Number
   */
  currentPage = 1;

  /**
   * Search Term
   */
  searchTerm = "";

  /**
   * Create company Form Declaration
   */
  createCompanyForm!: FormGroup;

  /**
   * Get company Form Validations
   */
  createCompanyValidation = this.validationService.createCompany;

  /**
   * Selected company
   */
  selectedDistrict = "";
  selectedDistrictId: any;

  /**
   * Creates an instance of CompanyComponent.
   * @param {Router} router
   * @param {Location} location
   * @param {LoaderService} loaderService
   * @param {ValidationService} validationService
   * @param {FormBuilder} formBuilder
   * @param {MastersService} mastersService
   */
  constructor(
    private router: Router,
    private location: Location,
    private loaderService: LoaderService,
    private validationService: ValidationService,
    private formBuilder: FormBuilder,
    private mastersService: MastersService
  ) {
    if (localStorage.getItem('userTypeId') == '1' || localStorage.getItem('userTypeId') == '4') {
      this.isAdminOrManager = true;
    }
  }

  /**
   * Life Cycle Hook Initialization
   */
  ngOnInit(): void {
    this.createCompanyFormValidations();
    this.getCompaniesList();
  }

  /**
   * This method is used to get companies list
   */
  getCompaniesList() {
    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    /* To call the service to get the companies list */
    this.mastersService.getCompanies().subscribe({
      next: (res: any) => {
        /* Disable the loader if response is success */
        this.loaderService.isLoading.next(false);
        this.companiesList = res.result;
        this.recordsCount = this.companiesList.length;
      },
      error: (err: any) => {
        /* Disable the loader if response is Error */
        this.loaderService.isLoading.next(false);
        this.companiesList = [];
        this.recordsCount = 0;
      }
    });
  }

  /**
   * This method used to reset company form
   */
  resetCompanyForm() {
    this.createCompanyForm.reset();
    this.isUpdateCompany = false;
    this.createCompanyFormValidations();
    this.createCompanyFormControls['CompanyName'].setValue('');
    this.createCompanyFormControls['place'].setValue('');
  }

  /**
   * Initialize Create Company Validations
   */
  createCompanyFormValidations() {
    this.createCompanyForm = this.formBuilder.group({
      CompanyName: [
        this.districtData?.companyName || "",
        [
          Validators.required,
          Validators.minLength(this.createCompanyValidation.CompanyName.minLength),
          Validators.maxLength(this.createCompanyValidation.CompanyName.maxLength)
        ]
      ],
      place: [
        this.districtData?.place || "",
        [
          Validators.required,
          Validators.minLength(this.createCompanyValidation.place.minLength),
          Validators.maxLength(this.createCompanyValidation.place.maxLength)
        ]
      ]
    });
  }

  /**
   * Create company Controls Initialized
   * @readonly
   */
  get createCompanyFormControls() {
    return this.createCompanyForm.controls;
  }

  /**
   * This Method Used To Navigation based on selection of privilege
   * @param {*} event
   */
  navigateToRoute(event: any) {
    const selectedValue = event.target.value;
    if (selectedValue === "Unit") {
      this.router.navigate(["/admin/masters/unitname"]);
    } else if (selectedValue === "Company") {
      this.router.navigate(["/admin/masters/company"]);
    }
  }

  /**
   * This method is used edit Company
   * @param {*} company
   */
  onClickEditUnit(company: any) {
    this.companyId = company.companyId;
    this.mastersService.getCompanyById(company.companyId).subscribe({
      next: (res: any) => {
        this.isUpdateCompany = true;
        this.districtData = res.result;
        this.createCompanyFormValidations();
      },
      error: (err: any) => {
        this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
      },
    });
  }

  /**
   * This method is used to sort column
   * @param key : value of which column based we need to sort the rows
   */
  sort(key: string) {
    const componentName = this.location.path();
    let value = key;
    sessionStorage.setItem(`${componentName}_property`, value);
    this.sortingKeyColumn = key;
    if (sessionStorage.getItem(componentName + "_order") == "desc") {
      this.sortingOrder = false;
    } else {
      this.sortingOrder = true;
    }
  }

  /**
   * This method is used to change the pagination controls
   * @param {*} event
   */
  onPageChange(event: any) {
    this.currentPage = event;
  }

  /**
   * Create company Form Submit
   * @return {*}
   */
  onCreateCompanyFormSubmit(): any {
    /** This will return false if form fields are invalid and stop the service calling */
    if (this.createCompanyForm.invalid) {
      this.validationService.validateAllFormFields(this.createCompanyForm);
      return;
    }

    const obj = {
      companyName: this.createCompanyForm.controls["CompanyName"].value?.trim() || "",
      place: this.createCompanyForm.controls["place"].value || "",
    };

    const isUpdateCompany = {
      companyId: this.companyId || "",
      companyName: this.createCompanyForm.controls["CompanyName"].value?.trim() || "",
      place: this.createCompanyForm.controls["place"].value || "",
      status: true,
    };

    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    if (this.isUpdateCompany === false) {
      //method to send payload to service for add company
      this.mastersService.addCompany(obj).subscribe({
        next: (res: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', '');
          this.getCompaniesList()
          this.resetCompanyForm();
        },
        error: (err: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
        }
      });
    } else {
      //method to send payload to service for update company
      this.mastersService.editCompany(isUpdateCompany).subscribe({
        next: (res: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', '');
          this.getCompaniesList();
          this.resetCompanyForm();
        },
        error: (err: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
        }
      });
    }
  }

  /**
   * This method is used to show search results
   */
  navigateToSearchResult() {
    this.currentPage = 1;
  }
}
