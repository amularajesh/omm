import { Location } from "@angular/common";
import { Component, OnInit, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";

import { SnackbarModalComponent } from "src/app/core/Dialogues/snackbar-modal/snackbar-modal.component";
import { LoaderService } from "src/app/core/Services/loader.service";
import { MastersService } from "src/app/core/Services/masters.service";
import { ValidationService } from "src/app/core/Services/validation.service";

/**
 * Unit Name Component
 * @export
 * @class UnitNameComponent
 * @implements {OnInit}
 */
@Component({
  selector: 'app-unit-name',
  templateUrl: './unit-name.component.html',
  styleUrls: ['./unit-name.component.scss']
})
export class UnitNameComponent implements OnInit {
  /**
   * Get Snackbar Modal Component
   * @type {SnackbarModalComponent}
   */
  @ViewChild("snackbarModalComponent") snackbarModalComponent!: SnackbarModalComponent;

  /**
   * Get Is Admin Or Manager Flag
   */
  isAdminOrManager = false;

  /**
   * Get Unit Names List
   * @type {*}
   */
  unitNamesList: any;

  /**
   * Get Unit Name Details
   * @type {*}
   */
  unitNameDetails: any;

  /**
   * Records Count
   */
  recordsCount = 0;

  /**
   * Declare Update Unit Name Flag
   */
  updateUnit = false;

  /**
   * Get Unit Types List
   * @type {*}
   */
  unitTypesList: any;

  /**
   * Default Page Number
   */
  currentPage = 1;

  /**
   * Default Sorting Key
   */
  sortingKeyColumn = "unitType";

  /**
   * Default Sort Order
   */
  sortingOrder = true;

  /**
   * Search Term
   */
  searchTerm = "";

  /**
   * Create Unit Name Form Declaration
   * @type {FormGroup}
   */
  createUnitForm!: FormGroup;

  /**
   * Get Unit Name Form Validations
   */
  createUnitValidation = this.validationService.createUnit;

  /**
   * Creates an instance of UnitNameComponent.
   * @param {Location} location
   * @param {LoaderService} loaderService
   * @param {ValidationService} validationService
   * @param {FormBuilder} formBuilder
   * @param {MastersService} mastersService
   */
  constructor(
    private location: Location,
    private loaderService: LoaderService,
    private validationService: ValidationService,
    private formBuilder: FormBuilder,
    private mastersService: MastersService
  ) {
    if (localStorage.getItem('userTypeId') == '1' || localStorage.getItem('userTypeId') == '4') {
      this.isAdminOrManager = true;
    }
  }

  /**
   * Life Cycle Hook Initialization
   */
  ngOnInit(): void {
    this.createUnitFormValidations();
    this.getUnitNamesList();
    this.getUnitTypesList();
  }

  /**
    * This method is used to get the unit types List
    */
  getUnitTypesList() {
    this.mastersService.getUnitTypes().subscribe({
      next: (res: any) => {
        this.unitTypesList = res.result;
      },
      error: () => {
        this.unitTypesList = [];
      },
    });
  }

  /**
   * This method is used to get unit names list
   */
  getUnitNamesList() {
    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    /* To call the service to get the unit names list */
    this.mastersService.getUnits().subscribe({
      next: (res: any) => {
        /* Disable the loader if response is success */
        this.loaderService.isLoading.next(false);
        this.unitNamesList = res.result;
        this.recordsCount = this.unitNamesList.length;
      },
      error: () => {
        /* Disable the loader if response is error */
        this.loaderService.isLoading.next(false);
        this.unitNamesList = [];
        this.recordsCount = 0;
      }
    });
  }

  /**
   * This method is used to reset unit name form
   */
  onResetUnitForm() {
    this.createUnitForm.reset();
    this.updateUnit = false;
    this.unitNameDetails = '';
    this.createUnitFormValidations();
  }

  /**
   * Initialize Create Unit Name Validations
   */
  createUnitFormValidations() {
    this.createUnitForm = this.formBuilder.group({
      UnitName: [
        this.unitNameDetails?.unitNames || "",
        [
          Validators.required,
          Validators.minLength(this.createUnitValidation.UnitName.minLength),
          Validators.maxLength(this.createUnitValidation.UnitName.maxLength)
        ]
      ],
      PanNumber: [
        this.unitNameDetails?.panNumber || "",
        [
          Validators.required,
          Validators.minLength(this.createUnitValidation.PanNumber.minLength),
          Validators.maxLength(this.createUnitValidation.PanNumber.maxLength),
          Validators.pattern('^[A-Z0-9]{10}$')
        ]
      ],
      unitTypeSelect: [this.unitNameDetails?.unitTypeId || "", [Validators.required]]
    });
  }

  /**
   * Create Unit Name Controls Initialized
   * @readonly
   */
  get createUnitFormControls() {
    return this.createUnitForm.controls;
  }

  /**
   * This method will fired when user selects the unit type
   * @param {*} event
   */
  onChangeUnitType(event: any) {
    if (event.target.value == '') {
      this.createUnitFormControls['unitTypeSelect'].markAsUntouched({ onlySelf: true });
    }
  }

  /**
   * This method is used to edit unit name
   * @param {*} unitName
   */
  onClickEditUnitName(unitName: any) {
    this.mastersService.getUnitNameById(unitName.unitNameId).subscribe({
      next: (res: any) => {
        this.updateUnit = true;
        this.unitNameDetails = res.result;
        this.createUnitFormValidations();
      },
      error: (err: any) => {
        this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message || err, '', '', '');
      }
    });
  }

  /**
   * This method is used to sort column
   * @param key : value of which column based we need to sort the rows
   */
  sort(key: string) {
    const componentName = this.location.path();
    let value = key;
    sessionStorage.setItem(`${componentName}_property`, value);
    this.sortingKeyColumn = key;
    if (sessionStorage.getItem(componentName + "_order") == "desc") {
      this.sortingOrder = false;
    } else {
      this.sortingOrder = true;
    }
  }

  /**
   * This method is used to change the pagination controls
   * @param {*} event
   */
  onPageChange(event: any) {
    this.currentPage = event;
  }

  /**
   * This method is used to show search results
   */
  navigateToSearchResult() {
    this.currentPage = 1;
  }

  /**
   * This method is used to submit the create unit name form
   */
  onSubmitCreateUnitForm(): any {
    /** This will return false if form fields are invalid and stop the service calling */
    if (this.createUnitForm.invalid) {
      this.validationService.validateAllFormFields(this.createUnitForm);
      return;
    }

    /* Prepare the request payload */
    const obj = {
      unitNames: this.createUnitForm.controls["UnitName"].value?.trim() || "",
      PanNumber: this.createUnitForm.controls["PanNumber"].value?.trim() || "",
      unitTypeId: this.createUnitFormControls['unitTypeSelect'].value,
    };

    /* Prepare the request payload */
    const updateUnitNameObj = {
      unitNameId: this.unitNameDetails?.unitNameId,
      unitTypeId: this.createUnitFormControls['unitTypeSelect'].value,
      unitNames: this.createUnitForm.controls["UnitName"].value?.trim() || "",
      PanNumber: this.createUnitForm.controls["PanNumber"].value?.trim() || "",
      status: true
    };

    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    if (this.updateUnit === false) {

      /* To call the service to add unit name by passing obj*/
      this.mastersService.addUnit(obj).subscribe({
        next: (res: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);
          this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', '');
          this.getUnitNamesList()
          this.onResetUnitForm();
        },
        error: (err: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);
          this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message || err, '', '', '');
        },
      });
    } else {
      /* To call the service to edit unit name by passing obj*/
      this.mastersService.editUnitName(updateUnitNameObj).subscribe({
        next: (res: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);
          this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', '');
          this.getUnitNamesList();
          this.onResetUnitForm();
        },
        error: (err: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);
          this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message || err, '', '', '');
        },
      });
    }
  }
}
