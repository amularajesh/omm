import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UnitNameComponent } from './unit-name.component';

describe('UnitNameComponent', () => {
  let component: UnitNameComponent;
  let fixture: ComponentFixture<UnitNameComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UnitNameComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UnitNameComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
