import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatTooltipModule } from '@angular/material/tooltip';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { AutosizeModule } from 'ngx-autosize';
import { NgxPaginationModule } from 'ngx-pagination';

import { ComponentModule } from 'src/app/core/Modules/component.module';
import { CompanyUnitsRoutingModule } from './company-units-routing.module';
import { CompanyUnitsComponent } from './company-units.component';
import { CompanyComponent } from './company/company.component';
import { UnitNameComponent } from './unit-name/unit-name.component';

/**
 * Company Units Module
 * @export
 * @class CompanyUnitsModule
 */
@NgModule({
  declarations: [
    CompanyUnitsComponent,
    CompanyComponent,
    UnitNameComponent
  ],
  imports: [
    CommonModule,
    CompanyUnitsRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    MatTooltipModule,
    AutosizeModule,
    NgxPaginationModule,
    Ng2SearchPipeModule,
    ComponentModule
  ]
})
export class CompanyUnitsModule { }
