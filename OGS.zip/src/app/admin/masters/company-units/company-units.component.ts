import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { AppService } from 'src/app/core/Services/app.service';

/**
 * Company Units Component
 * @export
 * @class CompanyUnitsComponent
 * @implements {OnInit}
 */
@Component({
  selector: 'app-company-units',
  templateUrl: './company-units.component.html',
  styleUrls: ['./company-units.component.scss']
})
export class CompanyUnitsComponent implements OnInit {
  /**
   * Get Company DropdownItems
   * @type {*}
   */
  companyDropdownItems: any;

  /**
   * Creates an instance of CompanyUnitsComponent.
   * @param {Router} router
   * @param {AppService} appService
   */
  constructor(
    private router: Router,
    private appService: AppService
  ) {
    this.appService.menuItems.subscribe((items: any) => {
      this.companyDropdownItems = items
        .filter((menu: any) => menu.menuName === 'Masters')
        .map((menu: any) => menu.groupList
          .filter((group: any) => group.groupingName === 'Company/Units')
          .flatMap((group: any) => group.subMenuList
            .filter((submenu: any) => submenu.checked === true)
          )
        ).reduce((acc: any, current: any) => acc.concat(current), []);
      if (this.companyDropdownItems.length > 0) {
        if (document.getElementById('companySelect')) {
          const selectedEle = document.getElementById('companySelect') as HTMLSelectElement;
          selectedEle.value = this.companyDropdownItems[0].submenuName;
        }
        if (this.router.routerState.snapshot.url === '/admin/home') {
          this.router.navigate(['/admin/home']);
        } else {
          this.onSelectNavigate(this.companyDropdownItems[0].submenuName);
        }
      }
    });
  }

  /**
   * Life Cycle Hook Initilization
   */
  ngOnInit(): void { }

  /**
   * This method is used to navigate to the selected company dropdown item
   * @param {*} event
   */
  onSelectNavigate(event: any) {
    const selectedValue = event?.target ? event.target.value : event;
    const selectedElement = this.companyDropdownItems.filter((item: any) => item.submenuName === selectedValue);
    this.router.navigate([selectedElement[0].link]);
  }
}
