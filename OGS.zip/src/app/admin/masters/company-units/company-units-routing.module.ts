import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { CompanyUnitsComponent } from './company-units.component';
import { CompanyComponent } from './company/company.component';
import { UnitNameComponent } from './unit-name/unit-name.component';

const routes: Routes = [
  {
    path: '', component: CompanyUnitsComponent,
    children: [
      { path: '', component: CompanyUnitsComponent, pathMatch: 'full' },
      { path: 'company', component: CompanyComponent },
      { path: 'unitname', component: UnitNameComponent }
    ]
  }
];

/**
 * Company Units Routing Module
 * @export
 * @class CompanyUnitsRoutingModule
 */
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CompanyUnitsRoutingModule { }
