import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatTooltipModule } from '@angular/material/tooltip';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { AutosizeModule } from 'ngx-autosize';
import { NgxPaginationModule } from 'ngx-pagination';

import { ComponentModule } from 'src/app/core/Modules/component.module';
import { AccessoriesComponent } from './accessories/accessories.component';
import { CollarComponent } from './collar/collar.component';
import { ColourComponent } from './colour/colour.component';
import { DressItemRoutingModule } from './dress-item-routing.module';
import { DressItemSizesSizesComponent } from './dress-item-sizes/dress-item-sizes.component';
import { DressItemComponent } from './dress-item.component';
import { DressItemsComponent } from './dress-items/dress-items.component';
import { ModelComponent } from './model/model.component';
import { PrintTypesComponent } from './print-types/print-types.component';
import { QualityComponent } from './quality/quality.component';
import { SizeComponent } from './size/size.component';

/**
 * Dress Item Module
 * @export
 * @class DressItemModule
 */
@NgModule({
  declarations: [
    DressItemComponent,
    ColourComponent,
    SizeComponent,
    DressItemsComponent,
    DressItemSizesSizesComponent,
    QualityComponent,
    ModelComponent,
    AccessoriesComponent,
    CollarComponent,
    PrintTypesComponent
  ],
  imports: [
    CommonModule,
    DressItemRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    MatTooltipModule,
    AutosizeModule,
    NgxPaginationModule,
    Ng2SearchPipeModule,
    ComponentModule
  ]
})
export class DressItemModule { }
