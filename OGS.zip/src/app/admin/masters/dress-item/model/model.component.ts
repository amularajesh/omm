import { Location } from "@angular/common";
import { Component, OnInit, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";

import { SnackbarModalComponent } from "src/app/core/Dialogues/snackbar-modal/snackbar-modal.component";
import { LoaderService } from "src/app/core/Services/loader.service";
import { MastersService } from "src/app/core/Services/masters.service";
import { ValidationService } from "src/app/core/Services/validation.service";

/**
 * Model Component
 * @export
 * @class ModelComponent
 */
@Component({
  selector: "app-model",
  templateUrl: "./model.component.html",
  styleUrls: ["./model.component.scss"],
})
export class ModelComponent implements OnInit {
  /**
   * Get Snackbar Modal Component
   * @type {SnackbarModalComponent}
   */
  @ViewChild("snackbarModalComponent") snackbarModalComponent!: SnackbarModalComponent;

  /**
   * Get Is Admin Or Manager Flag
   */
  isAdminOrManager = false;

  /**
   * Default Sorting Key
   */
  sortingKeyColumn = "dressItem";

  /**
   * Default Sort Order
   */
  sortingOrder = true;

  /**
   * Get Modals List
   * @type {*}
   */
  modalsList: any;

  /**
   * Get Dress Items List
   * @type {*}
   */
  dressItemsList: any;

  /**
   * Get ImageUrl
   */
  imageUrl = "";

  /**
   * Get ImageFile
   */
  imageFile: any;

  modelData: any;

  /**
   * Records Count
   */
  recordsCount = 0;

  /**
   * Users List
   */
  unitsList: any[] = [];

  /**
   * District Data
   */
  modellistData: any;

  /**
   *Declare variable to know edit click or not
   * @type {boolean}
   * @memberof DistrictComponent
   */
  updateModel: boolean = false;

  /**
   * Declaring variable to store model id
   * @type {*}
   * @memberof DistrictComponent
   */
  unitTypeId: any;

  /**
   * Default Page Number
   */
  currentPage = 1;

  /**
   * Search Term
   */
  searchTerm = "";

  /**
   * Create model Form Declaration
   */
  createModelForm!: FormGroup;

  /**
   * Get model Form Validations
   */
  createModelValidation = this.validationService.createModel;

  /**
   * States List
   * @type {DistrictMode[]}
   */
  statesList: any;

  /**
   * Get Is Model Edit Flag
   */
  isModelEdit = false;

  /**
   * Get Edit Model Details
   */
  editModelDetails: any;

  /**
   * Selected model
   */
  selectedDistrict = "";
  selectedDistrictId: any;

  /**
   * Creates an instance of ModelComponent.
   * @param {LoaderService} loaderService
   * @param {ValidationService} validationService
   * @param {FormBuilder} formBuilder
   * @param {MastersService} mastersService
   */
  constructor(
    private loaderService: LoaderService,
    private validationService: ValidationService,
    private formBuilder: FormBuilder,
    private mastersService: MastersService,
    private location: Location
  ) {
    if (localStorage.getItem('userTypeId') == '1' || localStorage.getItem('userTypeId') == '4') {
      this.isAdminOrManager = true;
    }
  }

  /**
   * Life cycle hook Initialization
   */
  ngOnInit(): void {
    this.createModelFormValidations();
    this.getModelsList();
    this.getDressItemList();
  }

  /**
   * Initialize Create model Validations
   */
  createModelFormValidations() {
    this.createModelForm = this.formBuilder.group({
      ModelName: [
        this.editModelDetails?.modelName || "",
        [
          Validators.required,
          Validators.minLength(this.createModelValidation.ModelName.minLength),
          Validators.maxLength(this.createModelValidation.ModelName.maxLength),
        ],
      ],
      dressItemSelect: [
        this.editModelDetails?.dressItemId || "",
        [Validators.required],
      ],
      modelDescription: [this.editModelDetails?.description || ""],
      modelFile: [""],
    });
  }

  /**
   * Create model Controls Initialized
   * @readonly
   */
  get createModelFormControls() {
    return this.createModelForm.controls;
  }

  /**
   * This method is used to get the models List
   */
  getModelsList() {
    const obj = {
      modelName: "",
    };
    this.mastersService.getModels(obj).subscribe({
      next: (res: any) => {
        this.modalsList = res.result;
        this.recordsCount = this.modalsList.length;
      },
      error: (err: any) => {
        this.modalsList = [];
        this.recordsCount = 0;
      },
    });
  }

  /**
   * This method is used to get the states List
   */
  getDressItemList() {
    this.mastersService.getDressItems().subscribe({
      next: (res: any) => {
        this.dressItemsList = res.result;
      },
      error: (err: any) => {
        this.dressItemsList = [];
      },
    });
  }

  /**
   * This method will fired when user selects Dress Item
   * @param {*} event
   */
  DressItemChange(event: any) {
    if (event.target?.value === '') {
      this.createModelFormControls["dressItemSelect"].markAsUntouched({ onlySelf: true });
    }
  }

  /**
   * This method will fired when user uploads the file
   * @param {*} event
   */
  onImageSelected(event: any) {
    const selectedFile = event.target.files[0];
    if (selectedFile) {
      this.imageFile = selectedFile;
      const reader = new FileReader();
      reader.onload = (e: any) => {
        this.imageUrl = e.target.result;
      };
      reader.readAsDataURL(selectedFile);
    }
  }

  /**
   * This method used to reset model form
   */
  resetModelForm() {
    this.createModelForm.reset();
    this.editModelDetails = "";
    this.isModelEdit = false;
    this.createModelFormValidations();
  }

  /**
   * This method is used edit model
   * @param {*} model
   */
  onClickEditModel(model: any) {
    const obj = {
      modelName: model.modelName,
    };

    /* To call the service to get the dress Item Size Details by passing dressItemSizeId */
    this.mastersService.getModels(obj).subscribe({
      next: (res: any) => {
        this.isModelEdit = true;
        this.editModelDetails = res.result[0];
        this.createModelFormValidations();
      },
      error: (err: any) => {
        this.isModelEdit = false;
        this.editModelDetails = "";
        this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message || err, '', '', '');
      }
    });
  }

  /**
   * This method is used to change the pagination controls
   * @param {*} event
   */
  onPageChange(event: any) {
    this.currentPage = event;
  }

  /**
   * Create model Form Submit
   * @return {*}
   */
  onCreateModelFormSubmit(): any {
    /* This will return false if form fields are invalid and stop the service calling */
    if (this.createModelForm.invalid) {
      this.validationService.validateAllFormFields(this.createModelForm);
      return;
    }

    /* Prepare the request payload */

    const obj: any = {
      modelName: this.createModelFormControls["ModelName"].value?.trim(),
      dressItemId: this.createModelFormControls["dressItemSelect"].value,
      description: this.createModelFormControls["modelDescription"].value?.trim() || "",
      modelImage: this.imageUrl.split(",")[1] || "",
    };

    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    if (!this.isModelEdit) {

      /* To call the service to add the model by passing data object*/
      this.mastersService.addModel(obj).subscribe({
        next: (res: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', '');
          this.resetModelForm();
          this.getModelsList();
        },
        error: (err: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message || err, '', '', '');
        },
      });
    } else {
      obj["modelId"] = this.editModelDetails?.modelId;
      obj["status"] = this.editModelDetails?.status;

      /* To call the service to update the model by passing data object */
      this.mastersService.editModel(obj).subscribe({
        next: (res: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', '');
          this.editModelDetails = [];
          this.isModelEdit = false;
          this.resetModelForm();
          this.getModelsList();
        },
        error: (err: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message || err, '', '', '');
        },
      });
    }
  }

  /**
   * This method is used to show search results
   */
  navigateToSearchResult() {
    this.currentPage = 1;
  }
  /**
   * This method is used to sort column
   * @param key : value of which column based we need to sort the rows
   */
  sort(key: string) {
    const componentName = this.location.path();
    let value = key;
    sessionStorage.setItem(`${componentName}_property`, value);
    this.sortingKeyColumn = key;

    if (sessionStorage.getItem(componentName + "_order") == "desc") {
      this.sortingOrder = false;
    } else {
      this.sortingOrder = true;
    }
  }
}
