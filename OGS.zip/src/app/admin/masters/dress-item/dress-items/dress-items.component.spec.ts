import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DressItemsComponent } from './dress-items.component';

describe('DressItemsComponent', () => {
  let component: DressItemsComponent;
  let fixture: ComponentFixture<DressItemsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DressItemsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DressItemsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
