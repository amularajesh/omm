import { Location } from "@angular/common";
import { Component, OnInit, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";

import { SnackbarModalComponent } from "src/app/core/Dialogues/snackbar-modal/snackbar-modal.component";
import { StateMode } from "src/app/core/Modals/modals";
import { LoaderService } from "src/app/core/Services/loader.service";
import { MastersService } from "src/app/core/Services/masters.service";
import { ValidationService } from "src/app/core/Services/validation.service";

/**
 * Dress Items Component
 * @export
 * @class DressItemsComponent
 * @implements {OnInit}
 */
@Component({
  selector: "app-dress-items",
  templateUrl: "./dress-items.component.html",
  styleUrls: ["./dress-items.component.scss"],
})
export class DressItemsComponent implements OnInit {
  /**
   * Get Snackbar Modal Component
   * @type {SnackbarModalComponent}
   */
  @ViewChild("snackbarModalComponent") snackbarModalComponent!: SnackbarModalComponent;

  /**
   * Get Is Admin Or Manager Flag
   */
  isAdminOrManager = false;

  sortingOrder = true;
  sortingKeyColumn = "dressItemName";

  DressItem: any;

  isUpdateDressItem: boolean = false;

  /**
   * Records Count
   */
  recordsCount = 0;

  /**
   * dressItemsList
   */
  dressItemsList: any[] = [];

  /**
   * District Data
   */
  districtData: any;

  /**
   * Default Page Number
   */
  currentPage = 1;

  /**
   * Search Term
   */
  searchTerm = "";

  /**
   * Create district Form Declaration
   */
  createDressItemForm!: FormGroup;

  /**
   * Get district Form Validations
   */
  createDressItemValidation = this.validationService.createDressItem;

  /**
   * Get Patterns
   * @private
   */
  private patterns = this.validationService.patterns;

  /**
   * District mode List
   * @type {DistrictMode[]}
   */
  statesList: StateMode[] = [];

  /**
   * Selected district Role
   */
  selectedDistrictRole = "";

  selectedDistrictId: any;

  /**
   * Creates an instance of DressItemsComponent.
   * @param {ValidationService} validationService
   * @param {FormBuilder} formBuilder
   * @param {MastersService} mastersService
   * @param {Location} location
   * @param {LoaderService} loaderService
   */
  constructor(
    private validationService: ValidationService,
    private formBuilder: FormBuilder,
    private mastersService: MastersService,
    private location: Location,
    private loaderService: LoaderService
  ) {
    if (localStorage.getItem('userTypeId') == '1' || localStorage.getItem('userTypeId') == '4') {
      this.isAdminOrManager = true;
    }
  }

  /**
   * Life Cycle Hook Initialization
   */
  ngOnInit(): void {
    this.createDistrictFormValidations();
    this.getDressItems();
  }

  /**
   * This method is used to get Dress list
   */
  getDressItems() {
    this.mastersService.getDressItems().subscribe({
      next: (res: any) => {
        this.dressItemsList = res.result;
        this.recordsCount = this.dressItemsList.length;
      },
      error: (err: any) => {
        this.dressItemsList = [];
      },
    });
  }

  /**
   * This method used to reset district form
   */
  resetDressItem() {
    this.createDressItemForm.reset();
    this.createDistrictFormValidations();
    this.createDressItemForm.controls["DressItemName"].setValue("");
    this.createDressItemForm.controls["Points"].setValue("");
    this.createDressItemForm.controls["PointsFlag"].setValue("");
    this.isUpdateDressItem = false;
  }

  /**
   * Initialize Create district Validations
   */
  createDistrictFormValidations() {
    this.createDressItemForm = this.formBuilder.group({
      DressItemName: [
        this.DressItem?.dressItemName || "",
        [
          Validators.required,
          Validators.minLength(
            this.createDressItemValidation.DressItemName.minLength
          ),
          Validators.maxLength(
            this.createDressItemValidation.DressItemName.maxLength
          ),
        ],
      ],
      Points: [
        this.DressItem?.dressItemPoints || "",
        [
          Validators.required,
          Validators.minLength(this.createDressItemValidation.Points.minLength),
          Validators.maxLength(this.createDressItemValidation.Points.maxLength),
          Validators.pattern(this.patterns.points),
        ],
      ],
      PointsFlag: [this.DressItem?.pointsFlag || false],
      globalPointsFlag: [false],
    });
  }

  /**
   * Create district Controls Initialized
   * @readonly
   */
  get createDressItemFormControls() {
    return this.createDressItemForm.controls;
  }

  /**
   * This method is used edit district
   */
  onClickEditUser(user: any) {
    this.districtData = user;
    this.isUpdateDressItem = true;
    this.mastersService.getDressItemById(user.dressItemId).subscribe({
      next: (res: any) => {
        this.DressItem = res.result;
        this.createDistrictFormValidations();
      },
      error: (err: any) => {
        this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
      },
    });
  }

  /**
   * This method is used to change the pagination controls
   * @param {*} event
   */
  onPageChange(event: any) {
    this.currentPage = event;
  }

  /**
   * Dress Item Form Submit
   */
  onDressItemFormSubmit() {
    /** This will return false if form fields are invalid and stop the service calling */
    if (this.createDressItemForm.invalid) {
      this.validationService.validateAllFormFields(this.createDressItemForm);
      return;
    }

    const obj = {
      dressItemId: 0,
      dressItemName: this.createDressItemForm.controls["DressItemName"].value?.trim(),
      dressItemPoints: Number(this.createDressItemForm.controls["Points"].value),
      pointsFlag: this.createDressItemForm.controls["PointsFlag"].value,
      status: 0,
    };

    const isUpdateDressItem = {
      dressItemId: this.DressItem?.dressItemId,
      dressItemName: this.createDressItemForm.controls["DressItemName"].value?.trim(),
      dressItemPoints: Number(this.createDressItemForm.controls["Points"].value),
      pointsFlag: this.createDressItemForm.controls["PointsFlag"].value,
      status: 1,
    };

    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    if (!this.isUpdateDressItem) {
      this.mastersService.addDressItem(obj).subscribe({
        next: (res: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', '');
          this.getDressItems();
          this.resetDressItem();
        },
        error: (err: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
        },
      });
    } else {
      this.mastersService.editDressItem(isUpdateDressItem).subscribe({
        next: (res: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', '');
          this.getDressItems();
          this.resetDressItem();
        },
        error: (err: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
        },
      });
    }
  }

  /**
   * This method is used to show search results
   */
  navigateToSearchResult() {
    this.currentPage = 1;
  }

  /**
   * Method to reset global points flag
   */
  resetGlobalFlag() { }

  /**
   * Method to update global points flag
   */
  updateGlobalFlag() {
    const check = {
      checked: this.createDressItemForm.controls["globalPointsFlag"].value,
    };

    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    this.mastersService.globalPointUpdate(check).subscribe({
      next: (res: any) => {
        /* Disable the loader */
        this.loaderService.isLoading.next(false);

        this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', '');
        this.resetDressItem();
      },
      error: (err: any) => {
        /* Disable the loader */
        this.loaderService.isLoading.next(false);

        this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
      },
    });
  }

  /**
   * This method is used to sort column
   * @param key : value of which column based we need to sort the rows
   */
  sort(key: string) {
    const componentName = this.location.path();
    let value = key;
    sessionStorage.setItem(`${componentName}_property`, value);
    this.sortingKeyColumn = key;
    if (sessionStorage.getItem(componentName + "_order") == "desc") {
      this.sortingOrder = false;
    } else {
      this.sortingOrder = true;
    }
  }
}
