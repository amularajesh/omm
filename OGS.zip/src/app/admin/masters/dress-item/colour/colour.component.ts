import { Location } from "@angular/common";
import { Component, OnInit, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";

import { SnackbarModalComponent } from "src/app/core/Dialogues/snackbar-modal/snackbar-modal.component";
import { LoaderService } from "src/app/core/Services/loader.service";
import { MastersService } from "src/app/core/Services/masters.service";
import { ValidationService } from "src/app/core/Services/validation.service";

/**
 * Colour Component
 * @export
 * @class ColourComponent
 * @implements {OnInit}
 */
@Component({
  selector: "app-colour",
  templateUrl: "./colour.component.html",
  styleUrls: ["./colour.component.scss"],
})
export class ColourComponent implements OnInit {
  /**
   * Get Snackbar Modal Component
   * @type {SnackbarModalComponent}
   */
  @ViewChild("snackbarModalComponent") snackbarModalComponent!: SnackbarModalComponent;

  /**
   * Get Is Admin Or Manager Flag
   */
  isAdminOrManager = false;

  sortingOrder = true;
  sortingKeyColumn = "colourName";
  /**
   * Get Colours List
   */
  coloursList: any[] = [];

  /**
   * Colours Records Count
   */
  coloursRecordsCount = 0;

  /**
   * Get Edit Colour Details
   */
  editColourDetails: any;

  /**
   * Get Is Update Colour Flag
   */
  isUpdateColour = false;

  /**
   * Declaring variable to store district id
   * @type {*}
   * @memberof DistrictComponent
   */
  colourId: any;

  /**
   * Default Page Number
   */
  currentPage = 1;

  /**
   * Search Term
   */
  searchTerm = "";

  /**
   * Create district Form Declaration
   */
  createColourForm!: FormGroup;

  /**
   * Get district Form Validations
   */
  createColourValidation = this.validationService.createColour;

  /**
   * Get Patterns
   * @private
   */
  private patterns = this.validationService.patterns;

  /**
   * Creates an instance of ColourComponent.
   * @param {LoaderService} loaderService
   * @param {ValidationService} validationService
   * @param {FormBuilder} formBuilder
   * @param {MastersService} mastersService
   * @param {Location} location
   */
  constructor(
    private loaderService: LoaderService,
    private validationService: ValidationService,
    private formBuilder: FormBuilder,
    private mastersService: MastersService,
    private location: Location
  ) {
    if (localStorage.getItem('userTypeId') == '1' || localStorage.getItem('userTypeId') == '4') {
      this.isAdminOrManager = true;
    }
  }

  /**
   * Life Cycle Hook Initialization
   */
  ngOnInit(): void {
    this.createColourFormValidations();
    this.getColoursList();
  }

  /**
   * This method is used to get the colours list
   */
  getColoursList() {
    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    /* To call the service to get the colors list */
    this.mastersService.getColours().subscribe({
      next: (res: any) => {
        /* Disable the loader if response is success */
        this.loaderService.isLoading.next(false);
        this.coloursList = res.result;
        this.coloursRecordsCount = this.coloursList.length;
      },
      error: (err: any) => {
        this.loaderService.isLoading.next(false);
        this.coloursList = [];
        this.coloursRecordsCount = 0;
      },
    });
  }

  /**
   * This method used to reset colors form
   */
  resetColorsForm() {
    this.createColourForm.reset();
    this.editColourDetails = "";
    this.isUpdateColour = false;
    this.createColourFormValidations();
    this.createColourFormControls["ColourName"].setValue("");
  }

  /**
   * Initialize Create Company Validations
   */
  createColourFormValidations() {
    this.createColourForm = this.formBuilder.group({
      ColourName: [
        this.editColourDetails?.colourName || "",
        [
          Validators.required,
          Validators.minLength(
            this.createColourValidation.ColourName.minLength
          ),
          Validators.maxLength(
            this.createColourValidation.ColourName.maxLength
          ),
          Validators.pattern(this.patterns.name),
        ],
      ],
    });
  }

  /**
   * Create company Controls Initialized
   * @readonly
   */
  get createColourFormControls() {
    return this.createColourForm.controls;
  }

  /**
   * This method is used to get the colour details by clicking on edit icon
   * @param {*} colour
   */
  onClickEditColour(colour: any) {
    this.colourId = colour.colourId;
    this.mastersService.getColourById(colour.colourId).subscribe({
      next: (res: any) => {
        this.isUpdateColour = true;
        this.editColourDetails = res.result;
        this.createColourFormValidations();
      },
      error: (err: any) => {
        this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
      },
    });
  }

  /**
   * This method is used to change the pagination controls
   * @param {*} event
   */
  onPageChange(event: any) {
    this.currentPage = event;
  }

  /**
   * This method is used to show search results
   */
  navigateToSearchResult() {
    this.currentPage = 1;
  }

  /**
   * This method is used to submit the Color Form
   * @return {*}
   */
  onColorFormSubmit(): any {
    /** This will return false if form fields are invalid and stop the service calling */
    if (this.createColourForm.invalid) {
      this.validationService.validateAllFormFields(this.createColourForm);
      return;
    }

    /* Prepare the request payload */
    const obj = {
      colourName: this.createColourForm.controls["ColourName"].value?.trim() || "",
    };

    /* Prepare the request payload */
    const isUpdateColour = {
      colourId: this.colourId || "",
      colourName: this.createColourForm.controls["ColourName"].value?.trim() || "",
      status: "1",
    };

    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    if (!this.isUpdateColour) {
      /* To call the service to add the color*/
      this.mastersService.addColour(obj).subscribe({
        next: (res: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', '');
          this.getColoursList();
          this.resetColorsForm();
        },
        error: (err: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
        },
      });
    } else {
      /* To call the service to update the color*/
      this.mastersService.editColour(isUpdateColour).subscribe({
        next: (res: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', '');
          this.getColoursList();
          this.resetColorsForm();
        },
        error: (err: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
        },
      });
    }
  }

  /**
   * This method is used to sort column
   * @param key : value of which column based we need to sort the rows
   */
  sort(key: string) {
    const componentName = this.location.path();
    let value = key;
    sessionStorage.setItem(`${componentName}_property`, value);
    this.sortingKeyColumn = key;

    if (sessionStorage.getItem(componentName + "_order") == "desc") {
      this.sortingOrder = false;
    } else {
      this.sortingOrder = true;
    }
  }
}
