import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AccessoriesComponent } from './accessories/accessories.component';
import { CollarComponent } from './collar/collar.component';
import { ColourComponent } from './colour/colour.component';
import { DressItemSizesSizesComponent } from './dress-item-sizes/dress-item-sizes.component';
import { DressItemComponent } from './dress-item.component';
import { DressItemsComponent } from './dress-items/dress-items.component';
import { ModelComponent } from './model/model.component';
import { PrintTypesComponent } from './print-types/print-types.component';
import { QualityComponent } from './quality/quality.component';
import { SizeComponent } from './size/size.component';

const routes: Routes = [
  {
    path: '', component: DressItemComponent,
    children: [
      { path: '', component: DressItemComponent, pathMatch: 'full' },
      { path: 'colour', component: ColourComponent },
      { path: 'size', component: SizeComponent },
      { path: 'dressitems', component: DressItemsComponent },
      { path: 'dressitemsizes', component: DressItemSizesSizesComponent },
      { path: 'quality', component: QualityComponent },
      { path: 'model', component: ModelComponent },
      { path: 'accessories', component: AccessoriesComponent },
      { path: 'collar', component: CollarComponent },
      { path: 'printtypes', component: PrintTypesComponent },
    ]
  }
];

/**
 * Dress Item Routing Module
 * @export
 * @class DressItemRoutingModule
 */
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DressItemRoutingModule { }
