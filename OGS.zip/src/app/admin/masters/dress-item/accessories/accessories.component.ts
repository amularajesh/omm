import { Location } from "@angular/common";
import { Component, OnInit, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";

import { SnackbarModalComponent } from "src/app/core/Dialogues/snackbar-modal/snackbar-modal.component";
import { LoaderService } from "src/app/core/Services/loader.service";
import { MastersService } from "src/app/core/Services/masters.service";
import { ValidationService } from "src/app/core/Services/validation.service";

/**
 * Accessories Component
 * @export
 * @class AccessoriesComponent
 * @implements {OnInit}
 */
@Component({
  selector: "app-accessories",
  templateUrl: "./accessories.component.html",
  styleUrls: ["./accessories.component.scss"],
})
export class AccessoriesComponent implements OnInit {
  /**
   * Get Snackbar Modal Component
   * @type {SnackbarModalComponent}
   */
  @ViewChild("snackbarModalComponent") snackbarModalComponent!: SnackbarModalComponent;

  /**
   * Get Is Admin Or Manager Flag
   */
  isAdminOrManager = false;

  /**
   * Get Accessory List
   */
  accessoryList: any[] = [];

  /**
   * Declare Update Accessory Flag
   */
  updateAccessory = false;

  /**
   * Get Measurements List
   * @type {*}
   */
  measurementsList: any;

  /**
   * Get Accessory Data
   * @type {*}
   */
  accessoryData: any;

  /**
   * Declare Sorting Order Flag
   */
  sortingOrder = true;

  /**
   * Declare Sorting Key Column
   */
  sortingKeyColumn = "accessoryName";

  /**
   * Records Count
   */
  recordsCount = 0;

  /**
   * Default Page Number
   */
  currentPage = 1;

  /**
   * Search Term
   */
  searchTerm = "";

  /**
   * Create accessories Form Declaration
   * @type {FormGroup}
   */
  createAccessoriesForm!: FormGroup;

  /**
   * Get accessories Form Validations
   */
  createAccessoriesValidation = this.validationService.createAccessories;

  /**
   * Creates an instance of AccessoriesComponent.
   * @param {LoaderService} loaderService
   * @param {ValidationService} validationService
   * @param {FormBuilder} formBuilder
   * @param {MastersService} mastersService
   * @param {Location} location
   */
  constructor(
    private loaderService: LoaderService,
    private validationService: ValidationService,
    private formBuilder: FormBuilder,
    private mastersService: MastersService,
    private location: Location
  ) {
    if (localStorage.getItem('userTypeId') == '1' || localStorage.getItem('userTypeId') == '4') {
      this.isAdminOrManager = true;
    }
  }

  /**
   * Life Cycle Hook Initialization
   */
  ngOnInit(): void {
    this.createAccessoriesFormValidations();
    this.getAccessoriesList();
    this.getMeasurementsList();
  }

  /**
   * Initialize Create accessories Validations
   */
  createAccessoriesFormValidations() {
    this.createAccessoriesForm = this.formBuilder.group({
      AccessoryType: [
        this.accessoryData?.accessoryName || "",
        [
          Validators.required,
          Validators.minLength(this.createAccessoriesValidation.AccessoryType.minLength),
          Validators.maxLength(this.createAccessoriesValidation.AccessoryType.maxLength)
        ]
      ],
      measurementSelect: [this.accessoryData?.measurementId || "", [Validators.required]],
      accessoriesDescription: [this.accessoryData?.description || ""]
    });
  }

  /**
   * Create accessories Controls Initialized
   * @readonly
   */
  get createAccessoriesFormControls() {
    return this.createAccessoriesForm.controls;
  }

  /**
   * This method is used to get accessories list
   */
  getAccessoriesList() {
    this.mastersService.getAccessories().subscribe({
      next: (res: any) => {
        this.accessoryList = res.result;
        this.recordsCount = this.accessoryList.length;
      },
      error: () => {
        this.accessoryList = [];
        this.recordsCount = 0;
      },
    });
  }

  /**
   * get measurements method
   */
  getMeasurementsList() {
    this.mastersService.getMeasurements().subscribe({
      next: (res: any) => {
        this.measurementsList = res.result;
      },
      error: () => {
        this.measurementsList = [];
      },
    });
  }

  /**
   * This method is used to reset accessories form
   */
  onResetAccessoryForm() {
    this.accessoryData = "";
    this.updateAccessory = false;
    this.createAccessoriesForm.reset();
    this.createAccessoriesFormValidations();
  }

  /**
   * This method will fired when user selects the measurement
   * @param {*} event
   */
  onChangeMeasurement(event: any) {
    if (event?.target?.value == '') {
      this.createAccessoriesFormControls["measurementSelect"].markAsUntouched({ onlySelf: true });
    }
  }

  /**
   * This method is used to get the accessory details by id
   * @param {*} accessory
   */
  onClickEditAccessory(accessory: any) {
    this.mastersService.getAccessoryById(accessory.accessoryId).subscribe({
      next: (res: any) => {
        this.updateAccessory = true;
        this.accessoryData = res.result;
        this.createAccessoriesFormValidations();
      },
      error: (err: any) => {
        this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message || err, '', '', '');
      },
    });
  }

  /**
   * This method is used to change the pagination controls
   * @param {*} event
   */
  onPageChange(event: any) {
    this.currentPage = event;
  }

  /**
   * This method is used to show search results
   */
  navigateToSearchResult() {
    this.currentPage = 1;
  }

  /**
   * This method is used to sort column
   * @param key : value of which column based we need to sort the rows
   */
  sort(key: string) {
    const componentName = this.location.path();
    let value = key;
    sessionStorage.setItem(`${componentName}_property`, value);
    this.sortingKeyColumn = key;
    if (sessionStorage.getItem(componentName + "_order") == "desc") {
      this.sortingOrder = false;
    } else {
      this.sortingOrder = true;
    }
  }

  /**
   * This method is used to submit the create accessories form 
   */
  onSubmitCreateAccessoryForm() {
    /** This will return false if form fields are invalid and stop the service calling */
    if (this.createAccessoriesForm.invalid) {
      this.validationService.validateAllFormFields(this.createAccessoriesForm);
      return;
    }

    /* Prepare the request payload */
    const obj = {
      accessoryId: this.updateAccessory ? this.accessoryData?.accessoryId : "",
      accessoryName: this.createAccessoriesFormControls["AccessoryType"]?.value?.trim() || "",
      description: this.createAccessoriesFormControls["accessoriesDescription"]?.value?.trim() || "",
      status: this.updateAccessory ? "1" : "0",
      measurementId: this.createAccessoriesFormControls["measurementSelect"]?.value || "",
    };

    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    if (this.updateAccessory === false) {
      this.mastersService.addAccessory(obj).subscribe({
        next: (res: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', '');
          this.getAccessoriesList();
          this.onResetAccessoryForm();
        },
        error: (err: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message || err, '', '', '');
        },
      });
    } else {
      this.mastersService.editAccessory(obj).subscribe({
        next: (res: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', '');
          this.getAccessoriesList();
          this.onResetAccessoryForm();
        },
        error: (err: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message || err, '', '', '');
        },
      });
    }
  }
}
