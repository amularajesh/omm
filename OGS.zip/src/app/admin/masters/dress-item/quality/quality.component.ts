import { Location } from "@angular/common";
import { Component, OnInit, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";

import { SnackbarModalComponent } from "src/app/core/Dialogues/snackbar-modal/snackbar-modal.component";
import { LoaderService } from "src/app/core/Services/loader.service";
import { MastersService } from "src/app/core/Services/masters.service";
import { ValidationService } from "src/app/core/Services/validation.service";

/**
 * Quality Component
 * @export
 * @class QualityComponent
 * @implements {OnInit}
 */
@Component({
  selector: "app-quality",
  templateUrl: "./quality.component.html",
  styleUrls: ["./quality.component.scss"]
})
export class QualityComponent implements OnInit {
  /**
   * Get Snackbar Modal Component
   * @type {SnackbarModalComponent}
   */
  @ViewChild("snackbarModalComponent") snackbarModalComponent!: SnackbarModalComponent;

  /**
   * Get Is Admin Or Manager Flag
   */
  isAdminOrManager = false;

  /**
   * Get Sorting Order Flag
   */
  sortingOrder = true;

  /**
   * Get Sorting Key Column Name
   */
  sortingKeyColumn = "inwardType";

  /**
   * Get Is Update Quality Flag
   */
  isUpdateQuality = false;

  /**
   * Get Quality Records Count
   */
  qualityRecordsCount = 0;

  /**
   * Get Quality List
   * @type {*}
   */
  qualityList: any;

  /**
   * Get Inward Types List
   * @type {*}
   */
  inwardTypesList: any;

  /**
   * Get Edit Quality Details
   * @type {*}
   */
  editQualityDetails: any;

  /**
   * Get Default Page Number
   */
  currentPage = 1;

  /**
   * Get Search Term
   */
  searchTerm = "";

  /**
   * Create Quality Form Declaration
   * @type {FormGroup}
   */
  createQualityForm!: FormGroup;

  /**
   * Get Create Quality Form Validations
   */
  createQualityFormValidation = this.validationService.createQuality;

  /**
   * Creates an instance of QualityComponent.
   * @param {ValidationService} validationService
   * @param {FormBuilder} formBuilder
   * @param {MastersService} mastersService
   * @param {LoaderService} loaderService
   * @param {Location} location
   */
  constructor(
    private validationService: ValidationService,
    private formBuilder: FormBuilder,
    private mastersService: MastersService,
    private loaderService: LoaderService,
    private location: Location
  ) {
    if (localStorage.getItem('userTypeId') == '1' || localStorage.getItem('userTypeId') == '4') {
      this.isAdminOrManager = true;
    }
  }

  /**
   * Life Cycle Hook Initialization
   */
  ngOnInit(): void {
    this.createQualityFormValidations();
    this.getQualitiesList();
    this.getInwardTypesList();
  }

  /**
   * Initialize Create Company Validations
   */
  createQualityFormValidations() {
    this.createQualityForm = this.formBuilder.group({
      inwardTypeSelect: [this.editQualityDetails?.inwardTypeId || "", Validators.required],
      DressItemQuality: [
        this.editQualityDetails?.qualityName || "",
        [
          Validators.required,
          Validators.minLength(this.createQualityFormValidation.DressItemQuality.minLength),
          Validators.maxLength(this.createQualityFormValidation.DressItemQuality.maxLength)
        ]
      ]
    });
  }

  /**
   * Create company Controls Initialized
   * @readonly
   */
  get createQualityFormControls() {
    return this.createQualityForm.controls;
  }

  /**
   * This method is used to get Qualities list
   */
  getQualitiesList() {
    this.mastersService.getQualities().subscribe({
      next: (res: any) => {
        this.qualityList = res.result;
        this.qualityRecordsCount = this.qualityList.length;
      },
      error: () => {
        this.qualityList = [];
        this.qualityRecordsCount = 0;
      }
    });
  }

  /**
   * This method is used to get Inward Types list
   */
  getInwardTypesList() {
    this.mastersService.getInwardTypes().subscribe({
      next: (res: any) => {
        this.inwardTypesList = res.result;
      },
      error: () => {
        this.inwardTypesList = [];
      }
    });
  }

  /**
   * This method used to reset district form
   */
  onClickReset() {
    this.createQualityForm.reset();
    this.isUpdateQuality = false;
    this.editQualityDetails = '';
    this.createQualityFormValidations();
  }

  /**
   * This method is used to change the inward type
   * @param {*} event
   */
  onChangeInwardType(event: any) {
    if (event?.target?.value == '') {
      this.createQualityFormControls["inwardTypeSelect"].markAsUntouched({ onlySelf: true });
    }
  }

  /**
   * This method is used to edit quality
   * @param {*} quality
   */
  onClickEditQuality(quality: any) {
    this.mastersService.getQualityById(quality.qualityId).subscribe({
      next: (res: any) => {
        this.isUpdateQuality = true;
        this.editQualityDetails = res.result;
        this.createQualityFormValidations();
      },
      error: (err: any) => {
        this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
      },
    });
  }

  /**
   * This method is used to change the pagination controls
   * @param {*} event
   */
  onPageChange(event: any) {
    this.currentPage = event;
  }

  /**
   * This method is used to show search results
   */
  navigateToSearchResult() {
    this.currentPage = 1;
  }
  /**
   * This method is used to sort column
   * @param key : value of which column based we need to sort the rows
   */
  sort(key: string) {
    const componentName = this.location.path();
    let value = key;
    sessionStorage.setItem(`${componentName}_property`, value);
    this.sortingKeyColumn = key;
    if (sessionStorage.getItem(componentName + "_order") == "desc") {
      this.sortingOrder = false;
    } else {
      this.sortingOrder = true;
    }
  }

  /**
   * This method is used to submit the create quality form
   */
  onCreateQualityFormSubmit(): any {
    /** This will return false if form fields are invalid and stop the service calling */
    if (this.createQualityForm.invalid) {
      this.validationService.validateAllFormFields(this.createQualityForm);
      return;
    }

    /* Prepare the request payload */
    const obj = {
      qualityId: this.isUpdateQuality ? this.editQualityDetails?.qualityId : 0,
      inwardTypeId: +this.createQualityFormControls["inwardTypeSelect"]?.value,
      qualityName: this.createQualityFormControls["DressItemQuality"]?.value?.trim() || "",
      status: 0
    };

    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    if (this.isUpdateQuality === false) {
      /* To call the service to add the quality by passing the obj */
      this.mastersService.addQuality(obj).subscribe({
        next: (res: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', '');
          this.getQualitiesList();
          this.onClickReset();
        },
        error: (err: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
        },
      });
    } else {
      /* To call the service to edit the quality by passing the obj */
      this.mastersService.editQuality(obj).subscribe({
        next: (res: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', '');
          this.getQualitiesList();
          this.onClickReset();
        },
        error: (err: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
        },
      });
    }
  }
}
