import { Location } from "@angular/common";
import { Component, OnInit, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";

import { SnackbarModalComponent } from "src/app/core/Dialogues/snackbar-modal/snackbar-modal.component";
import { LoaderService } from "src/app/core/Services/loader.service";
import { MastersService } from "src/app/core/Services/masters.service";
import { ValidationService } from "src/app/core/Services/validation.service";

/**
 * Print Types Component
 * @export
 * @class PrintTypesComponent
 * @implements {OnInit}
 */
@Component({
  selector: "app-print-types",
  templateUrl: "./print-types.component.html",
  styleUrls: ["./print-types.component.scss"],
})
export class PrintTypesComponent implements OnInit {
  /**
   * Get Snackbar Modal Component
   * @type {SnackbarModalComponent}
   */
  @ViewChild("snackbarModalComponent") snackbarModalComponent!: SnackbarModalComponent;

  /**
   * Get Is Admin Or Manager Flag
   */
  isAdminOrManager = false;

  /**
   * Declaring Variable to know Edit Action active or not
   */
  updatePrintType = false;

  /**
   * Print Mode variables
   * @type {*}
   */
  printModeId: any;
  PrintModeName = "";

  /**
   * PrintModesList
   */
  PrintModesList: any;
  /**
   * Records Count
   */
  recordsCount = 0;

  /**
   * PrintTypeList
   */
  PrintTypeList: any[] = [];

  /**
   * PrintTypeData
   */
  PrintTypeData: any;

  /**
   * Default Page Number
   */
  currentPage = 1;

  /**
   * Default Sorting Key
   */
  sortingKeyColumn = "printModeName";

  /**
   * Default Sort Order
   */
  sortingOrder = true;

  /**
   * Search Term
   */
  searchTerm = "";

  /**
   * Create printTypes Form Declaration
   */
  createPrintForm!: FormGroup;

  /**
   * Get printTypes Form Validations
   */
  createPrintValidation = this.validationService.createPrint;

  /**
   * States List
   * @type {any[]}
   */
  statesList: any[] = [];

  /**
   * Creates an instance of PrintTypesComponent.
   * @param {ValidationService} validationService
   * @param {FormBuilder} formBuilder
   * @param {MastersService} mastersService
   * @param {Location} location
   * @param {LoaderService} loaderService
   */
  constructor(
    private validationService: ValidationService,
    private formBuilder: FormBuilder,
    private mastersService: MastersService,
    private location: Location,
    private loaderService: LoaderService
  ) {
    if (localStorage.getItem('userTypeId') == '1' || localStorage.getItem('userTypeId') == '4') {
      this.isAdminOrManager = true;
    }
  }

  /**
   * Life Cycle Hook Initialization
   */
  ngOnInit(): void {
    this.createPrintTypeFormValidations();
    this.getPrintModes();
    this.getPrintList();
  }

  /**
   * This method is used to get the print modes
   */
  getPrintModes() {
    this.mastersService.getPrintModes().subscribe({
      next: (res: any) => {
        this.PrintModesList = res.result;
      },
      error: (err: any) => {
        this.PrintModesList = [];
      },
    });
  }

  /**
   * This method is used to get PrintTypesList
   */
  getPrintList() {
    this.mastersService.getPrintTypes().subscribe({
      next: (res: any) => {
        this.PrintTypeList = res.result;
        this.recordsCount = this.PrintTypeList.length;
      },
      error: (err: any) => {
        this.PrintTypeList = [];
        this.recordsCount = 0;
      },
    });
  }

  /**
   * This method used to reset printTypes form
   */
  resetPrintTypeForm() {
    this.createPrintForm.reset();
    this.createPrintTypeFormValidations();
    this.createPrintFormControls["PrintType"]?.setValue("");
    this.createPrintFormControls["printDescription"]?.setValue("");
    this.createPrintFormControls["printSelect"]?.setValue("");
    this.updatePrintType = false;
  }

  /**
   * Initialize Create printTypes Validations
   */
  createPrintTypeFormValidations() {
    this.createPrintForm = this.formBuilder.group({
      PrintType: [
        this.PrintTypeData?.printTypeName || "",
        [
          Validators.required,
          Validators.minLength(this.createPrintValidation.PrintType.minLength),
          Validators.maxLength(this.createPrintValidation.PrintType.maxLength),
        ],
      ],

      printSelect: [
        this.PrintTypeData?.printModeId || "",
        [Validators.required],
      ],
      printDescription: [this.PrintTypeData?.description || ""],
    });
    if (this.PrintTypeData) {
      this.onChangePrintMode(this.PrintTypeData?.printModeId);
    }
  }

  /**
   * Create printTypes Controls Initialized
   * @readonly
   */
  get createPrintFormControls() {
    return this.createPrintForm.controls;
  }

  /**
   * This method will fired when user selects the PrintMode
   * @param {*} event
   */
  onChangePrintMode(event: any) {
    const printModeValue = event?.target ? event?.target?.value : event;
    if (printModeValue == '') {
      this.createPrintFormControls["printSelect"].markAsUntouched({ onlySelf: true });
      this.PrintModeName = '';
      return;
    }
    for (const element of this.PrintModesList) {
      if (+element?.printModeId === +(printModeValue)) {
        this.PrintModeName = element.printModeName;
      }
    }
  }

  /**
   * This method is used edit printTypes
   */
  onClickEditPrintType(user: any) {
    this.mastersService.getPrintTypeById(user.printTypeId).subscribe({
      next: (res: any) => {
        this.updatePrintType = true;
        this.PrintTypeData = res.result;
        this.createPrintTypeFormValidations();
      },
      error: (err: any) => {
        this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message || err, '', '', '');
      },
    });
  }

  /**
   * This method is used to sort column
   * @param key : value of which column based we need to sort the rows
   */
  sort(key: string) {
    const componentName = this.location.path();
    let value = key;
    sessionStorage.setItem(`${componentName}_property`, value);
    this.sortingKeyColumn = key;
    if (sessionStorage.getItem(componentName + "_order") == "desc") {
      this.sortingOrder = false;
    } else {
      this.sortingOrder = true;
    }
  }

  /**
   * This method is used to change the pagination controls
   * @param {*} event
   */
  onPageChange(event: any) {
    this.currentPage = event;
  }

  /**
   * Create printTypes Form Submit
   */
  onCreateUserFormSubmit() {
    /** This will return false if form fields are invalid and stop the service calling */
    if (this.createPrintForm.invalid) {
      this.validationService.validateAllFormFields(this.createPrintForm);
      return;
    }

    const obj = {
      printTypeId: "0",
      printTypeName: this.createPrintFormControls["PrintType"]?.value?.trim() || "",
      description: this.createPrintFormControls["printDescription"]?.value?.trim() || "",
      status: "0",
      printModeId: this.createPrintFormControls["printSelect"]?.value || "",
      printModeName: this.PrintModeName || "",
    };

    const updatePrintTypeObj = {
      printTypeId: this.PrintTypeData?.printTypeId || "",
      printTypeName: this.createPrintFormControls["PrintType"]?.value?.trim() || "",
      description: this.createPrintFormControls["printDescription"]?.value?.trim() || "",
      status: this.PrintTypeData?.status || "0",
      printModeId: this.createPrintFormControls["printSelect"]?.value || "",
      printModeName: this.PrintModeName || "",
    };

    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    if (this.updatePrintType === false) {
      this.mastersService.addPrintType(obj).subscribe({
        next: (res: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', '');
          this.getPrintList();
          this.resetPrintTypeForm();
        },
        error: (err: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message || err, '', '', '');
        },
      });
    } else {
      this.mastersService.editPrintType(updatePrintTypeObj).subscribe({
        next: (res: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', '');
          this.getPrintList();
          this.resetPrintTypeForm();
        },
        error: (err: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message || err, '', '', '');
        },
      });
    }
  }

  /**
   * This method is used to show search results
   */
  navigateToSearchResult() {
    this.currentPage = 1;
  }
}
