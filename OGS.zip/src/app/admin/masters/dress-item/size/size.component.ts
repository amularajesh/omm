import { Location } from "@angular/common";
import { Component, OnInit, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";

import { SnackbarModalComponent } from "src/app/core/Dialogues/snackbar-modal/snackbar-modal.component";
import { LoaderService } from "src/app/core/Services/loader.service";
import { MastersService } from "src/app/core/Services/masters.service";
import { ValidationService } from "src/app/core/Services/validation.service";

/**
 * Size Component
 * @export
 * @class SizeComponent
 * @implements {OnInit}
 */
@Component({
  selector: "app-size",
  templateUrl: "./size.component.html",
  styleUrls: ["./size.component.scss"],
})
export class SizeComponent implements OnInit {
  /**
   * Get Snackbar Modal Component
   * @type {SnackbarModalComponent}
   */
  @ViewChild("snackbarModalComponent") snackbarModalComponent!: SnackbarModalComponent;

  /**
   * Get Is Admin Or Manager Flag
   */
  isAdminOrManager = false;

  /**
   * Declare Sorting Order Flag
   */
  sortingOrder = true;

  /**
   * Declare Sorting Key Column
   */
  sortingKeyColumn = "methodName";

  /**
   * Get Sizes List
   * @type {*}
   */
  sizesList: any;

  /**
   * Get Sizes Records Count
   */
  sizesRecordsCount = 0;

  /**
   * Get Edit Size Details
   * @type {*}
   */
  editSizeDetails: any;

  /**
   * Get Is Update Size Flag
   */
  isUpdateSize = false;

  /**
   * Default Page Number
   */
  currentPage = 1;

  /**
   * Search Term
   */
  searchTerm = "";

  /**
   * Create Size Form Declaration
   * @type {FormGroup}
   */
  createSizeForm!: FormGroup;

  /**
   * Get Size Form Validations
   */
  createSizeValidation = this.validationService.createSize;

  /**
   * Get Patterns
   */
  createSizeValidationPattern = this.validationService.patterns;

  /**
   * States List
   * @type {*}
   */
  statesList: any;

  /**
   * Selected Method
   * @type {*}
   */
  selectedMethod: any;

  /**
   * Creates an instance of SizeComponent.
   * @param {LoaderService} loaderService
   * @param {ValidationService} validationService
   * @param {FormBuilder} formBuilder
   * @param {MastersService} mastersService
   * @param {Location} location
   */
  constructor(
    private loaderService: LoaderService,
    private validationService: ValidationService,
    private formBuilder: FormBuilder,
    private mastersService: MastersService,
    private location: Location
  ) {
    if (localStorage.getItem('userTypeId') == '1' || localStorage.getItem('userTypeId') == '4') {
      this.isAdminOrManager = true;
    }
  }

  /**
   * Life Cycle Hook Initialization
   */
  ngOnInit(): void {
    this.createSizeFormValidations();
    this.getSizesList();
    this.getMethodList();
  }

  /**
   * This method is used to get the states List
   */
  getMethodList() {
    this.mastersService.getMethods().subscribe({
      next: (res: any) => {
        console.log(res.result, "states");
        this.statesList = res.result;
      },
      error: (err: any) => {
        this.statesList = [];
      },
    });
  }

  /**
   * This method is used to get sizes list
   */
  getSizesList() {
    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    /* To call the service to get the sizes list */
    this.mastersService.getSizes().subscribe({
      next: (res: any) => {
        /* Disable the loader if response is success */
        this.loaderService.isLoading.next(false);
        this.sizesList = res.result;
        this.sizesRecordsCount = this.sizesList.length;
      },
      error: (err: any) => {
        /* Disable the loader if response is error */
        this.loaderService.isLoading.next(false);
        this.sizesList = [];
        this.sizesRecordsCount = 0;
      },
    });
  }

  /**
   * This method used to reset Size form
   */
  onResetSizeForm() {
    this.createSizeForm.reset();
    this.createSizeFormValidations();
    this.createSizeFormControls["methodSelect"].setValue("");
    this.createSizeFormControls["SizeName"].setValue("");
    this.isUpdateSize = false;
  }

  /**
   * Initialize Create Size Validations
   */
  createSizeFormValidations() {
    this.createSizeForm = this.formBuilder.group({
      SizeName: [
        this.editSizeDetails?.sizeName || "",
        [
          Validators.required,
          Validators.minLength(this.createSizeValidation.SizeName.minLength),
          Validators.maxLength(this.createSizeValidation.SizeName.maxLength),
          Validators.pattern(this.createSizeValidationPattern.sizeRegex),
        ],
      ],

      methodSelect: [
        this.editSizeDetails?.methodId || "",
        [Validators.required],
      ],
    });

    if (this.editSizeDetails) {
      this.onChangeMethod(this.editSizeDetails?.methodId);
    }
  }

  /**
   * Create Size Controls Initialized
   * @readonly
   */
  get createSizeFormControls() {
    return this.createSizeForm.controls;
  }

  /**
   * This method will fired when user selects the method
   * @param {*} event
   */
  onChangeMethod(event: any) {
    let methodValue = event?.target ? event.target.value : event;
    for (const element of this.statesList) {
      if (+element.methodId === +methodValue) {
        this.selectedMethod = element;
      }
    }
  }

  /**
   * This method is used to change the pagination controls
   * @param {*} event
   */
  onPageChange(event: any) {
    this.currentPage = event;
  }

  /**
   * This method is used to show search results
   */
  navigateToSearchResult() {
    this.currentPage = 1;
  }

  /**
   * This method is used to sort column
   * @param key : value of which column based we need to sort the rows
   */
  sort(key: string) {
    const componentName = this.location.path();
    let value = key;
    sessionStorage.setItem(`${componentName}_property`, value);
    this.sortingKeyColumn = key;
    if (sessionStorage.getItem(componentName + "_order") == "desc") {
      this.sortingOrder = false;
    } else {
      this.sortingOrder = true;
    }
  }

  /**
   * This method is used edit size
   * @param {*} size
   */
  onClickEditSize(size: any) {
    this.mastersService.getSizeById(size.sizeId).subscribe({
      next: (res: any) => {
        this.isUpdateSize = true;
        this.editSizeDetails = res.result;
        this.createSizeFormValidations();
      },
      error: (err: any) => {
        this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message || err, '', '', '');
      },
    });
  }

  /**
   * This method is used to submit create size form
   */
  onSubmitCreateSizeForm(): any {
    /** This will return false if form fields are invalid and stop the service calling */
    if (this.createSizeForm.invalid) {
      this.validationService.validateAllFormFields(this.createSizeForm);
      return;
    }

    /* Prepare the request payload */
    const obj = {
      methodId: +this.selectedMethod?.methodId,
      methodName: this.selectedMethod?.methodName,
      sizeId: 0,
      sizeName: this.createSizeForm.controls["SizeName"].value?.toString()?.trim(),
      status: 0,
    };

    /* Prepare the request payload */
    const updateSizeObj = {
      methodId: this.selectedMethod?.methodId,
      methodName: this.selectedMethod?.methodName,
      sizeId: this.editSizeDetails?.sizeId,
      sizeName: this.createSizeForm.controls["SizeName"].value?.trim() || "",
      status: 0,
    };

    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    if (this.isUpdateSize === false) {

      /* To call the service to add the size by passing obj */
      this.mastersService.addSize(obj).subscribe({
        next: (res: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', '');
          this.getSizesList();
          this.onResetSizeForm();
        },
        error: (err: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message || err, '', '', '');
        },
      });
    } else {
      /* To call the service to edit the size by passing obj */
      this.mastersService.editSize(updateSizeObj).subscribe({
        next: (res: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', '');
          this.getSizesList();
          this.editSizeDetails = [];
          this.isUpdateSize = false;
          this.onResetSizeForm();
        },
        error: (err: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message || err, '', '', '');
        }
      });
    }
  }
}
