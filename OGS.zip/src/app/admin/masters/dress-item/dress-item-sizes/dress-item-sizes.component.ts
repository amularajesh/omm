import { Location } from "@angular/common";
import { ChangeDetectorRef, Component, OnInit, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";

import { SnackbarModalComponent } from "src/app/core/Dialogues/snackbar-modal/snackbar-modal.component";
import { LoaderService } from "src/app/core/Services/loader.service";
import { MastersService } from "src/app/core/Services/masters.service";
import { ValidationService } from "src/app/core/Services/validation.service";

/**
 * Dress Item Sizes Sizes Component
 * @export
 * @class DressItemSizesSizesComponent
 * @implements {OnInit}
 */
@Component({
  selector: "app-dress-item-sizes",
  templateUrl: "./dress-item-sizes.component.html",
  styleUrls: ["./dress-item-sizes.component.scss"],
})
export class DressItemSizesSizesComponent implements OnInit {
  /**
   * Get Snackbar Modal Component
   * @type {SnackbarModalComponent}
   */
  @ViewChild("snackbarModalComponent") snackbarModalComponent!: SnackbarModalComponent;

  /**
   * Get Is Admin Or Manager Flag
   */
  isAdminOrManager = false;

  /**
   * Declare Sorting Order Flag
   */
  sortingOrder = true;

  /**
   * Declare Sorting Key Column
   */
  sortingKeyColumn = "dressItemName";

  /**
   * Records Count
   */
  recordsCount = 0;

  /**
   * Get Dress Item Sizes List
   * @type {*}
   */
  dressItemSizesList: any;

  /**
   * Get Edit Dress Item Size Details
   * @type {*}
   */
  editDressItemSizeDetails: any;

  /**
   * Default Page Number
   */
  currentPage = 1;

  /**
   * Search Term
   */
  searchTerm = "";

  /**
   * Create DressItemSizes Form Declaration
   * @type {FormGroup}
   */
  createDressItemSizesForm!: FormGroup;

  /**
   * Get DressItemSizes Form Validations
   */
  createDressItemSizesValidation = this.validationService.createDressItemSize;

  /**
   * Get Dress Items List
   * @type {*}
   */
  dressItemsList: any;

  /**
   * Get Method Items List
   * @type {*}
   */
  methodItemsList: any;

  /**
   * Get Method Items List
   * @type {*}
   */
  sizesList: any;

  /**
   * Get Is Dress Item Size Edit Flag
   */
  isDressItemSizeEdit = false;

  /**
   * Creates an instance of DressItemSizesSizesComponent.
   * @param {LoaderService} loaderService
   * @param {ValidationService} validationService
   * @param {FormBuilder} formBuilder
   * @param {MastersService} mastersService
   * @param {Location} location
   * @param {ChangeDetectorRef} cdr
   */
  constructor(
    private loaderService: LoaderService,
    private validationService: ValidationService,
    private formBuilder: FormBuilder,
    private mastersService: MastersService,
    private location: Location,
    private cdr: ChangeDetectorRef,
  ) {
    if (localStorage.getItem('userTypeId') == '1' || localStorage.getItem('userTypeId') == '4') {
      this.isAdminOrManager = true;
    }
  }

  /**
   * Life cycle hook Initialization
   */
  ngOnInit(): void {
    this.getDressItemSizesList();
    this.getDressItemsList();
    this.createDressItemSizesFormValidations();
  }

  /**
   * Initialize Create Dress Item Sizes Validations
   */
  createDressItemSizesFormValidations() {
    this.createDressItemSizesForm = this.formBuilder.group({
      dressItemSelect: [
        this.editDressItemSizeDetails?.dressItemId || "",
        [Validators.required],
      ],
      methodsItemSelect: [
        this.editDressItemSizeDetails?.methodId || "",
        [Validators.required],
      ],
      sizeItemSelect: [
        this.editDressItemSizeDetails?.sizeId || "",
        [Validators.required],
      ],
    });

    if (this.editDressItemSizeDetails) {
      this.onChangeDressItem(this.editDressItemSizeDetails?.dressItemId);
    }
  }

  /**
   * Create DressItemSizes Controls Initialized
   * @readonly
   */
  get createDressItemSizesFormControls() {
    return this.createDressItemSizesForm.controls;
  }

  /**
   * This method is used to update value and validity
   * @param {*} formControls
   */
  onUpdateValueAndValidity(formControls: any, controls: any) {
    controls?.forEach((control: any) => {
      formControls[control].setValue("");
      formControls[control].markAsUntouched({ onlySelf: true });
      formControls[control].updateValueAndValidity({ onlySelf: true });
    });
  }

  /**
   * This method is used to get the dressItemSizes list
   */
  getDressItemSizesList() {
    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    /* To call the service to get the districts list */
    this.mastersService.getDressItemSizes().subscribe({
      next: (res: any) => {
        /* Disable the loader if response is success */
        this.loaderService.isLoading.next(false);
        this.dressItemSizesList = res.result;
        this.recordsCount = this.dressItemSizesList.length;
      },
      error: () => {
        this.dressItemSizesList = [];
        this.recordsCount = 0;
        /* Disable the loader if response is Error */
        this.loaderService.isLoading.next(false);
      },
    });
  }

  /**
   * This method is used to get Dress Items list
   */
  getDressItemsList() {
    this.mastersService.getDressItems().subscribe({
      next: (res: any) => {
        this.dressItemsList = res.result;
      },
      error: () => {
        this.dressItemsList = [];
      },
    });
  }

  /**
   * This method used to reset DressItemSizes form
   */
  DressItemSizesFormReset() {
    this.createDressItemSizesForm.reset();
    this.editDressItemSizeDetails = "";
    this.isDressItemSizeEdit = false;
    this.methodItemsList = [];
    this.sizesList = [];
    this.createDressItemSizesFormValidations();
  }

  /**
   * This method will fired when user selects Dress Item
   * @param {*} event
   */
  onChangeDressItem(event: any) {
    if (event?.target) {
      this.onUpdateValueAndValidity(this.createDressItemSizesFormControls, ['methodsItemSelect', 'sizeItemSelect']);
      this.methodItemsList = [];
      this.sizesList = [];
    }

    const dressItemSizeValue = event?.target ? +event.target?.value : event;
    const eventFlag = event?.target;

    if (dressItemSizeValue == '') {
      this.createDressItemSizesFormControls["dressItemSelect"].markAsUntouched({ onlySelf: true });
      return;
    }

    this.mastersService.getMethodsByDressItemId(dressItemSizeValue?.toString()).subscribe({
      next: (res: any) => {
        this.methodItemsList = res.result;
        if (!eventFlag) {
          this.createDressItemSizesFormControls["methodsItemSelect"].setValue(this.editDressItemSizeDetails?.methodId);
          this.cdr.detectChanges();
          this.onChangeMethod(this.editDressItemSizeDetails?.methodId);
        }
      },
      error: () => {
        this.methodItemsList = [];
      }
    });
  }

  /**
   * Method call when user select the method
   * @param {*} event
   */
  onChangeMethod(event: any) {
    if (event?.target) {
      this.sizesList = [];
      this.onUpdateValueAndValidity(this.createDressItemSizesFormControls, ['sizeItemSelect']);
    }

    const methodItemSizeValue = event?.target ? +event.target?.value : event;
    const eventFlag = event?.target;

    if (methodItemSizeValue == '') {
      this.createDressItemSizesFormControls["methodsItemSelect"].markAsUntouched({ onlySelf: true });
      return;
    }

    this.mastersService.getSizesByMethodId(methodItemSizeValue?.toString()).subscribe({
      next: (res: any) => {
        this.sizesList = res.result;
        if (!eventFlag) {
          this.createDressItemSizesFormControls["sizeItemSelect"].setValue(this.editDressItemSizeDetails?.sizeId);
          this.cdr.detectChanges();
        }
      },
      error: () => {
        this.sizesList = [];
      }
    });
  }

  /**
   * This method is used edit DressItemSizes Details
   * @param {*} dressItemSize
   */
  onClickEditDressItemSize(dressItemSize: any) {
    /* To call the service to get the dress Item Size Details by passing dressItemSizeId */
    this.mastersService.getDressItemSizeById(dressItemSize?.dressItemSizeId).subscribe({
      next: (res: any) => {
        this.isDressItemSizeEdit = true;
        this.editDressItemSizeDetails = res.result;
        this.createDressItemSizesFormValidations();
      },
      error: (err: any) => {
        this.isDressItemSizeEdit = false;
        this.editDressItemSizeDetails = "";
        this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
      }
    });
  }

  /**
   * This method is used to change the pagination controls
   * @param {*} event
   */
  onPageChange(event: any) {
    this.currentPage = event;
  }

  /**
   * This method is used to show search results
   */
  navigateToSearchResult() {
    this.currentPage = 1;
  }

  /**
   * This method is used to sort column
   * @param key : value of which column based we need to sort the rows
   */
  sort(key: string) {
    const componentName = this.location.path();
    let value = key;
    sessionStorage.setItem(`${componentName}_property`, value);
    this.sortingKeyColumn = key;
    if (sessionStorage.getItem(componentName + "_order") == "desc") {
      this.sortingOrder = false;
    } else {
      this.sortingOrder = true;
    }
  }

  /**
   * This method is used to submit create dressItemSizes form
   */
  onSubmitCreateDressItemSizesForm(): any {
    /** This will return false if form fields are invalid and stop the service calling */
    if (this.createDressItemSizesForm.invalid) {
      this.validationService.validateAllFormFields(this.createDressItemSizesForm);
      return;
    }

    /* Prepare the request payload */
    const obj = {
      dressItemSizeId: this.editDressItemSizeDetails?.dressItemSizeId || 0,
      dressItemId: this.createDressItemSizesFormControls["dressItemSelect"].value,
      methodId: this.createDressItemSizesFormControls["methodsItemSelect"].value,
      sizeId: this.createDressItemSizesFormControls["sizeItemSelect"].value,
      status: 0
    };

    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    if (!this.isDressItemSizeEdit) {
      /* To call the service to add the dress Item Size*/
      this.mastersService.addDressItemSize(obj).subscribe({
        next: (res: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', '');
          this.getDressItemSizesList();
          this.DressItemSizesFormReset();
        },
        error: (err: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
        },
      });
    } else {
      /* To call the service to update the dress Item Size*/
      this.mastersService.editDressItemSize(obj).subscribe({
        next: (res: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', '');
          this.getDressItemSizesList();
          this.DressItemSizesFormReset();
        },
        error: (err: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
        },
      });
    }
  }
}
