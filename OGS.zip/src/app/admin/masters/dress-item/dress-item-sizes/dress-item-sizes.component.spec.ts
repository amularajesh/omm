import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DressItemSizesComponent } from './dress-item-sizes.component';

describe('DressItemSizesComponent', () => {
  let component: DressItemSizesComponent;
  let fixture: ComponentFixture<DressItemSizesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DressItemSizesComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DressItemSizesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
