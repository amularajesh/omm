import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { AppService } from 'src/app/core/Services/app.service';

/**
 * Dress Item Component
 * @export
 * @class DressItemComponent
 * @implements {OnInit}
 */
@Component({
  selector: 'app-dress-item',
  templateUrl: './dress-item.component.html',
  styleUrls: ['./dress-item.component.scss']
})
export class DressItemComponent implements OnInit {
  /**
   * Get Dress Item DropdownItems
   * @type {*}
   */
  dressItemDropdownItems: any;

  /**
   * Creates an instance of DressItemComponent.
   * @param {Router} router
   * @param {AppService} appService
   */
  constructor(
    private router: Router,
    private appService: AppService
  ) {
    this.appService.menuItems.subscribe((items: any) => {
      this.dressItemDropdownItems = items
        .filter((menu: any) => menu.menuName === 'Masters')
        .map((menu: any) => menu.groupList
          .filter((group: any) => group.groupingName === 'DressItem')
          .flatMap((group: any) => group.subMenuList
            .filter((submenu: any) => submenu.checked === true)
          )
        ).reduce((acc: any, current: any) => acc.concat(current), []);
      if (this.dressItemDropdownItems.length > 0) {
        if (document.getElementById('dressItemSelect')) {
          const selectedEle = document.getElementById('dressItemSelect') as HTMLSelectElement;
          selectedEle.value = this.dressItemDropdownItems[0].submenuName;
        }
        if (this.router.routerState.snapshot.url === '/admin/home') {
          this.router.navigate(['/admin/home']);
        } else {
          this.onSelectNavigate(this.dressItemDropdownItems[0].submenuName);
        }
      }
    });
  }

  /**
   * Life Cycle Hook Initilization
   */
  ngOnInit(): void { }

  /**
   * This method is used to navigate to the selected dressItem dropdown item
   * @param {*} event
   */
  onSelectNavigate(event: any) {
    const selectedValue = event?.target ? event.target.value : event;
    const selectedElement = this.dressItemDropdownItems.filter((item: any) => item.submenuName === selectedValue);
    this.router.navigate([selectedElement[0].link]);
  }
}
