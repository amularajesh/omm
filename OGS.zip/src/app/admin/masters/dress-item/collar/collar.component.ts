import { Location } from "@angular/common";
import { Component, OnInit, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";

import { SnackbarModalComponent } from "src/app/core/Dialogues/snackbar-modal/snackbar-modal.component";
import { LoaderService } from "src/app/core/Services/loader.service";
import { MastersService } from "src/app/core/Services/masters.service";
import { ValidationService } from "src/app/core/Services/validation.service";

/**
 * Collar Component
 * @export
 * @class CollarComponent
 * @implements {OnInit}
 */
@Component({
  selector: "app-collar",
  templateUrl: "./collar.component.html",
  styleUrls: ["./collar.component.scss"]
})
export class CollarComponent implements OnInit {
  /**
  * Get Snackbar Modal Component
  * @type {SnackbarModalComponent}
  */
  @ViewChild("snackbarModalComponent") snackbarModalComponent!: SnackbarModalComponent;

  /**
   * Get Is Admin Or Manager Flag
   */
  isAdminOrManager = false;

  /**
   * Get Is Update Collar Flag
   */
  updateCollar = false;

  /**
   *collarMode vars
   *
   * @type {*}
   * @memberof CollarComponent
   */
  CollarModeId: any;
  collarModeName = "";

  /**
   * Records Count
   */
  recordsCount = 0;

  /**
   * collarsList
   */
  collarsList: any[] = [];

  /**
   * collarsModes
   */
  collarsModes: any[] = [];

  /**
   * collarData Data
   */
  collarData: any;

  /**
   * Default Page Number
   */
  currentPage = 1;

  /**
   * Default Sorting Key
   */
  sortingKeyColumn = "collarName";

  /**
   * Default Sort Order
   */
  sortingOrder = true;

  /**
   * Search Term
   */
  searchTerm = "";

  /**
   * Create Collar Form Declaration
   */
  createCollarForm!: FormGroup;

  /**
   * Get Collar Form Validations
   */
  createCollarValidation = this.validationService.createCollar;

  /**
   * Creates an instance of CollarComponent.
   * @param {ValidationService} validationService
   * @param {FormBuilder} formBuilder
   * @param {MastersService} mastersService
   * @param {Location} location
   * @param {LoaderService} loaderService
   */
  constructor(
    private validationService: ValidationService,
    private formBuilder: FormBuilder,
    private mastersService: MastersService,
    private location: Location,
    private loaderService: LoaderService,
  ) {
    if (localStorage.getItem('userTypeId') == '1' || localStorage.getItem('userTypeId') == '4') {
      this.isAdminOrManager = true;
    }
  }

  /**
   * Life Cycle Hook Initialization
   */
  ngOnInit(): void {
    this.createCollarFormValidations();
    this.getCollars();
    this.getCollarsModes();
  }

  /**
   * This method is used to get modes List
   */
  getCollarsModes() {
    this.mastersService.getCollarModes().subscribe({
      next: (res: any) => {
        this.collarsModes = res.result;
      },
      error: (err: any) => {
        this.collarsModes = [];
      },
    });
  }

  /**
   * This method is used to get collars list
   */
  getCollars() {
    this.mastersService.getCollars().subscribe({
      next: (res: any) => {
        this.collarsList = res.result;
        this.recordsCount = this.collarsList.length;
      },
      error: (err: any) => {
        this.collarsList = [];
        this.recordsCount = 0;
      }
    });
  }

  /**
   * This method used to reset Collar form
   */
  resetCollarForm() {
    this.createCollarForm.reset();
    this.createCollarFormValidations();
    this.createCollarFormControls["CollarType"]?.setValue("");
    this.createCollarFormControls["collarDescription"]?.setValue("");
    this.updateCollar = false;
  }

  /**
   * Initialize Create Collar Validations
   */
  createCollarFormValidations() {
    this.createCollarForm = this.formBuilder.group({
      CollarType: [
        this.collarData?.collarName || "",
        [
          Validators.required,
          Validators.minLength(
            this.createCollarValidation.CollarType.minLength
          ),
          Validators.maxLength(
            this.createCollarValidation.CollarType.maxLength
          ),
        ],
      ],
      collarDescription: [
        this.collarData?.description || "",
      ],
    });
  }

  /**
   * Create Collar Controls Initialized
   * @readonly
   */
  get createCollarFormControls() {
    return this.createCollarForm.controls;
  }

  /**
   * This method is used edit Collar
   */
  onClickEditCollar(user: any) {
    const collarId = user.collarId;
    this.updateCollar = true;
    this.mastersService.getCollarById(collarId).subscribe({
      next: (res: any) => {
        this.collarData = res.result;
        this.createCollarFormValidations();
      },
      error: (err: any) => {
        this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
      },
    });
  }

  /**
   * This method is used to sort column
   * @param key : value of which column based we need to sort the rows
   */
  sort(key: string) {
    const componentName = this.location.path();
    let value = key;
    sessionStorage.setItem(`${componentName}_property`, value);
    this.sortingKeyColumn = key;
    if (sessionStorage.getItem(componentName + "_order") == "desc") {
      this.sortingOrder = false;
    } else {
      this.sortingOrder = true;
    }
  }

  /**
   * This method is used to change the pagination controls
   * @param {*} event
   */
  onPageChange(event: any) {
    this.currentPage = event;
  }

  /**
   * Create Collar Form Submit
   */
  onCreateCollarFormSubmit() {
    /** This will return false if form fields are invalid and stop the service calling */
    if (this.createCollarForm.invalid) {
      this.validationService.validateAllFormFields(this.createCollarForm);
      return;
    }

    const obj = {
      collarId: "0",
      collarName: this.createCollarFormControls["CollarType"]?.value?.trim() || "",
      collarMode: this.collarModeName || "",
      description: this.createCollarFormControls["collarDescription"]?.value?.trim() || "",
      status: "0",
    };

    const updateCollarObj = {
      collarId: this.collarData?.collarId,
      collarName: this.createCollarFormControls["CollarType"]?.value?.trim() || "",
      collarMode: this.collarModeName || this.collarData?.collarMode,
      description: this.createCollarFormControls["collarDescription"]?.value?.trim() || "",
      status: this.collarData?.status || "",
    };

    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    if (this.updateCollar === false) {
      this.mastersService.addCollar(obj).subscribe({
        next: (res: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', '');
          this.getCollars();
          this.resetCollarForm();
        },
        error: (err: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
        },
      });
    } else {
      this.mastersService.editCollar(updateCollarObj).subscribe({
        next: (res: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', '');
          this.getCollars();
          this.updateCollar = false;
          this.resetCollarForm();
        },
        error: (err: any) => {
          /* Disable the loader */
          this.loaderService.isLoading.next(false);

          this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
        },
      });
    }
  }

  /**
   * This method is used to show search results
   */
  navigateToSearchResult() {
    this.currentPage = 1;
  }
}
