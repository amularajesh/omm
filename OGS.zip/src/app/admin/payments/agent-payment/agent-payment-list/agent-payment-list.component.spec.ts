import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AgentPaymentListComponent } from './agent-payment-list.component';

describe('AgentPaymentListComponent', () => {
  let component: AgentPaymentListComponent;
  let fixture: ComponentFixture<AgentPaymentListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AgentPaymentListComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AgentPaymentListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
