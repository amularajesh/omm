import { DatePipe, Location } from "@angular/common";
import { Component, OnInit, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";

import { SnackbarModalComponent } from "src/app/core/Dialogues/snackbar-modal/snackbar-modal.component";
import { LoaderService } from "src/app/core/Services/loader.service";
import { PaymentsService } from "src/app/core/Services/payments.service";
import { ValidationService } from "src/app/core/Services/validation.service";

/**
 * Agent Payment List Component
 * @export
 * @class AgentPaymentListComponent
 * @implements {OnInit}
 */
@Component({
  selector: 'app-agent-payment-list',
  templateUrl: './agent-payment-list.component.html',
  styleUrls: ['./agent-payment-list.component.scss']
})
export class AgentPaymentListComponent implements OnInit {
  /**
   * Get Snackbar Modal Component
   * @type {SnackbarModalComponent}
   */
  @ViewChild("snackbarModalComponent") snackbarModalComponent!: SnackbarModalComponent;

  /**
   * Declare Search Object
   */
  searchObj = {
    orderNo: 0,
    dressItemID: 0,
  };

  /**
   * Declaring Var To store Inward fabric min date.
   * @type {*}
   */
  paymentMinDate: Date;
  fromDate: Date;
  minDate: Date;

  paymentFromDate: any;

  paymentMaxDate: Date;

  /**
   * Get Agents List
   * @type {*}
   */
  agentsList: any;

  /**
   * Selected Dress Item
   */
  selectedAgent: any;

  /**
   * Get Agent Payments  List
   * @type {*}
   */
  agentPaymentList: any[] = [];

  /**
   * Get Sorting Order Flag
   */
  sortingOrder = false;

  /**
   * Get Sorting Key Column
   */
  sortingKeyColumn = "agentName";

  /**
   * Records Count
   */
  recordsCount = 0;

  /**
   * Default Page Number
   */
  currentPage = 1;

  /**
   * Search Term
   */
  searchTerm = "";

  /**
   * Create search agentPayment Form Declaration
   */
  searchAgentPaymentForm!: FormGroup;

  /**
   * Get search search agentPayment Form Validations
   */
  searchAgentVoucherValidation = this.validationService.searchAgentVoucher;

  /**
   * Initialize agent value
   * @type {*}
   */
  agentValue: any = 0;

  /**
   * Creates an instance of AgentPaymentListComponent.
   * @param {Router} router
   * @param {LoaderService} loaderService
   * @param {ValidationService} validationService
   * @param {FormBuilder} formBuilder
   * @param {DatePipe} datePipe
   * @param {PaymentsService} paymentsService
   * @param {Location} location
   */
  constructor(
    private router: Router,
    private loaderService: LoaderService,
    private validationService: ValidationService,
    private formBuilder: FormBuilder,
    private datePipe: DatePipe,
    private paymentsService: PaymentsService,
    private location: Location
  ) {
    // preparing initial date to fromDate
    this.fromDate = new Date();
    const lastMonth = new Date(this.fromDate);
    this.paymentMaxDate = new Date();

    if (lastMonth.getMonth() % 2 !== 0) {
      lastMonth.setMonth(lastMonth.getMonth() - 1);
      lastMonth.setDate(lastMonth.getDate() - 1);
    } else {
      lastMonth.setMonth(lastMonth.getMonth() - 1);
    }
    this.paymentMinDate = lastMonth;
    this.minDate = new Date("2000-01-01");
  }

  ngOnInit(): void {
    this.searchAgentPaymentFormValidations();
    this.getAgentsList();
    this.onSubmitSearchAgentPaymentForm();
  }

  /**
 * Create search agentPayment Controls Initialized
 * @readonly
 */
  get searchAgentPaymentFormControls() {
    return this.searchAgentPaymentForm.controls;
  }

  /**
   * Initialize Create search agentPayment Form Validations
   */
  searchAgentPaymentFormValidations() {
    this.searchAgentPaymentForm = this.formBuilder.group({
      agentSelect: [
        "0",
      ],
      issueDate: [""],
      fromDate: [
        new Date(this.paymentMinDate) || "",
        [Validators.required],
      ],
      toDate: [""],
    });

    this.fromDateChange(new Date(this.paymentMinDate))
  }

  /**
  * This method fired on change of from date
   * @param {Date} newValue
   */
  fromDateChange(newValue: Date) {
    this.paymentFromDate = newValue;
    this.searchAgentPaymentFormControls["toDate"]?.setValue("");
    this.searchAgentPaymentFormControls["toDate"]?.markAsUntouched({ onlySelf: true });
  }

  /**
   * This Method fired on change of issue date
   * @param {Date} newValue
   * @memberof AgentPaymentListComponent
   */
  IssueDateChange(newValue: Date) { }

  /**
   * This method fired on change of to date
   * @param {*} event
   */
  ToDateChange(event: any) { }

  /**
   * This method is used to get the agents List
   */
  getAgentsList() {
    this.paymentsService.getAgents().subscribe({
      next: (res: any) => {
        this.agentsList = res.result || [];
        this.agentsList.unshift({
          agentId: 0,
          agentName: "All"
        });
      },
      error: (err: any) => {
        this.agentsList = [];
        this.agentsList.unshift({
          agentId: 0,
          agentName: "All"
        });
      }
    });
  }

  /**
    * This method will fired when user selects agent
    * @param {*} event
    */
  onChangeAgent(event: any) {
    let dressItemSizeValue = event?.target ? +event.target?.value : +event;
    for (const element of this.agentsList) {
      if (element.agentId === dressItemSizeValue) {
        this.selectedAgent = element;
      }
    }
  }

  /**
   * This method is used to change the pagination controls
   * @param {*} event
   */
  onPageChange(event: any) {
    this.currentPage = event;
  }

  /**
   * This method is used to submit the search agent payment form
   */
  onSubmitSearchAgentPaymentForm() {
    /** This will return false if form fields are invalid and stop the service calling */
    if (this.searchAgentPaymentForm.invalid) {
      this.validationService.validateAllFormFields(this.searchAgentPaymentForm);
      return;
    }

    /* Prepare the request payload */
    const obj = {
      agentId: +this.searchAgentPaymentFormControls["agentSelect"].value || 0,
      issueDate: this.datePipe.transform(this.searchAgentPaymentFormControls["issueDate"].value, "yyyy-MM-dd") || "",
      fromDate: this.datePipe.transform(this.searchAgentPaymentFormControls["fromDate"].value, "yyyy-MM-dd") || "",
      toDate: this.datePipe.transform(this.searchAgentPaymentFormControls["toDate"].value, "yyyy-MM-dd") || "",
    }

    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    //method to send payload to get payments
    this.paymentsService.getAgentPayments(obj).subscribe({
      next: (res: any) => {
        /* Disable the loader if response is success */
        this.loaderService.isLoading.next(false);
        console.log(this.agentPaymentList, 'list');
        this.agentPaymentList = res.result;
        this.recordsCount = this.agentPaymentList.length;
        this.currentPage = 1;
        this.agentValue = +this.searchAgentPaymentFormControls["agentSelect"].value;
      },
      error: (err: any) => {
        /* Disable the loader if response is error */
        this.loaderService.isLoading.next(false);
        this.agentPaymentList = [];
        this.recordsCount = 0;
        this.currentPage = 1;
      }
    });
  }

  /**
   * This method is used to show search results
   */
  navigateToSearchResult() {
    this.currentPage = 1;
  }

  /**
   * This method is used to sort column
   * @param key : value of which column based we need to sort the rows
   */
  sort(key: string) {
    const componentName = this.location.path();
    let value = key;
    console.log(value);

    sessionStorage.setItem(`${componentName}_property`, value);
    this.sortingKeyColumn = key;

    if (sessionStorage.getItem(componentName + "_order") == "desc") {
      console.log(sessionStorage.getItem(componentName + "_order"));
      this.sortingOrder = false;
    } else {
      console.log(sessionStorage.getItem(componentName + "_order"));
      this.sortingOrder = true;
    }
  }

  /**
   * This Method Used To Navigate add payment page.
   */
  onClickCreateAgentPayment() {
    this.router.navigate(['/admin/payments/agentpayment/addpayment']);
  }

  /**
   * This Method Used To Navigate add payment page.
   */
  navigateToEdit(payment: any) {
    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    //method to send payload to get payments
    this.paymentsService.GetAgentPaymentById(payment?.agentPaymentId).subscribe({
      next: (res: any) => {
        /* Disable the loader if response is success */
        this.loaderService.isLoading.next(false);
        this.paymentsService.agentPaymentDetails.next(res.result);
        this.router.navigate(['/admin/payments/agentpayment/editpayment']);
      },
      error: (err: any) => {
        /* Disable the loader if response is error */
        this.loaderService.isLoading.next(false);
        this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message || err, '', '', '');
      }
    });
  }
}
