import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AgentPaymentRoutingModule } from './agent-payment-routing.module';
import { AddAgentPaymentComponent } from './add-agent-payment/add-agent-payment.component';
import { AgentPaymentListComponent } from './agent-payment-list/agent-payment-list.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatTooltipModule } from '@angular/material/tooltip';
import { NgxPaginationModule } from 'ngx-pagination';
import { ComponentModule } from 'src/app/core/Modules/component.module';
import { OrderModule } from 'ngx-order-pipe';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { AutosizeModule } from 'ngx-autosize';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { EditAgentPaymentComponent } from './edit-agent-payment/edit-agent-payment.component';


@NgModule({
  declarations: [
    AddAgentPaymentComponent,
    AgentPaymentListComponent,
    EditAgentPaymentComponent
  ],
  imports: [
    CommonModule,
    AgentPaymentRoutingModule,
    FormsModule,
    MatTooltipModule,
    ReactiveFormsModule,
    NgxPaginationModule,
    ComponentModule,
    OrderModule,
    BsDatepickerModule.forRoot(),
    NgMultiSelectDropDownModule,
    AutosizeModule,
    Ng2SearchPipeModule
  ]
})
export class AgentPaymentModule { }
