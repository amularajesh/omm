import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-agent-payment',
  templateUrl: './agent-payment.component.html',
  styleUrls: ['./agent-payment.component.scss']
})
export class AgentPaymentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
