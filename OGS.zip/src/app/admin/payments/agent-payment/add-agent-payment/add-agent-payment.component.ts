import { DatePipe } from '@angular/common';
import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

import { SnackbarModalComponent } from 'src/app/core/Dialogues/snackbar-modal/snackbar-modal.component';
import { LoaderService } from 'src/app/core/Services/loader.service';
import { PaymentsService } from 'src/app/core/Services/payments.service';
import { ValidationService } from 'src/app/core/Services/validation.service';

/**
 * Add Agent Payment Component
 * @export
 * @class AddAgentPaymentComponent
 * @implements {OnInit}
 */
@Component({
  selector: 'app-add-agent-payment',
  templateUrl: './add-agent-payment.component.html',
  styleUrls: ['./add-agent-payment.component.scss']
})
export class AddAgentPaymentComponent implements OnInit {
  /**
   * Get Snackbar Modal Component
   * @type {SnackbarModalComponent}
   */
  @ViewChild("snackbarModalComponent") snackbarModalComponent!: SnackbarModalComponent;

  /**
   * Set Min From Date
   * @type {Date}
   */
  minFromDate: Date;

  /**
   * Set Max From Date
   * @type {Date}
   */
  maxFromDate: Date;

  /**
   * Get Agent List
   * @type {*}
   */
  agentsList: any;

  /**
   * Get Payments Mode List
   * @type {*}
   */
  PaymentModeList: any;

  /**
   * Selected Payment Mode
   */
  selectedPaymentMode: any;

  /**
   * Create agentVoucher Form Declaration
   */
  addAgentVoucherForm!: FormGroup;

  /**
   * Get agentVoucher Form Validations
   */
  addAgentVoucherValidation = this.validationService.addAgentPayment;

  /**
   * Get Create agentVoucher Patterns
   * @private
   */
  private patterns = this.validationService.patterns;

  /**
   * Creates an instance of AddAgentPaymentComponent.
   * @param {Router} router
   * @param {LoaderService} loaderService
   * @param {ValidationService} validationService
   * @param {FormBuilder} formBuilder
   * @param {DatePipe} datePipe
   * @param {PaymentsService} paymentsService
   */
  constructor(
    private router: Router,
    private loaderService: LoaderService,
    private validationService: ValidationService,
    private formBuilder: FormBuilder,
    private datePipe: DatePipe,
    private paymentsService: PaymentsService
  ) {
    /* set Min Date */
    this.minFromDate = new Date();
    this.maxFromDate = new Date();
    const d = new Date();
    d.setDate(1);
    d.setMonth(0);
    d.setFullYear(2012);
    this.minFromDate = d;
  }

  /**
   * Life Cycle Hook Initialization
   */
  ngOnInit(): void {
    this.addAgentVoucherFormValidations();
    this.getAgentsList();
    this.getPaymentsList();
  }

  /**
   * Create add agent voucher Controls Initialized
   * @readonly
   */
  get addAgentVoucherFormControls() {
    return this.addAgentVoucherForm.controls;
  }

  /**
   * Initialize Create add agent voucher Form Validations
   */
  addAgentVoucherFormValidations() {
    this.addAgentVoucherForm = this.formBuilder.group({
      agentSelect: ['', [Validators.required]],
      paymentSelect: ['', [Validators.required]],
      SelectDate: [''],
      DraftNo: [''],
      payAmount: [
        '',
        [
          Validators.required,
          Validators.minLength(this.addAgentVoucherValidation.payAmount.minLength),
          Validators.maxLength(this.addAgentVoucherValidation.payAmount.maxLength),
          Validators.pattern(this.patterns?.payAmount)
        ]
      ],
      Remark: [
        '',
        [
          Validators.minLength(this.addAgentVoucherValidation?.Remark.minLength),
          Validators.maxLength(this.addAgentVoucherValidation?.Remark.maxLength)
        ]
      ]
    });
  }

  /**
   * This method is used to get the Agents List
   */
  getAgentsList() {
    this.paymentsService.getAgents().subscribe({
      next: (res: any) => {
        this.agentsList = res.result;
      },
      error: (err: any) => {
        this.agentsList = [];
      },
    });
  }

  /**
   * This method is used to get the Agents List
   */
  getPaymentsList() {
    this.paymentsService.getPaymentModes().subscribe({
      next: (res: any) => {
        this.PaymentModeList = res.result;
      },
      error: (err: any) => {
        this.PaymentModeList = [];
      },
    });
  }

  /**
   * This method used to reset form
   */
  resetAgentVoucher() {
    this.addAgentVoucherForm.reset();
    this.addAgentVoucherFormValidations();
  }

  /**
   * This method will fired when user selects Agent
   * @param {*} event
   */
  AgentChange(event: any) {
    if (event?.target?.value == '') {
      this.addAgentVoucherFormControls['agentSelect']?.markAsUntouched({ onlySelf: true });
    }
  }

  /**
   * This method will fired when user selects Payment
   * @param {*} event
   */
  PaymentChange(event: any) {
    if (event?.target?.value == '') {
      this.addAgentVoucherFormControls['paymentSelect']?.markAsUntouched({ onlySelf: true });
      this.selectedPaymentMode = '';
      this.onRemoveValidators(this.addAgentVoucherFormControls, ['DraftNo']);
      this.onUpdateValueAndValidity(this.addAgentVoucherFormControls, ['DraftNo']);
      return;
    }
    let paymentValue = event?.target ? +event.target?.value : +event;
    for (const element of this.PaymentModeList) {
      if (element.paymentModeId === paymentValue) {
        this.selectedPaymentMode = element;
      }
    }

    if (this.selectedPaymentMode.paymentModeId == 3 || this.selectedPaymentMode.paymentModeId == 4) {
      this.onRemoveValidators(this.addAgentVoucherFormControls, ['DraftNo']);
    } else {
      this.onAddValidators(this.addAgentVoucherFormControls, ['DraftNo']);
    }
    this.onUpdateValueAndValidity(this.addAgentVoucherFormControls, ['DraftNo']);
  }

  /**
   * This method is used to add validators
   * @param {*} formControls
   * @param {*} controls
   */
  onAddValidators(formControls: any, controls: any) {
    controls?.forEach((control: any) => {
      formControls[control].addValidators([Validators.required]);
      formControls[control].updateValueAndValidity({ onlySelf: true });
    });
  }

  /**
   * This method is used to remove validators
   * @param {*} formControls
   */
  onRemoveValidators(formControls: any, controls: any) {
    controls?.forEach((control: any) => {
      formControls[control].removeValidators([Validators.required]);
      formControls[control].updateValueAndValidity({ onlySelf: true });
    });
  }

  /**
   * This method is used to update value and validity
   * @param {*} formControls
   */
  onUpdateValueAndValidity(formControls: any, controls: any) {
    controls?.forEach((control: any) => {
      formControls[control].setValue("");
      formControls[control].markAsUntouched({ onlySelf: true });
      formControls[control].updateValueAndValidity({ onlySelf: true });
    });
  }

  /**
   * This Method Used To Navigate payment List page.
   */
  navigateToList() {
    this.router.navigate(['/admin/payments/agentpayment/paymentlist']);
  }

  /**
   * This method is used to submit add agent payment form
   */
  onSubmitAddAgentPaymentForm() {

    /** This will return false if form fields are invalid and stop the service calling */
    if (this.addAgentVoucherForm.invalid) {
      this.validationService.validateAllFormFields(this.addAgentVoucherForm);
      return;
    }

    /* Prepare request payload */
    const obj = {
      agentId: +this.addAgentVoucherFormControls['agentSelect']?.value || 0,
      paymentModeId: +this.addAgentVoucherFormControls['paymentSelect']?.value || 0,
      paymentMode: this.selectedPaymentMode?.paymentModeName || '',
      draftNo: this.addAgentVoucherFormControls['DraftNo']?.value || '',
      paymentAmount: +this.addAgentVoucherFormControls['payAmount']?.value || 0,
      issueDate: this.datePipe.transform(this.addAgentVoucherFormControls['SelectDate'].value, 'yyyy-MM-dd') || '',
      remarks: this.addAgentVoucherFormControls['Remark']?.value || '',
    };

    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    this.paymentsService.addAgentPayment(obj).subscribe({
      next: (res: any) => {
        /* Disable the loader */
        this.loaderService.isLoading.next(false);

        this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', 'agentPayment');
        this.resetAgentVoucher();
      },
      error: (err: any) => {
        /* Disable the loader */
        this.loaderService.isLoading.next(false);

        this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message || err, '', '', '');
      }
    });
  }
}
