import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddAgentPaymentComponent } from './add-agent-payment.component';

describe('AddAgentPaymentComponent', () => {
  let component: AddAgentPaymentComponent;
  let fixture: ComponentFixture<AddAgentPaymentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddAgentPaymentComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddAgentPaymentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
