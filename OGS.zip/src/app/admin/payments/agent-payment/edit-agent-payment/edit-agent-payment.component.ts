import { DatePipe } from "@angular/common";
import { Component, OnInit, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";

import { SnackbarModalComponent } from "src/app/core/Dialogues/snackbar-modal/snackbar-modal.component";
import { LoaderService } from "src/app/core/Services/loader.service";
import { PaymentsService } from "src/app/core/Services/payments.service";
import { ValidationService } from "src/app/core/Services/validation.service";

/**
 * Edit Agent Payment Component
 * @export
 * @class EditAgentPaymentComponent
 * @implements {OnInit}
 */
@Component({
  selector: 'app-edit-agent-payment',
  templateUrl: './edit-agent-payment.component.html',
  styleUrls: ['./edit-agent-payment.component.scss']
})
export class EditAgentPaymentComponent implements OnInit {
  /**
   * Get Snackbar Modal Component
   * @type {SnackbarModalComponent}
   */
  @ViewChild("snackbarModalComponent") snackbarModalComponent!: SnackbarModalComponent;

  /**
   * Set Min From Date
   * @type {Date}
   */
  minFromDate: Date;

  /**
   * Set Max From Date
   * @type {Date}
   */
  maxFromDate: Date;

  /**
   * Get Agent List
   * @type {*}
   */
  agentsList: any;

  /**
   * Get Payments Mode List
   * @type {*}
   */
  PaymentModeList: any;

  /**
   * Selected Agent
   */
  selectedAgent: any;

  /**
   * Selected Payment Mode
   */
  selectedPaymentMode: any;

  /**
   * Edit agentVoucher Form Declaration
   */
  editAgentPaymentForm!: FormGroup;

  /**
   * Get agentVoucher Form Validations
   */
  editAgentPaymentValidation = this.validationService.addAgentPayment;

  /**
   * Get Edit agentVoucher Patterns
   * @private
   */
  private patterns = this.validationService.patterns;

  /**
   * Get Agent payment details
   * @type {*}
   */
  editAgentPaymentDetails: any;

  /**
   * Creates an instance of EditAgentPaymentComponent.
   * @param {Router} router
   * @param {LoaderService} loaderService
   * @param {ValidationService} validationService
   * @param {FormBuilder} formBuilder
   * @param {DatePipe} datePipe
   * @param {PaymentsService} paymentsService
   */
  constructor(
    private router: Router,
    private loaderService: LoaderService,
    private validationService: ValidationService,
    private formBuilder: FormBuilder,
    private datePipe: DatePipe,
    private paymentsService: PaymentsService
  ) {

    /* set Min Date */
    this.minFromDate = new Date();
    this.maxFromDate = new Date();
    const d = new Date();
    d.setDate(1);
    d.setMonth(0);
    d.setFullYear(2012);
    this.minFromDate = d;

    /* Get Agent Payment Details from behavior subject */
    this.paymentsService.agentPaymentDetails.subscribe((val: any) => {
      if (Object.keys(val).length > 0) {
        this.editAgentPaymentDetails = val;
        console.log(this.editAgentPaymentDetails, 'details');
      } else {
        this.editAgentPaymentDetails = null;
        this.onNavigateToList();
      }
    });
  }

  /**
   * Life Cycle Hook Initialization
   */
  ngOnInit(): void {
    this.editAgentPaymentFormValidations();
    this.getAgentsList();
    this.getPaymentsList();
  }

  /**
   * Edit add agent voucher Controls Initialized
   * @readonly
   */
  get editAgentPaymentFormControls() {
    return this.editAgentPaymentForm.controls;
  }

  /**
   * Initialize Edit agent voucher Form Validations
   */
  editAgentPaymentFormValidations() {
    this.editAgentPaymentForm = this.formBuilder.group({
      agentSelect: ["", [Validators.required]],
      paymentSelect: ["", [Validators.required]],
      SelectDate: [this.editAgentPaymentDetails?.issueDate ? new Date(this.editAgentPaymentDetails?.issueDate) : ''],
      DraftNo: [this.editAgentPaymentDetails?.draftNo || ''],
      payAmount: [
        this.editAgentPaymentDetails?.paymentAmount || '',
        [
          Validators.required,
          Validators.minLength(this.editAgentPaymentValidation.payAmount.minLength),
          Validators.maxLength(this.editAgentPaymentValidation.payAmount.maxLength),
          Validators.pattern(this.patterns?.payAmount)
        ]
      ],
      Remark: [
        this.editAgentPaymentDetails?.remarks || '',
        [
          Validators.minLength(this.editAgentPaymentValidation?.Remark.minLength),
          Validators.maxLength(this.editAgentPaymentValidation?.Remark.maxLength)
        ]
      ]
    });
  }

  /**
   * This method is used to get the Agents List
   */
  getAgentsList() {
    this.paymentsService.getAgents().subscribe({
      next: (res: any) => {
        this.agentsList = res.result;
        if (this.editAgentPaymentDetails) {
          let agentValue = this.editAgentPaymentDetails?.agentId;
          this.editAgentPaymentFormControls['agentSelect'].setValue(agentValue?.toString());
          this.onChangeAgent(agentValue);
        }
      },
      error: (err: any) => {
        this.agentsList = [];
      }
    });
  }

  /**
   * This method is used to get the payment modes List
   */
  getPaymentsList() {
    this.paymentsService.getPaymentModes().subscribe({
      next: (res: any) => {
        this.PaymentModeList = res.result;
        if (this.editAgentPaymentDetails) {
          let paymentModeValue = this.editAgentPaymentDetails?.paymentModeId;
          this.editAgentPaymentFormControls['paymentSelect'].setValue(paymentModeValue?.toString());
          this.onChangePayment(paymentModeValue);
        }
      },
      error: (err: any) => {
        this.PaymentModeList = [];
      }
    });
  }

  /**
   * This method will fired when user selects Agent
   * @param {*} event
   */
  onChangeAgent(event: any) {
    if (event?.target?.value == '') {
      this.editAgentPaymentFormControls['agentSelect']?.markAsUntouched({ onlySelf: true });
      this.selectedAgent = '';
      return;
    }

    let agentValue = event?.target ? event.target?.value : event;
    for (const element of this.agentsList) {
      if (+element.agentId === +agentValue) {
        this.selectedAgent = element;
      }
    }
  }

  /**
   * This method will fired when user selects Payment
   * @param {*} event
   */
  onChangePayment(event: any) {
    if (event?.target?.value == '') {
      this.editAgentPaymentFormControls['paymentSelect']?.markAsUntouched({ onlySelf: true });
      this.selectedPaymentMode = '';
      this.onRemoveValidators(this.editAgentPaymentFormControls, ['DraftNo']);
      this.onUpdateValueAndValidity(this.editAgentPaymentFormControls, ['DraftNo']);
      return;
    }
    let paymentValue = event?.target ? event.target?.value : event;
    for (const element of this.PaymentModeList) {
      if (+element.paymentModeId === +paymentValue) {
        this.selectedPaymentMode = element;
      }
    }

    if (this.selectedPaymentMode.paymentModeId == 3 || this.selectedPaymentMode.paymentModeId == 4) {
      this.onRemoveValidators(this.editAgentPaymentFormControls, ['DraftNo']);
    } else {
      this.onAddValidators(this.editAgentPaymentFormControls, ['DraftNo']);
    }

    if (event?.target) {
      this.onUpdateValueAndValidity(this.editAgentPaymentFormControls, ['DraftNo']);
    }
  }

  /**
   * This method is used to add validators
   * @param {*} formControls
   * @param {*} controls
   */
  onAddValidators(formControls: any, controls: any) {
    controls?.forEach((control: any) => {
      formControls[control].addValidators([Validators.required]);
      formControls[control].updateValueAndValidity({ onlySelf: true });
    });
  }

  /**
   * This method is used to remove validators
   * @param {*} formControls
   */
  onRemoveValidators(formControls: any, controls: any) {
    controls?.forEach((control: any) => {
      formControls[control].removeValidators([Validators.required]);
      formControls[control].updateValueAndValidity({ onlySelf: true });
    });
  }

  /**
   * This method is used to update value and validity
   * @param {*} formControls
   */
  onUpdateValueAndValidity(formControls: any, controls: any) {
    controls?.forEach((control: any) => {
      formControls[control].setValue("");
      formControls[control].markAsUntouched({ onlySelf: true });
      formControls[control].updateValueAndValidity({ onlySelf: true });
    });
  }

  /**
   * This Method Used To Navigate payment List page.
   */
  onNavigateToList() {
    this.router.navigate(['/admin/payments/agentpayment/paymentlist']);
  }

  /**
   * This Method fired on submit of edit agent payment
   */
  editAgentVoucherFormSubmit() {
    /** This will return false if form fields are invalid and stop the service calling */
    if (this.editAgentPaymentForm.invalid) {
      this.validationService.validateAllFormFields(this.editAgentPaymentForm);
      return;
    }

    /* Prepare request payload */
    const obj = {
      agentPaymentId: this.editAgentPaymentDetails?.agentPaymentId,
      agentId: this.editAgentPaymentFormControls["agentSelect"].value || 0,
      agentName: this.selectedAgent?.agentName || '',
      paymentModeId: this.editAgentPaymentFormControls["paymentSelect"].value || 0,
      paymentMode: this.selectedPaymentMode?.paymentModeName || '',
      draftNo: this.editAgentPaymentFormControls["DraftNo"].value || "",
      paymentAmount: this.editAgentPaymentFormControls["payAmount"].value,
      issueDate: this.datePipe.transform(this.editAgentPaymentFormControls['SelectDate'].value, 'yyyy-MM-dd') || '',
      remarks: this.editAgentPaymentFormControls['Remark']?.value,
      activeStatus: this.editAgentPaymentDetails?.activeStatus,
      userId: this.editAgentPaymentDetails?.userId
    };

    console.log('Agent payment Add', obj);

    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    this.paymentsService.editAgentPayment(obj).subscribe({
      next: (res: any) => {
        /* Disable the loader */
        this.loaderService.isLoading.next(false);

        this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', 'agentPayment');
      },
      error: (err: any) => {
        /* Disable the loader */
        this.loaderService.isLoading.next(false);

        this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message || err, '', '', '');
      }
    });
  }
}
