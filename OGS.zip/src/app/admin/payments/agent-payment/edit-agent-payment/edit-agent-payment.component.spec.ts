import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditAgentPaymentComponent } from './edit-agent-payment.component';

describe('EditAgentPaymentComponent', () => {
  let component: EditAgentPaymentComponent;
  let fixture: ComponentFixture<EditAgentPaymentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EditAgentPaymentComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EditAgentPaymentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
