import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AgentPaymentComponent } from './agent-payment.component';
import { AgentPaymentListComponent } from './agent-payment-list/agent-payment-list.component';
import { AddAgentPaymentComponent } from './add-agent-payment/add-agent-payment.component';
import { EditAgentPaymentComponent } from './edit-agent-payment/edit-agent-payment.component';

const routes: Routes = [
  {
    path: "",
    component: AgentPaymentComponent,
    children: [
      { path: "", redirectTo: "paymentlist", pathMatch: "full" },
      {
        path: "addpayment",
        component: AddAgentPaymentComponent,
      },
      {
        path: "editpayment",
        component: EditAgentPaymentComponent,
      },
      {
        path: "paymentlist",
        component: AgentPaymentListComponent,
      },

    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AgentPaymentRoutingModule { }
