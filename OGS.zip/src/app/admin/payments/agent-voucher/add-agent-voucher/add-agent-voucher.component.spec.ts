import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddAgentVoucherComponent } from './add-agent-voucher.component';

describe('AddAgentVoucherComponent', () => {
  let component: AddAgentVoucherComponent;
  let fixture: ComponentFixture<AddAgentVoucherComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddAgentVoucherComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddAgentVoucherComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
