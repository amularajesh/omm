import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { OrderModule } from 'ngx-order-pipe';
import { ComponentModule } from 'src/app/core/Modules/component.module';
import { NgSelectModule } from '@ng-select/ng-select';
import { NgxPaginationModule } from 'ngx-pagination';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { MatTooltipModule } from '@angular/material/tooltip';
import { AutosizeModule } from 'ngx-autosize';
import { AgentTransactionHistoryRoutingModule } from './agent-transaction-history-routing.module';
import { AgentTransactionListComponent } from './agent-transaction-list/agent-transaction-list.component';


@NgModule({
    declarations: [
    
    AgentTransactionListComponent
  ],
    imports: [
        CommonModule,
        AgentTransactionHistoryRoutingModule,
        FormsModule,
        OrderModule,
        ComponentModule,
        NgSelectModule,
        NgxPaginationModule,
        Ng2SearchPipeModule,
        ReactiveFormsModule,
        BsDatepickerModule.forRoot(),
        MatTooltipModule,
        AutosizeModule
    ]
})
export class AgentTransactionHistoryModule { }
