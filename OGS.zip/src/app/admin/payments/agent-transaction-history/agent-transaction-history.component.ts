import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-agent-transaction-history',
  templateUrl: './agent-transaction-history.component.html',
  styleUrls: ['./agent-transaction-history.component.scss']
})
export class AgentTransactionHistoryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
