import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AgentTransactionHistoryComponent } from './agent-transaction-history.component';
import { AgentTransactionListComponent } from './agent-transaction-list/agent-transaction-list.component';

const routes: Routes = [
    {
        path: '',
        component: AgentTransactionHistoryComponent,
        children: [
            { path: '', redirectTo: "transactionlist", pathMatch: 'full' },

            {
                path: "transactionlist",
                component: AgentTransactionListComponent,
              },

        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class AgentTransactionHistoryRoutingModule { }
