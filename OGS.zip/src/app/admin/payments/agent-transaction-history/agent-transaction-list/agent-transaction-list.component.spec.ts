import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AgentTransactionListComponent } from './agent-transaction-list.component';

describe('AgentTransactionListComponent', () => {
  let component: AgentTransactionListComponent;
  let fixture: ComponentFixture<AgentTransactionListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AgentTransactionListComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AgentTransactionListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
