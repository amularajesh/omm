import { DatePipe, Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

import { CustomersService } from 'src/app/core/Services/customers.service';
import { LoaderService } from 'src/app/core/Services/loader.service';
import { MastersService } from 'src/app/core/Services/masters.service';
import { PaymentsService } from 'src/app/core/Services/payments.service';
import { ValidationService } from 'src/app/core/Services/validation.service';

/**
 * Agent Transaction List Component
 * @export
 * @class AgentTransactionListComponent
 * @implements {OnInit}
 */
@Component({
  selector: 'app-agent-transaction-list',
  templateUrl: './agent-transaction-list.component.html',
  styleUrls: ['./agent-transaction-list.component.scss']
})
export class AgentTransactionListComponent implements OnInit {
  /**
   * Declaring Var To store Inward fabric min date.
   * @type {Date}
   */
  inwardFabricMinDate: Date;
  fromDate: Date;
  minDate: Date;
  inwardFabricFromDate: any;
  inwardFabricMaxDate: Date;

  /**
   * Get Agents List
   * @type {*}
   */
  agentsList: any;

  /**
   * Get Agent Transaction History List
   * @type {any[]}
   */
  agentTransactionHistoryList: any[] = [];

  /**
   * Get Sorting Order Flag
   */
  sortingOrder = false;

  /**
   * Get Sorting Key Column
   */
  sortingKeyColumn = 'createdDate';

  /**
   * Records Count
   */
  recordsCount = 0;

  /**
   * Default Page Number
   */
  currentPage = 1;

  /**
   * Search Term
   */
  searchTerm = '';

  /**
   * Create search agent transaction history Form Declaration
   */
  searchAgentTransactionForm!: FormGroup;

  /**
   * Get search search agentVoucher Form Validations
   */
  searchAgentVoucherValidation = this.validationService.searchAgentTranctionHistory;

  /**
   * Get Create search agentVoucher Patterns
   * @private
   */
  private patterns = this.validationService.patterns;

  /**
   * Creates an instance of AgentTransactionListComponent.
   * @param {Router} router
   * @param {LoaderService} loaderService
   * @param {ValidationService} validationService
   * @param {FormBuilder} formBuilder
   * @param {DatePipe} datePipe
   * @param {PaymentsService} paymentsService
   * @param {Location} location
   */
  constructor(
    private router: Router,
    private loaderService: LoaderService,
    private validationService: ValidationService,
    private formBuilder: FormBuilder,
    private datePipe: DatePipe,
    private paymentsService: PaymentsService,
    private location: Location
  ) {
    // preparing initial date to fromDate
    this.fromDate = new Date();
    const lastMonth = new Date(this.fromDate);
    this.inwardFabricMaxDate = new Date();

    if (lastMonth.getMonth() % 2 !== 0) {
      lastMonth.setMonth(lastMonth.getMonth() - 1);
      lastMonth.setDate(lastMonth.getDate() - 1);
    } else {
      lastMonth.setMonth(lastMonth.getMonth() - 1);
    }
    this.inwardFabricMinDate = lastMonth;
    this.minDate = new Date('2000-01-01');
  }

  /**
   * Life Cycle Hook Initialization
   */
  ngOnInit(): void {
    this.searchAgentTransactionFormValidations();
    this.getAgentsList();
  }

  /**
   * Create search agent transaction history Controls Initialized
   * @readonly
   */
  get searchAgentTransactionFormControls() {
    return this.searchAgentTransactionForm.controls;
  }

  /**
   * Initialize Create search agent transaction history Form Validations
   */
  searchAgentTransactionFormValidations() {
    this.searchAgentTransactionForm = this.formBuilder.group({
      agentSelect: ['', [Validators.required]],
      fromDate: [''],
      toDate: ['']
    });
  }

  /**
   * This method fired on change of from date
   * @param {Date} newValue
   */
  fromDateChange(newValue: Date) {
    this.inwardFabricFromDate = newValue;
    this.searchAgentTransactionFormControls['toDate']?.setValue('');
    this.searchAgentTransactionFormControls['toDate']?.markAsUntouched({ onlySelf: true });
  }

  /**
   * This method fired on change of to date
   * @param {*} event
   */
  ToDateChange(event: any) { }

  /**
   * This method is used to get the Dress Item List
   */
  getAgentsList() {
    this.paymentsService.getAgents().subscribe({
      next: (res: any) => {
        this.agentsList = res.result;
      },
      error: (err: any) => {
        this.agentsList = [];
      }
    });
  }

  /**
   * This method used to search form
   */
  resetSampleOrder() {
    this.searchAgentTransactionForm.reset();
    this.searchAgentTransactionFormValidations();
  }

  /**
   * This method will fired when user selects Dress Item
   * @param {*} event
   */
  onChangeAgent(event: any) {
    if (event?.target?.value == '') {
      this.searchAgentTransactionFormControls['agentSelect']?.markAsUntouched({ onlySelf: true });
    }
  }

  /**
   * This method is used to change the pagination controls
   * @param {*} event
   */
  onPageChange(event: any) {
    this.currentPage = event;
  }

  /**
   * This method is used to submit the search cutting program
   */
  onSubmitSearchAgentTransactionForm() {
    /** This will return false if form fields are invalid and stop the service calling */
    if (this.searchAgentTransactionForm.invalid) {
      this.validationService.validateAllFormFields(this.searchAgentTransactionForm);
      return;
    }
    /* Prepare the request payload */
    const obj = {
      agentId: +this.searchAgentTransactionFormControls['agentSelect']?.value || 0,
      fromDate: this.datePipe.transform(this.searchAgentTransactionFormControls['fromDate'].value, 'yyyy-MM-dd') || '',
      toDate: this.datePipe.transform(this.searchAgentTransactionFormControls['toDate'].value, 'yyyy-MM-dd') || ''
    };

    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    /* To call the service to get the Agent Transaction History by passing obj */
    this.paymentsService.getAgentTransactionHistory(obj).subscribe({
      next: (res: any) => {
        /* Disable the loader if response is success */
        this.loaderService.isLoading.next(false);
        this.agentTransactionHistoryList = res.result;
        this.recordsCount = this.agentTransactionHistoryList.length;
        this.currentPage = 1;
      },
      error: (err: any) => {
        /* Disable the loader if response is error */
        this.loaderService.isLoading.next(false);
        this.agentTransactionHistoryList = [];
        this.recordsCount = 0;
        this.currentPage = 1;
      },
    });
  }

  /**
   *Onclick edit voucher
   *
   * @param {*} voucher
   * @memberof AgentVoucherListComponent
   */
  onClickEditVoucher(voucher: any) {
    this.paymentsService.ViewAgentVoucher(voucher?.Id).subscribe({
      next: (res: any) => {
        /* Disable the loader if response is success */
        this.loaderService.isLoading.next(false);
        //send data to behaviour subject
        this.paymentsService?.agentVoucherDetails.next(res?.result);
        this.agentTransactionHistoryList = res.result;
        this.navigateToEdit();
      },
      error: (err: any) => {
        /* Disable the loader if response is error */
        this.loaderService.isLoading.next(false);
      },
    });
  }

  /**
   * This method is used to show search results
   */
  navigateToSearchResult() {
    this.currentPage = 1;
  }

  /**
   * This method is used to sort column
   * @param key : value of which column based we need to sort the rows
   */
  sort(key: string) {
    const componentName = this.location.path();
    let value = key;
    console.log(value);

    sessionStorage.setItem(`${componentName}_property`, value);
    this.sortingKeyColumn = key;

    if (sessionStorage.getItem(componentName + '_order') == 'desc') {
      console.log(sessionStorage.getItem(componentName + '_order'));
      this.sortingOrder = false;
    } else {
      console.log(sessionStorage.getItem(componentName + '_order'));
      this.sortingOrder = true;
    }
  }

  /**
   * This method is used for navigate to create cutting order page when user clicked on add cutting program
   */
  onClickCreateagentVoucher() {
    this.router.navigate([
      '/admin/customer-order/agentVoucher/addAgentVoucher',
    ]);
  }

  /**
   * This Method Used To Navigate add Voucher page.
   */
  navigateToAdd() {
    this.router.navigate(['/admin/payments/agentvoucher/addAgentVoucher']);
  }

  /**
   * This Method Used To Navigate Edit Voucher page.
   */
  navigateToEdit() {
    this.router.navigate(['/admin/payments/agentvoucher/viewAgentVoucher']);
  }
}
