import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { DashbordChildComponent } from "./dashbord-child/dashbord-child.component";

const routes: Routes = [
  {
    path: "",
    component: DashbordChildComponent,
    children: [
      { path: "", redirectTo: "dash-board", pathMatch: "full" },
      { path: "dash-board", component: DashbordChildComponent },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class DashBoardRoutingModule {}
