import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashbord-child',
  templateUrl: './dashbord-child.component.html',
  styleUrls: ['./dashbord-child.component.scss']
})
export class DashbordChildComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
