import { DatePipe } from "@angular/common";
import { ChangeDetectorRef, Component, HostListener, OnDestroy, OnInit, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";

import { SnackbarModalComponent } from "src/app/core/Dialogues/snackbar-modal/snackbar-modal.component";
import { CourierMode, DiagramMode, OrderItems, OrganizationType, StatusMode } from "src/app/core/Modals/modals";
import { ChargesService } from "src/app/core/Services/charges.service";
import { CustomersService } from "src/app/core/Services/customers.service";
import { LoaderService } from "src/app/core/Services/loader.service";
import { MastersService } from "src/app/core/Services/masters.service";
import { OrderService } from "src/app/core/Services/order.service";
import { ValidationService } from "src/app/core/Services/validation.service";
import { OrdersMiddyPatternModalComponent } from "../orders-middy-pattern-modal/orders-middy-pattern-modal.component";
import { OrdersNickersModelComponent } from "../orders-nickers-model/orders-nickers-model.component";
import { OrdersPantPatternModalComponent } from "../orders-pant-pattern-modal/orders-pant-pattern-modal.component";
import { OrdersPinofersModelComponent } from "../orders-pinofers-model/orders-pinofers-model.component";
import { OrdersShotsModelComponent } from "../orders-shots-model/orders-shots-model.component";
import { OrdersTShirtsPatternModalComponent } from "../orders-t-shirts-pattern-modal/orders-t-shirts-pattern-modal.component";

/**
 * Add Orders Component
 * @export
 * @class AddOrdersComponent
 * @implements {OnInit}
 */
@Component({
  selector: "app-add-orders",
  templateUrl: "./add-orders.component.html",
  styleUrls: ["./add-orders.component.scss"],
})
export class AddOrdersComponent implements OnInit, OnDestroy {
  /**
   * Get Orders T-Shirts Pattern Modal Component
   * @type {OrdersTShirtsPatternModalComponent}
   */
  @ViewChild("tShirtsPatternComponent") tShirtsPatternComponent!: OrdersTShirtsPatternModalComponent;

  /**
   * Get Orders Middy Pattern Modal Component
   * @type {OrdersMiddyPatternModalComponent}
   */
  @ViewChild("middyPatternModalComponent") middyPatternModalComponent!: OrdersMiddyPatternModalComponent;

  /**
   * Get Orders Nickers Pattern Modal Component
   * @type {OrdersNickersModelComponent}
   */
  @ViewChild("nickersComponent") nickersComponent!: OrdersNickersModelComponent;

  /**
   * Get Orders Shots Pattern Modal Component
   * @type {OrdersShotsModelComponent}
   */
  @ViewChild("shortsComponent") shortsComponent!: OrdersShotsModelComponent;

  /**
   * Get Orders Pant Pattern Modal Component
   * @type {OrdersPantPatternModalComponent}
   */
  @ViewChild("pantComponent") pantComponent!: OrdersPantPatternModalComponent;

  /**
   * Get Orders Pinofers Pattern Modal Component
   * @type {OrdersPinofersModelComponent}
   */
  @ViewChild("pinofersComponent") pinofersComponent!: OrdersPinofersModelComponent;

  /**
   * Get Snackbar Modal Component
   * @type {SnackbarModalComponent}
   */
  @ViewChild("snackbarModalComponent") snackbarModalComponent!: SnackbarModalComponent;

  /**
   * Declare the Pocket Dress Items List
   */
  pocketDressItemsList = ["Pinofers", "Frock", "T-Shirts"];

  /**
   * Declare the Pattern Dress Items List
   */
  patternDressItemsList = [
    "T-Shirts",
    "Middy",
    "Nicker",
    "Pant",
    "Pinofers",
    "Shots",
  ];

  /**
   * Declare the Back Print Dress Items List
   */
  backPrintDressItemsList = ["Frock", "T-Shirts", "Pinofers"];

  /**
   * Get Order Items List
   */
  orderItemsList: OrderItems[] = [];

  /**
   * Get Saved Order Items List
   */
  savedOrderItemsList: OrderItems[] = [];

  /**
   * Get Total Order value
   */
  totalOrderValue = 0;

  /**
   * Get Total Quantity
   */
  totalQuantity = 0;

  /**
   * Get Average Unit Price
   * @type {*}
   */
  avgUnitPrice: any;

  /**
   * Get Master Colors List
   * @type {*}
   */
  masterColorsList: any;

  /**
   * Get Sizes List
   * @type {*}
   */
  sizesList: any;

  /**
   * Get Is Save Order Flag
   */
  isSaveOrder = false;

  /**
   * Get Is Add Order Items Flag
   */
  isAddOrderItems = false;

  /**
   * Get Is Add Pattern Details Flag
   */
  isAddPatternDetails = false;

  /**
   * Get Is Pattern Dress Item Flag
   */
  isPatternDressItem = false;

  /**
   * Get Is Back Print Flag
   */
  isBackPrint = false;

  /**
   * Get Is Print Type Flag
   */
  isPrintType = false;

  /**
   * Get Is TShirt Special Model Flag
   */
  isTShirtSpecialModel = '';

  /**
   * Get Staff Select Flag
   */
  isStaffSelect = true;

  /**
   * Diagram List
   * @type {DiagramMode[]}
   */
  diagramList: DiagramMode[] = [
    { id: 0, type: "No Image" },
    { id: 1, type: "1" },
    { id: 2, type: "2" },
    { id: 3, type: "3" },
    { id: 4, type: "4" },
    { id: 5, type: "5" },
    { id: 6, type: "6" }
  ];

  /**
   * Get Status Mode List
   * @type {StatusMode[]}
   */
  statusModesList: StatusMode[] = [
    { id: "1", type: "Not Completed" },
    { id: "2", type: "Completed" },
    { id: "3", type: "Cancelled" }
  ];

  /**
   * Get Courier Mode List
   * @type {CourierMode[]}
   */
  courierList: CourierMode[] = [
    { id: "1", type: "DHL" },
    { id: "2", type: "DTDC" }
  ];

  /**
   * Get Payment Modes List
   * @type {CourierMode[]}
   */
  paymentModesList: CourierMode[] = [
    { id: "1", type: "With Pass" },
    { id: "2", type: "Bank" }
  ];

  /**
   * Get Agents list
   * @type {*}
   */
  agentsList: any;

  /**
   * Get Staffs List
   * @type {*}
   */
  staffList: any;

  /**
   * Get Selected status
   */
  selectedStatus: any;

  /**
   * Get Selected courier
   */
  selectedCourier: any;

  /**
   * Get Is Courier Flag
   */
  isCourier = false;

  /**
   * Selected Diagram
   */
  selectedDiagram: any;

  /**
   * Selected Diagram URL
   */
  diagramURL = '';

  /**
   * Get Is Changes In Pattern Flag
   */
  isChangesInPattern = '';

  /**
   * print Type
   */
  selectedPrintType = 2;

  /**
   * Get Selected Method
   */
  selectedMethod: any;

  /**
   * Get Selected Quality
   */
  selectedQuality: any;

  /**
   * Get Selected Pattern
   */
  selectedPattern: any;

  /**
   * Get Dress Items List
   * @type {*}
   */
  dressItemsList: any;

  /**
   * method List
   */
  methodsList: any = [];

  /**
   * quality List
   */
  qualityList: any;

  /**
   * Get Patterns List
   */
  patternsList: any;

  /**
   * Selected Dress Item
   */
  selectedDressItem: any;

  /**
   * Get Organization Types List
   */
  organizationTypeList: OrganizationType[] = [
    { id: "1", type: "School" },
    { id: "2", type: "Showroom" },
  ];

  /**
   * Selected organization
   */
  selectedOrganization: any;

  /**
   * Selected New Dress Item
   */
  selectedNewDressItem: any;

  /**
   * Selected New Method
   */
  selectedNewMethod: any;

  /**
   * Selected New Pattern
   */
  selectedNewPattern: any;

  /**
   * Selected Payment Mode
   */
  selectedPaymentMode: any;

  /**
   * Get Organization Details
   * @type {*}
   */
  organizationDetails: any;

  /**
   * Create Order Form Declaration
   */
  createOrderForm!: FormGroup;

  /**
   * Get Order Form Validations
   */
  createOrderValidation = this.validationService.createOrder;

  /**
   * Declare Add Order Item Form
   * @type {FormGroup}
   */
  addOrderItemsForm!: FormGroup;

  /**
   * Get Add Order Form Validations
   */
  addOrderFormValidation = this.validationService.addOrder;

  /**
   * Get Add Order Form Validations
   */
  patterns = this.validationService.patterns;

  /**
   * Get Is Agent Flag
   */
  isAgent = false;

  /**
   * Get Is Through Agent Flag
   */
  isThroughAgent = false;

  /**
   * Get Selected Order Received
   */
  selectedOrderReceived = 0;

  /**
   * Get Selected Agent Type
   */
  selectedAgentType = 1;

  /**
   * Get Selected Agent
   */
  selectedAgent: any;

  /**
   * Get Selected Staff
   */
  selectedStaff: any;

  /**
   * Get Selected Calculate Points
   */
  selectedCalculatePoints = 0;

  /**
   * Get Selected School Type
   */
  selectedSchoolType = 1;

  /**
   * Get Latest Sales Tax Name
   * @type {*}
   */
  latestSalesTaxName: any;

  /**
   * Set Min From Date
   * @type {Date}
   */
  minFromDate: Date;

  /**
   * Get Is Success Snackbar Flag
   */
  isSuccessSnackbar = false;

  /**
   * Get Is Overlay Visible Flag
   */
  isOverlayVisible = false;

  /**
   * Get Inner HTML Message
   */
  innerHTMLMessage = '';

  /**
   * Get Inner HTML Order Id
   */
  innerHTMLOrderId = '';

  /**
   * Get Copy Sample Order Details
   * @type {*}
   */
  copySampleOrderDetails: any;

  /**
   * Get Copy Order Details
   * @type {*}
   */
  copyOrderDetails: any;

  /**
   * Creates an instance of AddOrdersComponent.
   * @param {Router} router
   * @param {ValidationService} validationService
   * @param {FormBuilder} formBuilder
   * @param {MastersService} mastersService
   * @param {ChargesService} chargesService
   * @param {OrderService} orderService
   * @param {LoaderService} loaderService
   * @param {CustomersService} customerService
   * @param {DatePipe} datePipe
   * @param {ChangeDetectorRef} cdr
   */
  constructor(
    private router: Router,
    private validationService: ValidationService,
    private formBuilder: FormBuilder,
    private mastersService: MastersService,
    private chargesService: ChargesService,
    private orderService: OrderService,
    private loaderService: LoaderService,
    private customerService: CustomersService,
    private datePipe: DatePipe,
    private cdr: ChangeDetectorRef
  ) {
    localStorage.removeItem("savedOrdersList");
    /* Get Organization Details from behavior subject*/
    this.orderService.organizationDetails.subscribe((val: any) => {
      if (Object.keys(val).length !== 0) {
        this.organizationDetails = val;
        if (this.organizationDetails?.organizationType === 'School') {
          this.isStaffSelect = true;
        } else {
          this.isStaffSelect = false;
        }
      } else {
        this.organizationDetails = null;
      }
    });
    this.minFromDate = new Date();

    /* Get Copy Sample Order Details from behavior subject*/
    this.orderService.copySampleOrderDetails.subscribe((val: any) => {
      if (Object.keys(val).length !== 0) {
        this.copySampleOrderDetails = val;
        if (this.copySampleOrderDetails?.sampleOrder?.organizationType === 'School') {
          this.isStaffSelect = true;
        } else {
          this.isStaffSelect = false;
        }
      } else {
        this.copySampleOrderDetails = null;
      }
    });

    /* Get Copy Order Details from behavior subject*/
    this.orderService.copyOrderDetails.subscribe((val: any) => {
      if (Object.keys(val).length !== 0) {
        this.copyOrderDetails = val;
        if (this.copyOrderDetails?.order?.organizationType === 'School') {
          this.isStaffSelect = true;
        } else {
          this.isStaffSelect = false;
        }
      } else {
        this.copyOrderDetails = null;
      }
    });
  }

  /**
   * Life Cycle Hook Initialization
   */
  ngOnInit(): void {
    this.createOrderFormValidations();
    this.addOrderFormValidations();
    this.getDressItemList();
    this.getColorsList();
    this.getQualityList();
    this.getSaleTax();
    if (this.isStaffSelect) {
      this.onAddValidators(this.createOrderFormControls, ['staff']);
    } else {
      this.onRemoveValidators(this.createOrderFormControls, ['staff']);
    }
    this.getStaffsList();
  }

  /**
   * Initialize Create Order Form Validations
   */
  createOrderFormValidations() {
    let organizationNameValue = '';
    let organizationSelectValue = '';
    let customerId = '';
    let stateName = '';
    let districtName = '';
    let mandalName = '';
    let townName = '';
    let address = '';
    let placeValue = '';
    let paymentModeValue = '';
    let deliveryDateValue: any = '';
    let remarksValue = '';
    let staffValue = '';
    let agentCommissionValue = '';
    let printTypeId = '2';
    let schoolTypeValue = '1';
    let orderReceivedValue = '0';
    let calculatePointsValue = '0';
    let unitPointsValue = '0';

    if (this.copySampleOrderDetails) {
      organizationNameValue = this.copySampleOrderDetails?.sampleOrder?.organizationName;
      organizationSelectValue = this.organizationTypeList?.filter((item: any) => item.type == this.copySampleOrderDetails?.sampleOrder?.organizationType)[0]?.id;
      customerId = this.copySampleOrderDetails?.sampleOrder?.customerId;
      stateName = this.copySampleOrderDetails?.sampleOrder?.stateName;
      districtName = this.copySampleOrderDetails?.sampleOrder?.districtName;
      mandalName = this.copySampleOrderDetails?.sampleOrder?.mandalName;
      townName = this.copySampleOrderDetails?.sampleOrder?.townName;
      address = this.copySampleOrderDetails?.sampleOrder?.address;
    } else if (this.organizationDetails) {
      organizationNameValue = this.organizationDetails?.organizationName;
      address = this.organizationDetails?.address;
      organizationSelectValue = this.organizationDetails?.organizationTypeId;
      customerId = this.organizationDetails?.mobileNo;
      stateName = this.organizationDetails?.stateName;
      districtName = this.organizationDetails?.districtName;
      mandalName = this.organizationDetails?.mandalName;
      townName = this.organizationDetails?.townName;
    } else if (this.copyOrderDetails) {
      organizationNameValue = this.copyOrderDetails?.order?.organizationName;
      organizationSelectValue = this.organizationTypeList?.filter((item: any) => item.type == this.copyOrderDetails?.order?.organizationType)[0]?.id;
      customerId = this.copyOrderDetails?.order?.customerId;
      stateName = this.copyOrderDetails?.order?.stateName;
      districtName = this.copyOrderDetails?.order?.districtName;
      mandalName = this.copyOrderDetails?.order?.mandalName;
      townName = this.copyOrderDetails?.order?.townName;
      address = this.copyOrderDetails?.order?.address;
      placeValue = this.copyOrderDetails?.order?.transportName || '';
      paymentModeValue = this.copyOrderDetails?.order?.modeOfPaymentId;
      remarksValue = this.copyOrderDetails?.order?.remarks || '';
      staffValue = this.copyOrderDetails?.order?.staffId || '';
      printTypeId = this.copyOrderDetails?.order?.printtypeId?.toString();
      schoolTypeValue = this.copyOrderDetails?.order?.orderTypeId?.toString();
      orderReceivedValue = this.copyOrderDetails?.order?.orderRecived?.toString();
      agentCommissionValue = this.copyOrderDetails?.order?.agentCommPerc?.toString() || '';
      calculatePointsValue = this.copyOrderDetails?.order?.calculatePoints?.toString() || '';
      unitPointsValue = this.copyOrderDetails?.order?.unitPoints?.toString() || '';

      deliveryDateValue = new Date();
      /* Convert date strings to Date objects */
      const date1: any = new Date();
      date1.setHours(0, 0, 0, 0);
      let date2: any;
      if (this.copyOrderDetails?.order?.expectedDDate) {
        date2 = new Date(this.copyOrderDetails?.order?.expectedDDate);
        date2.setHours(0, 0, 0, 0);
      }
      const date3: any = new Date();
      date3.setHours(0, 0, 0, 0);

      /* Calculate the time differences in milliseconds */
      const timeDifference1 = date2 - date1;
      const timeDifference2 = date3 - date1;

      /* Convert the time differences to years */
      const yearsDifference1 = timeDifference1 / (1000 * 60 * 60 * 24 * 365);
      const yearsDifference2 = timeDifference2 / (1000 * 60 * 60 * 24 * 365);

      /* Reset the value if the currentJoining date is less than minJoining date */
      if (yearsDifference2 < yearsDifference1) {
        deliveryDateValue = date2;
      } else {
        deliveryDateValue = new Date();
      }
    }

    this.createOrderForm = this.formBuilder.group({
      OrganizationName: [organizationNameValue, [Validators.required]],
      Address: [address],
      organizationSelect: [organizationSelectValue],
      StateName: [stateName],
      DistrictName: [districtName],
      MandalName: [mandalName],
      TownName: [townName],
      CustomerId: [customerId || ""],
      email: [""],
      dressItemSelect: ["", [Validators.required]],
      methodSelect: ["", [Validators.required]],
      qualitySelect: ["", [Validators.required]],
      patternSelect: [""],
      printType: [printTypeId],
      SchoolType: [schoolTypeValue],
      BackPrintOne: [
        "",
        [
          Validators.minLength(this.createOrderValidation.BackPrintOne.minLength),
          Validators.maxLength(this.createOrderValidation.BackPrintOne.maxLength)
        ]
      ],
      BackPrintTwo: [
        "",
        [
          Validators.minLength(this.createOrderValidation.BackPrintTwo.minLength),
          Validators.maxLength(this.createOrderValidation.BackPrintTwo.maxLength)
        ]
      ],
      BackPrintThree: [
        "",
        [
          Validators.minLength(this.createOrderValidation.BackPrintThree.minLength),
          Validators.maxLength(this.createOrderValidation.BackPrintThree.maxLength)
        ]
      ],
      BackPrintFour: [
        "",
        [
          Validators.minLength(this.createOrderValidation.BackPrintFour.minLength),
          Validators.maxLength(this.createOrderValidation.BackPrintFour.maxLength)
        ]
      ],
      diagramSelect: [""],
      place: [placeValue,
        [
          Validators.required,
          Validators.minLength(this.createOrderValidation.place.minLength),
          Validators.maxLength(this.createOrderValidation.place.maxLength)
        ]
      ],
      paymentMode: [paymentModeValue, [Validators.required]],
      deliveryDate: [deliveryDateValue, [Validators.required]],
      remarks: [remarksValue,
        [
          Validators.minLength(this.createOrderValidation.remarks.minLength),
          Validators.maxLength(this.createOrderValidation.remarks.maxLength)
        ]
      ],
      staff: [staffValue],
      orderReceived: [orderReceivedValue],
      agentType: ["1"],
      agent: [""],
      calculatePoints: [calculatePointsValue],
      unitPoints: [unitPointsValue,
        [
          Validators.minLength(this.createOrderValidation.unitPoints.minLength),
          Validators.maxLength(this.createOrderValidation.unitPoints.maxLength),
        ]
      ],
      agentCommission: [agentCommissionValue,
        [
          Validators.minLength(this.createOrderValidation.agentCommission.minLength),
          Validators.maxLength(this.createOrderValidation.agentCommission.maxLength),
        ]
      ]
    });

    if (this.copyOrderDetails) {
      this.createOrderFormControls['dressItemSelect'].disable({ onlySelf: true });
      this.createOrderFormControls['methodSelect'].disable({ onlySelf: true });
      this.createOrderFormControls['patternSelect'].disable({ onlySelf: true });
      this.onChangeSchoolType(schoolTypeValue);
      this.onChangePaymentMode(paymentModeValue);
      this.onChangeOrderReceived(orderReceivedValue);
      this.onChangeCalculatePoints(calculatePointsValue);
    }
  }

  /**
   * Initialize Add Order Form Validations
   */
  addOrderFormValidations() {
    this.addOrderItemsForm = this.formBuilder.group({
      colorSelect: ["", [Validators.required]],
      sizeSelect: ["", [Validators.required]],
      quantity: ["", [Validators.required, Validators.pattern(this.patterns.quantity)]],
      unitPrice: ["", [Validators.required, Validators.pattern(this.patterns.orderUnitPrice)]]
    });
  }

  /**
   * Create Order Controls Initialized
   * @readonly
   */
  get createOrderFormControls() {
    return this.createOrderForm.controls;
  }

  /**
   * Get Add Order Form Controls
   * @readonly
   */
  get addOrderItemsFormControls() {
    return this.addOrderItemsForm.controls;
  }

  /**
   * Life Cycle Hook Destroy
   */
  ngOnDestroy(): void {
    this.orderService.organizationDetails.next({});
    this.orderService.orderPatternDetailsObj.next({});
    this.orderService.copySampleOrderDetails.next({});
    this.orderService.copyOrderDetails.next({});
    const localStorageKeys = [
      "savedOrdersList",
      "pinofersSpecialModelCollars",
      "pinofersPanelColors",
      "tShirtSpecialModelCollars",
      "tShirtSpecialModelCuffs",
      "tShirtSpecialModelPanel",
      "tShirtsSpecialPatternCollars",
      "tShirtsSpecialPatternCuffs",
      "tShirtsNormalPatternCollar",
      "pantPatternPanelColoursList",
      "middyPatternPanelColoursList",
      "nickerPatternPanelColours",
      "shotsPatternPanelColours"
    ];
    localStorageKeys.forEach((item: string) => {
      localStorage.removeItem(item);
    });
  }

  /**
   * This method is used to close the snackbar on enter
   */
  @HostListener('document:keypress', ['$event'])
  handleKeyPress(event: KeyboardEvent) {
    if (event.key == 'Enter') {
      this.onClickSnackbarOkButton();
    }
  }

  /**
   * This method is used to get the dress items List
   */
  getDressItemList() {
    this.mastersService.getDressItems().subscribe({
      next: (res: any) => {
        this.dressItemsList = res.result;
        if (this.copySampleOrderDetails) {
          let dressItemId = this.copySampleOrderDetails?.sampleOrder?.dressItemId;
          this.createOrderFormControls['dressItemSelect'].setValue(dressItemId?.toString());
          this.onChangeDressItem(dressItemId, false, "saved");
        } else if (this.copyOrderDetails) {
          let dressItemId = this.copyOrderDetails?.order?.dressItemId;
          this.createOrderFormControls['dressItemSelect'].setValue(dressItemId?.toString());
          this.onChangeDressItem(dressItemId, false, "saved");
        }
      },
      error: (err: any) => {
        this.dressItemsList = [];
      },
    });
  }

  /**
   * This method is used to get the methods List
   * @param {*} eventFlag
   */
  getMethodList(eventFlag: any) {
    this.mastersService.getMethodsByDressItemId(this.selectedDressItem?.dressItemId?.toString()).subscribe({
      next: (res: any) => {
        this.methodsList = res.result;
        if (eventFlag) {
          let methodIdValue = '';
          if (this.copySampleOrderDetails) {
            methodIdValue = this.copySampleOrderDetails?.sampleOrder?.methodId;
          } else if (this.copyOrderDetails) {
            methodIdValue = this.copyOrderDetails?.order?.methodId;
          }
          this.createOrderFormControls['methodSelect'].setValue(methodIdValue?.toString());
          this.onChangeMethod(methodIdValue, false);
          this.getSizesList(eventFlag);
        }
      },
      error: (err: any) => {
        this.methodsList = [];
      },
    });
  }

  /**
   * This method is used to get the quality List
   */
  getQualityList() {
    this.mastersService.getQualities().subscribe({
      next: (res: any) => {
        this.qualityList = res.result;
        if (this.copySampleOrderDetails) {
          let qualityId = this.copySampleOrderDetails?.sampleOrder?.qualityId;
          this.createOrderFormControls['qualitySelect'].setValue(qualityId?.toString());
          this.onChangeQuality(qualityId);
        } else if (this.copyOrderDetails) {
          let qualityId = this.copyOrderDetails?.order?.qualityId;
          this.createOrderFormControls['qualitySelect'].setValue(qualityId?.toString());
          this.onChangeQuality(qualityId);
        }
      },
      error: (err: any) => {
        this.qualityList = [];
      },
    });
  }

  /**
   * This method is used to get the patterns list
   * @param {*} eventFlag
   */
  getPatternsList(eventFlag: any) {
    this.chargesService.getStitchingPatternTypesByDressItemId(this.selectedDressItem.dressItemId?.toString()).subscribe({
      next: (res: any) => {
        this.patternsList = res.result;
        if (eventFlag) {
          if (this.isPatternDressItem) {
            let patternValue = '';
            if (this.copySampleOrderDetails) {
              patternValue = this.copySampleOrderDetails?.sampleOrder?.patternTypeId;
            } else if (this.copyOrderDetails) {
              patternValue = this.copyOrderDetails?.order?.patternTypeId;
            }
            this.createOrderFormControls['patternSelect'].setValue(patternValue?.toString());
            this.onChangePattern(patternValue, false);

            const obj: any = {};
            if (this.selectedDressItem?.dressItemName == "T-Shirts") {
              if (this.selectedPattern?.patternType === "Special Model") {
                if (this.copySampleOrderDetails) {
                  obj.specialModelForTShirt = this.copySampleOrderDetails?.specialModelForTShirt;
                } else if (this.copyOrderDetails) {
                  obj.specialModelForTShirt = this.copyOrderDetails?.specialModelForTShirt;
                }
              } else if (this.selectedPattern?.patternType === "Special Pattern") {
                if (this.copySampleOrderDetails) {
                  obj.specialPatternForTshirt = this.copySampleOrderDetails?.specialPatternForTshirt;
                } else if (this.copyOrderDetails) {
                  obj.specialPatternForTshirt = this.copyOrderDetails?.specialPatternForTshirt;
                }
              } else {
                if (this.copySampleOrderDetails) {
                  obj.normalPatternforTshirt = this.copySampleOrderDetails?.normalPatternforTshirt;
                } else if (this.copyOrderDetails) {
                  obj.normalPatternforTshirt = this.copyOrderDetails?.normalPatternforTshirt;
                }
              }
            } else if (this.selectedDressItem?.dressItemName == "Middy") {
              if (this.selectedPattern?.patternType === "Special") {
                if (this.copySampleOrderDetails) {
                  obj.specialforMiddy = this.copySampleOrderDetails?.specialforMiddy;
                } else if (this.copyOrderDetails) {
                  obj.specialforMiddy = this.copyOrderDetails?.specialforMiddy;
                }
              } else {
                if (this.copySampleOrderDetails) {
                  obj.normalforMiddy = this.copySampleOrderDetails?.normalforMiddy;
                } else if (this.copyOrderDetails) {
                  obj.normalforMiddy = this.copyOrderDetails?.normalforMiddy;
                }
              }
            } else if (
              this.selectedDressItem?.dressItemName == "Pant" ||
              this.selectedDressItem?.dressItemName == "Nicker" ||
              this.selectedDressItem?.dressItemName == "Shots"
            ) {
              if (this.copySampleOrderDetails) {
                obj.patternforPant = this.copySampleOrderDetails?.patternforPant;
              } else if (this.copyOrderDetails) {
                obj.patternforPant = this.copyOrderDetails?.patternforPant;
              }
            } else if (this.selectedDressItem?.dressItemName == "Pinofers") {
              if (this.copySampleOrderDetails) {
                obj.patternforPinofer = this.copySampleOrderDetails?.patternforPinofer;
              } else if (this.copyOrderDetails) {
                obj.patternforPinofer = this.copyOrderDetails?.patternforPinofer;
              }
            }
            console.log(obj);
            this.orderService.orderPatternDetailsObj.next(obj);
          }


        }
      },
      error: (err: any) => {
        this.patternsList = [];
      },
    });
  }

  /**
   * This method is used to get the colors list
   */
  getColorsList() {
    this.mastersService.getColours().subscribe({
      next: (res: any) => {
        this.masterColorsList = res.result;
      },
      error: (err: any) => {
        this.masterColorsList = [];
      },
    });
  }

  /**
   * This method is used to get the sizes list
   * @param {*} eventFlag
   */
  getSizesList(eventFlag: any) {
    /* Prepare the Request Payload */
    const obj = {
      dressItemId: this.selectedDressItem?.dressItemId,
      methodId: this.selectedMethod?.methodId,
    };
    this.mastersService.getDressItemSizesByDressAndMethod(obj).subscribe({
      next: (res: any) => {
        this.sizesList = res.result;

        if (eventFlag) {
          let responseArray = this.copySampleOrderDetails || this.copyOrderDetails;
          const responseOrderItems = responseArray?.orderColours?.map((responseData: any, index: any) => {
            const colour = this.masterColorsList.find((element: any) => +responseData?.colorId === +element?.colourId);
            const size = this.sizesList.find((element: any) => +responseData?.sizeId === +element?.sizeId);

            return {
              id: index,
              colorId: +responseData.colorId,
              colourName: colour?.colourName,
              sizeId: +responseData.sizeId,
              size: size?.sizeName,
              quantity: Number(+responseData.quantity),
              unitPrice: Number(+responseData.unitPrice),
            };
          });

          this.savedOrderItemsList = responseOrderItems || [];
          localStorage.setItem("savedOrdersList", JSON.stringify(this.savedOrderItemsList));

          const totalQty = this.getSavedTotalQuantity();
          this.totalQuantity = totalQty;
          // Calculate order value for each item
          const orderValues = this.savedOrderItemsList.map((item) => item.quantity * item.unitPrice);
          // Calculate the total order value
          this.totalOrderValue = orderValues.reduce((sum, value) => sum + value, 0);
          const totalUnitPrice = (this.totalOrderValue * 100) / (100 + Number(this.latestSalesTaxName));
          this.avgUnitPrice = totalUnitPrice / this.totalQuantity;
          this.getPatternsList("noEvent");
        }

      },
      error: (err: any) => {
        this.sizesList = [];
      },
    });
  }

  /**
   * Get sales tax
   */
  getSaleTax() {
    this.mastersService.getSalesTax().subscribe({
      next: (res: any) => {
        const salesTaxArray: any[] = res.result || [];
        if (salesTaxArray.length > 0) {
          salesTaxArray.sort((a, b) => new Date(b.createdDate).getTime() - new Date(a.createdDate).getTime());
          this.latestSalesTaxName = salesTaxArray[0].salesTaxName;
        }
      },
      error: (err: any) => { }
    });
  }

  /**
   * This method is used to get staff list
   */
  getStaffsList() {
    /* To call the service to get the staff list */
    this.mastersService.getStaffs().subscribe({
      next: (res: any) => {
        this.staffList = res.result?.filter((item: any) => item.isStaff == '1');
        if (this.copyOrderDetails && this.isStaffSelect) {
          let staffValue = this.copyOrderDetails?.order?.staffId;
          setTimeout(() => {
            this.createOrderFormControls['staff'].setValue(staffValue?.toString() || '');
            this.cdr.detectChanges();
          }, 50);
          this.onChangeStaff(staffValue);
        }
      },
      error: (err: any) => {
        this.staffList = [];
      },
    });
  }

  /**
   * This method is used to get Agents List
   * @param {string} eventFlag
   */
  getAgentsList(eventFlag: string) {
    /* To call the service to get the agents list */
    this.mastersService.getAgents().subscribe({
      next: (res: any) => {
        this.agentsList = res.result;
        if (eventFlag && this.copyOrderDetails) {
          let agentId = this.copyOrderDetails?.order?.agentId;
          this.createOrderFormControls['agent'].setValue(agentId?.toString());
          this.onChangeAgent(agentId);
        }
      },
      error: (err: any) => {
        this.agentsList = [];
      }
    });
  }

  /**
   * This method is used to add validators
   * @param {*} formControls
   * @param {*} controls
   */
  onAddValidators(formControls: any, controls: any) {
    controls?.forEach((control: any) => {
      formControls[control].addValidators([Validators.required]);
      formControls[control].updateValueAndValidity({ onlySelf: true });
    });
  }

  /**
   * This method is used to remove validators
   * @param {*} formControls
   */
  onRemoveValidators(formControls: any, controls: any) {
    controls?.forEach((control: any) => {
      formControls[control].removeValidators([Validators.required]);
      formControls[control].updateValueAndValidity({ onlySelf: true });
    });
  }

  /**
   * This method is used to update value and validity
   * @param {*} formControls
   */
  onUpdateValueAndValidity(formControls: any, controls: any) {
    controls?.forEach((control: any) => {
      formControls[control].setValue("");
      formControls[control].markAsUntouched({ onlySelf: true });
      formControls[control].updateValueAndValidity({ onlySelf: true });
    });
  }

  /**
   * This method is used to reset Order form
   */
  onClickReset() {
    this.createOrderForm.reset();
    this.isBackPrint = false;
    this.isAddOrderItems = false;
    this.isPatternDressItem = false;
    this.isAddPatternDetails = false;
    this.methodsList = [];
    this.patternsList = [];
    this.orderItemsList = [];
    this.orderService.organizationDetails.next({});
    this.orderService.copySampleOrderDetails.next({});
    this.orderService.copyOrderDetails.next({});
    localStorage.removeItem("savedOrdersList");
    this.orderService.orderPatternDetailsObj.next({});
    this.isChangesInPattern = '';
    this.diagramURL = '';
    this.isStaffSelect = true;
    this.isAgent = false;
    this.isThroughAgent = false;
    this.createOrderFormValidations();
  }

  /**
   * This method will fired when user selects the Organization
   * @param {*} event
   */
  organizationChange(event: any) {
    for (const element of this.organizationTypeList) {
      if (element.id === event.target.value) {
        this.selectedOrganization = element;
      }
    }
  }

  /**
   * This method will fired when user selects Dress Item
   * @param {*} event
   * @param {boolean} changeFlag
   * @param {*} savedFlag
   */
  onChangeDressItem(event: any, changeFlag: boolean, savedFlag: any) {
    if (!this.organizationDetails && !this.copySampleOrderDetails && !this.copyOrderDetails) {
      this.onUpdateValueAndValidity(this.createOrderFormControls, ["dressItemSelect"]);
      this.snackbarModalComponent.onOpenSnackbarModal(false, "Please Select Organization", '', '', '');
      return;
    }

    if (!changeFlag) {

      if (localStorage.getItem("savedOrdersList")) {
        this.selectedNewDressItem = event.target?.value;
        this.isChangesInPattern = 'dressItem';
        document.getElementById("alertModalBtn")?.click();
        return;
      }

      let dressItemSizeValue = event?.target ? +event.target?.value : +event;
      this.isAddOrderItems = false;
      this.onUpdateValueAndValidity(this.createOrderFormControls, ["methodSelect"]);
      this.selectedMethod = "";
      this.onUpdateValueAndValidity(this.createOrderFormControls, ["qualitySelect"]);
      this.orderItemsList = [];
      this.savedOrderItemsList = [];
      localStorage.removeItem("savedOrdersList");
      this.diagramURL = '';

      for (const element of this.dressItemsList) {
        if (+element.dressItemId === +dressItemSizeValue) {
          this.selectedDressItem = element;
          if (this.selectedDressItem && this.selectedMethod) {
            this.isAddOrderItems = true;
          } else {
            this.isAddOrderItems = false;
          }
        }
      }

      if (event?.target || (!this.copySampleOrderDetails && !this.copyOrderDetails)) {
        this.getPatternsList("");
        this.getMethodList("");
      } else if (savedFlag) {
        this.getMethodList("noEvent");
      } else {
        this.getMethodList("");
      }

      const isDressItemContainsPocket = this.pocketDressItemsList.includes(this.selectedDressItem?.dressItemName);
      if (isDressItemContainsPocket) {
        this.createOrderFormControls['printType'].enable({ onlySelf: true });
        this.createOrderFormControls['printType'].setValue('2');
        this.isPrintType = true;
      } else {
        this.createOrderFormControls['printType'].setValue('');
        this.createOrderFormControls['printType'].disable({ onlySelf: true });
        this.isPrintType = false;
      }
      let noEvent = event?.target;

      if (!noEvent && this.isPrintType && savedFlag) {
        let printTypeId = '';
        if (this.copySampleOrderDetails) {
          printTypeId = this.copySampleOrderDetails?.sampleOrder?.printtypeId?.toString();
        } else if (this.copyOrderDetails) {
          printTypeId = this.copyOrderDetails?.order?.printtypeId?.toString();
        }
        this.createOrderFormControls['printType'].setValue(printTypeId?.toString());
        this.printTypeChange(printTypeId);
      }

      const isDressItemContainsBackPrint = this.backPrintDressItemsList.includes(this.selectedDressItem?.dressItemName);
      if (isDressItemContainsBackPrint) {
        this.isBackPrint = true;
        if (!noEvent && savedFlag) {
          let backPrint1Value = '';
          let backPrint2Value = '';
          let backPrint3Value = '';
          let backPrint4Value = '';
          let diagramIdValue = '';
          if (this.copySampleOrderDetails) {
            backPrint1Value = this.copySampleOrderDetails?.sampleOrder?.backPrint1 || '';
            backPrint2Value = this.copySampleOrderDetails?.sampleOrder?.backPrint2 || '';
            backPrint3Value = this.copySampleOrderDetails?.sampleOrder?.backPrint3 || '';
            backPrint4Value = this.copySampleOrderDetails?.sampleOrder?.backPrint4 || '';
            diagramIdValue = this.copySampleOrderDetails?.sampleOrder?.diagramId || '';
          } else if (this.copyOrderDetails) {
            backPrint1Value = this.copyOrderDetails?.order?.backPrint1 || '';
            backPrint2Value = this.copyOrderDetails?.order?.backPrint2 || '';
            backPrint3Value = this.copyOrderDetails?.order?.backPrint3 || '';
            backPrint4Value = this.copyOrderDetails?.order?.backPrint4 || '';
            diagramIdValue = this.copyOrderDetails?.order?.diagramId || '';
          }

          this.createOrderFormControls['BackPrintOne'].setValue(backPrint1Value?.toString());
          this.createOrderFormControls['BackPrintTwo'].setValue(backPrint2Value?.toString());
          this.createOrderFormControls['BackPrintThree'].setValue(backPrint3Value?.toString());
          this.createOrderFormControls['BackPrintFour'].setValue(backPrint4Value?.toString());
          this.createOrderFormControls['diagramSelect'].setValue(diagramIdValue?.toString());
          this.diagramChange(diagramIdValue);
        }
        this.onAddValidators(this.createOrderFormControls, ["BackPrintOne", "BackPrintTwo", "diagramSelect"]);
      } else {
        this.isBackPrint = false;
        this.onRemoveValidators(this.createOrderFormControls, ["BackPrintOne", "BackPrintTwo", "diagramSelect"]);
      }

      this.orderService.orderPatternDetailsObj.subscribe((val: any) => {
        if (Object.keys(val).length !== 0) {
          if (val?.specialModelForTShirt) {
            const specialModel = val?.specialModelForTShirt;
            if (specialModel?.printingId === 0) {
              this.onHandleSpecialModel("NoBackPrintDetails", false);
            } else if (specialModel?.printingId === 2) {
              if (specialModel.sublimationId === 23 && specialModel.isBackPrint) {
                this.onHandleSpecialModel("NoBackPrintDetails", true);
              } else {
                this.onHandleSpecialModel("NoBackPrintDetails", false);
              }
            } else {
              if (isDressItemContainsBackPrint) {
                this.onHandleSpecialModel("", true);
              }
            }
          }
        }
      });

      const isDressItemContainsPattern = this.patternDressItemsList.includes(this.selectedDressItem?.dressItemName);
      if (isDressItemContainsPattern) {
        this.isPatternDressItem = true;
        this.onAddValidators(this.createOrderFormControls, ["patternSelect"]);
      } else {
        this.isPatternDressItem = false;
        this.onRemoveValidators(this.createOrderFormControls, ["patternSelect"]);
      }

      if (noEvent || !savedFlag) {
        this.selectedPattern = "";
        this.isAddPatternDetails = false;
        this.onUpdateValueAndValidity(this.createOrderFormControls, ["patternSelect", "BackPrintOne", "BackPrintTwo", "BackPrintThree", "BackPrintFour", "diagramSelect"]);
      }
    }
  }

  /**
   * This method is used to handle the back print details
   * @param {*} isTShirtSpecialModel
   * @param {*} isBackPrint
   */
  onHandleSpecialModel(isTShirtSpecialModel: any, isBackPrint: any) {
    this.isTShirtSpecialModel = isTShirtSpecialModel;
    this.isBackPrint = isBackPrint;
    this.isPrintType = isBackPrint;

    const controlsToRemove = ["BackPrintOne", "BackPrintTwo", "diagramSelect"];
    if (!isBackPrint) {
      this.onRemoveValidators(this.createOrderFormControls, controlsToRemove);
    } else {
      this.onAddValidators(this.createOrderFormControls, controlsToRemove);
    }
  }

  /**
   * This method will fired when user selects the method
   * @param {*} event
   * @param {boolean} changeFlag
   */
  onChangeMethod(event: any, changeFlag: boolean) {
    if (!changeFlag) {
      let methodValue = event?.target ? +event.target?.value : +event;
      if (localStorage.getItem("savedOrdersList")) {
        this.selectedNewMethod = methodValue;
        this.isChangesInPattern = 'method';
        document.getElementById("alertModalBtn")?.click();
        return;
      }

      this.isAddPatternDetails = false;
      this.orderItemsList = [];
      this.savedOrderItemsList = [];
      localStorage.removeItem("savedOrdersList");

      for (const element of this.methodsList) {
        if (+element.methodId === +methodValue) {
          this.selectedMethod = element;
        }
      }
      if (this.selectedDressItem && this.selectedMethod) {
        this.isAddOrderItems = true;
      } else {
        this.isAddOrderItems = false;
      }
    }
  }

  /**
   * This method will fired when user selects the quality
   * @param {*} event
   */
  onChangeQuality(event: any) {
    let qualityValue = event?.target ? +event.target?.value : +event;
    if (!this.selectedDressItem && event?.target) {
      this.onUpdateValueAndValidity(this.createOrderFormControls, ["qualitySelect"]);
      this.snackbarModalComponent.onOpenSnackbarModal(false, "Please Select Dress Item", '', '', '');
      return;
    }

    if (!this.selectedMethod && event?.target) {
      this.onUpdateValueAndValidity(this.createOrderFormControls, ["qualitySelect"]);
      this.snackbarModalComponent.onOpenSnackbarModal(false, "Please Select Method", '', '', '');
      return;
    }

    if (this.savedOrderItemsList.length === 0 && event?.target) {
      this.onUpdateValueAndValidity(this.createOrderFormControls, ["qualitySelect"]);
      this.snackbarModalComponent.onOpenSnackbarModal(false, "Please Add Order Items", '', '', '');
      return;
    }

    for (const element of this.qualityList) {
      if (+element.qualityId === +qualityValue) {
        this.selectedQuality = element;
      }
    }
  }

  /**
   * This method will fired when user selects the pattern
   * @param {*} event
   * @param {boolean} changeFlag
   */
  onChangePattern(event: any, changeFlag: boolean) {
    if (!this.selectedMethod && event?.target) {
      this.onUpdateValueAndValidity(this.createOrderFormControls, ["patternSelect"]);
      this.snackbarModalComponent.onOpenSnackbarModal(false, "Please Select Method", '', '', '');
      return;
    }

    if (this.savedOrderItemsList.length === 0 && event?.target) {
      this.onUpdateValueAndValidity(this.createOrderFormControls, ["patternSelect"]);
      this.snackbarModalComponent.onOpenSnackbarModal(false, "Add Order Items", '', '', '');
      return;
    }

    if (!changeFlag) {
      let patternValue = event?.target ? +event.target?.value : +event;
      let selectedPatternDetails = {};
      this.orderService.orderPatternDetailsObj.subscribe((val: any) => {
        if (Object.keys(val).length > 0) {
          selectedPatternDetails = val;
        } else {
          selectedPatternDetails = {};
        }
      });

      if (Object.keys(selectedPatternDetails).length > 0) {
        this.selectedNewPattern = event.target?.value;
        this.isChangesInPattern = 'pattern';
        document.getElementById("alertModalBtn")?.click();
        return;
      }

      for (const element of this.patternsList) {
        if (+element.patternTypeId === +patternValue) {
          this.selectedPattern = element;
        }
      }
      if (
        this.selectedDressItem &&
        this.selectedMethod &&
        this.selectedPattern &&
        this.savedOrderItemsList.length > 0
      ) {
        this.isAddPatternDetails = true;
      } else {
        this.isAddPatternDetails = false;
      }
    }
  }

  /**
   * This method is used to open the add patterns modal
   */
  onClickAddPatterns() {
    if (this.selectedDressItem?.dressItemName == "T-Shirts") {
      this.tShirtsPatternComponent.openModal(
        this.selectedPattern,
        this.selectedDressItem
      );
    } else if (this.selectedDressItem?.dressItemName == "Pinofers") {
      this.pinofersComponent.openModal(
        this.selectedPattern,
        this.selectedDressItem
      );
    } else if (this.selectedDressItem?.dressItemName == "Middy") {
      this.middyPatternModalComponent.openModal(
        this.selectedPattern,
        this.selectedDressItem
      );
    } else if (this.selectedDressItem?.dressItemName == "Nicker") {
      this.nickersComponent.openModal(
        this.selectedPattern,
        this.selectedDressItem
      );
    } else if (this.selectedDressItem?.dressItemName == "Shots") {
      this.shortsComponent.openModal(
        this.selectedPattern,
        this.selectedDressItem
      );
    } else if (this.selectedDressItem?.dressItemName == "Pant") {
      this.pantComponent.openModal(
        this.selectedPattern,
        this.selectedDressItem
      );
    }
  }

  /**
   * This method is used to change the print type radio
   * @param {*} event
   */
  printTypeChange(event: any) {
    let printTypeValue = event?.target ? +event.target?.value : +event;
    this.selectedPrintType = +printTypeValue;
  }

  /**
  * This method will fired when user selects the status
  * @param {*} event
  */
  onChangeStatus(event: any) {
    let statusValue = event?.target ? +event.target?.value : +event;
    for (const element of this.statusModesList) {
      if (+element.id === +statusValue) {
        this.selectedStatus = element;
      }
    }
    if (+this.selectedStatus?.id === 2) {
      this.isCourier = true;
    } else {
      this.isCourier = false;
    }
    let isEvent = event?.target;

    if (this.isCourier) {
      this.onAddValidators(this.createOrderFormControls, ['courierSelect']);
      this.onAddValidators(this.createOrderFormControls, ['SelectDate']);
      this.onAddValidators(this.createOrderFormControls, ['DocketNo']);
      if (isEvent) {
        this.onUpdateValueAndValidity(this.createOrderFormControls, ['courierSelect', 'SelectDate', 'DocketNo']);
      }
    } else {
      this.onRemoveValidators(this.createOrderFormControls, ['courierSelect']);
      this.onRemoveValidators(this.createOrderFormControls, ['SelectDate']);
      this.onRemoveValidators(this.createOrderFormControls, ['DocketNo']);
      this.onUpdateValueAndValidity(this.createOrderFormControls, ['courierSelect', 'SelectDate', 'DocketNo']);
    }
  }

  /**
   * This method will fired when user selects the status
   * @param {*} event
   */
  onChangePaymentMode(event: any) {
    let paymentModeValue = event?.target ? +event.target?.value : +event;
    for (const element of this.paymentModesList) {
      if (+element.id === +paymentModeValue) {
        this.selectedPaymentMode = element;
      }
    }
  }

  /**
   * This method is used to change the school type radio
   * @param {*} event
   */
  onChangeSchoolType(event: any) {
    let schoolTypeValue = event?.target ? +event.target?.value : +event;
    this.selectedSchoolType = +schoolTypeValue;
  }

  /**
   * This method is used to change the Order received radio
   * @param {*} event
   */
  onChangeOrderReceived(event: any) {
    let orderReceivedValue = event?.target ? event.target?.value : event;
    this.selectedOrderReceived = +orderReceivedValue;
    if (this.selectedOrderReceived === 1) {
      this.isAgent = true;
      if (event?.target) {
        this.getAgentsList('');
      } else {
        this.getAgentsList('noEvent');
      }
      this.onAddValidators(this.createOrderFormControls, ['agentCommission', 'agent']);
    } else {
      this.isAgent = false;
      this.onRemoveValidators(this.createOrderFormControls, ['agentCommission', 'agent']);
    }
    if (event?.target) {
      this.onUpdateValueAndValidity(this.createOrderFormControls, ['agent']);
      this.selectedAgent = '';
      this.onChangeAgentType(1)
      this.createOrderFormControls['agentType'].setValue('1');
    } else if (this.copyOrderDetails) {
      let agentTypeValue = this.copyOrderDetails?.order.agentThroughId;
      this.onChangeAgentType(agentTypeValue)
      this.createOrderFormControls['agentType'].setValue(agentTypeValue?.toString());
    }
  }

  /**
   * This method is used to change the Agent type radio
   * @param {*} event
   */
  onChangeAgentType(event: any) {
    let agentTypeValue = event?.target ? +event.target?.value : +event;
    this.selectedAgentType = +agentTypeValue;
    if (this.selectedAgentType === 2) {
      this.isThroughAgent = true;
    } else {
      this.isThroughAgent = false;
    }
  }

  /**
   * This method is used to change the staff select
   * @param {*} event
   */
  onChangeStaff(event: any) {
    let staffValue = event?.target ? +event.target?.value : +event;
    for (const element of this.staffList) {
      if (+element.staffId === +staffValue) {
        this.selectedStaff = element;
      }
    }
  }

  /**
   * This method is used to change the Agent select
   * @param {*} event
   */
  onChangeAgent(event: any) {
    let agentValue = event?.target ? +event.target?.value : +event;
    for (const element of this.agentsList) {
      if (+element.agentId === +agentValue) {
        this.selectedAgent = element;
      }
    }
  }

  /**
   * This method is used to change the calculate Points radio
   * @param {*} event
   */
  onChangeCalculatePoints(event: any) {
    let calculatePointsValue = event?.target ? +event.target?.value : +event;
    this.selectedCalculatePoints = +calculatePointsValue;
  }

  /**
   * This method will fired when user selects the diagram
   * @param {*} event
   */
  diagramChange(event: any) {
    let diagramValue = event?.target ? event.target.value : event;
    for (const element of this.diagramList) {
      if (+element.id === +diagramValue) {
        this.selectedDiagram = element;
      }
    }

    /* Assign diagram URL based on selected diagram */
    if (this.selectedDiagram?.id === 1) {
      this.diagramURL = '../../../../../assets/Images/1.jpg';
    } else if (this.selectedDiagram?.id === 2) {
      this.diagramURL = '../../../../../assets/Images/2.jpg';
    } else if (this.selectedDiagram?.id === 3) {
      this.diagramURL = '../../../../../assets/Images/3.jpg';
    } else if (this.selectedDiagram?.id === 4) {
      this.diagramURL = '../../../../../assets/Images/4.jpg';
    } else if (this.selectedDiagram?.id === 5) {
      this.diagramURL = '../../../../../assets/Images/5.jpg';
    } else if (this.selectedDiagram?.id === 6) {
      this.diagramURL = '../../../../../assets/Images/6.jpg';
    } else {
      this.diagramURL = '';
    }
  }

  /**
   * This method is used to open the add order modal
   */
  onClickOpenAddOrderModal() {
    this.getColorsList();
    this.getSizesList('');
    document.getElementById("addOrderItemModal")?.click();
    this.isSaveOrder = false;
    if (JSON.parse(localStorage.getItem("savedOrdersList")!)) {
      this.orderItemsList = JSON.parse(localStorage.getItem("savedOrdersList")!);
    } else {
      this.orderItemsList = [];
    }
    const modal = document.getElementById("addOrderDetailsForm") as HTMLElement;
    const snackbar = document.getElementById("snackbar") as HTMLElement;
    modal.style.display = "block";
    snackbar.style.zIndex = "9999";
  }

  /**
   * This method is used to get the unique sizes for the table
   * @return {*}  {string[]}
   */
  getUniqueSizes(): string[] {
    return Array.from(
      new Set(this.savedOrderItemsList.map((item) => item.size))
    );
  }

  /**
   * This method is used to get the unique colors for the table
   * @return {*}  {string[]}
   */
  getUniqueColors(): string[] {
    return Array.from(
      new Set(this.savedOrderItemsList.map((item) => item.colourName))
    );
  }

  /**
   * This method is used to get the quantity for the table
   * @param {string} color
   * @param {string} size
   * @return {*}  {number}
   */
  getQuantity(color: string, size: string): number {
    const item = this.savedOrderItemsList.find(
      (item) => item.colourName === color && item.size === size
    );
    return item ? parseInt(item.quantity?.toString(), 10) : 0;
  }

  /**
   * This method is used to get the row total for the table
   * @param {string} color
   * @return {*}  {number}
   */
  getRowTotal(color: string): number {
    return this.getUniqueSizes().reduce(
      (total: any, size: any) => total + this.getQuantity(color, size),
      0
    );
  }

  /**
   * This method is used to get the column total for the table
   * @param {string} size
   * @return {*}  {number}
   */
  getColumnTotal(size: string): number {
    return this.getUniqueColors().reduce(
      (total: any, color: any) => total + this.getQuantity(color, size),
      0
    );
  }

  /**
   * This method is used to get the grand total for the table
   * @return {*}  {number}
   */
  getGrandTotal(): number {
    return this.getUniqueSizes().reduce(
      (total, size) => total + this.getColumnTotal(size),
      0
    );
  }

  /**
   * This method is used to get the orders total quantity
   * @return {*}  {number}
   */
  getTotalQuantity(): number {
    let orderTotalQuantity = 0;
    for (const order of this.orderItemsList) {
      orderTotalQuantity += order.quantity;
    }
    this.totalQuantity = orderTotalQuantity;
    return orderTotalQuantity;
  }

  /**
   * This method is used to get the saved orders total quantity
   * @return {*}  {number}
   */
  getSavedTotalQuantity(): number {
    let orderTotalQuantity = 0;
    for (const order of this.savedOrderItemsList) {
      if (order && order.quantity) {
        orderTotalQuantity += order.quantity;
      }
    }
    this.totalQuantity = orderTotalQuantity;
    return orderTotalQuantity;
  }

  /**
   * This method is used to change the colour
   * @param {*} event
   */
  onChangeColour(event: any) {
    if (event?.target.value == '') {
      this.addOrderItemsFormControls['colorSelect'].markAsUntouched({ onlySelf: true });
    }
  }

  /**
   * This method is used to change the size
   * @param {*} event
   */
  onChangeSize(event: any) {
    if (event?.target.value == '') {
      this.addOrderItemsFormControls['sizeSelect'].markAsUntouched({ onlySelf: true });
    }
  }

  /**
   * This method is used to add the order items
   */
  onClickAdd() {
    document.getElementById('quantity')?.blur();
    document.getElementById('unitPrice')?.blur();
    if (this.addOrderItemsForm.invalid) {
      this.validationService.validateAllFormFields(this.addOrderItemsForm);
      return;
    }

    if (+this.addOrderItemsFormControls["quantity"].value > 5000) {
      this.showSnackbar("Quantity should not exceed 5000", '', false, true);
      return;
    }

    if (+this.addOrderItemsFormControls["unitPrice"].value > 999) {
      this.showSnackbar("Unit Price should not exceed 999", '', false, true);
      return;
    }

    /* Get Selected Colour */
    const selectedColour = this.masterColorsList.filter(
      (item: any) => +item.colourId === +this.addOrderItemsFormControls["colorSelect"].value
    );

    /* Get Selected Size */
    const selectedSize = this.sizesList.filter(
      (item: any) => +item.sizeId === +this.addOrderItemsFormControls["sizeSelect"].value
    );

    const existingRecord = this.orderItemsList.find((item) => {
      return (
        item.colourName === selectedColour[0].colourName &&
        item.size === selectedSize[0].sizeName
      );
    });

    if (existingRecord) {
      this.showSnackbar("Record Already Exists", '', false, true);
      return;
    }

    /* Prepare the orderItem Object */
    const obj = {
      id: this.orderItemsList.length > 0 ? this.orderItemsList.length : 0,
      colorId: +selectedColour[0].colourId,
      colourName: selectedColour[0].colourName,
      sizeId: +selectedSize[0].sizeId,
      size: selectedSize[0].sizeName,
      quantity: Number(this.addOrderItemsFormControls["quantity"].value),
      unitPrice: Number(this.addOrderItemsFormControls["unitPrice"].value),
    };

    /* Push the Order Item */
    this.orderItemsList.push(obj);
    this.addOrderFormValidations();
  }

  /**
   * This method is used to delete the order item
   * @param {*} order
   */
  onClickDeleteOrderItem(order: any) {
    this.orderItemsList = this.orderItemsList.filter(
      (item: any) => item.id !== order.id
    );
    this.orderItemsList = this.orderItemsList.map((item, index) => ({
      ...item,
      id: index,
    }));
  }

  /**
   * This method is used to save the order items
   */
  onClickSaveOrderItems() {
    if (this.orderItemsList.length === 0) {
      if (this.addOrderItemsForm.invalid) {
        this.validationService.validateAllFormFields(this.addOrderItemsForm);
        return;
      }
      this.showSnackbar("Add Order Items", '', false, true);
      document.getElementById('saveButton')?.blur();
      return;
    } else {
      if (this.totalQuantity > 5000) {
        this.showSnackbar("Total Quantity should not exceed 5000", '', false, true);
        document.getElementById('saveButton')?.blur();
        return;
      }
      this.isSaveOrder = true;
    }

    const storedValue: any = this.orderItemsList;
    localStorage.setItem("savedOrdersList", JSON.stringify(storedValue));
    this.savedOrderItemsList = JSON.parse(localStorage.getItem("savedOrdersList")!);
    document.getElementById("closeOrdersModal")?.click();
    // Calculate order value for each item
    const orderValues = this.orderItemsList.map((item) => item.quantity * item.unitPrice);

    // Calculate the total order value
    this.totalOrderValue = orderValues.reduce((sum, value) => sum + value, 0);
    const totalUnitPrice = (this.totalOrderValue * 100) / (100 + Number(this.latestSalesTaxName));
    this.avgUnitPrice = totalUnitPrice / this.totalQuantity;
  }

  /**
   * This method is used to close the orders modal
   */
  closeAddOrderModal() {
    this.addOrderItemsForm.reset();
    this.addOrderFormValidations();
  }

  /**
   *This Method used to navigate user to organizationList Page
   */
  navigateToUserList() {
    this.router.navigate(["/admin/customer-order/organizationlist"]);
  }

  /**
   * This method will be fired when user selects no in alert modal
   */
  onClickNo() {
    if (this.isChangesInPattern === 'pattern') {
      this.createOrderFormControls["patternSelect"].setValue(this.selectedPattern?.patternTypeId);
      this.onChangePattern(this.selectedPattern?.patternTypeId, true);
    } else if (this.isChangesInPattern === 'method') {
      this.createOrderFormControls["methodSelect"].setValue(this.selectedMethod?.methodId);
      this.onChangeMethod(this.selectedMethod?.methodId, true);
    } else {
      this.createOrderFormControls["dressItemSelect"].setValue(this.selectedDressItem?.dressItemId);
      this.onChangeDressItem(this.selectedDressItem?.dressItemId, true, "");
    }
    document.getElementById("closeAlertModal")?.click();
  }

  /**
   * This method will be fired when user selects yes in alert modal
   */
  onClickYes() {
    this.orderService.orderPatternDetailsObj.next({});
    if (this.isChangesInPattern === 'pattern') {
      this.createOrderFormControls["patternSelect"].setValue(this.selectedNewPattern);
      this.onChangePattern(this.selectedNewPattern, false);
    } else if (this.isChangesInPattern === 'method') {
      localStorage.removeItem("savedOrdersList");
      this.createOrderFormControls["methodSelect"].setValue(this.selectedNewMethod);
      this.onChangeMethod(this.selectedNewMethod, false);
      this.createOrderFormControls["patternSelect"].setValue('');
    } else {
      localStorage.removeItem("savedOrdersList");
      this.createOrderFormControls["dressItemSelect"].setValue(this.selectedNewDressItem);
      this.onChangeDressItem(this.selectedNewDressItem, false, "");
    }
    const isDressItemContainsBackPrint = this.backPrintDressItemsList.includes(this.selectedDressItem?.dressItemName);
    if (isDressItemContainsBackPrint) {
      this.onHandleSpecialModel("", true);
    }
    document.getElementById("closeAlertModal")?.click();
  }

  /**
   * This method is used to show the snackbar
   * @param {string} message
   * @param {*} orderId
   * @param {boolean} successFlag
   * @param {boolean} isModalOverlay
   */
  showSnackbar(message: string, orderId: any, successFlag: boolean, isModalOverlay: boolean) {
    const snackbar = document.getElementById("snackbar") as HTMLElement;
    this.innerHTMLMessage = message;
    this.innerHTMLOrderId = orderId;
    this.isOverlayVisible = isModalOverlay;
    this.isSuccessSnackbar = successFlag;
    snackbar.style.display = "block";
  }

  /**
   * This method is used to hide the snackbar
   */
  onClickSnackbarOkButton() {
    const snackbar = document.getElementById("snackbar") as HTMLElement;
    snackbar.style.display = "none";
    this.innerHTMLMessage = '';
    this.isOverlayVisible = false;
    this.isSuccessSnackbar = false;
  }

  /**
   * This method is used to navigate to the order list
   */
  onClickNavigateToOrderList() {
    this.router.navigate(["/admin/customer-order/order/orderList"]);
  }

  /**
   * This method is used to submit the Create Order Form
   * @return {*}
   */
  onCreateOrderFormSubmit(): any {
    if (!this.isBackPrint) {
      this.onUpdateValueAndValidity(this.createOrderFormControls, ["BackPrintOne", "BackPrintTwo", "BackPrintThree", "BackPrintFour", "diagramSelect"])
    }

    /** This will return false if form fields are invalid and stop the service calling */
    if (this.createOrderForm.invalid) {
      this.validationService.validateAllFormFields(this.createOrderForm);
      return;
    }

    /* Check whether order items added or not */
    if (this.savedOrderItemsList.length === 0) {
      this.snackbarModalComponent.onOpenSnackbarModal(false, "Add Order Items", '', '', '');
      return;
    }

    /* Prepare Pattern Details Obj */
    let patternDetails: any;
    let patternDetailsInvalid = false;
    if (this.isPatternDressItem) {
      this.orderService.orderPatternDetailsObj.subscribe((val: any) => {
        if (Object.keys(val).length > 0) {
          patternDetails = val;
          patternDetailsInvalid = false;
        } else {
          patternDetails = {};
          patternDetailsInvalid = true;
        }
      });
    }

    if (patternDetailsInvalid) {
      this.snackbarModalComponent.onOpenSnackbarModal(false, "Add Pattern Details", '', '', '');
      return;
    }

    let orderItemsMisMatch = '';
    const orderItemsColorIdsArray = this.savedOrderItemsList.map((item: any) => item.colorId);

    // Use a Set to store unique colour names
    const uniqueColourNames = new Set(this.savedOrderItemsList.map((item: any) => item.colourName));
    // Create a new array with unique items based on colourName
    const uniqueArray = Array.from(uniqueColourNames).map(colourName => {
      return this.savedOrderItemsList.find((item: any) => item.colourName === colourName);
    });
    const tShirtsColoursList = uniqueArray;

    if (this.selectedDressItem?.dressItemName == "T-Shirts") {

      if (patternDetails?.specialModelForTShirt) {

        /* Check whether special model collar colors present in order items */
        if (patternDetails?.specialModelForTShirt?.specialModelCollars?.length > 0) {
          // Check if each colourId in orderItemsColorIdsArray exists in tShirtColour.colourName of array2
          const tShirtColorsForCollarAllExists = orderItemsColorIdsArray.every((colorId: any) =>
            patternDetails?.specialModelForTShirt?.specialModelCollars.some((item: any) =>
              item.tShirtColorId === colorId
            ));

          if (!tShirtColorsForCollarAllExists) {
            orderItemsMisMatch = 'Add All T-Shirt Collar Colours';
          }

          let responseSpecialModelCollarItems = patternDetails?.specialModelForTShirt?.specialModelCollars?.map((responseData: any, index: any) => {
            const tShirtColour = tShirtsColoursList?.find((element: any) => +responseData?.tShirtColorId === +element?.colorId);
            const collarColour = this.masterColorsList?.find((element: any) => +responseData?.collarColorId === +element?.colourId);
            const stripeColour = this.masterColorsList?.find((element: any) => +responseData?.stripeColorId === +element?.colourId);
            return {
              tShirtColorId: tShirtColour?.colorId,
              collarColorId: +collarColour?.colourId,
              stripeColorId: stripeColour ? +stripeColour?.colourId : 0
            };
          });
          responseSpecialModelCollarItems = responseSpecialModelCollarItems.filter((item: any) => item.tShirtColorId);
          patternDetails.specialModelForTShirt.specialModelCollars = responseSpecialModelCollarItems;

        } else {
          if (patternDetails?.specialModelForTShirt?.collarTypeId && patternDetails?.specialModelForTShirt?.collarTypeId !== 0) {
            orderItemsMisMatch = 'Add T-Shirt Collar Colours';
          }
        }

        /* Check whether special model cuff colors present in order items */
        if (patternDetails?.specialModelForTShirt?.specialModelCuffs?.length > 0) {
          // Check if each colourId in orderItemsColorIdsArray exists in tShirtColour.colourName of array2
          const tShirtColorsForCuffAllExists = orderItemsColorIdsArray.every((colorId: any) =>
            patternDetails?.specialModelForTShirt?.specialModelCuffs.some((item: any) =>
              item.tShirtColorId === colorId
            ));

          if (!tShirtColorsForCuffAllExists) {
            orderItemsMisMatch = 'Add All T-Shirt Cuff Colours';
          }

          let responseSpecialModelCuffItems = patternDetails?.specialModelForTShirt?.specialModelCuffs?.map((responseData: any, index: any) => {
            const tShirtColour = tShirtsColoursList?.find((element: any) => +responseData?.tShirtColorId === +element?.colorId);
            const cuffColour = this.masterColorsList?.find((element: any) => +responseData?.cuffColorId === +element?.colourId);
            const stripeColour = this.masterColorsList?.find((element: any) => +responseData?.cuffStripeColorId === +element?.colourId);
            return {
              tShirtColorId: tShirtColour?.colorId,
              cuffColorId: +cuffColour?.colourId,
              cuffStripeColorId: stripeColour ? +stripeColour?.colourId : 0
            };
          });
          responseSpecialModelCuffItems = responseSpecialModelCuffItems.filter((item: any) => item.tShirtColorId);
          patternDetails.specialModelForTShirt.specialModelCuffs = responseSpecialModelCuffItems;
        } else {
          if (patternDetails?.specialModelForTShirt?.isCuff) {
            orderItemsMisMatch = 'Add T-Shirt Cuff Colours';
          }
        }

      } else if (patternDetails?.specialPatternForTshirt) {

        /* Check whether special pattern collar colors present in order items */
        if (patternDetails?.specialPatternForTshirt?.specialPatternCollars?.length > 0) {
          // Check if each colourId in orderItemsColorIdsArray exists in tShirtColour.colourName of array2
          const tShirtColorsForCollarAllExists = orderItemsColorIdsArray.every((colorId: any) =>
            patternDetails?.specialPatternForTshirt?.specialPatternCollars.some((item: any) =>
              item.tShirtColorId === colorId
            ));

          if (!tShirtColorsForCollarAllExists) {
            orderItemsMisMatch = 'Add All T-Shirt Collar Colours';
          }

          let responseSpecialPatternCollarItems = patternDetails?.specialPatternForTshirt?.specialPatternCollars?.map((responseData: any, index: any) => {
            const tShirtColour = tShirtsColoursList?.find((element: any) => +responseData?.tShirtColorId === +element?.colorId);
            const cuffColour = this.masterColorsList?.find((element: any) => +responseData?.collarColorId === +element?.colourId);
            const stripeColour = this.masterColorsList?.find((element: any) => +responseData?.stripeColorId === +element?.colourId);
            return {
              tShirtColorId: tShirtColour?.colorId,
              collarColorId: +cuffColour?.colourId,
              stripeColorId: stripeColour ? +stripeColour?.colourId : 0
            };
          });
          responseSpecialPatternCollarItems = responseSpecialPatternCollarItems.filter((item: any) => item.tShirtColorId);
          patternDetails.specialPatternForTshirt.specialPatternCollars = responseSpecialPatternCollarItems;

        } else {
          if (patternDetails?.specialPatternForTshirt?.collarTypeId && patternDetails?.specialPatternForTshirt?.collarTypeId !== 0) {
            orderItemsMisMatch = 'Add T-Shirt Collar Colours';
          }
        }

        /* Check whether special pattern cuff colors present in order items */
        if (patternDetails?.specialPatternForTshirt?.specialPatternCuffs?.length > 0) {
          // Check if each colourId in orderItemsColorIdsArray exists in tShirtColour.colourName of array2
          const tShirtColorsForCuffAllExists = orderItemsColorIdsArray.every((colorId: any) =>
            patternDetails?.specialPatternForTshirt?.specialPatternCuffs.some((item: any) =>
              item.tShirtColorId === colorId
            ));

          if (!tShirtColorsForCuffAllExists) {
            orderItemsMisMatch = 'Add All T-Shirt Cuff Colours';
          }

          let responseSpecialPatternCuffItems = patternDetails?.specialPatternForTshirt?.specialPatternCuffs?.map((responseData: any, index: any) => {
            const tShirtColour = tShirtsColoursList?.find((element: any) => +responseData?.tShirtColorId === +element?.colorId);
            const cuffColour = this.masterColorsList?.find((element: any) => +responseData?.cuffColorId === +element?.colourId);
            const stripeColour = this.masterColorsList?.find((element: any) => +responseData?.cuffStripeColorId === +element?.colourId);
            return {
              tShirtColorId: tShirtColour?.colorId,
              cuffColorId: +cuffColour?.colourId,
              cuffStripeColorId: stripeColour ? +stripeColour?.colourId : 0
            };
          });
          responseSpecialPatternCuffItems = responseSpecialPatternCuffItems.filter((item: any) => item.tShirtColorId);
          patternDetails.specialPatternForTshirt.specialPatternCuffs = responseSpecialPatternCuffItems;
        } else {
          if (patternDetails?.specialModelForTShirt?.cuffId && patternDetails?.specialModelForTShirt?.cuffId !== 0) {
            orderItemsMisMatch = 'Add T-Shirt Cuff Colours';
          }
        }

      } else if (patternDetails?.normalPatternforTshirt) {

        /* Check whether normal pattern collar colors present in order items */
        if (patternDetails?.normalPatternforTshirt?.normalPatternCollar?.length > 0) {
          // Check if each colourId in orderItemsColorIdsArray exists in tShirtColour.colourName of array2
          const tShirtColorsForCollarAllExists = orderItemsColorIdsArray.every((colorId: any) =>
            patternDetails?.normalPatternforTshirt?.normalPatternCollar.some((item: any) =>
              item.tShirtColorId === colorId
            ));

          if (!tShirtColorsForCollarAllExists) {
            orderItemsMisMatch = 'Add All T-Shirt Collar Colours';
          }

          let responseNormalCollarItems = patternDetails?.normalPatternforTshirt?.normalPatternCollar?.map((responseData: any, index: any) => {
            const tShirtColour = tShirtsColoursList?.find((element: any) => +responseData?.tShirtColorId === +element?.colorId);
            const collarColour = this.masterColorsList?.find((element: any) => +responseData?.collarColorId === +element?.colourId);
            const stripeColour = this.masterColorsList?.find((element: any) => +responseData?.stripeColorId === +element?.colourId);
            return {
              tShirtColorId: tShirtColour?.colorId,
              collarColorId: +collarColour?.colourId,
              stripeColorId: stripeColour ? +stripeColour?.colourId : 0
            };
          });
          responseNormalCollarItems = responseNormalCollarItems.filter((item: any) => item.tShirtColorId);
          patternDetails.normalPatternforTshirt.normalPatternCollar = responseNormalCollarItems;
        } else {
          if (patternDetails?.normalPatternforTshirt?.collarTypeId && patternDetails?.normalPatternforTshirt?.collarTypeId !== 0) {
            orderItemsMisMatch = 'Add T-Shirt Collar Colours';
          }
        }

      }

    } else if (this.selectedDressItem?.dressItemName == "Pinofers" && patternDetails?.patternforPinofer) {

      /* Check whether special collar colors present in order items */
      if (patternDetails?.patternforPinofer?.specialModelCollars?.length > 0) {
        // Check if each colourId in orderItemsColorIdsArray exists in tShirtColour.colourName of array2
        const pinofersColorsForCollarAllExists = orderItemsColorIdsArray.every((colorId: any) =>
          patternDetails?.patternforPinofer?.specialModelCollars.some((item: any) =>
            item.tShirtColorId === colorId
          ));

        if (!pinofersColorsForCollarAllExists) {
          orderItemsMisMatch = 'Add All T-Shirt Collar Colours';
        }

        let responsePinofersSpecialModelCollarItems = patternDetails?.patternforPinofer?.specialModelCollars?.map((responseData: any, index: any) => {
          const tShirtColour = tShirtsColoursList?.find((element: any) => +responseData?.tShirtColorId === +element?.colorId);
          const collarColour = this.masterColorsList?.find((element: any) => +responseData?.collarColorId === +element?.colourId);
          const stripeColour = this.masterColorsList?.find((element: any) => +responseData?.stripeColorId === +element?.colourId);
          return {
            tShirtColorId: tShirtColour?.colorId,
            collarColorId: +collarColour?.colourId,
            stripeColorId: stripeColour ? +stripeColour?.colourId : 0
          };
        });
        responsePinofersSpecialModelCollarItems = responsePinofersSpecialModelCollarItems.filter((item: any) => item.tShirtColorId);
        patternDetails.patternforPinofer.specialModelCollars = responsePinofersSpecialModelCollarItems;

      } else {
        if (patternDetails?.patternforPinofer?.collarTypeId && patternDetails?.patternforPinofer?.collarTypeId !== 0) {
          orderItemsMisMatch = 'Add T-Shirt Collar Colours';
        }
      }
    }

    if (orderItemsMisMatch) {
      this.snackbarModalComponent.onOpenSnackbarModal(false, orderItemsMisMatch, '', '', '');
      return;
    }

    /* Re-format the saved order items list array */
    let newSavedOrderItemsList = this.savedOrderItemsList.map(
      ({ id, colourName, size, ...rest }) => ({ ...rest })
    );

    /* Prepare Order Obj */
    const OrderObj = {
      schoolId: this.organizationDetails?.organizationId || this.copySampleOrderDetails?.sampleOrder?.schoolId || this.copyOrderDetails?.order?.schoolId,
      organizationName: this.createOrderFormControls["OrganizationName"].value,
      organizationType: this.createOrderFormControls["organizationSelect"].value?.toString(),
      stateName: this.createOrderFormControls["StateName"].value,
      districtName: this.createOrderFormControls["DistrictName"].value,
      mandalName: this.createOrderFormControls["MandalName"].value,
      townName: this.createOrderFormControls["TownName"].value,
      address: this.createOrderFormControls["Address"].value,
      dressItemId: this.selectedDressItem?.dressItemId,
      dressItem: this.selectedDressItem?.dressItemName,
      methodId: this.selectedMethod?.methodId,
      method: this.selectedMethod?.methodName,
      qualityId: this.selectedQuality?.qualityId,
      quality: this.selectedQuality?.qualityName,
      patternTypeId: this.isPatternDressItem ? this.selectedPattern?.patternTypeId : 0,
      backPrint1: this.isBackPrint ? this.createOrderFormControls["BackPrintOne"].value?.trim() : "",
      backPrint2: this.isBackPrint ? this.createOrderFormControls["BackPrintTwo"].value?.trim() : "",
      backPrint3: this.isBackPrint ? this.createOrderFormControls["BackPrintThree"].value?.trim() : "",
      backPrint4: this.isBackPrint ? this.createOrderFormControls["BackPrintFour"].value?.trim() : "",
      diagramId: this.isBackPrint ? this.selectedDiagram?.id : 0,
      printtypeId: this.isPrintType ? this.selectedPrintType : 0,
      expectedDDate: this.datePipe.transform(this.createOrderFormControls['deliveryDate'].value, 'yyyy-MM-dd', 'en-US'),
      modeOfPaymentId: +this.selectedPaymentMode?.id,
      remarks: this.createOrderFormControls['remarks'].value?.trim(),
      staffId: this.isStaffSelect ? +this.selectedStaff?.staffId : 0,
      orderRecived: this.isStaffSelect ? this.selectedOrderReceived : 0,
      agentThroughId: this.isStaffSelect && this.selectedOrderReceived == 1 ? this.selectedAgentType : 0,
      agentId: this.isStaffSelect && this.selectedOrderReceived == 1 ? +this.selectedAgent?.agentId : 0,
      agentCommPerc: this.isStaffSelect && this.selectedOrderReceived == 1 ? +this.createOrderFormControls["agentCommission"].value : 0,
      calculatePoints: this.isStaffSelect ? this.selectedCalculatePoints : 0,
      unitPoints: this.isStaffSelect && this.selectedCalculatePoints == 1 ? +this.createOrderFormControls['unitPoints'].value : 0,
      totalPoints: this.isStaffSelect && this.selectedCalculatePoints == 1 ? +this.createOrderFormControls['unitPoints'].value : 0,
      orderTypeId: this.isStaffSelect ? this.selectedSchoolType : 0,
      orderStatusId: 0,
      orderValue: +this.totalOrderValue,
      transportName: this.createOrderFormControls['place'].value?.trim(),
      SampleOrderId: this.copySampleOrderDetails ? this.copySampleOrderDetails?.sampleOrder?.orderId : 0
    }

    /* Prepare the request payload */
    const obj: any = {
      order: OrderObj,
      orderColours: newSavedOrderItemsList
    };

    if (this.selectedDressItem?.dressItemName == "T-Shirts") {
      if (this.selectedPattern?.patternType === "Special Model") {
        obj.specialModelForTShirt = patternDetails?.specialModelForTShirt;
      } else if (this.selectedPattern?.patternType === "Special Pattern") {
        obj.specialPatternForTshirt = patternDetails?.specialPatternForTshirt;
      } else {
        obj.normalPatternforTshirt = patternDetails?.normalPatternforTshirt;
      }
    } else if (this.selectedDressItem?.dressItemName == "Middy") {
      if (this.selectedPattern?.patternType === "Special") {
        obj.specialforMiddy = patternDetails?.specialforMiddy;
      } else {
        obj.normalforMiddy = patternDetails?.normalforMiddy;
      }
    } else if (this.selectedDressItem?.dressItemName == "Pant") {
      obj.patternforPant = patternDetails?.patternforPant;
    } else if (this.selectedDressItem?.dressItemName == "Nicker") {
      obj.patternforPant = patternDetails?.patternforPant;
    } else if (this.selectedDressItem?.dressItemName == "Shots") {
      obj.patternforPant = patternDetails?.patternforPant;
    } else if (this.selectedDressItem?.dressItemName == "Pinofers") {
      obj.patternforPinofer = patternDetails?.patternforPinofer;
    }

    console.log("Final Obj", obj);

    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    /* To call the service to add the sample order by passing the data object */
    this.orderService.addOrder(obj).subscribe({
      next: (res: any) => {
        /* Disable the loader if response is success*/
        this.loaderService.isLoading.next(false);
        this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, res?.result?.orderId, res?.result?.orderNo, 'order');
      },
      error: (err: any) => {
        /* Disable the loader if response is error */
        this.loaderService.isLoading.next(false);
        this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message || err, '', '', '');
      },
    });

  }
}
