import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OrdersPinofersModelComponent } from './orders-pinofers-model.component';

describe('OrdersPinofersModelComponent', () => {
  let component: OrdersPinofersModelComponent;
  let fixture: ComponentFixture<OrdersPinofersModelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OrdersPinofersModelComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(OrdersPinofersModelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
