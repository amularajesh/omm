import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { PanelColoursItems } from 'src/app/core/Modals/modals';
import { ChargesService } from 'src/app/core/Services/charges.service';
import { MastersService } from 'src/app/core/Services/masters.service';
import { OrderService } from 'src/app/core/Services/order.service';
import { SampleOrderService } from 'src/app/core/Services/sample-order.service';
import { ValidationService } from 'src/app/core/Services/validation.service';

/**
 * Orders Pinofers Model Component
 * @export
 * @class OrdersPinofersModelComponent
 * @implements {OnInit}
 */
@Component({
  selector: 'app-orders-pinofers-model',
  templateUrl: './orders-pinofers-model.component.html',
  styleUrls: ['./orders-pinofers-model.component.scss']
})
export class OrdersPinofersModelComponent implements OnInit {
  /**
   * Get Master Colours List
   */
  masterColoursList: any;

  /**
   * Get Selected Model No.
   * @type {*}
   */
  selectedModelNo: any;

  /**
   * Get Selected Collar Radio
   */
  selectedCollarRadio = 0;

  /**
   * Get Model No. List
   */
  modelNoList: any;

  /**
   * Get Selected Neck Collar
   * @type {*}
   */
  selectedCollarType: any;

  /**
   * Get Selected Striped Type Collar
   * @type {*}
   */
  selectedStripedTypeCollar: any;

  /**
   * Get Panel Colours List
   * @type {PanelColoursItems[]}
   */
  panelColoursList: PanelColoursItems[] = [];

  /**
   * Get Selected Body
   * @type {*}
   */
  selectedBody: any;

  /**
   * Get Selected Panel
   * @type {*}
   */
  selectedPanel: any;

  /**
   * Get Collar Types List
   */
  collarTypesList: any;

  /**
   * Get Striped Collar Types List
   */
  stripedCollarTypesList: any;

  /**
   * Get Selected Piping Radio
   */
  selectedPipingRadio = 0;

  /**
   * Get Selected Piping Colour
   * @type {*}
   */
  selectedPipingColour: any;

  /**
   * Get Selected Button Colour
   * @type {*}
   */
  selectedButtonColour: any;

  /**
   * Get T-shirts Colours List
   */
  tShirtsColoursList: any;

  /**
   * Get button type List
   */
  buttonTypesList: any;

  /**
   * Get Selected button type
   * @type {*}
   */
  selectedButtonType: any;

  /**
   * Declare Pinofers Pattern Form
   * @type {FormGroup}
   */
  pinofersPatternForm!: FormGroup;

  /**
   * Declare Pinofers Normal Pattern Form
   * @type {FormGroup}
   */
  pinofersNormalPatternForm!: FormGroup;

  /**
   * Declare Pinofers Special Pattern Form
   * @type {FormGroup}
   */
  pinofersSpecialModelForm!: FormGroup;

  /**
   * Get Selected Pinofers Pattern
   * @type {*}
   */
  selectedPinofersPattern: any;

  /**
   * Get Selected Dress Item
   * @type {*}
   */
  selectedDressItem: any;

  /**
   * Get Collar Colours List
   * @type {*}
   */
  collarColoursList: any[] = [];

  /**
   * Get Selected Collar TShirt Colour
   * @type {*}
   */
  selectedCollarTShirtColour: any;

  /**
   * Get Selected Collar Colour
   * @type {*}
   */
  selectedCollarColour: any;

  /**
   * Get Selected Striped Collar Colour
   * @type {*}
   */
  selectedStripedCollarColour: any;

  /**
   * Get Saved Pinofers Special Model Pattern Details
   * @type {*}
   */
  savedSpecialModelPatternDetails: any;

  /**
   * Get Saved Pinofers Normal Pattern Details
   * @type {*}
   */
  savedNormalPatternDetails: any;

  /**
   * Get Is Success Snackbar Flag
   */
  isSuccessSnackbar = false;

  /**
   * Get Is Overlay Visible Flag
   */
  isOverlayVisible = false;

  /**
   * Get Inner HTML Message
   */
  innerHTMLMessage = '';

  /**
   * Get Inner HTML Order Id
   */
  innerHTMLOrderId = '';

  /**
   * Get Pinofers Patterns Form Validations
   */
  pinofersPatternFormValidation = this.validationService.pinofersPattern;

  /**
   * Creates an instance of PinofersModelComponent.
   * @param {ValidationService} validationService
   * @param {FormBuilder} formBuilder
   * @param {ChargesService} chargesService
   * @param {SampleOrderService} sampleOrderService
   * @param {MastersService} masterService
   */
  constructor(
    private validationService: ValidationService,
    private formBuilder: FormBuilder,
    private chargesService: ChargesService,
    private sampleOrderService: SampleOrderService,
    private orderService: OrderService,
    private masterService: MastersService,
    private cdr: ChangeDetectorRef
  ) {
    /* Get Order Pattern Details from behavior subject */
    this.orderService.orderPatternDetailsObj.subscribe((val: any) => {
      if (Object.keys(val).length > 0) {
        this.savedSpecialModelPatternDetails = val?.patternforPinofer;
        this.savedNormalPatternDetails = val?.patternforPinofer;
      } else {
        this.savedSpecialModelPatternDetails = '';
        this.savedNormalPatternDetails = '';
      }
    });
  }

  /**
   * Life Cycle Hook Initialization
   */
  ngOnInit(): void {
    this.getColoursList();
    this.pinofersPatternFormValidations();
    this.pinofersNormalPatternFormValidations();
    this.pinofersSpecialModelFormValidations();
  }

  /**
   * Initialize Pinofers Pattern Form Validations
   */
  pinofersPatternFormValidations() {
    this.pinofersPatternForm = this.formBuilder.group({
      pattern: [this.selectedPinofersPattern?.patternType || '', [Validators.required]],
      dressItem: [this.selectedDressItem?.dressItemName || '', [Validators.required]]
    });
  }

  /**
   * Initialize Pinofers Normal Pattern Form Validations
   */
  pinofersNormalPatternFormValidations() {
    let buttonTypeValue = '';
    let buttonColorValue = '';
    if (this.savedNormalPatternDetails) {
      buttonTypeValue = this.savedNormalPatternDetails?.buttonTypeId?.toString();
      buttonColorValue = this.savedNormalPatternDetails?.colorTypeId?.toString();
    } else {
      this.onResetPinofersNormalPatternForm();
    }
    this.pinofersNormalPatternForm = this.formBuilder.group({
      buttonTypeSelect: [buttonTypeValue, [Validators.required]],
      buttonColourSelect: [buttonColorValue, [Validators.required]]
    });
  }

  /**
   * Initialize Pinofers Special Model Form Validations
   */
  pinofersSpecialModelFormValidations() {
    let modelNoValue = '';
    let collarRadioValue = '0';
    let collarSelectValue = '';
    let neckTypeCollarSelectValue = '';
    let pipingRadioValue = '0';
    let pipingColourSelectValue = '';

    if (this.savedSpecialModelPatternDetails) {
      modelNoValue = this.savedSpecialModelPatternDetails?.modelId?.toString();
      neckTypeCollarSelectValue = this.savedSpecialModelPatternDetails?.collarId?.toString();
      if (this.savedSpecialModelPatternDetails?.collarTypeId !== 0) {
        collarRadioValue = '1';
        this.onChangeCollarRadio(collarRadioValue);
      }
      pipingRadioValue = this.savedSpecialModelPatternDetails?.isPiping ? '1' : '0';
      this.onChangePipingRadio(pipingRadioValue);
      pipingColourSelectValue = this.savedSpecialModelPatternDetails?.pipingColorid?.toString();
    } else {
      this.onResetPinofersSpecialPatternForm();
    }

    this.pinofersSpecialModelForm = this.formBuilder.group({
      modelNoSelect: [modelNoValue, [Validators.required]],
      collarRadio: [collarRadioValue, [Validators.required]],
      collarSelect: [collarSelectValue],
      neckTypeCollarSelect: [neckTypeCollarSelectValue],
      pipingRadio: [pipingRadioValue],
      pipingColourSelect: [pipingColourSelectValue],
      collarTShirtColourSelect: [''],
      collarColourSelect: [''],
      stripedCollarColourSelect: [''],
      bodySelect: [''],
      panelSelect: ['']
    });
  }

  /**
   * Get Pinofers Pattern Form Controls
   * @readonly
   */
  get pinofersPatternFormControls() {
    return this.pinofersPatternForm.controls;
  }

  /**
   * Get Pinofers Normal Pattern Form Controls
   * @readonly
   */
  get pinofersNormalPatternFormControls() {
    return this.pinofersNormalPatternForm.controls;
  }

  /**
   * Get Pinofers Special Model Form Controls
   * @readonly
   */
  get pinofersSpecialModelFormControls() {
    return this.pinofersSpecialModelForm.controls;
  }

  /**
   * This method is used to open the pinofers Modal
   * @param {*} selectedPattern
   * @param {*} selectedDressItem
   */
  openModal(selectedPattern: any, selectedDressItem: any) {
    this.selectedPinofersPattern = selectedPattern;
    this.selectedDressItem = selectedDressItem;
    this.pinofersPatternFormValidations();
    this.getColoursList();
    if (this.selectedPinofersPattern?.patternType === 'Special Model') {
      this.pinofersSpecialModelFormValidations();
      if (this.savedSpecialModelPatternDetails) {
        this.getModelNoList("noEvent");
      } else {
        this.getModelNoList("");
      }
    } else {
      this.pinofersNormalPatternFormValidations();
      if (this.savedNormalPatternDetails) {
        this.getButtonTypesList("noEvent");
      } else {
        this.getButtonTypesList("");
      }
    }
    document.getElementById('pinofersModalButton')?.click();
    const savedOrderItemsList = JSON.parse(localStorage.getItem('savedOrdersList')!);
    // Use a Set to store unique colour names
    const uniqueColourNames = new Set(savedOrderItemsList.map((item: any) => item.colourName));
    // Create a new array with unique items based on colourName
    const uniqueArray = Array.from(uniqueColourNames).map(colourName => {
      return savedOrderItemsList.find((item: any) => item.colourName === colourName);
    });
    this.tShirtsColoursList = uniqueArray;
    const modal = document.getElementById("pinofersPattern") as HTMLElement;
    const snackbar = document.getElementById("pinofersSnackbar") as HTMLElement;
    modal.style.display = "block";
    snackbar.style.zIndex = '9999';
  }

  /**
   * This method is used to reset the Pinofers form pattern form
   */
  onResetPinofersNormalPatternForm() {
    this.selectedButtonColour = '';
    this.selectedButtonType = '';
  }

  /**
   * This method is used to reset the Pinofers form pattern form
   */
  onResetPinofersSpecialPatternForm() {
    this.selectedModelNo = '';
    this.selectedCollarRadio = 0;
    this.collarColoursList = [];
    this.panelColoursList = [];
  }

  /**
   * This method is used to get colours list
   */
  getColoursList() {
    this.masterService.getColours().subscribe({
      next: (res: any) => {
        this.masterColoursList = res.result;
        if (this.savedSpecialModelPatternDetails) {
          const responsePanelColorsItems = this.savedSpecialModelPatternDetails?.panelColors?.map((responseData: any, index: any) => {
            const bodyColour = this.masterColoursList?.find((element: any) => +responseData?.bodyColorId === +element?.colourId);
            const panelColour = this.masterColoursList?.find((element: any) => +responseData?.panelColorId === +element?.colourId);
            return {
              id: index,
              body: bodyColour,
              panel: panelColour
            };
          });
          console.log(responsePanelColorsItems);

          if (responsePanelColorsItems?.length > 0) {
            localStorage.setItem("pinofersPanelColors", JSON.stringify(responsePanelColorsItems));
            this.panelColoursList = responsePanelColorsItems || [];
          } else {
            this.panelColoursList = JSON.parse(localStorage.getItem("pinofersPanelColors")!) || [];
          }

          console.log(this.selectedPipingRadio);


          if (this.selectedPipingRadio === 1) {
            let pipingColourSelectValue = this.savedSpecialModelPatternDetails?.pipingColorid;
            console.log(this.pinofersSpecialModelFormControls['pipingColourSelect']);

            setTimeout(() => {
              this.pinofersSpecialModelFormControls['pipingColourSelect'].setValue(pipingColourSelectValue?.toString());
              this.cdr.detectChanges();
            }, 50);
            this.onChangePipingColour(pipingColourSelectValue);
          }
        }

        if (this.savedNormalPatternDetails) {
          let buttonColorValue = this.savedNormalPatternDetails?.colorTypeId;
          setTimeout(() => {
            this.pinofersNormalPatternFormControls['buttonColourSelect'].setValue(buttonColorValue?.toString());
            this.cdr.detectChanges();
          }, 50);
          this.onChangeButtonColour(buttonColorValue);
        }
      },
      error: (err: any) => {
        this.masterColoursList = [];
      }
    });
  }

  /**
   * This method is used to get the Model list
   * @param {*} eventFlag
   */
  getModelNoList(eventFlag: any) {
    this.chargesService
      .getModelsByDressItemId(this.selectedDressItem?.dressItemId)
      .subscribe({
        next: (res: any) => {
          this.modelNoList = res.result;
          if (eventFlag) {
            let modelNoValue = this.savedSpecialModelPatternDetails?.modelId;
            setTimeout(() => {
              this.pinofersSpecialModelFormControls['modelNoSelect'].setValue(modelNoValue?.toString());
              this.cdr.detectChanges();
            }, 50);
            this.onChangeModelNo(modelNoValue);
          }
        },
        error: (err: any) => {
          this.modelNoList = [];
        }
      });
  }

  /**
   * This method is used to get the button type list
   * @param {*} eventFlag
   */
  getButtonTypesList(eventFlag: any) {
    this.sampleOrderService.getButtonTypes().subscribe({
      next: (res: any) => {
        this.buttonTypesList = res.result;
        if (eventFlag) {
          let buttonTypeValue = this.savedNormalPatternDetails?.buttonTypeId;
          setTimeout(() => {
            this.pinofersNormalPatternFormControls['buttonTypeSelect'].setValue(buttonTypeValue?.toString());
            this.cdr.detectChanges();
          }, 50);
          this.onChangeButtonType(buttonTypeValue);
        }
      },
      error: (err: any) => {
        this.buttonTypesList = [];
      },
    });
  }

  /**
   * This method is used to get the collar types list
   * @param {*} eventFlag
   */
  getCollarTypesList(eventFlag: any) {
    this.sampleOrderService.getCollarTypes().subscribe({
      next: (res: any) => {
        this.collarTypesList = res.result;
        if (eventFlag) {

          if (this.selectedCollarRadio === 1) {
            let collarSelectValue = this.savedSpecialModelPatternDetails?.collarTypeId;
            console.log(this.pinofersSpecialModelFormControls['collarSelect']);

            setTimeout(() => {
              this.pinofersSpecialModelFormControls['collarSelect'].setValue(collarSelectValue?.toString());
              this.cdr.detectChanges();
            }, 50);
            this.onChangeCollarType(collarSelectValue);

            let responseModelCollarItems = this.savedSpecialModelPatternDetails?.specialModelCollars?.map((responseData: any, index: any) => {
              const tShirtColour = this.tShirtsColoursList?.find((element: any) => +responseData?.tShirtColorId === +element?.colorId);
              const collarColour = this.masterColoursList?.find((element: any) => +responseData?.collarColorId === +element?.colourId);
              const stripeColour = this.masterColoursList?.find((element: any) => +responseData?.stripeColorId === +element?.colourId);
              return {
                id: index,
                tShirtColour: tShirtColour,
                collarColour: collarColour,
                stripeColour: this.selectedCollarType?.name === 'Striped Collar' ? stripeColour : 0
              };
            });
            responseModelCollarItems = responseModelCollarItems.filter((item: any) => item.tShirtColour);

            if (responseModelCollarItems?.length > 0) {
              localStorage.setItem("pinofersSpecialModelCollars", JSON.stringify(responseModelCollarItems));
              this.collarColoursList = responseModelCollarItems || [];
            }
            // else {
            //   this.collarColoursList = JSON.parse(localStorage.getItem("pinofersSpecialModelCollars")!);
            // }
          }

        }

      },
      error: (err: any) => {
        this.collarTypesList = [];
      }
    });
  }

  /**
   * This method is used to get the striped collar types list
   * @param {*} eventFlag
   */
  getStripedCollarTypesList(eventFlag: any) {
    this.sampleOrderService.getStripedCollarTypes().subscribe({
      next: (res: any) => {
        this.stripedCollarTypesList = res.result;
        if (eventFlag) {
          if (this.selectedCollarType?.name === 'Striped Collar') {
            console.log(this.pinofersSpecialModelFormControls['neckTypeCollarSelect']);
            let neckTypeCollarSelectValue = this.savedSpecialModelPatternDetails?.collarId;
            setTimeout(() => {
              this.pinofersSpecialModelFormControls['neckTypeCollarSelect'].setValue(neckTypeCollarSelectValue?.toString());
              this.cdr.detectChanges();
            }, 50);
            this.onChangeCollarStripeType(neckTypeCollarSelectValue);
          }
        }
      },
      error: (err: any) => {
        this.stripedCollarTypesList = [];
      }
    });
  }

  /**
   * This method is used to add validators
   * @param {*} formControls
   * @param {*} controls
   */
  onAddValidators(formControls: any, controls: any) {
    controls?.forEach((control: any) => {
      formControls[control].addValidators([Validators.required]);
      formControls[control].updateValueAndValidity({ onlySelf: true });
    });
  }

  /**
   * This method is used to remove validators
   * @param {*} formControls
   */
  onRemoveValidators(formControls: any, controls: any) {
    controls?.forEach((control: any) => {
      formControls[control].removeValidators([Validators.required]);
      formControls[control].updateValueAndValidity({ onlySelf: true });
    });
  }

  /**
   * This method is used to update value and validity
   * @param {*} formControls
   */
  onUpdateValueAndValidity(formControls: any, controls: any) {
    controls?.forEach((control: any) => {
      formControls[control].setValue('');
      formControls[control].markAsUntouched({ onlySelf: true });
      formControls[control].updateValueAndValidity({ onlySelf: true });
    });
  }

  /**
   * This method is used to change the button type
   * @param {*} event
   */
  onChangeButtonType(event: any) {
    let buttonTypeValue = event?.target ? event.target.value : event;
    this.selectedButtonType = this.buttonTypesList?.filter((item: any) => +item.id === +buttonTypeValue)[0];
  }

  /**
   * This method is used to change the button Colour
   * @param {*} event
   */
  onChangeButtonColour(event: any) {
    let buttonColorValue = event?.target ? event.target.value : event;
    this.selectedButtonColour = this.masterColoursList?.filter((item: any) => +item.colourId === +buttonColorValue)[0];
  }

  /**
   * This method is used to change the piping radio
   * @param {*} event
   */
  onChangePipingRadio(event: any) {
    let pipingRadioValue = event?.target ? event.target.value : event;
    this.selectedPipingRadio = +pipingRadioValue;
    if (this.selectedPipingRadio === 1) {
      this.onAddValidators(this.pinofersSpecialModelFormControls, ['pipingColourSelect']);
    } else {
      this.onRemoveValidators(this.pinofersSpecialModelFormControls, ['pipingColourSelect']);
    }
    this.onUpdateValueAndValidity(this.pinofersSpecialModelFormControls, ['pipingColourSelect']);
  }

  /**
   * This method is used to change the piping colour
   * @param {*} event
   */
  onChangePipingColour(event: any) {
    let pipingColorValue = event?.target ? event.target.value : event;
    this.selectedPipingColour = this.masterColoursList?.filter((item: any) => (+item.colourId) === (+pipingColorValue))[0];
  }

  /**
   * This method is used to change the body
   * @param {*} event
   */
  onChangeBody(event: any) {
    this.selectedBody = this.masterColoursList?.filter((item: any) => +item.colourId === (+event.target.value))[0];
  }

  /**
   * This method is used to change the Panel
   * @param {*} event
   */
  onChangePanel(event: any) {
    this.selectedPanel = this.masterColoursList?.filter((item: any) => +item.colourId === (+event.target.value))[0];
  }

  /**
   * This method is used to change the model no
   * @param {*} event
   */
  onChangeModelNo(event: any) {
    let modelNoValue = event?.target ? event.target.value : event;
    this.selectedModelNo = this.modelNoList?.filter((item: any) => +item.modelId === (+modelNoValue))[0];
  }

  /**
   * This method is used to change the collar radio
   * @param {*} event
   */
  onChangeCollarRadio(event: any) {
    let collarRadioValue = event?.target ? event.target.value : event;
    this.selectedCollarRadio = +collarRadioValue;
    if (this.selectedCollarRadio === 1) {
      if (event?.target) {
        this.getCollarTypesList("");
      } else {
        this.getCollarTypesList("noEvent");
      }
      this.onAddValidators(this.pinofersSpecialModelFormControls, ['collarSelect']);
    } else {
      this.onRemoveValidators(this.pinofersSpecialModelFormControls, ['collarSelect']);
    }
    this.onUpdateValueAndValidity(this.pinofersSpecialModelFormControls, ['collarSelect']);
    this.onChangeCollarType('');
  }

  /**
   * This method is used to change the neck collar
   * @param {*} event
   */
  onChangeCollarType(event: any) {
    let collarTypeValue = event?.target ? event.target.value : event;
    if (event) {
      this.selectedCollarType = this.collarTypesList.filter((item: any) => (+item.id) === (+collarTypeValue))[0];
      if (this.selectedCollarType?.name === 'Striped Collar') {
        this.onAddValidators(this.pinofersSpecialModelFormControls, ['neckTypeCollarSelect']);
        if (event?.target) {
          this.getStripedCollarTypesList("");
        } else {
          this.getStripedCollarTypesList("noEvent");
        }
      } else {
        this.onRemoveValidators(this.pinofersSpecialModelFormControls, ['neckTypeCollarSelect']);
      }
    } else {
      this.onRemoveValidators(this.pinofersSpecialModelFormControls, ['neckTypeCollarSelect']);
      this.selectedCollarType = '';
    }
    this.selectedStripedTypeCollar = '';
    this.onUpdateValueAndValidity(this.pinofersSpecialModelFormControls, ['neckTypeCollarSelect']);
    this.collarColoursList = [];
    this.selectedCollarTShirtColour = '';
    this.selectedCollarColour = '';
    this.selectedStripedCollarColour = '';
    this.onUpdateValueAndValidity(this.pinofersSpecialModelFormControls, ['collarTShirtColourSelect', 'collarColourSelect', 'stripedCollarColourSelect']);
  }

  /**
   * This method is used to change the neck collar stripe type
   * @param {*} event
   */
  onChangeCollarStripeType(event: any) {
    let stripedCollarTypeValue = event?.target ? event.target.value : event;
    this.selectedStripedTypeCollar = this.stripedCollarTypesList.filter((item: any) => (+item.id) === (+stripedCollarTypeValue))[0];
  }

  /**
   * This method is used to add the body panels
   */
  onClickAddBodyPanel() {
    this.onAddValidators(this.pinofersSpecialModelFormControls, ['bodySelect', 'panelSelect']);
    const body = this.selectedBody;
    const panel = this.selectedPanel;

    if (!body || !panel) {
      this.pinofersSpecialModelFormControls['bodySelect'].markAsTouched({ onlySelf: true, });
      this.pinofersSpecialModelFormControls['panelSelect'].markAsTouched({ onlySelf: true, });
      return;
    }

    const existingRecord = this.panelColoursList.find((item) => {
      return item.body?.colourName === body?.colourName && item.panel?.colourName === panel?.colourName;
    });

    if (existingRecord) {
      this.showSnackbar("Record Already Exists", '', false, true);
      return;
    }

    /* Prepare the panel colour item object */
    const obj: any = {
      id: this.panelColoursList.length > 0 ? this.panelColoursList.length : 0,
      body: body,
      panel: panel,
    };

    /* Push the panel colour item */
    this.panelColoursList.push(obj);
    this.selectedBody = '';
    this.selectedPanel = '';
    this.onRemoveValidators(this.pinofersSpecialModelFormControls, ['bodySelect', 'panelSelect']);
    this.onUpdateValueAndValidity(this.pinofersSpecialModelFormControls, ['bodySelect', 'panelSelect']);
  }

  /**
   * This method is used to delete the panel colour item
   * @param {*} panelColour
   */
  onClickDeletePanelColourItem(panelColour: any) {
    this.panelColoursList = this.panelColoursList.filter(
      (item: any) => item.id !== panelColour.id
    );
  }

  /**
   * This method is used to change the Collar T-Shirt Colour
   * @param {*} event
   */
  onChangeCollarTShirtColour(event: any) {
    this.selectedCollarTShirtColour = this.tShirtsColoursList?.filter((item: any) => (+item.colorId) === (+event.target.value))[0];
  }

  /**
   * This method is used to change the Collar Colour
   * @param {*} event
   */
  onChangeCollarColour(event: any) {
    this.selectedCollarColour = this.masterColoursList?.filter((item: any) => (+item.colourId) === (+event.target.value))[0];
  }

  /**
   * This method is used to change the Collar Colour
   * @param {*} event
   */
  onChangeStripedCollarColour(event: any) {
    this.selectedStripedCollarColour = this.masterColoursList?.filter((item: any) => (+item.colourId) === (+event.target.value))[0];
  }

  /**
   * This method is used to add the Collar Colour
   */
  onClickAddCollarColour() {
    this.onAddValidators(this.pinofersSpecialModelFormControls, ['collarTShirtColourSelect', 'collarColourSelect']);
    if (this.selectedCollarType?.name === 'Striped Collar') {
      this.onAddValidators(this.pinofersSpecialModelFormControls, ['stripedCollarColourSelect']);
      this.pinofersSpecialModelFormControls['stripedCollarColourSelect'].markAsTouched({ onlySelf: true });
    } else {
      this.onRemoveValidators(this.pinofersSpecialModelFormControls, ['stripedCollarColourSelect']);
      this.pinofersSpecialModelFormControls['stripedCollarColourSelect'].markAsUntouched({ onlySelf: true });
    }

    const collarTShirtColour = this.selectedCollarTShirtColour;
    const collarColor = this.selectedCollarColour;
    const stripedCollarColor = this.selectedStripedCollarColour;

    if (!collarTShirtColour || !collarColor) {
      this.pinofersSpecialModelFormControls['collarTShirtColourSelect'].markAsTouched({ onlySelf: true });
      this.pinofersSpecialModelFormControls['collarColourSelect'].markAsTouched({ onlySelf: true });
      return;
    }

    if (this.selectedCollarType?.name === 'Striped Collar' && !stripedCollarColor) {
      this.pinofersSpecialModelFormControls['stripedCollarColourSelect'].markAsTouched({ onlySelf: true });
      return;
    }

    const existingRecord = this.collarColoursList.find(item => {
      return item.tShirtColour?.colourName === collarTShirtColour?.colourName;
    });

    if (existingRecord) {
      this.showSnackbar("Record Already Exists", '', false, true);
      return;
    }

    /* Prepare the colour item object */
    const obj: any = {
      id: this.collarColoursList.length > 0 ? this.collarColoursList.length : 0,
      tShirtColour: collarTShirtColour,
      collarColour: collarColor,
      stripeColour: this.selectedCollarType?.name === 'Striped Collar' ? stripedCollarColor : 0
    };

    console.log(obj);

    /* Push the colour item */
    this.collarColoursList.push(obj);
    this.selectedCollarTShirtColour = '';
    this.selectedCollarColour = '';
    this.selectedStripedCollarColour = '';
    this.onRemoveValidators(this.pinofersSpecialModelFormControls, ['collarTShirtColourSelect', 'collarColourSelect', 'stripedCollarColourSelect']);
    this.onUpdateValueAndValidity(this.pinofersSpecialModelFormControls, ['collarTShirtColourSelect', 'collarColourSelect', 'stripedCollarColourSelect']);
  }

  /**
   * This method is used to delete the colour item
   * @param {*} colour
   */
  onClickDeleteCollarColourItem(colour: any) {
    this.collarColoursList = this.collarColoursList.filter((item: any) => item.id !== colour.id);
  }

  /**
   * This method is used to reset the selected color fields
   */
  onResetSpecialColorFields() {
    this.selectedCollarTShirtColour = '';
    this.selectedCollarColour = '';
    this.selectedStripedCollarColour = '';
    this.selectedBody = '';
    this.selectedPanel = '';
    this.onRemoveValidators(this.pinofersSpecialModelFormControls, [
      'bodySelect',
      'panelSelect',
      'collarTShirtColourSelect',
      'collarColourSelect',
      'stripedCollarColourSelect',
    ]);
    this.onUpdateValueAndValidity(this.pinofersSpecialModelFormControls, [
      'bodySelect',
      'panelSelect',
      'collarTShirtColourSelect',
      'collarColourSelect',
      'stripedCollarColourSelect',
    ]);
  }

  /**
   * This method is used to show the snackbar
   * @param {string} message
   * @param {*} orderId
   * @param {boolean} successFlag
   * @param {boolean} isModalOverlay
   */
  showSnackbar(message: string, orderId: any, successFlag: boolean, isModalOverlay: boolean) {
    const snackbar = document.getElementById("pinofersSnackbar") as HTMLElement;
    this.innerHTMLMessage = message;
    this.innerHTMLOrderId = orderId;
    this.isSuccessSnackbar = successFlag;
    this.isOverlayVisible = isModalOverlay;
    snackbar.style.display = "block";
  }

  /**
   * This method is used to hide the snackbar
   */
  onClickSnackbarOkButton() {
    const snackbar = document.getElementById("pinofersSnackbar") as HTMLElement;
    snackbar.style.display = "none";
    this.innerHTMLOrderId = '';
    this.innerHTMLMessage = '';
    this.isOverlayVisible = false;
    this.isSuccessSnackbar = false;
  }

  /**
   * This method is used to save the special model items
   */
  onClickSaveSpecialModelItems() {
    this.onResetSpecialColorFields();
    /** This will return false if form fields are invalid and return */
    if (this.pinofersSpecialModelForm.invalid) {
      this.validationService.validateAllFormFields(this.pinofersSpecialModelForm);
      return;
    }

    // Extract colourName values from array1
    const colourNamesArray1 = this.tShirtsColoursList.map((item: any) => item.colourName);

    // Check if each colourName in array1 exists in tShirtColour.colourName of array2
    const tShirtColorsForCollarAllExists = colourNamesArray1.every((colourName: any) =>
      this.collarColoursList.some((item: any) => item.tShirtColour.colourName === colourName)
    );


    if (this.selectedCollarRadio === 1) {
      if (this.collarColoursList?.length === 0) {
        this.showSnackbar("Add Order Collar Colours", '', false, true);
        return;
      } else if (!tShirtColorsForCollarAllExists) {
        this.showSnackbar("Add All T-Shirt Colours", '', false, true);
        return;
      }
    }

    /* Prepare Special Model For Pinofers Panel Colors Array */
    const panelColors = [];
    for (let index = 0; index < this.panelColoursList?.length; index++) {
      const element = this.panelColoursList[index];
      panelColors.push({
        bodyColorId: +element.body.colourId,
        panelColorId: +element.panel.colourId,
        patternId: +this.selectedPinofersPattern?.patternTypeId
      });
    }

    console.log(panelColors);

    /* Prepare Special Model For Pinofers Collar Colours Array */
    const specialModelCollars = [];
    for (let index = 0; index < this.collarColoursList?.length; index++) {
      const element = this.collarColoursList[index];
      specialModelCollars.push({
        tShirtColorId: +element?.tShirtColour?.colorId,
        collarColorId: +element.collarColour?.colourId,
        stripeColorId: element.stripeColour?.colourId ? +element.stripeColour?.colourId : 0
      });
    }

    /* Prepare the pinofers special pattern obj */
    const patternForPinofersObj = {
      modelId: +this.selectedModelNo?.modelId,
      isPiping: this.selectedPipingRadio === 1,
      pipingColorid: this.selectedPipingRadio === 1 ? +this.selectedPipingColour?.colourId : 0,
      buttonTypeId: 0,
      colorTypeId: 0,
      isNeckCollar: this.selectedCollarRadio === 1,
      patternId: this.selectedPinofersPattern?.patternTypeId,
      collarTypeId: this.selectedCollarRadio === 1 ? +this.selectedCollarType?.id : 0,
      collarId: this.selectedCollarRadio == 1 && this.selectedCollarType?.name === 'Striped Collar' ? +this.selectedStripedTypeCollar?.id : 0,
      specialModelCollars: specialModelCollars.length > 0 ? specialModelCollars : [],
      panelColors: panelColors.length > 0 ? panelColors : [],
    }

    localStorage.setItem('pinofersSpecialModelCollars', JSON.stringify(this.collarColoursList));
    localStorage.setItem('pinofersPanelColors', JSON.stringify(this.panelColoursList));

    /* Prepare the pinofers special pattern obj */
    const obj = {
      patternforPinofer: patternForPinofersObj,
    }

    console.log(obj);
    this.orderService.orderPatternDetailsObj.next(obj);
    document.getElementById('closePinofersModal')?.click();
  }

  /**
   * This method is used to add the pinofers
   */
  onClickSaveNormalPinofersPatternItems() {
    /** This will return false if form fields are invalid and return */
    if (this.pinofersNormalPatternForm.invalid) {
      this.validationService.validateAllFormFields(this.pinofersNormalPatternForm);
      return;
    }

    /* Prepare the pinofers normal pattern obj */
    const patternForPinofersObj = {
      buttonTypeId: +this.selectedButtonType?.id,
      colorTypeId: +this.selectedButtonColour?.colourId,
      patternId: this.selectedPinofersPattern?.patternTypeId
    };

    /* Prepare the pinofers normal pattern obj */
    const obj = {
      patternforPinofer: patternForPinofersObj,
    }

    console.log(obj);

    this.orderService.orderPatternDetailsObj.next(obj);
    document.getElementById('closePinofersModal')?.click();
  }
}
