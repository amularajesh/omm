import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import {
  MasterColourItems,
  PanelColoursItems,
  StripePipingItems,
} from 'src/app/core/Modals/modals';
import { ChargesService } from 'src/app/core/Services/charges.service';
import { MastersService } from 'src/app/core/Services/masters.service';
import { OrderService } from 'src/app/core/Services/order.service';
import { SampleOrderService } from 'src/app/core/Services/sample-order.service';
import { ValidationService } from 'src/app/core/Services/validation.service';

/**
 * Orders Pant Pattern Modal Component
 * @export
 * @class OrdersPantPatternModalComponent
 * @implements {OnInit}
 */
@Component({
  selector: 'app-orders-pant-pattern-modal',
  templateUrl: './orders-pant-pattern-modal.component.html',
  styleUrls: ['./orders-pant-pattern-modal.component.scss'],
})
export class OrdersPantPatternModalComponent implements OnInit {
  /**
   * Get Panel Colours List
   * @type {PanelColoursItems[]}
   */
  panelColoursList: PanelColoursItems[] = [];

  /**
   * Get Colours List
   * @type {MasterColourItems[]}
   */
  masterColoursList: MasterColourItems[] = [];

  /**
   * Get Striped Count List
   * @type {StripePipingItems[]}
   */
  stripedCountList: StripePipingItems[] = [];

  /**
   * Get Model No List
   * @type {*}
   */
  modelNoList: any;

  /**
   * Get Selected Panel
   * @type {*}
   */
  selectedPanel: any;

  /**
   * Get Selected Body
   * @type {*}
   */
  selectedBody: any;

  /**
   * Get Selected Piping Colour
   * @type {*}
   */
  selectedPipingColour: any;

  /**
   * Get Selected Piping Radio
   */
  selectedPipingRadio = 0;

  /**
   * Get Selected Inner rope Radio
   */
  selectedInnerRopeRadio = 0;

  /**
   * Get Selected pocket Radio
   */
  selectedPocketRadio = 0;

  /**
   * Get Selected Zip Radio
   */
  selectedZipRadio = 0;

  /**
   * Get Selected Back Pocket Radio
   */
  selectedBackPocketRadio = 0;

  /**
   * Get Selected Zip type
   * @type {*}
   */
  selectedZipType: any;

  /**
   * Get Selected Model No
   * @type {*}
   */
  selectedModelNo: any;

  /**
   * Get Selected Normal Body
   * @type {*}
   */
  selectedNormalBody: any;

  /**
   * Get Selected Back Pocket type
   * @type {*}
   */
  selectedBackPocketType: any;

  /**
   * Get Selected Striped Count
   * @type {*}
   */
  selectedStripedCount: any;

  /**
   * Get Selected pocket type
   */
  selectedPocketType: any;

  /**
   * Get Selected Striped Colour
   * @type {*}
   */
  selectedStripedColour: any;

  /**
   * Get Selected stript Radio
   */
  selectedStripedRadio = 0;

  /**
   * Get Selected strip colour Radio
   */
  selectedStripedColourRadio = 0;

  /**
   * Get Pocket Types List
   */
  pocketTypesList: any;

  /**
   * Get Zip Types List
   */
  zipTypesList: any;

  /**
   * Get Back Pocket Types List
   */
  backPocketTypesList: any;

  /**
   * Declare Pant Pattern Form
   * @type {FormGroup}
   */
  pantPatternForm!: FormGroup;

  /**
   * Get Selected Pant Pattern
   * @type {*}
   */
  selectedPantPattern: any;

  /**
   * Get Selected Dress Item
   * @type {*}
   */
  selectedDressItem: any;

  /**
   * Get Saved Pant Pattern Details
   * @type {*}
   */
  savedPantPatternDetails: any;

  /**
   * Get Is Success Snackbar Flag
   */
  isSuccessSnackbar = false;

  /**
   * Get Is Overlay Visible Flag
   */
  isOverlayVisible = false;

  /**
   * Get Inner HTML Message
   */
  innerHTMLMessage = '';

  /**
   * Get Inner HTML Order Id
   */
  innerHTMLOrderId = '';

  /**
   * Get Pant Patterns Form Validations
   */
  pantPatternFormValidation = this.validationService.nickersPattern;

  /**
   * Creates an instance of PantPatternModalComponent.
   * @param {ValidationService} validationService
   * @param {FormBuilder} formBuilder
   * @param {MastersService} masterService
   * @param {SampleOrderService} sampleOrderService
   * @param {ChargesService} chargesService
   * @param {ChangeDetectorRef} cdr
   */
  constructor(
    private validationService: ValidationService,
    private formBuilder: FormBuilder,
    private masterService: MastersService,
    private sampleOrderService: SampleOrderService,
    private orderService: OrderService,
    private chargesService: ChargesService,
    private cdr: ChangeDetectorRef
  ) {
    /* Get Pattern Details from behavior subject */
    this.orderService.orderPatternDetailsObj.subscribe((val: any) => {
      if (Object.keys(val).length > 0) {
        this.savedPantPatternDetails = val?.patternforPant;
      } else {
        this.savedPantPatternDetails = '';
      }
    });
  }

  /**
   * Life Cycle Hook Initialization
   */
  ngOnInit(): void {
    this.getColoursList();
    this.pantPatternFormValidations();
  }

  /**
   * Initialize Pant Pattern Form Validations
   */
  pantPatternFormValidations() {
    let modelNoSelectValue = '';
    let normalBodySelectValue = '';
    let pipingRadioValue = '0';
    let innerRopeRadioValue = '0';
    let stripedRadioValue = '0';
    let stripedColourRadioValue = '0';
    let pocketRadioValue = '0';
    let zipRadioValue = '0';
    let backPocketRadioValue = '0';
    let pipingColourSelectValue = '';
    let stripedCountSelectValue = '';
    let stripedColourSelectValue = '';
    let pocketTypeSelectValue = '';
    let zipTypeSelectValue = '';
    let backPocketTypeSelectValue = '';

    if (this.savedPantPatternDetails) {
      pipingRadioValue = this.savedPantPatternDetails?.isPiping ? '1' : '0';
      this.onChangePipingRadio(pipingRadioValue);

      pocketRadioValue = this.savedPantPatternDetails?.isPocket ? '1' : '0';
      this.onChangePocketRadio(pocketRadioValue);

      innerRopeRadioValue = this.savedPantPatternDetails?.isInnerRope
        ? '1'
        : '0';
      this.onChangeInnerRopeRadio(innerRopeRadioValue);

      normalBodySelectValue = this.savedPantPatternDetails?.bodyColorId;

      if (this.selectedPantPattern?.patternType === 'Special') {
        stripedRadioValue = this.savedPantPatternDetails?.isStripes ? '1' : '0';
        this.onChangeStripedRadio(stripedRadioValue);
        if (this.savedPantPatternDetails?.zipId !== 0) {
          zipRadioValue = '1';
        }
        this.onChangeZipRadio(zipRadioValue);
        if (this.savedPantPatternDetails?.backPocketId !== 0) {
          backPocketRadioValue = '1';
        }
        this.onChangeBackPocketRadio(backPocketRadioValue);
      }
    } else {
      this.onResetPantPatternForm();
    }

    this.pantPatternForm = this.formBuilder.group({
      pattern: [
        this.selectedPantPattern?.patternType || '',
        [Validators.required],
      ],
      dressItem: [
        this.selectedDressItem?.dressItemName || '',
        [Validators.required],
      ],
      modelNoSelect: [modelNoSelectValue],
      patternBodySelect: [normalBodySelectValue],
      pipingRadio: [pipingRadioValue],
      innerRopeRadio: [innerRopeRadioValue],
      stripedRadio: [stripedRadioValue],
      pocketRadio: [pocketRadioValue],
      stripedColourRadio: [stripedColourRadioValue],
      zipRadio: [zipRadioValue],
      backPocketRadio: [backPocketRadioValue],
      pipingColourSelect: [pipingColourSelectValue],
      stripedCountSelect: [stripedCountSelectValue],
      stripedColourSelect: [stripedColourSelectValue],
      pocketTypeSelect: [pocketTypeSelectValue],
      zipTypeSelect: [zipTypeSelectValue],
      backPocketTypeSelect: [backPocketTypeSelectValue],
      bodySelect: [''],
      panelSelect: [''],
    });
  }

  /**
   * Get Pant Pattern Model Form Controls
   * @readonly
   */
  get pantPatternFormControls() {
    return this.pantPatternForm.controls;
  }

  /**
   * This method is used to open the pant Modal
   * @param {*} selectedPattern
   * @param {*} selectedDressItem
   */
  openModal(selectedPattern: any, selectedDressItem: any) {
    this.selectedPantPattern = selectedPattern;
    this.selectedDressItem = selectedDressItem;
    this.pantPatternFormValidations();
    this.getColoursList();
    document.getElementById('pantModalButton')?.click();
    if (this.selectedPantPattern?.patternType === 'Special') {
      if (this.savedPantPatternDetails) {
        this.getModelNoList('noEvent');
      } else {
        this.getModelNoList('');
      }
      this.onAddValidators(this.pantPatternFormControls, ['modelNoSelect']);
      this.onRemoveValidators(this.pantPatternFormControls, [
        'patternBodySelect',
      ]);
    } else {
      this.onAddValidators(this.pantPatternFormControls, ['patternBodySelect']);
      this.onRemoveValidators(this.pantPatternFormControls, ['modelNoSelect']);
    }
    const modal = document.getElementById('pantPattern') as HTMLElement;
    const snackbar = document.getElementById('pantSnackbar') as HTMLElement;
    modal.style.display = 'block';
    snackbar.style.zIndex = '9999';
  }

  /**
   * This method is used to reset the pant pattern form
   */
  onResetPantPatternForm() {
    this.selectedPipingRadio = 0;
    this.selectedPocketRadio = 0;
    this.selectedStripedRadio = 0;
    this.selectedStripedColourRadio = 0;
    this.selectedBackPocketRadio = 0;
    this.selectedZipRadio = 0;
    this.selectedInnerRopeRadio = 0;
    this.selectedModelNo = '';
    this.selectedNormalBody = '';
    this.selectedBackPocketType = '';
    this.selectedBody = '';
    this.selectedPanel = '';
    this.selectedPipingColour = '';
    this.selectedPocketType = '';
    this.selectedStripedColour = '';
    this.selectedZipType = '';
    this.selectedStripedCount = '';
    this.panelColoursList = [];
  }

  /**
   * This method is used to get the neck collars list
   * @param {*} eventFlag
   */
  getModelNoList(eventFlag: any) {
    this.chargesService
      .getModelsByDressItemId(this.selectedDressItem?.dressItemId)
      .subscribe({
        next: (res: any) => {
          this.modelNoList = res.result;
          if (eventFlag) {
            let modelNoSelectValue = this.savedPantPatternDetails?.modelId;
            setTimeout(() => {
              this.pantPatternFormControls['modelNoSelect'].setValue(
                modelNoSelectValue?.toString()
              );
              this.cdr.detectChanges();
            }, 50);
            this.onChangeModelNo(modelNoSelectValue);
          }
        },
        error: (err: any) => {
          this.modelNoList = [];
        },
      });
  }

  /**
   * This method is used to get colours list
   */
  getColoursList() {
    this.masterService.getColours().subscribe({
      next: (res: any) => {
        this.masterColoursList = res.result;
        if (this.savedPantPatternDetails) {
          let pipingColourSelectValue =
            this.savedPantPatternDetails?.pipingColorid;
          setTimeout(() => {
            this.pantPatternFormControls['pipingColourSelect'].setValue(
              pipingColourSelectValue?.toString()
            );
            this.cdr.detectChanges();
          }, 50);
          this.onChangePipingColour(pipingColourSelectValue);

          let stripedColourSelectValue =
            this.savedPantPatternDetails?.stripesColorID;
          setTimeout(() => {
            this.pantPatternFormControls['stripedColourSelect'].setValue(
              stripedColourSelectValue?.toString()
            );
            this.cdr.detectChanges();
          }, 50);
          this.onChangeStripedColour(stripedColourSelectValue);

          let normalBodySelectValue = this.savedPantPatternDetails?.bodyColorId;
          setTimeout(() => {
            this.pantPatternFormControls['patternBodySelect'].setValue(
              normalBodySelectValue?.toString()
            );
            this.cdr.detectChanges();
          }, 50);
          this.onChangeNormalBodySelect(normalBodySelectValue);

          const responsePanelColorsItems =
            this.savedPantPatternDetails?.panelColors?.map(
              (responseData: any, index: any) => {
                const bodyColour = this.masterColoursList?.find(
                  (element: any) =>
                    +responseData?.bodyColorId === +element?.colourId
                );
                const panelColour = this.masterColoursList?.find(
                  (element: any) =>
                    +responseData?.panelColorId === +element?.colourId
                );
                return {
                  id: index,
                  body: bodyColour,
                  panel: panelColour,
                };
              }
            );

          if (responsePanelColorsItems?.length > 0) {
            localStorage.setItem(
              'pantPatternPanelColoursList',
              JSON.stringify(responsePanelColorsItems)
            );
            this.panelColoursList = responsePanelColorsItems || [];
          } else {
            this.panelColoursList =
              JSON.parse(
                localStorage.getItem('pantPatternPanelColoursList')!
              ) || [];
          }
        }
      },
      error: (err: any) => {
        this.masterColoursList = [];
      },
    });
  }

  /**
   * This method is used to get colours list
   * @param {*} eventFlag
   */
  getPocketTypesList(eventFlag: any) {
    this.chargesService
      .getPocketTypesByDressItemId(this.selectedDressItem?.dressItemId)
      .subscribe({
        next: (res: any) => {
          this.pocketTypesList = res.result;

          if (eventFlag) {
            if (this.savedPantPatternDetails) {
              if (this.selectedPocketRadio === 1) {
                let pocketTypeSelectValue =
                  this.savedPantPatternDetails?.pocketId;
                setTimeout(() => {
                  this.pantPatternFormControls['pocketTypeSelect'].setValue(
                    pocketTypeSelectValue?.toString()
                  );
                  this.cdr.detectChanges();
                }, 50);
                this.onChangePocketType(pocketTypeSelectValue);
              }
            }
          }
        },
        error: (err: any) => {
          this.pocketTypesList = [];
        },
      });
  }

  /**
   * This method is used to get colours list
   * @param {*} eventFlag
   */
  getZipTypesList(eventFlag: any) {
    this.chargesService
      .getPocketTypesByDressItemId(this.selectedDressItem?.dressItemId)
      .subscribe({
        next: (res: any) => {
          this.zipTypesList = res.result;

          if (eventFlag) {
            if (this.savedPantPatternDetails) {
              if (this.selectedZipRadio === 1) {
                let zipTypeSelectValue = this.savedPantPatternDetails?.zipId;
                setTimeout(() => {
                  this.pantPatternFormControls['zipTypeSelect'].setValue(
                    zipTypeSelectValue?.toString()
                  );
                  this.cdr.detectChanges();
                }, 50);
                this.onChangeZipType(zipTypeSelectValue);
              }
            }
          }
        },
        error: (err: any) => {
          this.zipTypesList = [];
        },
      });
  }

  /**
   * This method is used to get colours list
   * @param {*} eventFlag
   */
  getBackPocketTypesList(eventFlag: any) {
    this.chargesService
      .getPocketTypesByDressItemId(this.selectedDressItem?.dressItemId)
      .subscribe({
        next: (res: any) => {
          this.backPocketTypesList = res.result;

          if (eventFlag) {
            if (this.savedPantPatternDetails) {
              if (this.selectedBackPocketRadio === 1) {
                let backPocketTypeSelectValue =
                  this.savedPantPatternDetails?.backPocketId;
                setTimeout(() => {
                  this.pantPatternFormControls['backPocketTypeSelect'].setValue(
                    backPocketTypeSelectValue?.toString()
                  );
                  this.cdr.detectChanges();
                }, 50);
                this.onChangeBackPocketType(backPocketTypeSelectValue);
              }
            }
          }
        },
        error: (err: any) => {
          this.backPocketTypesList = [];
        },
      });
  }

  /**
   * This method is used to get striped count list
   * @param {*} eventFlag
   */
  getStripedCountList(eventFlag: any) {
    this.sampleOrderService.getStripedCount().subscribe({
      next: (res: any) => {
        this.stripedCountList = res.result;
        if (eventFlag) {
          if (this.savedPantPatternDetails) {
            if (this.selectedStripedRadio === 1) {
              let stripedCountSelectValue =
                this.savedPantPatternDetails?.stripesCount;
              setTimeout(() => {
                this.pantPatternFormControls['stripedCountSelect'].setValue(
                  stripedCountSelectValue?.toString()
                );
                this.cdr.detectChanges();
              }, 50);
              this.onChangeStripedCount(stripedCountSelectValue);

              let stripedColourRadioValue = this.savedPantPatternDetails
                ?.isStripesColor
                ? '1'
                : '0';
              setTimeout(() => {
                this.pantPatternFormControls['stripedColourRadio'].setValue(
                  stripedColourRadioValue?.toString()
                );
                this.cdr.detectChanges();
              }, 50);
              this.onChangeStripedColourRadio(stripedColourRadioValue);
            }
          }
        }
      },
      error: (err: any) => {
        this.stripedCountList = [];
      },
    });
  }

  /**
   * This method is used to add validators
   * @param {*} formControls
   * @param {*} controls
   */
  onAddValidators(formControls: any, controls: any) {
    controls?.forEach((control: any) => {
      formControls[control].addValidators([Validators.required]);
      formControls[control].updateValueAndValidity({ onlySelf: true });
    });
  }

  /**
   * This method is used to remove validators
   * @param {*} formControls
   */
  onRemoveValidators(formControls: any, controls: any) {
    controls?.forEach((control: any) => {
      formControls[control].removeValidators([Validators.required]);
      formControls[control].updateValueAndValidity({ onlySelf: true });
    });
  }

  /**
   * This method is used to update value and validity
   * @param {*} formControls
   */
  onUpdateValueAndValidity(formControls: any, controls: any) {
    controls?.forEach((control: any) => {
      formControls[control].setValue('');
      formControls[control].markAsUntouched({ onlySelf: true });
      formControls[control].updateValueAndValidity({ onlySelf: true });
    });
  }

  /**
   * This method is used to change the model no
   * @param {*} event
   */
  onChangeModelNo(event: any) {
    let modelNoValue = event?.target ? event?.target.value : event;
    this.selectedModelNo = this.modelNoList.filter(
      (item: any) => +item.modelId === +modelNoValue
    )[0];
  }

  /**
   * This method is used to change the body
   * @param {*} event
   */
  onChangeNormalBodySelect(event: any) {
    let bodyValue = event?.target ? event?.target.value : event;
    this.selectedNormalBody = this.masterColoursList.filter(
      (item: any) => +item.colourId === +bodyValue
    )[0];
  }

  /**
   * This method is used to change the piping radio
   * @param {*} event
   */
  onChangePipingRadio(event: any) {
    let pipingRadioValue = event?.target ? event?.target.value : event;
    this.selectedPipingRadio = +pipingRadioValue;
    if (this.selectedPipingRadio === 1) {
      this.onAddValidators(this.pantPatternFormControls, [
        'pipingColourSelect',
      ]);
    } else {
      this.onRemoveValidators(this.pantPatternFormControls, [
        'pipingColourSelect',
      ]);
    }
    this.selectedPipingColour = '';
    this.onUpdateValueAndValidity(this.pantPatternFormControls, [
      'pipingColourSelect',
    ]);
  }

  /**
   * This method is used to change the piping colour colour
   * @param {*} event
   */
  onChangePipingColour(event: any) {
    let pipingColorValue = event?.target ? event?.target.value : event;
    this.selectedPipingColour = this.masterColoursList.filter(
      (item: any) => +item.colourId === +pipingColorValue
    )[0];
  }

  /**
   * This method is used to change the inner rope radio
   * @param {*} event
   */
  onChangeInnerRopeRadio(event: any) {
    let innerRopeRadioValue = event?.target ? event?.target.value : event;
    this.selectedInnerRopeRadio = +innerRopeRadioValue;
  }

  /**
   * This method is used to change the zip radio
   * @param {*} event
   */
  onChangeZipRadio(event: any) {
    let zipRadioValue = event?.target ? event?.target.value : event;
    this.selectedZipRadio = +zipRadioValue;
    if (this.selectedZipRadio === 1) {
      if (event?.target) {
        this.getZipTypesList('');
      } else {
        this.getZipTypesList('noEvent');
      }
      this.onAddValidators(this.pantPatternFormControls, ['zipTypeSelect']);
    } else {
      this.onRemoveValidators(this.pantPatternFormControls, ['zipTypeSelect']);
    }
    if (event?.target) {
      this.selectedZipType = '';
      this.onUpdateValueAndValidity(this.pantPatternFormControls, [
        'zipTypeSelect',
      ]);
    }
  }

  /**
   * This method is used to change the zip type
   * @param {*} event
   */
  onChangeZipType(event: any) {
    let zipTypeValue = event?.target ? event?.target.value : event;
    this.selectedZipType = this.zipTypesList.filter(
      (item: any) => +item.pocketTypeId === +zipTypeValue
    )[0];
  }

  /**
   * This method is used to change the back pocket radio
   * @param {*} event
   */
  onChangeBackPocketRadio(event: any) {
    let backPocketRadioValue = event?.target ? event?.target.value : event;
    this.selectedBackPocketRadio = +backPocketRadioValue;
    if (this.selectedBackPocketRadio === 1) {
      if (event?.target) {
        this.getBackPocketTypesList('');
      } else {
        this.getBackPocketTypesList('noEvent');
      }
      this.onAddValidators(this.pantPatternFormControls, [
        'backPocketTypeSelect',
      ]);
    } else {
      this.onRemoveValidators(this.pantPatternFormControls, [
        'backPocketTypeSelect',
      ]);
    }
    if (event?.target) {
      this.selectedBackPocketType = '';
      this.onUpdateValueAndValidity(this.pantPatternFormControls, [
        'backPocketTypeSelect',
      ]);
    }
  }

  /**
   * This method is used to change the back pocket type
   * @param {*} event
   */
  onChangeBackPocketType(event: any) {
    let backPocketTypeValue = event?.target ? event?.target.value : event;
    this.selectedBackPocketType = this.backPocketTypesList.filter(
      (item: any) => +item.pocketTypeId === +backPocketTypeValue
    )[0];
  }

  /**
   * This method is used to change the Striped radio
   * @param {*} event
   */
  onChangeStripedRadio(event: any) {
    let stripedRadioValue = event?.target ? event?.target.value : event;
    this.selectedStripedRadio = +stripedRadioValue;
    if (this.selectedStripedRadio === 1) {
      this.onAddValidators(this.pantPatternFormControls, [
        'stripedCountSelect',
      ]);
      if (event?.target) {
        this.getStripedCountList('');
      } else {
        this.getStripedCountList('noEvent');
      }
    } else {
      this.onRemoveValidators(this.pantPatternFormControls, [
        'stripedCountSelect',
      ]);
      this.pantPatternFormControls['stripedColourRadio'].setValue('0');
      this.selectedStripedColourRadio = 0;
      this.onRemoveValidators(this.pantPatternFormControls, [
        'stripedColourSelect',
      ]);
      this.onUpdateValueAndValidity(this.pantPatternFormControls, [
        'stripedColourSelect',
      ]);
    }
    if (event?.target) {
      this.selectedStripedCount = '';
      this.onUpdateValueAndValidity(this.pantPatternFormControls, [
        'stripedCountSelect',
      ]);
    }
  }

  /**
   * This method is used to change the strip count
   * @param {*} event
   */
  onChangeStripedCount(event: any) {
    let stripedCountValue = event?.target ? event?.target.value : event;
    this.selectedStripedCount = this.stripedCountList.filter(
      (item: any) => +item.id === +stripedCountValue
    )[0];
  }

  /**
   * This method is used to change the Striped colour radio
   * @param {*} event
   */
  onChangeStripedColourRadio(event: any) {
    let stripedColorRadioValue = event?.target ? event?.target.value : event;
    this.selectedStripedColourRadio = +stripedColorRadioValue;
    if (this.selectedStripedColourRadio === 1) {
      this.onAddValidators(this.pantPatternFormControls, [
        'stripedColourSelect',
      ]);
    } else {
      this.onRemoveValidators(this.pantPatternFormControls, [
        'stripedColourSelect',
      ]);
    }
    this.selectedStripedColour = '';
    this.onUpdateValueAndValidity(this.pantPatternFormControls, [
      'stripedColourSelect',
    ]);
  }

  /**
   * This method is used to change the strip colour
   * @param {*} event
   */
  onChangeStripedColour(event: any) {
    let stripedColorValue = event?.target ? event?.target.value : event;
    this.selectedStripedColour = this.masterColoursList.filter(
      (item: any) => +item.colourId === +stripedColorValue
    )[0];
  }

  /**
   * This method is used to change the pocket radio
   * @param {*} event
   */
  onChangePocketRadio(event: any) {
    let pocketRadioValue = event?.target ? event?.target.value : event;
    this.selectedPocketRadio = +pocketRadioValue;
    if (this.selectedPocketRadio === 1) {
      if (event?.target) {
        this.getPocketTypesList('');
      } else {
        this.getPocketTypesList('noEvent');
      }
      this.onAddValidators(this.pantPatternFormControls, ['pocketTypeSelect']);
    } else {
      this.onRemoveValidators(this.pantPatternFormControls, [
        'pocketTypeSelect',
      ]);
    }
    if (event?.target) {
      this.selectedPocketType = '';
      this.onUpdateValueAndValidity(this.pantPatternFormControls, [
        'pocketTypeSelect',
      ]);
    }
  }

  /**
   * This method is used to change the pocket type
   * @param {*} event
   */
  onChangePocketType(event: any) {
    let pocketTypeValue = event?.target ? event?.target.value : event;
    this.selectedPocketType = this.pocketTypesList.filter(
      (item: any) => +item.pocketTypeId === +pocketTypeValue
    )[0];
  }

  /**
   * This method is used to change the body
   * @param {*} event
   */
  onChangeBody(event: any) {
    this.selectedBody = this.masterColoursList?.filter(
      (item: any) => +item.colourId === +event.target.value
    )[0];
  }

  /**
   * This method is used to change the Panel
   * @param {*} event
   */
  onChangePanel(event: any) {
    this.selectedPanel = this.masterColoursList?.filter(
      (item: any) => +item.colourId === +event.target.value
    )[0];
  }

  /**
   * This method is used to add the body panels
   */
  onClickAddBodyPanel() {
    this.onAddValidators(this.pantPatternFormControls, [
      'bodySelect',
      'panelSelect',
    ]);
    const body = this.selectedBody;
    const panel = this.selectedPanel;

    if (!body || !panel) {
      this.pantPatternFormControls['bodySelect'].markAsTouched({
        onlySelf: true,
      });
      this.pantPatternFormControls['panelSelect'].markAsTouched({
        onlySelf: true,
      });
      return;
    }

    const existingRecord = this.panelColoursList.find((item) => {
      return (
        item.body?.colourName === body?.colourName &&
        item.panel?.colourName === panel?.colourName
      );
    });

    if (existingRecord) {
      this.showSnackbar('Record Already Exists', '', false, true);
      return;
    }

    /* Prepare the panel colour item object */
    const obj: any = {
      id: this.panelColoursList.length > 0 ? this.panelColoursList.length : 0,
      body: body,
      panel: panel,
    };

    /* Push the panel colour item */
    this.panelColoursList.push(obj);
    this.selectedBody = '';
    this.selectedPanel = '';
    this.onRemoveValidators(this.pantPatternFormControls, [
      'bodySelect',
      'panelSelect',
    ]);
    this.onUpdateValueAndValidity(this.pantPatternFormControls, [
      'bodySelect',
      'panelSelect',
    ]);
  }

  /**
   * This method is used to delete the panel colour item
   * @param {*} panelColour
   */
  onClickDeletePanelColourItem(panelColour: any) {
    this.panelColoursList = this.panelColoursList.filter(
      (item: any) => item.id !== panelColour.id
    );
  }

  /**
   * This method is used to show the snackbar
   * @param {string} message
   * @param {*} orderId
   * @param {boolean} successFlag
   * @param {boolean} isModalOverlay
   */
  showSnackbar(
    message: string,
    orderId: any,
    successFlag: boolean,
    isModalOverlay: boolean
  ) {
    const snackbar = document.getElementById('pantSnackbar') as HTMLElement;
    this.innerHTMLMessage = message;
    this.innerHTMLOrderId = orderId;
    this.isSuccessSnackbar = successFlag;
    this.isOverlayVisible = isModalOverlay;
    snackbar.style.display = 'block';
  }

  /**
   * This method is used to hide the snackbar
   */
  onClickSnackbarOkButton() {
    const snackbar = document.getElementById('pantSnackbar') as HTMLElement;
    snackbar.style.display = 'none';
    this.innerHTMLOrderId = '';
    this.innerHTMLMessage = '';
    this.isOverlayVisible = false;
    this.isSuccessSnackbar = false;
  }

  /**
   * This method is used to reset the selected color fields
   */
  onResetSpecialColorFields() {
    this.selectedBody = '';
    this.selectedPanel = '';
    this.onRemoveValidators(this.pantPatternFormControls, [
      'bodySelect',
      'panelSelect',
    ]);
    this.onUpdateValueAndValidity(this.pantPatternFormControls, [
      'bodySelect',
      'panelSelect',
    ]);
  }

  /**
   * This method is used to save the special model items
   */
  onClickSaveSpecialModelItems() {
    this.onResetSpecialColorFields();
    if (this.pantPatternForm.invalid) {
      /** This will return false if form fields are invalid and return */
      this.validationService.validateAllFormFields(this.pantPatternForm);
      return;
    }

    /* Prepare Special Model For TShirt Panel Colors Array */
    const panelColors = [];
    for (let index = 0; index < this.panelColoursList?.length; index++) {
      const element = this.panelColoursList[index];
      panelColors.push({
        bodyColorId: +element.body.colourId,
        panelColorId: +element.panel.colourId,
        patternId: +this.selectedPantPattern?.patternTypeId,
      });
    }

    /* Prepare the pant pattern object */
    const patternForPantObj = {
      dressItemId: +this.selectedDressItem?.dressItemId,
      patternId: +this.selectedPantPattern?.patternTypeId,
      modelId:
        this.selectedPantPattern?.patternType === 'Special'
          ? +this.selectedModelNo?.modelId
          : 0,
      bodyColorId:
        this.selectedPantPattern?.patternType === 'Normal'
          ? +this.selectedNormalBody?.colourId
          : 0,
      isPiping: this.selectedPipingRadio === 1,
      pipingColorid:
        this.selectedPipingRadio === 1
          ? +this.selectedPipingColour?.colourId
          : 0,
      isStripes:
        this.selectedPantPattern?.patternType === 'Special'
          ? this.selectedStripedRadio === 1
          : false,
      stripesCount:
        this.selectedPantPattern?.patternType === 'Special' &&
        this.selectedStripedRadio === 1
          ? +this.selectedStripedCount?.id
          : 0,
      isStripesColor:
        this.selectedPantPattern?.patternType === 'Special' &&
        this.selectedStripedRadio === 1 &&
        this.selectedStripedColourRadio === 1,
      stripesColorID:
        this.selectedPantPattern?.patternType === 'Special' &&
        this.selectedStripedRadio === 1 &&
        this.selectedStripedColourRadio === 1
          ? +this.selectedStripedColour?.colourId
          : 0,
      isPocket: this.selectedPocketRadio === 1,
      pocketId:
        this.selectedPocketRadio === 1
          ? +this.selectedPocketType?.pocketTypeId
          : 0,
      isPocketColor: false,
      pocketColorId: 0,
      isInnerRope: this.selectedInnerRopeRadio === 1,
      zipId:
        this.selectedPantPattern?.patternType === 'Special' &&
        this.selectedZipRadio === 1
          ? +this.selectedZipType?.pocketTypeId
          : 0,
      backPocketId:
        this.selectedPantPattern?.patternType === 'Special' &&
        this.selectedBackPocketRadio === 1
          ? +this.selectedBackPocketType?.pocketTypeId
          : 0,
      panelColors: panelColors?.length > 0 ? panelColors : [],
    };

    localStorage.setItem(
      'pantPatternPanelColoursList',
      JSON.stringify(this.panelColoursList)
    );

    /* Prepare the pant pattern obj */
    const obj = {
      patternforPant: patternForPantObj,
    };

    console.log(obj);

    this.orderService.orderPatternDetailsObj.next(obj);
    document.getElementById('closePantModal')?.click();
  }
}
