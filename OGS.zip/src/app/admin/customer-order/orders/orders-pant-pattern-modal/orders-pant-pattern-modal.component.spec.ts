import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OrdersPantPatternModalComponent } from './orders-pant-pattern-modal.component';

describe('OrdersPantPatternModalComponent', () => {
  let component: OrdersPantPatternModalComponent;
  let fixture: ComponentFixture<OrdersPantPatternModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [OrdersPantPatternModalComponent]
    })
      .compileComponents();

    fixture = TestBed.createComponent(OrdersPantPatternModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
