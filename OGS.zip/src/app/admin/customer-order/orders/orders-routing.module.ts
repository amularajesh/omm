import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AddOrdersComponent } from './add-orders/add-orders.component';
import { EditOrdersComponent } from './edit-orders/edit-orders.component';
import { OrderLayoutComponent } from './order-layout/order-layout.component';
import { OrdersListComponent } from './orders-list/orders-list.component';
import { OrdersComponent } from './orders.component';
import { ProformaInvoiceComponent } from './proforma-invoice/proforma-invoice.component';

const routes: Routes = [
  {
    path: '',
    component: OrdersComponent,
    children: [
      { path: '', redirectTo: "orderList", pathMatch: 'full' },
      { path: 'orderList', component: OrdersListComponent },
      { path: 'addOrder', component: AddOrdersComponent },
      { path: 'editOrder', component: EditOrdersComponent },
      { path: 'orderlayout', component: OrderLayoutComponent },
      { path: 'proformainvoice', component: ProformaInvoiceComponent }
    ]
  }
];

/**
 * Orders Routing Module
 * @export
 * @class OrdersRoutingModule
 */
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class OrdersRoutingModule { }
