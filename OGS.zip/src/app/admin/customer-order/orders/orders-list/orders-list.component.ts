import { Location } from "@angular/common";
import { Component, OnInit, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";

import { SnackbarModalComponent } from "src/app/core/Dialogues/snackbar-modal/snackbar-modal.component";
import { CustomersService } from "src/app/core/Services/customers.service";
import { MastersService } from "src/app/core/Services/masters.service";
import { OrderService } from "src/app/core/Services/order.service";
import { ValidationService } from "src/app/core/Services/validation.service";

/**
 * Orders List Component
 * @export
 * @class OrdersListComponent
 * @implements {OnInit}
 */
@Component({
  selector: 'app-orders-list',
  templateUrl: './orders-list.component.html',
  styleUrls: ['./orders-list.component.scss']
})
export class OrdersListComponent implements OnInit {
  /**
   * Get Snackbar Modal Component
   * @type {SnackbarModalComponent}
   */
  @ViewChild("snackbarModalComponent") snackbarModalComponent!: SnackbarModalComponent;

  /**
   * Get Is Admin Or Manager Flag
   */
  isAdminOrManager = false;

  /**
   * Get Is Admin Flag
   */
  isAdmin = false;

  /**
   * Get orders List
   * @type {*}
   */
  ordersList: any;

  /**
   * Get financial years List
   * @type {*}
   */
  financialYearsList: any;

  /**
   * Get States List
   * @type {*}
   */
  statesList: any;

  /**
   * Get Districts List
   * @type {*}
   */
  districtsList: any;

  /**
   * Get Mandals List
   * @type {*}
   */
  mandalsList: any;

  /**
   * Get Towns List
   * @type {*}
   */
  townsList: any;

  /**
   * Get Dress Items List
   * @type {*}
   */
  dressItemsList: any;

  /**
   * Declare Sorting Order Flag
   */
  sortingOrder = false;

  /**
   * Declare Sorting Key Column
   */
  sortingKeyColumn = "orderNo";

  /**
   * Records Count
   */
  recordsCount = 0;

  /**
   * Default Page Number
   */
  currentPage = 1;

  /**
   * Search Term
   */
  searchTerm = "";

  /**
   * Create Search Order Form Declaration
   * @type {FormGroup}
   */
  searchOrdersForm!: FormGroup;

  /**
   * Get search orders Validations
   */
  searchOrdersValidation = this.validationService.searchOrders;

  /**
   * Get Location Validations
   */
  locationValidation = this.validationService.locationSelect;

  /**
   * Get Patterns
   * @private
   */
  private patterns = this.validationService.patterns;

  /**
   * Creates an instance of OrdersListComponent.
   * @param {Router} router
   * @param {ValidationService} validationService
   * @param {FormBuilder} formBuilder
   * @param {CustomersService} customerService
   * @param {MastersService} mastersService
   * @param {OrderService} orderService
   * @param {Location} location
   */
  constructor(
    private router: Router,
    private validationService: ValidationService,
    private formBuilder: FormBuilder,
    private customerService: CustomersService,
    private mastersService: MastersService,
    private orderService: OrderService,
    private location: Location
  ) {
    if (localStorage.getItem('userTypeId') == '1') {
      this.isAdmin = true;
    }
    if (localStorage.getItem('userTypeId') == '1' || localStorage.getItem('userTypeId') == '4') {
      this.isAdminOrManager = true;
    }
  }

  /**
   * Life Cycle Hook Initialization
   */
  ngOnInit(): void {
    this.searchOrdersFormValidations();
    this.getFinancialYears();
    this.getDressItemList();
    this.getTowns();
    this.getStates();
  }

  /**
   * Create Orders Search Form Controls Initialized
   * @readonly
   */
  get ordersSearchFormControls() {
    return this.searchOrdersForm.controls;
  }

  /**
   * Initialize search orders Form Validations
   */
  searchOrdersFormValidations() {
    this.searchOrdersForm = this.formBuilder.group({
      financialYear: ["", [Validators.required]],
      stateSelect: [""],
      districtSelect: [""],
      mandalSelect: [""],
      townSelect: ["",],
      dressItemSelect: [""],
      orderNumber: [
        '',
        [

          Validators.minLength(this.searchOrdersValidation.orderNumber.minLength),
          Validators.maxLength(this.searchOrdersValidation.orderNumber.maxLength),
          Validators.pattern(this.patterns.number)
        ]
      ],
      mobileNo: [
        "",
        [
          Validators.minLength(this.searchOrdersValidation.mobileNo.minLength),
          Validators.maxLength(this.searchOrdersValidation.mobileNo.maxLength),
          Validators.pattern(this.patterns.mobileNo)
        ]
      ],
      organizationType: ['1'],
      approved: ['0']
    });

    if (!this.isAdmin) {
      this.ordersSearchFormControls['approved'].disable({ onlySelf: true });
    }
  }

  /**
   * This method used to reset search orders form
   */
  onResetSearchOrdersForm() {
    this.searchOrdersForm.reset();
    this.districtsList = [];
    this.mandalsList = [];
    this.getTowns();
    this.searchOrdersFormValidations();
  }

  /**
   * This method is used to update value and validity
   * @param {*} formControls
   */
  onUpdateValueAndValidity(formControls: any, controls: any) {
    controls?.forEach((control: any) => {
      formControls[control].setValue("");
      formControls[control].markAsUntouched({ onlySelf: true });
      formControls[control].updateValueAndValidity({ onlySelf: true });
    });
  }

  /**
   * This method is used to get the order List
   * @param {*} initialFlag
   */
  getOrdersList(initialFlag: any) {
    const currentDate = new Date();
    const currentMonth = currentDate.getMonth(); // Month is zero-based
    let currentYear;
    if (currentMonth <= 2) { // January (0) and February (1)
      currentYear = currentDate.getFullYear() - 1;
    } else {
      currentYear = currentDate.getFullYear();
    }

    /* Prepare the request payload */
    const obj = {
      financialYear: initialFlag ? currentYear?.toString() : this.ordersSearchFormControls['financialYear'].value,
      stateId: +this.ordersSearchFormControls['stateSelect'].value,
      districtId: +this.ordersSearchFormControls['districtSelect'].value,
      mandalId: +this.ordersSearchFormControls['mandalSelect'].value,
      townId: +this.ordersSearchFormControls['townSelect'].value,
      dressItemId: +this.ordersSearchFormControls['dressItemSelect'].value,
      orderNo: this.ordersSearchFormControls['orderNumber'].value,
      phoneNo: this.ordersSearchFormControls['mobileNo'].value,
      approved: this.ordersSearchFormControls['approved'].value,
      financialYearStartDate: "2023-12-06T05:10:30.895Z",
      financialYearEndDate: "2023-12-06T05:10:30.895Z",
      organizationId: +this.ordersSearchFormControls['organizationType'].value,
      schoolId: 0,
      orderId: 0
    }

    this.orderService.getOrders(obj).subscribe({
      next: (res: any) => {
        this.ordersList = res.result;
        this.recordsCount = this.ordersList.length;
        this.currentPage = 1;
      },
      error: (err: any) => {
        this.ordersList = [];
        this.recordsCount = 0;
        this.currentPage = 1;
      }
    });
  }

  /**
   * This method is used to get the financial years List
   */
  getFinancialYears() {
    this.customerService.GetFinancialYears().subscribe({
      next: (res: any) => {
        this.financialYearsList = res.result;
        this.getOrdersList("initial");
        let currentDate = new Date();
        let currentMonth = currentDate.getMonth(); // Month is zero-based
        let currentYear;
        if (currentMonth <= 2) { // January (0) and February (1)
          currentYear = currentDate.getFullYear() - 1;
        } else {
          currentYear = currentDate.getFullYear();
        }
        this.ordersSearchFormControls['financialYear'].setValue(currentYear.toString());
        this.onChangeFinancialYear(currentYear);
      },
      error: (err: any) => {
        this.financialYearsList = [];
      }
    });
  }

  /**
   * This method is used to get dress items list
   */
  getDressItemList() {
    this.mastersService.getDressItems().subscribe({
      next: (res: any) => {
        this.dressItemsList = res.result;
      },
      error: (err: any) => {
        this.dressItemsList = [];
      }
    });
  }

  /**
   * This method is used to get the states List
   */
  getStates() {
    this.mastersService.getStates().subscribe({
      next: (res: any) => {
        this.statesList = res.result;
      },
      error: (err: any) => {
        this.statesList = [];
      }
    });
  }

  /**
   * This method is used to get the towns List
   */
  getTowns() {
    this.mastersService.getTowns().subscribe({
      next: (res: any) => {
        this.townsList = res.result;
      },
      error: (err: any) => {
        this.townsList = [];
      },
    });
  }

  /**
   * This method will fired when user selects financial year
   * @param {*} event
   */
  onChangeFinancialYear(event: any) {
    if (event?.target?.value == '') {
      this.ordersSearchFormControls["financialYear"].markAsUntouched({ onlySelf: true });
    }
  }

  /**
   * This method will fired when user selects the state
   * @param {*} event
   */
  onChangeState(event: any) {
    this.onUpdateValueAndValidity(this.ordersSearchFormControls, ['districtSelect', 'mandalSelect', 'townSelect']);
    this.districtsList = [];
    this.mandalsList = [];
    this.townsList = [];

    if (event?.target?.value == '') {
      this.ordersSearchFormControls["stateSelect"].markAsUntouched({ onlySelf: true });
      return;
    }

    /* To call the service to get the districts list by passing stateId */
    this.mastersService.getDistrictsByStateId(event?.target?.value?.toString()).subscribe({
      next: (res: any) => {
        this.districtsList = res.result;
      },
      error: () => {
        this.districtsList = [];
      }
    });
  }

  /**
   * This method will fired when user selects the district
   * @param {*} event
   */
  onChangeDistrict(event: any) {
    this.onUpdateValueAndValidity(this.ordersSearchFormControls, ['mandalSelect', 'townSelect']);
    this.mandalsList = [];
    this.townsList = [];

    if (event.target?.value == '') {
      this.ordersSearchFormControls["districtSelect"].markAsUntouched({ onlySelf: true });
      return;
    }

    /* To call the service to get the mandals list by passing districtId */
    this.mastersService.getMandalsByDistrictId(event?.target?.value?.toString()).subscribe({
      next: (res: any) => {
        this.mandalsList = res.result;
      },
      error: () => {
        this.mandalsList = [];
      }
    });
  }

  /**
   * This method will fired when user selects the mandal
   * @param {*} event
   */
  onChangeMandal(event: any) {
    this.onUpdateValueAndValidity(this.ordersSearchFormControls, ['townSelect']);
    this.townsList = [];

    if (event.target?.value == '') {
      this.ordersSearchFormControls["mandalSelect"].markAsUntouched({ onlySelf: true });
      return;
    }

    /* To call the service to get the towns list by passing mandalId */
    this.mastersService.getTownsByMandalId(event.target?.value?.toString()).subscribe({
      next: (res: any) => {
        this.townsList = res.result;
      },
      error: () => {
        this.townsList = [];
      }
    });
  }

  /**
   * This method is used to change the pagination controls
   * @param {*} event
   */
  onPageChange(event: any) {
    this.currentPage = event;
  }

  /**
   * This method is used to show search results
   */
  navigateToSearchResult() {
    this.currentPage = 1;
  }

  /**
   * This method is used to sort column
   * @param key : value of which column based we need to sort the rows
   */
  sort(key: string) {
    const componentName = this.location.path();
    let value = key;
    sessionStorage.setItem(`${componentName}_property`, value);
    this.sortingKeyColumn = key;

    if (sessionStorage.getItem(componentName + "_order") == "desc") {
      this.sortingOrder = false;
    } else {
      this.sortingOrder = true;
    }
  }

  /**
   * This method is used to submit the search orders form
   */
  onSearchOrdersFormSubmit() {
    /** This will return false if form fields are invalid and stop the service calling */
    if (this.searchOrdersForm.invalid) {
      this.validationService.validateAllFormFields(this.searchOrdersForm);
      return;
    }
    this.getOrdersList("")
  }

  /**
   * This method is used for navigate to create order page when user clicked on add order
   */
  onClickCreateOrder() {
    this.router.navigate(["/admin/customer-order/order/addOrder"]);
  }

  /**
   * This method is used for navigate to edit order page when user clicked on edit
   * @param {*} order
   */
  onClickEditOrder(order: any) {
    this.orderService.getOrderById(order?.orderId).subscribe({
      next: (res: any) => {
        this.orderService.editOrderDetails.next(res.result);
        this.router.navigate(["/admin/customer-order/order/editOrder"]);
      },
      error: (err: any) => {
        this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message || err, '', '', '');
      }
    });
  }

  /**
   * This method is used for navigate to add order page when user clicked on copy order
   * @param {*} order
   */
  onClickCopyOrder(order: any) {
    /* To call the service to get the order details by passing order id */
    this.orderService.getOrderById(order?.orderId).subscribe({
      next: (res: any) => {
        this.orderService.copyOrderDetails.next(res?.result);
        this.router.navigate(["/admin/customer-order/order/addOrder"]);
      },
      error: (err: any) => {
        this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message || err, '', '', '');
      }
    });
  }

  /**
   * This method is used to navigate to order Layout
   * @param {*} order
   */
  onNavigateToOrderLayout(order: any) {
    /* To call the service to get the order layout details by passing order id */
    this.customerService.getStitchingDcById(order?.orderId).subscribe({
      next: (res: any) => {
        this.orderService.orderLayoutDetails.next(res.result);
        this.router.navigate(['/admin/customer-order/order/orderlayout']);
      },
      error: (err: any) => {
        this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message || err, '', '', '');
      }
    });
  }

  /**
   * This method is used to navigate to proforma Invoice
   * @param {*} order
   */
  onNavigateToProformaInvoice(order: any) {
    /* To call the service to get the order layout details by passing order id */
    this.orderService.getProformaDetailsById(order?.orderId).subscribe({
      next: (res: any) => {
        this.orderService.orderProformaDetails.next(res.result);
        this.router.navigate(['/admin/customer-order/order/proformainvoice']);
      },
      error: (err: any) => {
        this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message || err, '', '', '');
      }
    });
  }
}
