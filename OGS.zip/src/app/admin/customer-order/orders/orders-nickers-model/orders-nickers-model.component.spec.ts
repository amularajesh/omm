import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OrdersNickersModelComponent } from './orders-nickers-model.component';

describe('OrdersNickersModelComponent', () => {
  let component: OrdersNickersModelComponent;
  let fixture: ComponentFixture<OrdersNickersModelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OrdersNickersModelComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(OrdersNickersModelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
