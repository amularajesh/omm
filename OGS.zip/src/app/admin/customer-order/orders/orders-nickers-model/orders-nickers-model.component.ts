import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { MasterColourItems, PanelColoursItems, StripePipingItems } from 'src/app/core/Modals/modals';
import { ChargesService } from 'src/app/core/Services/charges.service';
import { MastersService } from 'src/app/core/Services/masters.service';
import { OrderService } from 'src/app/core/Services/order.service';
import { SampleOrderService } from 'src/app/core/Services/sample-order.service';
import { ValidationService } from 'src/app/core/Services/validation.service';

/**
 * Orders Nickers Model Component
 * @export
 * @class OrdersNickersModelComponent
 * @implements {OnInit}
 */
@Component({
  selector: 'app-orders-nickers-model',
  templateUrl: './orders-nickers-model.component.html',
  styleUrls: ['./orders-nickers-model.component.scss']
})
export class OrdersNickersModelComponent implements OnInit {
  /**
    * Declare Nickers Pattern Form
    * @type {FormGroup}
    */
  nickersPatternForm!: FormGroup;

  /**
   * Get Master Colours List
   * @type {MasterColourItems[]}
   */
  masterColoursList: MasterColourItems[] = [];

  /**
   * Get Panel Colours List
   * @type {PanelColoursItems[]}
   */
  panelColoursList: PanelColoursItems[] = [];

  /**
   * Get Striped Count List
   * @type {StripePipingItems[]}
   */
  stripedCountList: StripePipingItems[] = [];

  /**
   * Get Model No. List
   */
  modelNoList: any;

  /**
   * Get Selected Panel
   * @type {*}
   */
  selectedPanel: any;

  /**
   * Get Selected Body
   * @type {*}
   */
  selectedBody: any;

  /**
   * Get Selected Normal Body
   * @type {*}
   */
  selectedNormalBody: any;

  /**
   * Get Selected Model No.
   * @type {*}
   */
  selectedModelNo: any;

  /**
   * Get Selected Piping Colour
   * @type {*}
   */
  selectedPipingColour: any;

  /**
   * Get Selected Piping Radio
   */
  selectedPipingRadio = 0;

  /**
   * Get Selected Inner rope Radio
   */
  selectedInnerRopeRadio = 0;

  /**
   * Get Selected pocket Radio
   */
  selectedPocketRadio = 0;

  /**
   * Get Selected Striped type
   * @type {*}
   */
  selectedStripedCount: any;

  /**
   * Get Selected pocket type
   */
  selectedPocketType: any;

  /**
   * Get Selected Striped Colour
   * @type {*}
   */
  selectedStripedColour: any;

  /**
   * Get Selected stript Radio
   */
  selectedStripedRadio = 0;

  /**
   * Get Selected strip colour Radio
   */
  selectedStripedColourRadio = 0;

  /**
   * Get Selected Nicker Pattern
   * @type {*}
   */
  selectedNickerPattern: any;

  /**
   * Get Selected Dress Item
   * @type {*}
   */
  selectedDressItem: any;

  /**
   * Get Pocket Types List
   */
  pocketTypesList: any;

  /**
   * Get Saved Nicker Pattern Details
   * @type {*}
   */
  savedNickerPatternDetails: any;

  /**
   * Get Is Success Snackbar Flag
   */
  isSuccessSnackbar = false;

  /**
   * Get Is Overlay Visible Flag
   */
  isOverlayVisible = false;

  /**
   * Get Inner HTML Message
   */
  innerHTMLMessage = '';

  /**
   * Get Inner HTML Order Id
   */
  innerHTMLOrderId = '';

  /**
   * Get nicker Patterns Form Validations
   */
  nickerPatternFormValidation = this.validationService.nickersPattern;

  /**
   * Creates an instance of NickersModelComponent.
   * @param {ValidationService} validationService
   * @param {FormBuilder} formBuilder
   * @param {ChargesService} chargesService
   * @param {MastersService} masterService
   * @param {SampleOrderService} sampleOrderService
   */
  constructor(
    private validationService: ValidationService,
    private formBuilder: FormBuilder,
    private chargesService: ChargesService,
    private masterService: MastersService,
    private sampleOrderService: SampleOrderService,
    private orderService: OrderService,
  ) {
    /* Get Pattern Details from behavior subject */
    this.orderService.orderPatternDetailsObj.subscribe((val: any) => {
      if (Object.keys(val).length > 0) {
        this.savedNickerPatternDetails = val?.patternforPant;
      } else {
        this.savedNickerPatternDetails = "";
      }
    });
  }

  /**
   * Life Cycle Hook Initialization
   */
  ngOnInit(): void {
    this.nickersPatternFormValidations();
  }

  /**
   * Initialize Nickers Pattern Form Validations
   */
  nickersPatternFormValidations() {
    let modelNoSelectValue = "";
    let normalBodySelectValue = "";
    let pipingRadioValue = "0";
    let innerRopeRadioValue = "0";
    let stripedRadioValue = "0";
    let stripedColourRadioValue = "0";
    let pocketRadioValue = "0";
    let pipingColourSelectValue = "";
    let stripedCountSelectValue = "";
    let stripedColourSelectValue = "";
    let pocketTypeSelectValue = "";

    if (this.savedNickerPatternDetails) {
      pipingRadioValue = this.savedNickerPatternDetails?.isPiping ? "1" : "0";
      this.onChangePipingRadio(pipingRadioValue);
      if (this.selectedPipingRadio === 1) {
        pipingColourSelectValue = this.savedNickerPatternDetails?.pipingColorid;
        this.onChangePipingColour(pipingColourSelectValue);
      }
      pocketRadioValue = this.savedNickerPatternDetails?.isPocket ? "1" : "0";
      this.onChangePocketRadio(pocketRadioValue);
      if (this.selectedPocketRadio === 1) {
        pocketTypeSelectValue = this.savedNickerPatternDetails?.pocketId;
        this.onChangePocketType(pocketTypeSelectValue);
      }
      innerRopeRadioValue = this.savedNickerPatternDetails?.isInnerRope
        ? "1"
        : "0";
      this.onChangeInnerRopeRadio(innerRopeRadioValue);
      if (this.selectedNickerPattern?.patternType === "Special") {
        modelNoSelectValue = this.savedNickerPatternDetails?.modelId;
        this.onChangeModelNo(modelNoSelectValue);
        stripedRadioValue = this.savedNickerPatternDetails?.isStripes
          ? "1"
          : "0";
        this.onChangeStripedRadio(stripedRadioValue);
        if (this.selectedStripedRadio === 1) {
          stripedCountSelectValue = this.savedNickerPatternDetails
            ?.stripesCount;
          this.onChangeStripedCount(stripedCountSelectValue);
          stripedColourRadioValue = this.savedNickerPatternDetails
            ?.isStripesColor
            ? "1"
            : "0";
          this.onChangeStripedColourRadio(stripedColourRadioValue);
          if (this.selectedStripedColourRadio === 1) {
            stripedColourSelectValue = this.savedNickerPatternDetails
              ?.stripesColorID;
            this.onChangeStripedColour(stripedColourSelectValue);
          }
        }
        this.panelColoursList = JSON.parse(
          localStorage.getItem("nickerPatternPanelColours")!
        ) || [];
      } else {
        normalBodySelectValue = this.savedNickerPatternDetails?.bodyColorId;
        this.onChangeNormalBodySelect(normalBodySelectValue);
      }
    } else {
      this.onResetNickerPatternForm();
    }

    this.nickersPatternForm = this.formBuilder.group({
      pattern: [
        this.selectedNickerPattern?.patternType || "",
        [Validators.required],
      ],
      dressItem: [
        this.selectedDressItem?.dressItemName || "",
        [Validators.required],
      ],
      modelNoSelect: [modelNoSelectValue],
      patternBodySelect: [normalBodySelectValue],
      pipingRadio: [pipingRadioValue],
      pipingColourSelect: [pipingColourSelectValue],
      stripedRadio: [stripedRadioValue],
      stripedCountSelect: [stripedCountSelectValue],
      stripedColourRadio: [stripedColourRadioValue],
      stripedColourSelect: [stripedColourSelectValue],
      pocketRadio: [pocketRadioValue],
      pocketTypeSelect: [pocketTypeSelectValue],
      innerRopeRadio: [innerRopeRadioValue],
      bodySelect: [""],
      panelSelect: [""],
    });

    setTimeout(() => {
      if (this.savedNickerPatternDetails) {
        console.log(this.savedNickerPatternDetails);

        if (this.selectedNickerPattern?.patternType === "Special") {
          if (this.savedNickerPatternDetails?.modelId) {
            this.nickersPatternFormControls["modelNoSelect"].setValue(
              this.savedNickerPatternDetails?.modelId.toString()
            );
          }

          if (this.selectedPipingRadio === 1) {
            pipingColourSelectValue = this.savedNickerPatternDetails
              ?.pipingColorid;
            this.nickersPatternFormControls["pipingColourSelect"].setValue(
              pipingColourSelectValue?.toString()
            );
            this.onChangePipingColour(pipingColourSelectValue);
          }

          if (this.selectedStripedRadio === 1) {
            stripedCountSelectValue = this.savedNickerPatternDetails
              ?.stripesCount;

            this.nickersPatternFormControls["stripedCountSelect"].setValue(
              stripedCountSelectValue?.toString()
            );
            this.onChangeStripedCount(stripedCountSelectValue);
          }

          if (this.selectedStripedColourRadio === 1) {
            stripedColourSelectValue = this.savedNickerPatternDetails
              ?.stripesColorID;
            this.nickersPatternFormControls["stripedColourSelect"].setValue(
              stripedColourSelectValue?.toString()
            );
            this.onChangeStripedColour(stripedColourSelectValue);
          }
          if (this.selectedPocketRadio === 1) {
            pocketTypeSelectValue = this.savedNickerPatternDetails?.pocketId;
            this.nickersPatternFormControls["pocketTypeSelect"].setValue(
              pocketTypeSelectValue?.toString()
            );
            this.onChangePocketType(pocketTypeSelectValue);
          }

          const responsePanelColorsItems = this.savedNickerPatternDetails?.panelColors?.map(
            (responseData: any, index: any) => {
              const bodyColour = this.masterColoursList?.find(
                (element: any) =>
                  +responseData?.bodyColorId === +element?.colourId
              );
              const panelColour = this.masterColoursList?.find(
                (element: any) =>
                  +responseData?.panelColorId === +element?.colourId
              );
              return {
                id: index,
                body: bodyColour,
                panel: panelColour,
              };
            }
          );

          if (responsePanelColorsItems?.length > 0) {
            localStorage.setItem(
              "nickerPatternPanelColours",
              JSON.stringify(responsePanelColorsItems)
            );
            this.panelColoursList = responsePanelColorsItems || [];
          } else {
            this.panelColoursList =
              JSON.parse(localStorage.getItem("nickerPatternPanelColours")!) ||
              [];
          }
        } else {
          normalBodySelectValue = this.savedNickerPatternDetails?.bodyColorId;
          this.nickersPatternFormControls["patternBodySelect"].setValue(
            normalBodySelectValue?.toString()
          );
          this.onChangeNormalBodySelect(normalBodySelectValue);
          if (this.selectedPipingRadio === 1) {
            pipingColourSelectValue = this.savedNickerPatternDetails
              ?.pipingColorid;
            this.nickersPatternFormControls["pipingColourSelect"].setValue(
              pipingColourSelectValue?.toString()
            );
            this.onChangePipingColour(pipingColourSelectValue);
          }
          if (this.selectedPocketRadio === 1) {
            pocketTypeSelectValue = this.savedNickerPatternDetails?.pocketId;
            this.nickersPatternFormControls["pocketTypeSelect"].setValue(
              pocketTypeSelectValue?.toString()
            );
            this.onChangePocketType(pocketTypeSelectValue);
          }
        }
      }
    }, 100);
  }

  /**
   * Get Nickers Pattern Form Controls
   * @readonly
   */
  get nickersPatternFormControls() {
    return this.nickersPatternForm.controls;
  }

  /**
   * This method is used to open the nicker Modal
   * @param {*} selectedPattern
   * @param {*} selectedDressItem
   */
  openModal(selectedPattern: any, selectedDressItem: any) {
    this.selectedNickerPattern = selectedPattern;
    this.selectedDressItem = selectedDressItem;
    this.nickersPatternFormValidations();
    this.getColoursList();
    document.getElementById("nickersModalButton")?.click();
    if (this.selectedNickerPattern?.patternType === "Special") {
      if (this.savedNickerPatternDetails) {
        this.getModelNoList("noEvent");
      } else {
        this.getModelNoList("");
      }
      this.onAddValidators(this.nickersPatternFormControls, ["modelNoSelect"]);
      this.onRemoveValidators(this.nickersPatternFormControls, [
        "patternBodySelect",
      ]);
    } else {
      this.onAddValidators(this.nickersPatternFormControls, [
        "patternBodySelect",
      ]);
      this.onRemoveValidators(this.nickersPatternFormControls, [
        "modelNoSelect",
      ]);
    }
    const modal = document.getElementById("nickersPattern") as HTMLElement;
    const snackbar = document.getElementById("nickerSnackbar") as HTMLElement;
    modal.style.display = "block";
    snackbar.style.zIndex = "9999";
  }

  /**
   * This method is used to get colours list
   */
  getColoursList() {
    this.masterService.getColours().subscribe({
      next: (res: any) => {
        this.masterColoursList = res.result;
      },
      error: (err: any) => {
        this.masterColoursList = [];
      },
    });
  }

  /**
   * This method is used to get the Model list
   */
  getModelNoList(eventFlag: any) {
    this.chargesService
      .getModelsByDressItemId(this.selectedDressItem?.dressItemId)
      .subscribe({
        next: (res: any) => {
          this.modelNoList = res.result;
        },
        error: (err: any) => {
          this.modelNoList = [];
        },
      });
  }

  /**
   * This method is used to get colours list
   */
  getPocketTypesList() {
    this.chargesService.getPocketTypesByDressItemId(this.selectedDressItem?.dressItemId).subscribe({
      next: (res: any) => {
        this.pocketTypesList = res.result;
      },
      error: (err: any) => {
        this.pocketTypesList = [];
      },
    });
  }

  /**
   * This method is used to get striped count list
   */
  getStripedCountList() {
    this.sampleOrderService.getStripedCount().subscribe({
      next: (res: any) => {
        this.stripedCountList = res.result;
      },
      error: (err: any) => {
        this.stripedCountList = [];
      },
    });
  }

  /**
   * This method is used to add validators
   * @param {*} formControls
   * @param {*} controls
   */
  onAddValidators(formControls: any, controls: any) {
    controls?.forEach((control: any) => {
      formControls[control].addValidators([Validators.required]);
      formControls[control].updateValueAndValidity({ onlySelf: true });
    });
  }

  /**
   * This method is used to remove validators
   * @param {*} formControls
   */
  onRemoveValidators(formControls: any, controls: any) {
    controls?.forEach((control: any) => {
      formControls[control].removeValidators([Validators.required]);
    });
  }

  /**
   * This method is used to update value and validity
   * @param {*} formControls
   */
  onUpdateValueAndValidity(formControls: any, controls: any) {
    controls?.forEach((control: any) => {
      formControls[control].setValue("");
      formControls[control].markAsUntouched({ onlySelf: true });
      formControls[control].updateValueAndValidity({ onlySelf: true });
    });
  }

  /**
   * This method is used to reset the nicker pattern form
   */
  onResetNickerPatternForm() {
    this.selectedPipingRadio = 0;
    this.selectedPocketRadio = 0;
    this.selectedStripedRadio = 0;
    this.selectedStripedColourRadio = 0;
    this.selectedInnerRopeRadio = 0;
    this.selectedModelNo = "";
    this.selectedNormalBody = "";
    this.selectedBody = "";
    this.selectedPanel = "";
    this.selectedPipingColour = "";
    this.selectedPocketType = "";
    this.selectedStripedColour = "";
    this.panelColoursList = [];
  }

  /**
   * This method is used to change the model no
   * @param {*} event
   */
  onChangeModelNo(event: any) {
    let modelNoValue = event?.target ? event?.target.value : event;
    this.selectedModelNo = this.modelNoList?.filter(
      (item: any) => +item.modelId === +modelNoValue
    )[0];
  }

  /**
   * This method is used to change the body
   * @param {*} event
   */
  onChangeNormalBodySelect(event: any) {
    let bodyValue = event?.target ? event?.target.value : event;
    this.selectedNormalBody = this.masterColoursList.filter(
      (item: any) => +item.colourId === +bodyValue
    )[0];
  }

  /**
   * This method is used to change the piping radio
   * @param {*} event
   */
  onChangePipingRadio(event: any) {
    let pipingRadioValue = event?.target ? event?.target.value : event;
    this.selectedPipingRadio = +pipingRadioValue;
    if (this.selectedPipingRadio === 1) {
      this.onAddValidators(this.nickersPatternFormControls, [
        "pipingColourSelect",
      ]);
    } else {
      this.onRemoveValidators(this.nickersPatternFormControls, [
        "pipingColourSelect",
      ]);
    }
    this.selectedPipingColour = "";
    this.onUpdateValueAndValidity(this.nickersPatternFormControls, [
      "pipingColourSelect",
    ]);
  }

  /**
   * This method is used to change the piping colour colour
   * @param {*} event
   */
  onChangePipingColour(event: any) {
    let pipingColorValue = event?.target ? event?.target.value : event;
    this.selectedPipingColour = this.masterColoursList.filter(
      (item: any) => +item.colourId === +pipingColorValue
    )[0];
  }

  /**
   * This method is used to change the inner rope radio
   * @param {*} event
   */
  onChangeInnerRopeRadio(event: any) {
    let innerRopeRadioValue = event?.target ? event?.target.value : event;
    this.selectedInnerRopeRadio = +innerRopeRadioValue;
  }

  /**
   * This method is used to change the Striped radio
   * @param {*} event
   */
  onChangeStripedRadio(event: any) {
    let stripedRadioValue = event?.target ? event?.target.value : event;
    this.selectedStripedRadio = +stripedRadioValue;
    if (this.selectedStripedRadio === 1) {
      this.onAddValidators(this.nickersPatternFormControls, [
        "stripedCountSelect",
      ]);
      this.getStripedCountList();
    } else {
      this.onRemoveValidators(this.nickersPatternFormControls, [
        "stripedCountSelect",
      ]);
      this.nickersPatternFormControls["stripedColourRadio"].setValue("0");
      this.selectedStripedColourRadio = 0;
    }
    this.selectedStripedCount = "";
    this.onUpdateValueAndValidity(this.nickersPatternFormControls, [
      "stripedCountSelect",
    ]);
  }

  /**
   * This method is used to change the strip count
   * @param {*} event
   */
  onChangeStripedCount(event: any) {
    let stripedCountValue = event?.target ? event?.target.value : event;
    this.selectedStripedCount = this.stripedCountList.filter(
      (item: any) => +item.id === +stripedCountValue
    )[0];
  }

  /**
   * This method is used to change the Striped colour radio
   * @param {*} event
   */
  onChangeStripedColourRadio(event: any) {
    let stripedColorRadioValue = event?.target ? event?.target.value : event;
    this.selectedStripedColourRadio = +stripedColorRadioValue;
    if (this.selectedStripedColourRadio === 1) {
      this.onAddValidators(this.nickersPatternFormControls, [
        "stripedColourSelect",
      ]);
    } else {
      this.onRemoveValidators(this.nickersPatternFormControls, [
        "stripedColourSelect",
      ]);
    }
    this.selectedStripedColour = "";
    this.onUpdateValueAndValidity(this.nickersPatternFormControls, [
      "stripedColourSelect",
    ]);
  }

  /**
   * This method is used to change the strip colour
   * @param {*} event
   */
  onChangeStripedColour(event: any) {
    let stripedColorValue = event?.target ? event?.target.value : event;
    this.selectedStripedColour = this.masterColoursList.filter(
      (item: any) => +item.colourId === +stripedColorValue
    )[0];
  }

  /**
   * This method is used to change the pocket radio
   * @param {*} event
   */
  onChangePocketRadio(event: any) {
    let pocketRadioValue = event?.target ? event?.target.value : event;
    this.selectedPocketRadio = +pocketRadioValue;
    if (this.selectedPocketRadio === 1) {
      this.onAddValidators(this.nickersPatternFormControls, [
        "pocketTypeSelect",
      ]);
      this.getPocketTypesList();
    } else {
      this.onRemoveValidators(this.nickersPatternFormControls, [
        "pocketTypeSelect",
      ]);
    }
    if (event?.target) {
      this.selectedPocketType = "";
      this.onUpdateValueAndValidity(this.nickersPatternFormControls, [
        "pocketTypeSelect",
      ]);
    }
  }

  /**
   * This method is used to change the pocket type
   * @param {*} event
   */
  onChangePocketType(event: any) {
    let pocketTypeValue = event?.target ? event?.target.value : event;
    this.selectedPocketType = this.pocketTypesList?.filter(
      (item: any) => +item.pocketTypeId === +pocketTypeValue
    )[0];
  }

  /**
   * This method is used to change the body
   * @param {*} event
   */
  onChangeBody(event: any) {
    this.selectedBody = this.masterColoursList?.filter(
      (item: any) => +item.colourId === +event.target.value
    )[0];
  }

  /**
   * This method is used to change the Panel
   * @param {*} event
   */
  onChangePanel(event: any) {
    this.selectedPanel = this.masterColoursList?.filter(
      (item: any) => +item.colourId === +event.target.value
    )[0];
  }

  /**
   * This method is used to add the body panels
   */
  onClickAddBodyPanel() {
    this.onAddValidators(this.nickersPatternFormControls, [
      "bodySelect",
      "panelSelect",
    ]);
    const body = this.selectedBody;
    const panel = this.selectedPanel;

    if (!body || !panel) {
      this.nickersPatternFormControls["bodySelect"].markAsTouched({
        onlySelf: true,
      });
      this.nickersPatternFormControls["panelSelect"].markAsTouched({
        onlySelf: true,
      });
      return;
    }

    const existingRecord = this.panelColoursList.find((item) => {
      return (
        item.body?.colourName === body?.colourName &&
        item.panel?.colourName === panel?.colourName
      );
    });

    if (existingRecord) {
      this.showSnackbar("Record Already Exists", '', false, true);
      return;
    }

    /* Prepare the panel colour item object */
    const obj: any = {
      id: this.panelColoursList.length > 0 ? this.panelColoursList.length : 0,
      body: body,
      panel: panel,
    };

    /* Push the panel colour item */
    this.panelColoursList.push(obj);
    this.selectedBody = "";
    this.selectedPanel = "";
    this.onRemoveValidators(this.nickersPatternFormControls, [
      "bodySelect",
      "panelSelect",
    ]);
    this.onUpdateValueAndValidity(this.nickersPatternFormControls, [
      "bodySelect",
      "panelSelect",
    ]);
  }

  /**
   * This method is used to delete the panel colour item
   * @param {*} panelColour
   */
  onClickDeletePanelColourItem(panelColour: any) {
    this.panelColoursList = this.panelColoursList.filter(
      (item: any) => item.id !== panelColour.id
    );
  }

  /**
   * This method is used to show the snackbar
   * @param {string} message
   * @param {*} orderId
   * @param {boolean} successFlag
   * @param {boolean} isModalOverlay
   */
  showSnackbar(message: string, orderId: any, successFlag: boolean, isModalOverlay: boolean) {
    const snackbar = document.getElementById("nickerSnackbar") as HTMLElement;
    this.innerHTMLMessage = message;
    this.innerHTMLOrderId = orderId;
    this.isSuccessSnackbar = successFlag;
    this.isOverlayVisible = isModalOverlay;
    snackbar.style.display = "block";
  }

  /**
   * This method is used to hide the snackbar
   */
  onClickSnackbarOkButton() {
    const snackbar = document.getElementById("nickerSnackbar") as HTMLElement;
    snackbar.style.display = "none";
    this.innerHTMLOrderId = '';
    this.innerHTMLMessage = '';
    this.isOverlayVisible = false;
    this.isSuccessSnackbar = false;
  }

  /**
   * This method is used to reset the selected color fields
   */
  onResetSpecialColorFields() {
    this.selectedBody = "";
    this.selectedPanel = "";
    this.onRemoveValidators(this.nickersPatternFormControls, [
      "bodySelect",
      "panelSelect",
    ]);
    this.onUpdateValueAndValidity(this.nickersPatternFormControls, [
      "bodySelect",
      "panelSelect",
    ]);
  }

  /**
   * This method is used to save the nicker pattern items
   */
  onClickSaveNickerPatternItems() {
    this.onResetSpecialColorFields();
    console.log(this.nickersPatternFormControls["pipingRadio"]?.value);
    console.log(this.nickersPatternFormControls["stripedRadio"]?.value);
    console.log(this.nickersPatternFormControls["innerRopeRadio"]?.value);
    console.log(this.nickersPatternFormControls["pocketRadio"]?.value);

    if (
      this.nickersPatternFormControls["pipingRadio"]?.value === "0" &&
      this.nickersPatternFormControls["stripedRadio"]?.value === "0" &&
      this.nickersPatternFormControls["innerRopeRadio"]?.value === "0" &&
      this.nickersPatternFormControls["pocketRadio"]?.value === "0"
    ) {
      console.log("yes");
    } else if (this.nickersPatternForm.invalid) {
      console.log(this.nickersPatternForm.invalid);

      /** This will return false if form fields are invalid and return */
      this.validationService.validateAllFormFields(this.nickersPatternForm);
      return;
    }

    /* Prepare Special Model For Nicker Panel Colors Array */
    const panelColors = [];
    for (let index = 0; index < this.panelColoursList?.length; index++) {
      const element = this.panelColoursList[index];
      panelColors.push({
        bodyColorId: +element.body.colourId,
        panelColorId: +element.panel.colourId,
        patternId: +this.selectedNickerPattern?.patternTypeId,
      });
    }
    console.log(+this.selectedDressItem?.dressItemId, "dressitemid");
    console.log(this.selectedModelNo, "modelNo");

    /* Prepare the nicker pattern object */
    const patternForNickerObj = {
      dressItemId: +this.selectedDressItem?.dressItemId,
      patternId: +this.selectedNickerPattern?.patternTypeId,
      modelId:
        this.selectedNickerPattern?.patternType === "Special"
          ? +this.selectedModelNo?.modelId
            ? +this.selectedModelNo?.modelId
            : +this.nickersPatternFormControls["modelNoSelect"]?.value
          : 0,
      bodyColorId:
        this.selectedNickerPattern?.patternType === "Normal"
          ? +this.selectedNormalBody?.colourId
          : 0,
      isPiping: this.selectedPipingRadio === 1,
      pipingColorid:
        this.selectedPipingRadio === 1
          ? +this.selectedPipingColour?.colourId
          : 0,
      isStripes:
        this.selectedNickerPattern?.patternType === "Special"
          ? this.selectedStripedRadio === 1
          : false,
      stripesCount:
        this.selectedNickerPattern?.patternType === "Special" &&
          this.selectedStripedRadio === 1
          ? +this.selectedStripedCount?.id
            ? +this.selectedStripedCount?.id
            : +this.nickersPatternFormControls["stripedCountSelect"]?.value
          : 0,
      isStripesColor:
        this.selectedNickerPattern?.patternType === "Special" &&
        this.selectedStripedRadio === 1 &&
        this.selectedStripedColourRadio === 1,
      stripesColorID:
        this.selectedNickerPattern?.patternType === "Special" &&
          this.selectedStripedRadio === 1 &&
          this.selectedStripedColourRadio === 1
          ? +this.selectedStripedColour?.colourId
            ? +this.selectedStripedColour?.colourId
            : +this.nickersPatternFormControls["stripedColourSelect"]?.value
          : 0,
      isPocket: this.selectedPocketRadio === 1,
      pocketId:
        this.selectedPocketRadio === 1
          ? +this.selectedPocketType?.pocketTypeId
            ? +this.selectedPocketType?.pocketTypeId
            : +this.nickersPatternFormControls["pocketTypeSelect"]?.value
          : 0,
      isPocketColor: false,
      pocketColorId: 0,
      isInnerRope: this.selectedInnerRopeRadio === 1,
      panelColors: panelColors?.length > 0 ? panelColors : [],
    };

    localStorage.setItem(
      "nickerPatternPanelColours",
      JSON.stringify(this.panelColoursList)
    );

    /* Prepare the nicker pattern obj */
    const obj = {
      patternforPant: patternForNickerObj,
    };

    console.log(obj);

    this.orderService.orderPatternDetailsObj.next(obj);
    document.getElementById("closeNickersModal")?.click();
  }
}
