import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {
  AlignmentType,
  BorderStyle,
  Document,
  Header,
  HeightRule,
  ImageRun,
  Packer,
  Paragraph,
  Table,
  TableCell,
  TableRow,
  TextRun,
  VerticalAlign,
  WidthType,
} from 'docx';

import { MastersService } from 'src/app/core/Services/masters.service';
import { OrderService } from 'src/app/core/Services/order.service';

@Component({
  selector: 'app-order-layout',
  templateUrl: './order-layout.component.html',
  styleUrls: ['./order-layout.component.scss'],
})
export class OrderLayoutComponent implements OnInit {
  fromDate: Date;
  src: any;
  /**
   * Get Order Layout Details
   */
  orderLayoutDetails: any;

  /**
   * Get Pattern Details
   * @type {*}
   */
  patternData: any;

  /**
   * Get Total Order value
   */
  totalOrderValue = 0;

  /**
   * Get Total Quantity
   */
  totalQuantity = 0;

  /**
   * Get Average Unit Price
   * @type {*}
   */
  avgUnitPrice: any;

  /**
   * Get Latest Sales Tax Name
   * @type {*}
   */
  latestSalesTaxName: any;
  patternDataDetail: any;

  /**
   * Creates an instance of CpLayoutComponent.
   * @param {Router} router
   * @param {OrderService} orderService
   * @param {MastersService} mastersService
   */
  constructor(
    private router: Router,
    private orderService: OrderService,
    private mastersService: MastersService
  ) {
    this.fromDate = new Date();

    /* Get Order Layout Details from behavior subject*/
    this.orderService.orderLayoutDetails.subscribe((res: any) => {
      if (Object.keys(res).length > 0) {
        this.orderLayoutDetails = res;
        this.patternDataDetail = this.orderLayoutDetails?.patternData;
        this.patternData = res.patternData?.split(',');
        if (this.orderLayoutDetails?.imageBase64 !== '') {
          this.src =
            'data:image/png;base64,' + this.orderLayoutDetails?.imageBase64;
        } else if (
          this.orderLayoutDetails?.imageBase64 === '' &&
          this.orderLayoutDetails?.imageFileFullName === ''
        ) {
          this.src = '';
        }
      } else {
        this.onClickNavigateToOrderList();
      }
    });
  }

  /**
   * Life Cycle Hook Initialization
   */
  ngOnInit(): void {
    this.getSaleTax();
  }

  /**
   * Life Cycle Hook After View Initialization
   */
  ngAfterViewInit(): void {
    if (document.getElementById('dynamicTh')) {
      if (this.orderLayoutDetails?.patternColoursList.length > 1) {
        document
          .getElementById('dynamicTh')
          ?.setAttribute(
            'colspan',
            (this.orderLayoutDetails?.patternColoursList.length - 1)?.toString()
          );
      } else {
        document.getElementById('dynamicTh')?.setAttribute('colspan', '2');
      }
    }
  }

  /**
   * Get sales tax
   */
  getSaleTax() {
    this.mastersService.getSalesTax().subscribe({
      next: (res: any) => {
        const salesTaxArray: any[] = res.result || [];
        if (salesTaxArray.length > 0) {
          salesTaxArray.sort(
            (a, b) =>
              new Date(b.createdDate).getTime() -
              new Date(a.createdDate).getTime()
          );
          this.latestSalesTaxName = salesTaxArray[0].salesTaxName;

          const totalQty = this.getSavedTotalQuantity();
          this.totalQuantity = totalQty;
          // Calculate order value for each item
          const orderValues = this.orderLayoutDetails.colourDetails.map(
            (item: any) => item.quantity * item.unitPrice
          );
          // Calculate the total order value
          this.totalOrderValue = orderValues.reduce(
            (sum: any, value: any) => sum + value,
            0
          );
          const totalUnitPrice =
            (this.totalOrderValue * 100) /
            (100 + Number(this.latestSalesTaxName));
          this.avgUnitPrice = totalUnitPrice / this.totalQuantity;
        }
      },
      error: (err: any) => { },
    });
  }

  /**
   * This method is used to get the unique sizes for the table
   * @return {*}  {string[]}
   */
  getUniqueSizes(): string[] {
    return Array.from(
      new Set(
        this.orderLayoutDetails?.colourDetails.map((item: any) => item.size)
      )
    );
  }

  /**
   * This method is used to get the unique colors for the table
   * @return {*}  {string[]}
   */
  getUniqueColors(): string[] {
    return Array.from(
      new Set(
        this.orderLayoutDetails?.colourDetails.map((item: any) => item.color)
      )
    );
  }

  /**
   * This method is used to get the quantity for the table
   * @param {string} color
   * @param {string} size
   * @return {*}  {number}
   */
  getQuantity(color: string, size: string): number {
    const item = this.orderLayoutDetails?.colourDetails.find(
      (item: any) => item.color === color && item.size === size
    );
    return item ? parseInt(item.quantity?.toString(), 10) : 0;
  }

  /**
   * This method is used to get the row total for the table
   * @param {string} color
   * @return {*}  {number}
   */
  getRowTotal(color: string): number {
    return this.getUniqueSizes().reduce(
      (total: any, size: any) => total + this.getQuantity(color, size),
      0
    );
  }

  /**
   * This method is used to get the column total for the table
   * @param {string} size
   * @return {*}  {number}
   */
  getColumnTotal(size: string): number {
    return this.getUniqueColors().reduce(
      (total: any, color: any) => total + this.getQuantity(color, size),
      0
    );
  }

  /**
   * This method is used to get the grand total for the table
   * @return {*}  {number}
   */
  getGrandTotal(): number {
    return this.getUniqueSizes().reduce(
      (total, size) => total + this.getColumnTotal(size),
      0
    );
  }

  /**
   * This method is used to get the saved orders total quantity
   * @return {*}  {number}
   */
  getSavedTotalQuantity(): number {
    let orderTotalQuantity = 0;
    for (const order of this.orderLayoutDetails.colourDetails) {
      if (order && order.quantity) {
        orderTotalQuantity += order.quantity;
      }
    }
    this.totalQuantity = orderTotalQuantity;
    return orderTotalQuantity;
  }

  /**
   * This method is used for navigate to orderList
   */
  onClickNavigateToOrderList() {
    this.router.navigate(['/admin/customer-order/order/orderList']);
  }

  /**
   *This method fired on click of exportToWord
   *
   * @param {*} event
   * @memberof InwardFabricListComponent
   */
  ExportToWord(orderLayoutDetails: any, avgUnitPrice: any) {
    const tableRows: TableRow[] = [];
    const tableTwoRows: TableRow[] = [];
    const tableThreeRows: TableRow[] = [];
    const tableFourRows: TableRow[] = [];
    const tableFiveRows: TableRow[] = [];
    const tableSixRows: TableRow[] = [];
    const transportTableRows: TableRow[] = [];
    const PatternTableRows: TableRow[] = [];

    const inputString = orderLayoutDetails?.patternData;
    console.log(orderLayoutDetails?.unitPoints);

    // Replace <b> and </b> tags with an empty string
    const withoutBoldTags = inputString?.replace(/<\/?b>/g, '');
    // Replace <br \\> with <br>
    const convertedString = withoutBoldTags?.replace(/<br \\>/g, '<br>');
    const data = convertedString?.split('<br>');
    let panelArray = data.filter((item: any) => item !== '');

    const IMAGE_PATH =
      '/9j/4AAQSkZJRgABAQEAYABgAAD/2wBDAAIBAQIBAQICAgICAgICAwUDAwMDAwYEBAMFBwYHBwcGBwcICQsJCAgKCAcHCg0KCgsMDAwMBwkODw0MDgsMDAz/2wBDAQICAgMDAwYDAwYMCAcIDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAz/wAARCAAuAKADASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD9/K+eP2wv+CqfwM/YYuzYePvG9pB4g2CRdD06J77UiCMqWijB8oEcgylAexrwn/gvd/wVKvv2A/gXp/hnwVdJB8TPHySpZXO0OdFsk+WW7APHmFiEjzxne3Pl4P8AOpK+tfEjxTNM51PXtb1OV55nbzLq6u5DlndjyzseSScnqTX0mUZD9Zh7as7R6d3/AMA8TMc29hL2VJXl+R++t3/wdXfs7W9y6J4T+Mc6qcCSPSNOCv7jdfA/mBUf/EVr+zx/0Jvxn/8ABTpn/wAn1+CGu+BNc8LwiTU9G1XTo2OA11aSQgn6sBVbQ/DuoeJ737NptjeahcbS3lW0LSvgdThQTivf/wBXMDa+v3nj/wBt4u/T7j9+P+IrX9nj/oTfjP8A+CnTP/k+j/iK1/Z4/wChN+M//gp0z/5Pr8H/APhTXjD/AKFTxJ/4LJv/AImqlj8OPEOp3tzbW2g61cXFkwW4iisZXeAnoHAXKk+9H+ruA8/vD+2sX5fcfvX/AMRWv7PH/Qm/Gf8A8FOmf/J9en/s/wD/AAcV/sxfHfXYdNuPEus+Ary5YJF/wlWni0gZj2aeJ5YY/rI6j3r+b7TPB+pat4st9DjtJI9VurhbRLeYeSwlYhQrbsbeSOuK9V/ap/Yi8S/sbGy0/wAb6ho9r4mu4knfRrafz57VGGQJGHyhgCCRnjcuCcnGdTh3A6QTab21NIZzi/isml5H9Zum6lb6xp8F3aTw3VpdRrNDNC4eOZGGVZWHBUgggjgg1PX89/8Awb/f8FZtb/Zs+OOi/CHxrrFxe/DTxldJp+m/apdw8OX8rbYmjZj8kEjkK652qWDjGH3f0IV8hmWXzwdX2ctV0fc+jwWMhiafPHfqgor8Xf8AgqF8N/j1+xt+0j8G9D0v9qj4r6hZfHDxRc6cU8+S2XQY/tVmiiNRMRIFF4cA7f8AVj14+6dI+NfhD/gj18DdM0z9oL48+JPGN14m1e6l03Xtc0m9u7mQLHDutgtutwVRMbgWIBMhxVVMutThOnLmctkk7u2/ToTDG3nKM48qju21byPrmivyq/4LV/8ABRfxbr/7Mfwb8Z/A3xp4l0T4M/EHUryDxF440DTbiG+s44Z44FRfMWKaElhdEDMbSNAAHA+95n+zR+0l8QNE/Zc/aUvvCH7VkXxm8HaN4EudV0WbVLvUbXxz4ev1WPExiuYyywhmlQslxImVhZdpYrWtPJ6kqKqt2u7Ws+9tdLJ+TInmUFUdNK+l76dr6d15n7Q0V+Qn7D//AAXu1z4S/Bn4FaB8T/h78Qde0bxlLJpd38TNTvG8q9uzeyoxhR4j9pSAPEjt5ysNjhUbYN3T+Ev+Ci3hD9lL9pX9tvxzZ+GviFrup+Cb/T21ey1LxWkun3ZXUF05PscX2cG3AM2752lwqhF2iplk+IjKUWvTbX3uXvoOOZUZJST9fLS/zP1Uor8r/wBpH/gtz8V/H/8AwTw8b/E34cfB7xn8Pba1bRE0fxff+TdW4S5eT7XcJFPbGKWKKWBbUMC283iPhNuK2PBv/BdjxB8Ff2Dfg74i+Ifw713xB8UPibcNpmiW8t9a6XbeJliS036m84jENrFI92iqojIBVs7VBIn+yMTy3sr3ta6vtf0/HTqV/aVC9r6WveztvY/Tiivn/wDYH/bZ1r9srwzr83iH4UeM/hZq3h26S3kh1aMz6fqStvAksr0IkV0oMbBjGMDKHJDg19AVwVacqcnCe6OunUjOPNHY/mx/4OQ/H174x/4KueMtOundoPCmlaVpdmGPCRPZRXZA9vMupD9Sa+af2D9UuNH/AG2fhJNazPBL/wAJhpSbkODta7iVh9CpIPsa+8f+Dpf9lTUPAH7WegfFi2tnfQfH+mRWF1OBxFqNouzYx7brfySuevlyY+6a+Cv2Hhbw/tg/DS7vL2206x0vxJY6jdXNxu2QwwTpNIcKrMTtQ4ABr9KwE4zy6Lj/AC2+dtfxPh8ZGUcbLm/m/XQ/Rf8AaP8A2z/FHgb/AILHN8N9Wlt/EXw08U+IxoOpeHtRt0ntHt7m+e3IVSPlKqFwR0wfWuE0n9jC6/Zj/wCC+fhTwx8OoWt/Duk+J9N1C4Q3ccS22mzXixSxMZGG8MhKbBlm3YAJrf8AidoPw38bf8FXJvjf4g+InhuH4eeG9WbX44k85b3U3jupp4Yo0kjRckmMnLZxnAJ4rxnSP2xrD9pv/gtB4W+Kd/q9v4c8M2Piqx1S4lm850Fla3S3BjCxozudoIHyjJGfl7efShLltTVlya6denzOupOPN77159PT/I+p/wBqz4jftBfB/wDae+KXjXw34t0C18F/Dea71WTS5tQs7xr5W1SW3jt2t43aVFEcsX31ULtA6jFfH3/BNj/goDf/AA//AOCnOleNvE175eh+PNTbTtfSQgxCG5YqJHzwfLdlkJ68E969L/aT+E3hj9pT9vXW/Eq/F/RPDXgDxBqV22o3UVtqX2mezl1C4nKCJbbBYxyJwxxn6V8Y/tO/B/S/gT8XrrT/AA34hh8SaGkzNp2oojxNOitgOUdVdc8Hle5GTgmunB0KU6bpTWso9rf076mOJq1IzVSL0T73Ppr4+/sh6j4c/wCCuuo6Fq7yXGmafqUmu39zIf8AVWdqnnuXboC0aIw9RNH3NfMf7XHx7v8A9pT9oHxJ4sv5nmOoXcnklj0jDHH0zycdBnA4Ar9GP24v2lPC3xP/AGHNE8YeH9Y068+MGueC7LQ/FMMSSq6RQFWeQSMiqzsFRmIbJ8iNfm6V+TtdOXOVSPPUWsVy/wCb+ZhjVGD5YPR6/wCQ+3uJLS4SWJ3jljYOjocMjDkEHsa/sF/Zv8b3XxM/Z38BeJL7JvfEHhzT9SuMj/lpNbRyN+rGv5Mf2ZfgBrf7U/x/8JfD3w7C0ureLNSisYiFyIEJzJM3+xHGHkb/AGUNf14eD/Ctn4F8JaXomnIY9P0ezisbZCclIokCIP8AvlRXg8WTj+7h11+7Q9fh6Mvfl00PkP8A4Kkf8E7PG37bnx6/Z18U+FNU8Lafp/wi8Ry6xrEerXM8U1zC1xp8oW3EcMgZ9tpJw5QZZeeSR9hav4esPECIt/Y2d6sZJQXEKyBCeuNwOKwPjh8VYPgj8J9c8VXFpLfx6Nb+aLaNwhmcsFRSzcICzLljwoycHFcPqX7XMHw6uLnT/HOjLpGtWsF1eGHSNQTVbaS3gm0+IsJCsLq5bUrf5JIkb5XPK7Gf5Sdec4RpvaN7fN3PoY0oxnKa3lv8tDy7/go9+xV8XPjmngzXPgT8UH+HWueD5pPP0C7up4vDXiGF2V9l3bxB0fBDDDxOrrIwOMA18n/Cj/ghJ8XNRu/jh438d+Ivhdp/j34neDLvwzpek+F7SSw0S0luEhQzT+XbpsAEK5EcTlmdnLFuv3Jd/wDBQ/wxFq9pFHomvCzGo3tlqdxObeJ9KjtrK5vGneHzTLgx2spCMqyYUnbkory3H/BRHwdaXUVrJonjJdRM629zZDT42msHeSxjiEuJSv7xtSstu0t/rxnG1tvVRzHEUqfs4W+5X3va5hUwVKpPnlf79Ox8YfE7/giL8VvGn7AP7N/wqtfEHw9j8Q/B/Xr3VNZuJb68FlcxTXks6i3YWpdmCuAQ6IM55I5pvxU/4Ih/Ffxxrv7X11aeIPh7HH8f7q2m8PCa+vAbNYtYivm+14tTsPlIQPL8z5iB0+avs34iftwS6T4Z8K6z4V8Lwa5p2v8Ah3VvFF1/amrHSprG0042wmjVRBMsk5NwQFZ40zGcyYOQ9v8Agov4El/t37LY+KLxdB2CWSOxRIpCZo4ZB5jyKkXlSSqHacxrwxUsFJGizbEra299u8ub80Q8uoP7rfhb8jzvx1/wTn8R/EL/AII2W37ONzrWiWfiuDwpYaQdRiaWXTjd2ksMy/MUWTymeEKW8vcAxO0kYPgHiL/glf8AtF+P/wBgH4X/AA71uf4A6trvwyu5baLSNZ02a+03UtMWOEQZu/IFzb3I2TI/kbVkR0O9GWvr+2/4KIeEDeXaGy1q8SG4jw9jbpKILaRNP8ueUl1GGk1GFMRlz1bG1SwD/wAFH/Aq+HpNSbTfFUUEbWrHzrOGFRBcJdNHcmR5RGsRNlcJ8zhy6AKrbl3ZU8wrw2t8XNt1Zc8FSnv2t8jxj/gjT/wS58Yf8E9br4i614t13w5HN8QLqK4i8LeGHu5NF0JUaVh5b3JMrsBKIxuyQsYy8mcj7npFcOoIIIIyCO9LXNicROvUdWpuzejRjSgqcNkeeftT/sueDv2yfghrPw/8dab/AGjoOsoMlCFns5V5juIXwdkqHkNg9wQVJU/z7/tvf8G+Xx4/ZV8U31z4S0K++KXg0OzWeo6BAZr9I+yz2a5lV8ZyYxInH3hnA/pLorty7Nq+DdoaxfRnLjcupYnWej7n8gF7+zL8T7Sdobj4fePI5EOGjk0K7DKfcFKhX9mz4kIcjwD43B9Rod1/8RX9gtFe1/rZP/n2vv8A+AeX/q9H+f8AA/j9/wCGc/iX/wBCJ45/8El1/wDEU1/2bfiRIfm8A+Nz9dDuv/iK/sEoo/1sn/z7X3/8AP8AV6P8/wCH/BP4/P8AhnH4lbcf8IH44x0x/Yl1/wDEV6X+z9/wSo/aF/aX16Cy8NfCnxfHBM4VtR1WwfTNPiHdjPcBEOByQpZvRSSBX9XFFTPiuq17tNJ+v/DFR4ep396bPh3/AIJBf8EYPDv/AATZ0CfxDrl3Z+KviprEHkXeqxRn7LpcJwTb2gYBsEgb5GAZ8AYUZB+4qKK+axGIqV6jq1Xds9yjRhSgoU1ZFXWtFs/Emj3Wn6ha219YX0LW9zbXEQkiuI2BVkdSCGUgkEEYINcPD+yd8MoNE0/TU8BeE1sdJnlurOEaZFtt5ZdvmSL8vDNsTJ6ny0/ujHoVFYGpxFp+zZ8P7BiYfBnhqIm8/tA7dPiH7/ZJHv6f3JZVx0xI4xhjldG/Zt8AeHbO3t7Dwb4cs4bUgxJDYRoEInhuARgdRNbwP9YY/wC6K7aii4HD+JP2aPh94w07RrTVfBnhzUrTw75n9mwXNhHLFZeYyvIEUggBmRCRjB2jNP1n9nHwD4h1TVL298HeHbm81pke+newjMlyysrKzNjO7ciHPXKKewrtaKLsDyHx7+w78O/Ht9oMjaNb6Xb6BcLcxWun2tvDFMVNrtViYmdAFsrdMwtG2yPbnbxXR6n+zD8O9a09bS78FeGrm2WGK3EUthGyiOIThEwR90C5uBjpieQdGNd3RRdgIqhFAAwBwAO1LRRQB//Z';
    //preparing unique sizes Array
    const uniqueSizesSet = this.getUniqueSizes();
    console.log(uniqueSizesSet, 'uniquesizes');

    //preparing unique colours Array
    const uniqueColoursSet = this.getUniqueColors();
    const grandTotal = this.getGrandTotal();
    const formattedgrandTotal = grandTotal.toLocaleString('en-IN');
    const GrandTotal = grandTotal
      .toFixed(3)
      .replace(/\d(?=(\d{3})+\.)/g, '$&,');
    console.log(uniqueColoursSet);

    const originalDate = orderLayoutDetails?.orderDate;
    const avgValue = avgUnitPrice.toFixed('2');

    //Logo
    const image = new Header({
      children: [
        new Paragraph({
          children: [
            new ImageRun({
              data: IMAGE_PATH,
              transformation: {
                width: 130,
                height: 40,
              },
            }),
          ],
        }),
      ],
    });

    // Header
    const additionalInfo = new Paragraph({
      alignment: AlignmentType.CENTER,
      children: [
        new TextRun({
          text: `Order Sheet`,
          bold: true,
          font: 'Arial Black',
          color: '#000000',
          size: 32,
        }),
      ],
    });
    //creating empty para
    const emptypara = new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: {
        line: 150,
      },
      children: [
        new TextRun({
          text: ``,
        }),
      ],
    });
    // subHeader
    const subhead = new Paragraph({
      alignment: AlignmentType.CENTER,

      children: [
        new TextRun({
          text: `Order Sheet`,
          bold: true,
          font: 'Arial Black',
          color: '#000000',
          size: 28,
        }),
      ],
    });

    // create pattern details
    const PatternDetails = new Paragraph({
      alignment: AlignmentType.LEFT,
      children: [
        new TextRun({
          text: ``,
          bold: true,
          font: 'Arial',
          color: '#000000',
        }),
        ...panelArray?.map((data: any, index: any) => {
          const [label, value] = data?.split(':');
          let before = 0;
          if (index !== 0) {
            before = 1560;
          }

          const paragraph = new Paragraph({
            indent: { left: before },
            spacing: {
              line: 300,
            },
            children: [
              new TextRun({
                text: `${label}: `,
                font: 'Arial',
                color: '#000000',
                bold: true,
              }),
              new TextRun({
                text: `${value ? value : '-'} `,
                font: 'Arial',
                color: '#000000',
              }),
            ],
          });

          return paragraph;
        }),
      ],
    });

    //creating quality
    const Quality = new Paragraph({
      indent: { left: 10 },
      children: [
        new TextRun({
          style: AlignmentType.LEFT,
          text: 'Quality\u00A0: ',
          bold: true,
          font: 'Arial',
        }),
        new TextRun({
          style: AlignmentType.LEFT,
          text: orderLayoutDetails?.quality,
          font: 'Arial',
        }),
      ],
    });

    //creating quality
    const pocket = new Paragraph({
      indent: { left: 10 },
      children: [
        new TextRun({
          style: AlignmentType.LEFT,
          text: 'Pocket / Chest Print\u00A0: ',
          bold: true,
          font: 'Arial',
        }),
        new TextRun({
          text: `${orderLayoutDetails?.printType == 1
            ? 'Pocket Print'
            : orderLayoutDetails?.printType == 2
              ? 'Chest Print'
              : ''
            }`,
          color: '#000000',
          font: 'Arial',
        }),
      ],
    });



    const imgeModelPath = orderLayoutDetails?.imageBase64
      ? `data:image/png;base64,${orderLayoutDetails?.imageBase64}`
      : '';

    //creating imagemodel
    const imageModel = new Paragraph({
      alignment: AlignmentType.CENTER,
      children: [
        new ImageRun({
          data: imgeModelPath,
          transformation: {
            width: 150,
            height: 150,
          },
        }),
      ],
    });

    //creating noimagemodel
    const noImageModel = new Paragraph({
      indent: { left: 800 },
      children: [
        new TextRun({
          style: AlignmentType.CENTER,
          text: '',
          font: 'Arial',
        }),
      ],
    });

    //creating Remarks
    const remarks = new Paragraph({
      children: [
        new TextRun({
          style: AlignmentType.END,
          text: 'Remarks : ',
          bold: true,
          font: 'Arial',
        }),
        new TextRun({
          style: AlignmentType.END,
          text: `${orderLayoutDetails?.remarks}`,
          font: 'Arial',
        }),
      ],
    });

    // preparing backPrintObject
    const backPrintObject: any = {};
    if (orderLayoutDetails?.backPrint1) {
      backPrintObject.backPrint1 = orderLayoutDetails.backPrint1;
    }

    if (orderLayoutDetails?.backPrint2) {
      backPrintObject.backPrint2 = orderLayoutDetails.backPrint2;
    }

    if (orderLayoutDetails?.backPrint3) {
      backPrintObject.backPrint3 = orderLayoutDetails.backPrint3;
    }

    if (orderLayoutDetails?.backPrint4) {
      backPrintObject.backPrint4 = orderLayoutDetails.backPrint4;
    }

    // preparing boolean back print value present or not
    const hasAtLeastOneValue = Object.values(backPrintObject).some(
      (value) => value !== undefined && value !== null && value !== ''
    );
    console.log(hasAtLeastOneValue, 'backprint yes');

    // preparing back print array
    const backprintArray = Object.keys(backPrintObject);

    // Assuming panelArray includes "backPrint1," "backPrint2," etc.
    // const backprintArray = [
    //   'backPrint1',
    //   'backPrint2',
    //   'backPrint3',
    //   'backPrint4',
    // ];

    // Create backprint details details
    const BackprintDetails = new Paragraph({
      alignment: AlignmentType.LEFT,
      children: [
        new TextRun({
          text: `Back Print : `,
          bold: true,
          font: 'Arial',
          color: '#000000',
        }),
        ...backprintArray.map((label, index) => {
          const value = backPrintObject[label] || ''; // Access the values from your data object
          console.log(value);
          let before = 0;
          if (index !== 0) {
            before = 1150;
          }

          const paragraph = new Paragraph({
            indent: { left: before },
            // spacing: {
            //   line: 300,
            // },
            children: [
              // new TextRun({
              //   text: `${label.charAt(0).toUpperCase() + label.slice(1)}: `,
              //   font: 'Arial',
              //   color: '#000000',
              //   bold: true,
              // }),
              new TextRun({
                text: `${value !== '' ? value : ''}`,
                font: 'Arial',
                color: '#000000',
              }),
            ],
          });

          return paragraph;
        }),
      ],
    });

    // Create table headers
    const tableHeader = new TableRow({
      children: [
        new TableCell({
          margins: {
            top: 40,
            bottom: 40,
          },
          width: {
            size: 3505,
            type: WidthType.DXA,
          },
          verticalAlign: VerticalAlign.CENTER,
          shading: {
            fill: 'DBDBDB', // Specifying the background color
          },
          children: [
            new Paragraph({
              children: [
                new TextRun({
                  text: 'Colour',
                  bold: true,
                  color: '#000000',
                  font: 'Arial',
                }),
              ],
              alignment: AlignmentType.CENTER, // Center align the text vertically
            }),
          ],
        }),
        // Dynamically generate cells for each unique size
        ...uniqueSizesSet?.map(
          (size) =>
            new TableCell({
              margins: {
                top: 40,
                bottom: 40,
              },
              width: {
                size: 2000, // Adjust the width as needed
                type: WidthType.DXA,
              },
              verticalAlign: VerticalAlign.CENTER,
              shading: {
                fill: 'DBDBDB', // Specifying the background color
              },
              children: [
                new Paragraph({
                  children: [
                    new TextRun({
                      text: `${size} `,
                      bold: true,
                      font: 'Arial',
                      color: '#000000',
                    }),
                  ],
                  alignment: AlignmentType.CENTER, // Center align the text vertically
                }),
              ],
            })
        ),
        // Last cell for "Total"
        new TableCell({
          margins: {
            top: 40,
            bottom: 40,
          },
          width: {
            size: 2000,
            type: WidthType.DXA,
          },
          verticalAlign: VerticalAlign.CENTER,
          shading: {
            fill: 'DBDBDB', // Specifying the background color
          },
          children: [
            new Paragraph({
              children: [
                new TextRun({
                  text: 'Total Quantity',
                  bold: true,
                  font: 'Arial',
                  color: '#000000',
                }),
              ],
              alignment: AlignmentType.CENTER, // Center align the text vertically
            }),
          ],
        }),
      ],
    });

    //adding header to table rows
    tableRows.push(tableHeader);

    //Create data rows from the inwardFabricList array
    uniqueColoursSet?.forEach((item: any, index: number) => {
      const rowTotal = this.getRowTotal(item);
      let RowTotal = rowTotal.toLocaleString('en-IN');
      const row = new TableRow({
        height: {
          value: 350,
          rule: HeightRule.EXACT,
        },
        children: [
          // Dynamically generate cells for each unique size
          new TableCell({
            margins: {
              left: 100,
            },
            width: {
              size: 2000, // Adjust the width as needed
              type: WidthType.DXA,
            },
            verticalAlign: VerticalAlign.CENTER,
            children: [
              new Paragraph({
                children: [
                  new TextRun({
                    text: `${item} `,
                    font: 'Arial',
                    color: '#000000',
                  }),
                ],
                alignment: AlignmentType.LEFT,
                // Center align the text vertically
              }),
            ],
          }),
          ...uniqueSizesSet.map((size) => {
            const quantity = this.getQuantity(item, size);
            const Quantity = quantity.toLocaleString('en-IN');
            return new TableCell({
              margins: {
                right: 100,
              },
              width: {
                size: 2000, // Adjust the width as needed
                type: WidthType.DXA,
              },
              verticalAlign: VerticalAlign.CENTER,
              children: [
                new Paragraph({
                  children: [
                    new TextRun({
                      text: `${Quantity} `,
                      font: 'Arial',
                      color: '#000000',
                    }),
                  ],
                  alignment: AlignmentType.RIGHT, // Center align the text vertically
                }),
              ],
            });
          }),
          new TableCell({
            margins: {
              right: 100,
            },
            width: {
              size: 2000, // Adjust the width as needed
              type: WidthType.DXA,
            },
            verticalAlign: VerticalAlign.CENTER,
            children: [
              new Paragraph({
                children: [
                  new TextRun({
                    text: `${RowTotal} `,
                    font: 'Arial',
                    color: '#000000',
                  }),
                ],
                alignment: AlignmentType.RIGHT, // Center align the text vertically
              }),
            ],
          }),
        ],
      });
      tableRows.push(row);
    });

    //table Footer
    const tableFooter = new TableRow({
      children: [
        new TableCell({
          margins: {
            right: 100,
            top: 40,
            bottom: 40,
          },
          width: {
            size: 3505, // Adjust the width as needed
            type: WidthType.DXA,
          },
          verticalAlign: VerticalAlign.CENTER,
          shading: {
            fill: 'DBDBDB', // Specifying the background color
          },
          children: [
            new Paragraph({
              alignment: AlignmentType.RIGHT,
              children: [
                new TextRun({
                  text: `Total: `,
                  color: '#000000',
                  size: 20,
                  font: 'Arial',
                  bold: true,
                }),
              ],
            }),
          ],
        }),
        ...uniqueSizesSet.map((size) => {
          const columnTotal = this.getColumnTotal(size);
          let ColumnTotal = columnTotal.toLocaleString('en-IN');
          return new TableCell({
            margins: {
              right: 100,
              top: 40,
              bottom: 40,
            },
            verticalAlign: VerticalAlign.CENTER,
            shading: {
              fill: 'DBDBDB', // Specifying the background color
            },
            children: [
              new Paragraph({
                children: [
                  new TextRun({
                    text: `${ColumnTotal} `,
                    font: 'Arial',
                    color: '#000000',
                    bold: true,
                  }),
                ],
                alignment: AlignmentType.RIGHT, // Center align the text vertically
              }),
            ],
          });
        }),
        new TableCell({
          margins: {
            right: 100,
            top: 40,
            bottom: 40,
          },
          width: {
            size: 2000, // Adjust the width as needed
            type: WidthType.DXA,
          },
          verticalAlign: VerticalAlign.CENTER,
          shading: {
            fill: 'DBDBDB', // Specifying the background color
          },
          children: [
            new Paragraph({
              children: [
                new TextRun({
                  text: `${formattedgrandTotal} `,
                  font: 'Arial',
                  color: '#000000',
                  bold: true,
                }),
              ],
              alignment: AlignmentType.RIGHT, // Center align the text vertically
            }),
          ],
        }),
      ],
    });

    //adding footer to table rows
    tableRows.push(tableFooter);

    //preparing table
    const table = new Table({
      alignment: AlignmentType.LEFT,
      width: {
        size: 9100, // Adjust the width size as needed
        type: WidthType.DXA,
      },
      rows: tableRows,
    });

    const tableTwoHeader = new TableRow({
      children: [
        new TableCell({
          margins: {
            top: 40,
            bottom: 40,
          },
          width: {
            size: 2000,
            type: WidthType.DXA,
          },
          verticalAlign: VerticalAlign.CENTER,
          shading: {
            fill: 'DBDBDB', // Specifying the background color
          },
          children: [
            new Paragraph({
              children: [
                new TextRun({
                  text: 'Body',
                  bold: true,
                  color: '#000000',
                  font: 'Arial',
                }),
              ],
              alignment: AlignmentType.CENTER, // Center align the text vertically
            }),
          ],
        }),

        // Last cell for "Total"
        new TableCell({
          margins: {
            top: 40,
            bottom: 40,
          },
          width: {
            size: 2000,
            type: WidthType.DXA,
          },
          verticalAlign: VerticalAlign.CENTER,
          shading: {
            fill: 'DBDBDB', // Specifying the background color
          },
          children: [
            new Paragraph({
              children: [
                new TextRun({
                  text: 'Panel',
                  bold: true,
                  font: 'Arial',
                  color: '#000000',
                }),
              ],
              alignment: AlignmentType.CENTER, // Center align the text vertically
            }),
          ],
        }),
      ],
    });

    //adding header to table rows
    tableTwoRows.push(tableTwoHeader);

    orderLayoutDetails?.panelData.forEach((item: any, index: number) => {
      const row = new TableRow({
        children: [
          new TableCell({
            margins: {
              left: 100,
              top: 40,
              bottom: 40,
            },
            width: {
              size: 2000,
              type: WidthType.DXA,
            },
            verticalAlign: VerticalAlign.CENTER,
            children: [
              new Paragraph({
                alignment: AlignmentType.LEFT,

                children: [
                  new TextRun({
                    text: `${item?.bodyColor}`,
                    color: '#000000',
                    font: 'Arial',
                  }),
                ],
              }),
            ],
          }),
          new TableCell({
            margins: {
              left: 100,
              top: 40,
              bottom: 40,
            },
            width: {
              size: 2000,
              type: WidthType.DXA,
            },
            verticalAlign: VerticalAlign.CENTER,
            children: [
              new Paragraph({
                alignment: AlignmentType.LEFT,

                children: [
                  new TextRun({
                    text: `${item?.panelColor}`,
                    color: '#000000',
                    font: 'Arial',
                  }),
                ],
              }),
            ],
          }),
        ],
      });
      tableTwoRows.push(row);
    });

    const tabletwo = new Table({
      alignment: AlignmentType.CENTER,
      width: {
        size: 6500, // Adjust the width size as needed
        type: WidthType.DXA,
      },
      rows: tableTwoRows,
    });

    const TableRowOne = new TableRow({
      children: [
        new TableCell({
          margins: { top: 100, bottom: 100, left: 100 },
          // borders: {
          //   top: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the top border of the cell
          //   bottom: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the bottom border of the cell
          //   left: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the left border of the cell
          //   right: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the right border of the cell
          // },
          shading: {
            fill: 'DBDBDB', // Specifying the background color
          },
          width: {
            size: 2100,
            type: WidthType.DXA,
          },
          verticalAlign: VerticalAlign.TOP,
          children: [
            new Paragraph({
              alignment: AlignmentType.LEFT,

              children: [
                new TextRun({
                  text: `Payment Mode :`,
                  color: '#000000',
                  font: 'Arial',
                  bold: true,
                }),
              ],
            }),
          ],
        }),
        new TableCell({
          margins: { top: 100, bottom: 100, left: 100 },
          // borders: {
          //   top: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the top border of the cell
          //   bottom: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the bottom border of the cell
          //   left: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the left border of the cell
          //   right: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the right border of the cell
          // },

          width: {
            size: 4000,
            type: WidthType.DXA,
          },
          verticalAlign: VerticalAlign.TOP,
          children: [
            new Paragraph({
              alignment: AlignmentType.LEFT,

              children: [
                new TextRun({
                  text: `${orderLayoutDetails?.paymentMode}`,
                  color: '#000000',
                  font: 'Arial',
                }),
              ],
            }),
          ],
        }),
        new TableCell({
          margins: { top: 100, bottom: 100, left: 100 },
          // borders: {
          //   top: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the top border of the cell
          //   bottom: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the bottom border of the cell
          //   left: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the left border of the cell
          //   right: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the right border of the cell
          // },
          shading: {
            fill: 'DBDBDB', // Specifying the background color
          },
          width: {
            size: 2700,
            type: WidthType.DXA,
          },
          verticalAlign: VerticalAlign.TOP,
          children: [
            new Paragraph({
              alignment: AlignmentType.LEFT,

              children: [
                new TextRun({
                  text: `PIN Code :`,
                  color: '#000000',
                  font: 'Arial',
                  bold: true,
                }),
              ],
            }),
          ],
        }),
        new TableCell({
          margins: { top: 100, bottom: 100, left: 100 },
          // borders: {
          //   top: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the top border of the cell
          //   bottom: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the bottom border of the cell
          //   left: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the left border of the cell
          //   right: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the right border of the cell
          // },
          width: {
            size: 2700,
            type: WidthType.DXA,
          },
          verticalAlign: VerticalAlign.TOP,
          children: [
            new Paragraph({
              alignment: AlignmentType.LEFT,

              children: [
                new TextRun({
                  text: `${orderLayoutDetails?.pin}`,
                  color: '#000000',
                  font: 'Arial',
                }),
              ],
            }),
          ],
        }),
      ],
    });
    const TableRowTwo = new TableRow({
      children: [
        new TableCell({
          margins: { top: 100, bottom: 100, left: 100 },
          // borders: {
          //   top: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the top border of the cell
          //   bottom: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the bottom border of the cell
          //   left: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the left border of the cell
          //   right: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the right border of the cell
          // },
          shading: {
            fill: 'DBDBDB', // Specifying the background color
          },
          width: {
            size: 2300,
            type: WidthType.DXA,
          },
          verticalAlign: VerticalAlign.TOP,
          children: [
            new Paragraph({
              alignment: AlignmentType.LEFT,

              children: [
                new TextRun({
                  text: `Calculate Points :`,
                  color: '#000000',
                  font: 'Arial',
                  bold: true,
                }),
              ],
            }),
          ],
        }),
        new TableCell({
          margins: { top: 100, bottom: 100, left: 100 },
          // borders: {
          //   top: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the top border of the cell
          //   bottom: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the bottom border of the cell
          //   left: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the left border of the cell
          //   right: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the right border of the cell
          // },
          width: {
            size: 4000,
            type: WidthType.DXA,
          },
          verticalAlign: VerticalAlign.TOP,
          children: [
            new Paragraph({
              alignment: AlignmentType.LEFT,

              children: [
                new TextRun({
                  text: `${orderLayoutDetails?.orderPointsFlag}`,
                  color: '#000000',
                  font: 'Arial',
                }),
              ],
            }),
          ],
        }),
        new TableCell({
          shading: {
            fill: 'DBDBDB', // Specifying the background color
          },
          margins: { left: 100, top: 100, bottom: 100 },
          // borders: {
          //   top: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the top border of the cell
          //   bottom: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the bottom border of the cell
          //   left: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the left border of the cell
          //   right: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the right border of the cell
          // },
          width: {
            size: 2700,
            type: WidthType.DXA,
          },
          verticalAlign: VerticalAlign.TOP,
          children: [
            new Paragraph({
              alignment: AlignmentType.LEFT,

              children: [
                new TextRun({
                  text: `Delivery Date :`,
                  color: '#000000',
                  font: 'Arial',
                  bold: true,
                }),
              ],
            }),
          ],
        }),
        new TableCell({
          margins: { top: 100, bottom: 100, left: 100 },
          // borders: {
          //   top: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the top border of the cell
          //   bottom: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the bottom border of the cell
          //   left: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the left border of the cell
          //   right: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the right border of the cell
          // },
          width: {
            size: 2700,
            type: WidthType.DXA,
          },
          verticalAlign: VerticalAlign.TOP,
          children: [
            new Paragraph({
              alignment: AlignmentType.LEFT,

              children: [
                new TextRun({
                  text: `${orderLayoutDetails?.expDelDate.split('T')[0]}`,
                  color: '#000000',
                  font: 'Arial',
                }),
              ],
            }),
          ],
        }),
      ],
    });
    const TableRowThree = new TableRow({

      children: [
        new TableCell({
          margins: { top: 100, bottom: 100, left: 100 },
          shading: {
            fill: 'DBDBDB', // Specifying the background color
          },
          // borders: {
          //   top: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the top border of the cell
          //   bottom: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the bottom border of the cell
          //   left: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the left border of the cell
          //   right: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the right border of the cell
          // },
          width: {
            size: 2100,
            type: WidthType.DXA,
          },
          verticalAlign: VerticalAlign.TOP,
          children: [
            new Paragraph({
              alignment: AlignmentType.LEFT,

              children: [
                new TextRun({
                  text: `Unit Points :`,
                  color: '#000000',
                  font: 'Arial',
                  bold: true,
                }),
              ],
            }),
          ],
        }),
        new TableCell({
          margins: { top: 100, bottom: 100, left: 100 },
          // borders: {
          //   top: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the top border of the cell
          //   bottom: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the bottom border of the cell
          //   left: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the left border of the cell
          //   right: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the right border of the cell
          // },
          width: {
            size: 4000,
            type: WidthType.DXA,
          },
          verticalAlign: VerticalAlign.TOP,
          children: [
            new Paragraph({
              alignment: AlignmentType.LEFT,

              children: [
                new TextRun({
                  text: `${orderLayoutDetails?.unitPoints}`,
                  color: '#000000',
                  font: 'Arial',
                }),
              ],
            }),
          ],
        }),
        new TableCell({
          margins: { top: 100, bottom: 100, left: 100 },
          // borders: {
          //   top: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the top border of the cell
          //   bottom: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the bottom border of the cell
          //   left: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the left border of the cell
          //   right:
          //     { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the right border of the cell
          // },
          shading: {
            fill: 'DBDBDB', // Specifying the background color
          },
          width: {
            size: 2700,
            type: WidthType.DXA,
          },
          verticalAlign: VerticalAlign.TOP,
          children: [
            new Paragraph({
              alignment: AlignmentType.LEFT,

              children: [
                new TextRun({
                  text: `Order Received :`,
                  color: '#000000',
                  font: 'Arial',
                  bold: true,
                }),
              ],
            }),
          ],
        }),
        new TableCell({
          margins: { bottom: 100, left: 100 },
          // borders: {
          //   top: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the top border of the cell
          //   bottom: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the bottom border of the cell
          //   left: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the left border of the cell
          //   right: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the right border of the cell
          // },
          width: {
            size: 2700,
            type: WidthType.DXA,
          },
          verticalAlign: VerticalAlign.TOP,
          children: [
            new Paragraph({
              alignment: AlignmentType.LEFT,

              children: [
                new TextRun({
                  text: `${orderLayoutDetails?.directAgent !== 'Direct' ? `${orderLayoutDetails?.directAgent} (${orderLayoutDetails?.agentName})` : orderLayoutDetails?.directAgent}`,
                  color: '#000000',
                  font: 'Arial',
                }),
              ],
            }),
          ],
        }),
      ],
    });

    tableThreeRows.push(TableRowOne, TableRowTwo, TableRowThree);

    const tablethree = new Table({
      // borders: {
      //   top: { style: BorderStyle.NONE },
      //   bottom: { style: BorderStyle.NONE },
      //   left: { style: BorderStyle.NONE },
      //   right: { style: BorderStyle.NONE },
      // },
      alignment: AlignmentType.CENTER,
      width: {
        size: 9100, // Adjust the width size as needed
        type: WidthType.DXA,
      },
      rows: tableThreeRows,
    });

    //Organization Table
    const TableRow1 = new TableRow({
      height: {
        value: 350,
        rule: HeightRule.EXACT,
      },
      children: [
        new TableCell({
          borders: {
            top: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the top border of the cell
            bottom: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the bottom border of the cell
            left: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the left border of the cell
            right: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the right border of the cell
          },
          width: {
            size: 1700,
            type: WidthType.DXA,
          },
          verticalAlign: VerticalAlign.CENTER,
          children: [
            new Paragraph({
              alignment: AlignmentType.LEFT,
              children: [
                new TextRun({
                  text: `Order No :`,
                  color: '#000000',
                  font: 'Arial',
                  bold: true,
                }),
              ],
            }),
          ],
        }),
        new TableCell({
          borders: {
            top: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the top border of the cell
            bottom: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the bottom border of the cell
            left: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the left border of the cell
            right: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the right border of the cell
          },
          width: {
            size: 6300,
            type: WidthType.DXA,
          },
          verticalAlign: VerticalAlign.CENTER,
          children: [
            new Paragraph({
              alignment: AlignmentType.LEFT,

              children: [
                new TextRun({
                  text: `${orderLayoutDetails?.orderNo}`,
                  color: '#000000',
                  font: 'Arial',
                }),
              ],
            }),
          ],
        }),
        new TableCell({
          borders: {
            top: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the top border of the cell
            bottom: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the bottom border of the cell
            left: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the left border of the cell
            right: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the right border of the cell
          },
          width: {
            size: 1700,
            type: WidthType.DXA,
          },
          verticalAlign: VerticalAlign.CENTER,
          children: [
            new Paragraph({
              alignment: AlignmentType.LEFT,

              children: [
                new TextRun({
                  text: `Order Date :`,
                  color: '#000000',
                  font: 'Arial',
                  bold: true,
                }),
              ],
            }),
          ],
        }),
        new TableCell({

          borders: {
            top: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the top border of the cell
            bottom: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the bottom border of the cell
            left: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the left border of the cell
            right: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the right border of the cell
          },
          width: {
            size: 1700,
            type: WidthType.DXA,
          },
          verticalAlign: VerticalAlign.CENTER,
          children: [
            new Paragraph({
              alignment: AlignmentType.LEFT,

              children: [
                new TextRun({
                  text: `${originalDate.split('T')[0]}`,
                  color: '#000000',
                  font: 'Arial',
                }),
              ],
            }),
          ],
        }),
      ],
    });
    const TableRow2 = new TableRow({
      children: [
        new TableCell({
          margins: { bottom: 100 },
          borders: {
            top: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the top border of the cell
            bottom: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the bottom border of the cell
            left: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the left border of the cell
            right: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the right border of the cell
          },
          width: {
            size: 1700,
            type: WidthType.DXA,
          },
          verticalAlign: VerticalAlign.TOP,
          children: [
            new Paragraph({
              alignment: AlignmentType.LEFT,

              children: [
                new TextRun({
                  text: `Organization :`,
                  color: '#000000',
                  font: 'Arial',
                  bold: true,
                }),
              ],
            }),
          ],
        }),
        new TableCell({
          margins: { bottom: 100 },
          borders: {
            top: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the top border of the cell
            bottom: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the bottom border of the cell
            left: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the left border of the cell
            right: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the right border of the cell
          },
          width: {
            size: 6300,
            type: WidthType.DXA,
          },
          verticalAlign: VerticalAlign.TOP,
          children: [
            new Paragraph({
              alignment: AlignmentType.LEFT,

              children: [
                new TextRun({
                  text: `${orderLayoutDetails?.schoolName}`,
                  color: '#000000',
                  font: 'Arial',
                }),
              ],
            }),
          ],
        }),
        new TableCell({
          margins: { bottom: 100 },
          borders: {
            top: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the top border of the cell
            bottom: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the bottom border of the cell
            left: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the left border of the cell
            right: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the right border of the cell
          },
          width: {
            size: 1700,
            type: WidthType.DXA,
          },
          verticalAlign: VerticalAlign.TOP,
          children: [
            new Paragraph({
              alignment: AlignmentType.LEFT,

              children: [
                new TextRun({
                  text: `Town :`,
                  color: '#000000',
                  font: 'Arial',
                  bold: true,
                }),
              ],
            }),
          ],
        }),
        new TableCell({
          margins: { bottom: 100 },
          borders: {
            top: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the top border of the cell
            bottom: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the bottom border of the cell
            left: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the left border of the cell
            right: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the right border of the cell
          },
          width: {
            size: 1500,
            type: WidthType.DXA,
          },
          verticalAlign: VerticalAlign.TOP,
          children: [
            new Paragraph({
              alignment: AlignmentType.LEFT,

              children: [
                new TextRun({
                  text: `${orderLayoutDetails?.town?.trim()}`,
                  color: '#000000',
                  font: 'Arial',
                }),
              ],
            }),
          ],
        }),
      ],
    });
    const TableRow3 = new TableRow({
      children: [
        new TableCell({
          borders: {
            top: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the top border of the cell
            bottom: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the bottom border of the cell
            left: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the left border of the cell
            right: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the right border of the cell
          },
          width: {
            size: 1700,
            type: WidthType.DXA,
          },
          verticalAlign: VerticalAlign.TOP,
          children: [
            new Paragraph({
              alignment: AlignmentType.LEFT,

              children: [
                new TextRun({
                  text: `Pattern Type :`,
                  color: '#000000',
                  font: 'Arial',
                  bold: true,
                }),
              ],
            }),
          ],
        }),
        new TableCell({

          borders: {
            top: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the top border of the cell
            bottom: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the bottom border of the cell
            left: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the left border of the cell
            right: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the right border of the cell
          },
          width: {
            size: 6300,
            type: WidthType.DXA,
          },
          verticalAlign: VerticalAlign.TOP,
          children: [
            new Paragraph({
              alignment: AlignmentType.LEFT,

              children: [
                new TextRun({
                  text: `${orderLayoutDetails?.pattern}${orderLayoutDetails?.modelName
                    ? ' (' + orderLayoutDetails?.modelName + ')'
                    : ''
                    }`,
                  color: '#000000',
                  font: 'Arial',
                  bold: true,
                  size: 24,
                }),
              ],
            }),
          ],
        }),
        new TableCell({
          borders: {
            top: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the top border of the cell
            bottom: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the bottom border of the cell
            left: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the left border of the cell
            right: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the right border of the cell
          },
          width: {
            size: 1700,
            type: WidthType.DXA,
          },
          verticalAlign: VerticalAlign.TOP,
          children: [
            new Paragraph({
              alignment: AlignmentType.LEFT,

              children: [
                new TextRun({
                  text: `Dress Item :`,
                  color: '#000000',
                  font: 'Arial',
                  bold: true,
                }),
              ],
            }),
          ],
        }),
        new TableCell({

          borders: {
            top: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the top border of the cell
            bottom: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the bottom border of the cell
            left: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the left border of the cell
            right: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the right border of the cell
          },
          width: {
            size: 1500,
            type: WidthType.DXA,
          },
          verticalAlign: VerticalAlign.TOP,
          children: [
            new Paragraph({
              alignment: AlignmentType.LEFT,

              children: [
                new TextRun({
                  text: `${orderLayoutDetails?.dressItem}`,
                  color: '#000000',
                  font: 'Arial',
                  bold: true,
                  size: 24,
                }),
              ],
            }),
          ],
        }),
      ],
    });

    tableFourRows.push(TableRow1, TableRow2, TableRow3);

    const tableOrganization = new Table({
      borders: {
        top: { style: BorderStyle.NONE },
        bottom: { style: BorderStyle.NONE },
        left: { style: BorderStyle.NONE },
        right: { style: BorderStyle.NONE },
      },
      alignment: AlignmentType.CENTER,
      width: {
        size: 9100, // Adjust the width size as needed
        type: WidthType.DXA,
      },
      rows: tableFourRows,
    });

    const TableFiveRow1 = new TableRow({
      height: {
        value: 400,
        rule: HeightRule.EXACT,
      },
      children: [
        new TableCell({
          borders: {
            top: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the top border of the cell
            bottom: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the bottom border of the cell
            left: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the left border of the cell
            right: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the right border of the cell
          },
          width: {
            size: 2000,
            type: WidthType.DXA,
          },
          verticalAlign: VerticalAlign.CENTER,
          children: [
            new Paragraph({
              alignment: AlignmentType.LEFT,

              children: [
                new TextRun({
                  text: `Manager:`,
                  color: '#000000',
                  font: 'Arial',
                  bold: true,
                }),
              ],
            }),
          ],
        }),
        new TableCell({
          borders: {
            top: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the top border of the cell
            bottom: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the bottom border of the cell
            left: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the left border of the cell
            right: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the right border of the cell
          },
          margins: {
            left: 100,
          },
          width: {
            size: 4000,
            type: WidthType.DXA,
          },
          verticalAlign: VerticalAlign.CENTER,
          children: [
            new Paragraph({
              alignment: AlignmentType.LEFT,

              children: [
                new TextRun({
                  text: ``,
                  color: '#000000',
                  font: 'Arial',
                }),
              ],
            }),
          ],
        }),
        new TableCell({
          borders: {
            top: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the top border of the cell
            bottom: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the bottom border of the cell
            left: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the left border of the cell
            right: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the right border of the cell
          },
          width: {
            size: 4000,
            type: WidthType.DXA,
          },
          verticalAlign: VerticalAlign.CENTER,
          children: [
            new Paragraph({
              alignment: AlignmentType.LEFT,

              children: [
                new TextRun({
                  text: `2`,
                  color: '#000000',
                  font: 'Arial',
                  bold: true,
                }),
                new TextRun({
                  text: 'nd',
                  color: '#000000',
                  font: 'Arial',
                  superScript: true,
                  bold: true,
                }),
                new TextRun({
                  text: ` Checked:`,
                  color: '#000000',
                  font: 'Arial',
                  bold: true,
                }),
              ],
            }),
          ],
        }),
        new TableCell({
          borders: {
            top: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the top border of the cell
            bottom: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the bottom border of the cell
            left: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the left border of the cell
            right: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the right border of the cell
          },
          width: {
            size: 1500,
            type: WidthType.DXA,
          },
          verticalAlign: VerticalAlign.CENTER,
          children: [
            new Paragraph({
              alignment: AlignmentType.LEFT,

              children: [
                new TextRun({
                  text: ``,
                  color: '#000000',
                  font: 'Arial',
                }),
              ],
            }),
          ],
        }),
        new TableCell({
          borders: {
            top: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the top border of the cell
            bottom: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the bottom border of the cell
            left: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the left border of the cell
            right: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the right border of the cell
          },
          width: {
            size: 4000,
            type: WidthType.DXA,
          },
          verticalAlign: VerticalAlign.CENTER,
          children: [
            new Paragraph({
              alignment: AlignmentType.RIGHT,

              children: [
                new TextRun({
                  text: `Order Processed by:`,
                  color: '#000000',
                  font: 'Arial',
                  bold: true,
                }),
              ],
            }),
          ],
        }),
        new TableCell({
          borders: {
            top: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the top border of the cell
            bottom: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the bottom border of the cell
            left: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the left border of the cell
            right: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the right border of the cell
          },
          width: {
            size: 1500,
            type: WidthType.DXA,
          },
          verticalAlign: VerticalAlign.CENTER,
          children: [
            new Paragraph({
              alignment: AlignmentType.LEFT,

              children: [
                new TextRun({
                  text: ``,
                  color: '#000000',
                  font: 'Arial',
                }),
              ],
            }),
          ],
        }),
      ],
    });

    tableFiveRows.push(TableFiveRow1);

    const tableFive = new Table({
      borders: {
        top: { style: BorderStyle.NONE },
        bottom: { style: BorderStyle.NONE },
        left: { style: BorderStyle.NONE },
        right: { style: BorderStyle.NONE },
      },
      alignment: AlignmentType.CENTER,
      width: {
        size: 9100, // Adjust the width size as needed
        type: WidthType.DXA,
      },
      rows: tableFiveRows,
    });

    // avg table
    const tableSixRow1 = new TableRow({
      children: [
        new TableCell({
          borders: {
            top: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the top border of the cell
            bottom: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the bottom border of the cell
            left: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the left border of the cell
            right: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the right border of the cell
          },
          width: {
            size: 2200,
            type: WidthType.DXA,
          },
          verticalAlign: VerticalAlign.CENTER,
          children: [
            new Paragraph({
              alignment: AlignmentType.LEFT,

              children: [
                new TextRun({
                  text: `Avg. Unit Value (Rs) :`,
                  color: '#000000',
                  font: 'Arial',
                  bold: true,
                }),
              ],
            }),
          ],
        }),
        new TableCell({
          borders: {
            top: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the top border of the cell
            bottom: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the bottom border of the cell
            left: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the left border of the cell
            right: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the right border of the cell
          },
          verticalAlign: VerticalAlign.CENTER,
          children: [
            new Paragraph({
              alignment: AlignmentType.LEFT,
              children: [
                new TextRun({
                  text: `${avgValue}`,
                  color: '#000000',
                  font: 'Arial',
                  bold: true,
                  size: 24,
                }),
              ],
            }),
          ],
        }),
      ],
    });
    tableSixRows.push(tableSixRow1);

    const tableAvg = new Table({
      borders: {
        top: { style: BorderStyle.NONE },
        bottom: { style: BorderStyle.NONE },
        left: { style: BorderStyle.NONE },
        right: { style: BorderStyle.NONE },
      },
      alignment: AlignmentType.CENTER,
      width: {
        size: 9100, // Adjust the width size as needed
        type: WidthType.DXA,
      },
      rows: tableSixRows,
    });

    //transport table
    const tableTransportRow1 = new TableRow({
      children: [

        new TableCell({
          margins: {
            left: 100,
            bottom: 100,
          },
          // borders: {
          //   top: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the top border of the cell
          //   bottom: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the bottom border of the cell
          //   left: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the left border of the cell
          //   right: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the right border of the cell
          // },
          shading: {
            fill: 'DBDBDB', // Specifying the background color
          },
          width: {
            size: 2200,
            type: WidthType.DXA,
          },
          verticalAlign: VerticalAlign.TOP,
          children: [
            new Paragraph({
              alignment: AlignmentType.LEFT,
              children: [
                new TextRun({
                  text: `Print Type :`,
                  color: '#000000',
                  font: 'Arial',
                  bold: true,
                }),
              ],
            }),
          ],
        }),
        new TableCell({
          // borders: {
          //   top: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the top border of the cell
          //   bottom: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the bottom border of the cell
          //   left: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the left border of the cell
          //   right: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the right border of the cell
          // },
          margins: {
            left: 100,
            bottom: 100,
          },
          width: {
            size: 4000,
            type: WidthType.DXA,
          },
          verticalAlign: VerticalAlign.TOP,
          children: [
            new Paragraph({
              alignment: AlignmentType.LEFT,

              children: [
                new TextRun({
                  text: `${orderLayoutDetails?.printType == 1
                    ? 'Pocket Print'
                    : orderLayoutDetails?.printType == 2
                      ? 'Chest Print'
                      : '-'
                    }`,
                  color: '#000000',
                  font: 'Arial',
                }),

              ],
            }),
          ],
        }),
        new TableCell({
          margins: {
            left: 100,
            bottom: 100,
          },
          // borders: {
          //   top: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the top border of the cell
          //   bottom: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the bottom border of the cell
          //   left: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the left border of the cell
          //   right: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the right border of the cell
          // },
          shading: {
            fill: 'DBDBDB', // Specifying the background color
          },
          width: {
            size: 2500,
            type: WidthType.DXA,
          },
          verticalAlign: VerticalAlign.TOP,
          children: [
            new Paragraph({
              alignment: AlignmentType.LEFT,

              children: [
                new TextRun({
                  // text: `Pocket :`,
                  text: 'Comm.Per Unit (Rs) :',
                  color: '#000000',
                  font: 'Arial',
                  bold: true,
                }),
              ],
            }),
          ],
        }),
        new TableCell({
          margins: {
            left: 100,
            bottom: 100,
          },
          // borders: {
          //   top: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the top border of the cell
          //   bottom: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the bottom border of the cell
          //   left: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the left border of the cell
          //   right: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the right border of the cell
          // },

          width: {
            size: 2900,
            type: WidthType.DXA,
          },
          verticalAlign: VerticalAlign.TOP,
          children: [
            new Paragraph({
              alignment: AlignmentType.LEFT,

              children: [
                new TextRun({
                  // text: `Pocket :`,
                  text: `${orderLayoutDetails.agentCommPerc}`,
                  color: '#000000',
                  font: 'Arial',
                }),
                // new TextRun({
                //   text: `${orderLayoutDetails?.printType == 1
                //     ? 'Pocket Print'
                //     : orderLayoutDetails?.printType == 2
                //       ? 'Chest Print'
                //       : ''
                //     }`,
                //   color: '#000000',
                //   font: 'Arial',
                // }),
              ],
            }),
          ],
        }),
      ],
    });
    const tableTransportRow2 = new TableRow({
      children: [

        new TableCell({
          margins: {
            left: 100,
            bottom: 100,
          },
          // borders: {
          //   top: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the top border of the cell
          //   bottom: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the bottom border of the cell
          //   left: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the left border of the cell
          //   right: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the right border of the cell
          // },
          shading: {
            fill: 'DBDBDB', // Specifying the background color
          },
          width: {
            size: 2200,
            type: WidthType.DXA,
          },
          verticalAlign: VerticalAlign.TOP,
          children: [
            new Paragraph({
              alignment: AlignmentType.LEFT,
              children: [
                new TextRun({
                  text: `Transport Name :`,
                  color: '#000000',
                  font: 'Arial',
                  bold: true,
                }),
              ],
            }),
          ],
        }),
        new TableCell({
          borders: {
            // top: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the top border of the cell
            // bottom: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the bottom border of the cell
            // left: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the left border of the cell
            // right: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the right border of the cell
          },
          margins: {
            left: 100,
            bottom: 100,
          },
          columnSpan: 1,
          width: {
            size: 4000,
            type: WidthType.DXA,
          },
          verticalAlign: VerticalAlign.TOP,
          children: [
            new Paragraph({
              alignment: AlignmentType.LEFT,

              children: [
                // new TextRun({
                //   text: `${orderLayoutDetails?.printType == 1
                //     ? 'Pocket Print'
                //     : orderLayoutDetails?.printType == 2
                //       ? 'Chest Print'
                //       : '-'
                //     }`,
                //   color: '#000000',
                //   font: 'Arial',
                // }),
                new TextRun({
                  text: `${orderLayoutDetails?.transport}`,
                  color: '#000000',
                  font: 'Arial',
                }),
              ],
            }),
          ],
        }),
        new TableCell({
          margins: {
            left: 100,
            bottom: 100,
          },
          borders: {
            // top: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the top border of the cell
            // bottom: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the bottom border of the cell
            // left: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the left border of the cell
            // right: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the right border of the cell
          },
          shading: {
            fill: 'DBDBDB', // Specifying the background color
          },
          // width: {
          //   size: 2200,
          //   type: WidthType.DXA,
          // },
          verticalAlign: VerticalAlign.TOP,
          children: [
            new Paragraph({
              alignment: AlignmentType.LEFT,

              children: [
                new TextRun({
                  // text: `Pocket :`,
                  text: 'Staff Name :',
                  color: '#000000',
                  font: 'Arial',
                  bold: true,
                }),
              ],
            }),
          ],
        }),
        new TableCell({
          margins: {
            left: 100,
            bottom: 100,
          },
          borders: {
            // top: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the top border of the cell
            // bottom: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the bottom border of the cell
            left: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the left border of the cell
            // right: { style: BorderStyle.NIL, color: '#FFFFFF' }, // White color for the right border of the cell
          },

          // width: {
          //   size: 3200,
          //   type: WidthType.DXA,
          // },
          verticalAlign: VerticalAlign.TOP,
          children: [
            new Paragraph({
              alignment: AlignmentType.LEFT,

              children: [
                new TextRun({
                  // text: `Pocket :`,
                  text: `${orderLayoutDetails?.staffName}`,
                  color: '#000000',
                  font: 'Arial',
                  bold:true,
                  size: 22,
                }),
                // new TextRun({
                //   text: `${orderLayoutDetails?.printType == 1
                //     ? 'Pocket Print'
                //     : orderLayoutDetails?.printType == 2
                //       ? 'Chest Print'
                //       : ''
                //     }`,
                //   color: '#000000',
                //   font: 'Arial',
                // }),
              ],
            }),
          ],
        }),
      ],
    });
    transportTableRows.push(tableTransportRow1, tableTransportRow2);

    const transportTable = new Table({
      margins: { top: 120 },
      // borders: {
      //   top: { style: BorderStyle.NONE },
      //   bottom: { style: BorderStyle.NONE },
      //   left: { style: BorderStyle.NONE },
      //   right: { style: BorderStyle.NONE },
      // },
      alignment: AlignmentType.CENTER,
      width: {
        size: 9100, // Adjust the width size as needed
        type: WidthType.DXA,
      },
      rows: transportTableRows,
    });

    //conditional table two show
    const tableTwoShow =
      orderLayoutDetails?.panelData?.length > 0 ? tabletwo : emptypara;

    const pattren =
      orderLayoutDetails?.patternData?.length > 0 ? PatternDetails : emptypara;

    const backprint =
      (orderLayoutDetails?.dressItem === 'T-Shirts' && hasAtLeastOneValue) ||
        (orderLayoutDetails?.dressItem === 'Pinofers' && hasAtLeastOneValue)
        ? BackprintDetails
        : emptypara;
    const remarksPara = orderLayoutDetails?.remarks != '' ? remarks : emptypara;

    let tablePatternRow1: any;

    if (orderLayoutDetails?.patternData !== '') {
      tablePatternRow1 = new TableRow({
        // height: {
        //   value: 650,
        //   rule: HeightRule.EXACT,
        // },
        children: [
          new TableCell({
            borders: {
              top: { style: BorderStyle.NIL, color: '#FFFFFF' },
              bottom: { style: BorderStyle.NIL, color: '#FFFFFF' },
              left: { style: BorderStyle.NIL, color: '#FFFFFF' },
              right: { style: BorderStyle.NIL, color: '#FFFFFF' },
            },
            // width: {
            //   size: 2000,
            //   type: WidthType.DXA,
            // },
            verticalAlign: VerticalAlign.TOP,
            children: [
              new Paragraph({
                alignment: AlignmentType.LEFT,
                children: [
                  new TextRun({
                    text: `Pattern Details\u00A0: `,
                    color: '#000000',
                    font: 'Arial',
                    bold: true,
                  }),
                  PatternDetails,
                  // Adding the PatternDetails paragraph here
                ],
              }),
            ],
          }),
          new TableCell({
            borders: {
              top: { style: BorderStyle.NIL, color: '#FFFFFF' },
              bottom: { style: BorderStyle.NIL, color: '#FFFFFF' },
              left: { style: BorderStyle.NIL, color: '#FFFFFF' },
              right: { style: BorderStyle.NIL, color: '#FFFFFF' },
            },

            verticalAlign: VerticalAlign.TOP,
            children: [
              new Paragraph({
                alignment: AlignmentType.CENTER,
                children: [
                  new TextRun({
                    text: '\u00A0\u00A0\u00A0\u00A0',
                    bold: true,
                    font: 'Arial',
                  }),
                ],
              }),
              orderLayoutDetails?.imageBase64 !== ''
                ? imageModel
                : noImageModel, // This will appear below 'Image Model:'
            ],
          }),
        ],
      });
    } else {
      tablePatternRow1 = new TableRow({
        // height: {
        //   value: 650,
        //   rule: HeightRule.EXACT,
        // },
        children: [
          new TableCell({
            borders: {
              top: { style: BorderStyle.NIL, color: '#FFFFFF' },
              bottom: { style: BorderStyle.NIL, color: '#FFFFFF' },
              left: { style: BorderStyle.NIL, color: '#FFFFFF' },
              right: { style: BorderStyle.NIL, color: '#FFFFFF' },
            },
            // width: {
            //   size: 2000,
            //   type: WidthType.DXA,
            // },
            verticalAlign: VerticalAlign.TOP,
            children: [
              new Paragraph({
                alignment: AlignmentType.LEFT,
                children: [
                  new TextRun({
                    text: `Pattern Details\u00A0: `,
                    color: '#000000',
                    font: 'Arial',
                    bold: true,
                  }),
                  new TextRun({
                    text: `${orderLayoutDetails?.pattern} `,
                    color: '#000000',
                    font: 'Arial',
                    bold: true,
                  }),
                  // Adding the PatternDetails paragraph here
                ],
              }),
            ],
          }),
          new TableCell({
            borders: {
              top: { style: BorderStyle.NIL, color: '#FFFFFF' },
              bottom: { style: BorderStyle.NIL, color: '#FFFFFF' },
              left: { style: BorderStyle.NIL, color: '#FFFFFF' },
              right: { style: BorderStyle.NIL, color: '#FFFFFF' },
            },

            verticalAlign: VerticalAlign.TOP,
            children: [
              new Paragraph({
                alignment: AlignmentType.RIGHT,
                children: [
                  new TextRun({
                    text: '\u00A0\u00A0\u00A0\u00A0',
                    bold: true,
                    font: 'Arial',
                  }),
                ],
              }),
              orderLayoutDetails?.imageBase64 !== ''
                ? imageModel
                : noImageModel, // This will appear below 'Image Model:'
            ],
          }),
        ],
      });
    }
    // const tablePatternRow1 = new TableRow({
    //   // height: {
    //   //   value: 650,
    //   //   rule: HeightRule.EXACT,
    //   // },
    //   children: [
    //     new TableCell({
    //       borders: {
    //         top: { style: BorderStyle.NIL, color: '#FFFFFF' },
    //         bottom: { style: BorderStyle.NIL, color: '#FFFFFF' },
    //         left: { style: BorderStyle.NIL, color: '#FFFFFF' },
    //         right: { style: BorderStyle.NIL, color: '#FFFFFF' },
    //       },
    //       // width: {
    //       //   size: 2000,
    //       //   type: WidthType.DXA,
    //       // },
    //       verticalAlign: VerticalAlign.CENTER,
    //       children: [
    //         new Paragraph({
    //           alignment: AlignmentType.RIGHT,
    //           children: [
    //             new TextRun({
    //               text: `\u00A0\u00A0\u00A0Pattern Details\u00A0: `,
    //               color: '#000000',
    //               font: 'Arial',
    //               bold: true,
    //             }),
    //             PatternDetails // Adding the PatternDetails paragraph here
    //           ],
    //         }),
    //       ],
    //     }),
    //     new TableCell({
    //       borders: {
    //         top: { style: BorderStyle.NIL, color: '#FFFFFF' },
    //         bottom: { style: BorderStyle.NIL, color: '#FFFFFF' },
    //         left: { style: BorderStyle.NIL, color: '#FFFFFF' },
    //         right: { style: BorderStyle.NIL, color: '#FFFFFF' },
    //       },

    //       verticalAlign: VerticalAlign.TOP,
    //       children: [
    //         new Paragraph({
    //           alignment: AlignmentType.LEFT,
    //           children: [
    //             new TextRun({
    //               text: '\u00A0\u00A0\u00A0\u00A0',
    //               bold: true,
    //               font: 'Arial',
    //             }),
    //           ],
    //         }),
    //         orderLayoutDetails?.imageBase64 !== '' ? imageModel : noImageModel,  // This will appear below 'Image Model:'
    //       ],
    //     })

    //   ],
    // });

    PatternTableRows.push(tablePatternRow1);

    const PatternTable = new Table({
      borders: {
        top: { style: BorderStyle.NONE },
        bottom: { style: BorderStyle.NONE },
        left: { style: BorderStyle.NONE },
        right: { style: BorderStyle.NONE },
      },
      alignment: AlignmentType.CENTER,
      width: {
        size: 9100, // Adjust the width size as needed
        type: WidthType.DXA,
      },
      rows: PatternTableRows,
    });

    const doc = new Document({
      sections: [
        {
          headers: {
            default: image,
          },
          children: [
            additionalInfo,
            // subhead,

            emptypara,
            emptypara,
            tableOrganization,
            emptypara,
            emptypara,
            table,
            emptypara,
            emptypara,
            Quality,
            emptypara,
            PatternTable,
            backprint,
            tableTwoShow,
            emptypara, emptypara, emptypara,
            tablethree,
            transportTable,
            emptypara,
            emptypara,
            tableAvg,
            emptypara,
            remarksPara,
            emptypara,
            emptypara,
            emptypara,
            emptypara,
            emptypara,
            emptypara,
            emptypara,
            emptypara,
            tableFive,
          ],
        },
      ],
    });

    const Year = this.fromDate.getFullYear();
    const Month = (this.fromDate.getMonth() + 1).toString().padStart(2, '0'); // Months are zero-based
    const Day = this.fromDate.getDate().toString().padStart(2, '0');
    // Create the readable format
    const monthNames = [
      "Jan", "Feb", "Mar", "Apr", "May", "Jun",
      "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
    ];
    const Mont = monthNames[(+Month - 1)];
    const readableFormat = `${Day}-${Mont}-${Year}`;
    // Generate the document and offer it for download
    Packer.toBlob(doc).then((blob) => {
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `OrderSheet_${orderLayoutDetails?.organizationType}_${orderLayoutDetails?.orderNo}_${readableFormat}.docx`;
      a.click();
      window.URL.revokeObjectURL(url);
    });
  }
}
