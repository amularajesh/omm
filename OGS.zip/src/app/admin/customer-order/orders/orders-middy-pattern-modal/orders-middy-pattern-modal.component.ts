import { ChangeDetectorRef, Component, OnInit } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";

import { MasterColourItems, PanelColoursItems, StripePipingItems } from "src/app/core/Modals/modals";
import { ChargesService } from "src/app/core/Services/charges.service";
import { MastersService } from "src/app/core/Services/masters.service";
import { OrderService } from "src/app/core/Services/order.service";
import { SampleOrderService } from "src/app/core/Services/sample-order.service";
import { ValidationService } from "src/app/core/Services/validation.service";

/**
 * Orders Middy Pattern Modal Component
 * @export
 * @class OrdersMiddyPatternModalComponent
 * @implements {OnInit}
 */
@Component({
  selector: "app-orders-middy-pattern-modal",
  templateUrl: "./orders-middy-pattern-modal.component.html",
  styleUrls: ["./orders-middy-pattern-modal.component.scss"],
})
export class OrdersMiddyPatternModalComponent implements OnInit {
  /**
   * Get Selected Middy Pattern
   * @type {*}
   */
  selectedMiddyPattern: any;

  /**
   * Get Selected Dress Item
   * @type {*}
   */
  selectedDressItem: any;

  /**
   * Declare Middy Pattern Form
   * @type {FormGroup}
   */
  middyPatternForm!: FormGroup;

  /**
   * Declare Middy Special Pattern Form
   * @type {FormGroup}
   */
  middySpecialPatternForm!: FormGroup;

  /**
   * Declare Middy Normal Pattern Form
   * @type {FormGroup}
   */
  middyNormalPatternForm!: FormGroup;

  /**
   * Get Model No. List
   */
  modelNoList: any;

  /**
   * Get Colours List
   * @type {MasterColourItems[]}
   */
  coloursList: MasterColourItems[] = [];

  /**
   * Get Striped Count List
   * @type {StripePipingItems[]}
   */
  stripedCountList: StripePipingItems[] = [];

  /**
   * Get Selected Striped Radio
   */
  selectedStripedRadio = 0;

  /**
   * Get Selected Striped Count
   * @type {*}
   */
  selectedStripedCount: any;

  /**
   * Get Selected Striped Colour Radio
   */
  selectedStripedColourRadio = 0;

  /**
   * Get Selected Striped Colour
   * @type {*}
   */
  selectedStripedColour: any;

  /**
   * Get Selected Piping Radio
   */
  selectedPipingRadio = 0;

  /**
   * Get Selected Normal Pattern Body
   * @type {*}
   */
  selectedNormalPatternBody: any;

  /**
   * Get Selected Normal Pattern Piping Radio
   */
  selectedNormalPatternPipingRadio = 0;

  /**
   * Get Selected Normal Pattern Piping Color
   * @type {*}
   */
  selectedNormalPatternPipingColour: any;

  /**
   * Get Selected Normal Pattern Pocket Radio
   */
  selectedNormalPatternPocketRadio = 0;

  /**
   * Get Selected Normal Pocket Type
   * @type {*}
   */
  selectedNormalPocketType: any;

  /**
   * Get Selected Piping Colour
   * @type {*}
   */
  selectedPipingColour: any;

  /**
   * Get Pocket Types List
   */
  pocketTypesList: any;

  /**
   * Get Selected Model No
   * @type {*}
   */
  selectedModelNo: any;

  /**
   * Get Selected Pocket Radio
   */
  selectedPocketRadio = 0;

  /**
   * Get Selected Pocket Type
   * @type {*}
   */
  selectedPocketType: any;

  /**
   * Get Selected Inner rope Radio
   */
  selectedInnerRopeRadio = 0;

  /**
   * Get Selected Body
   * @type {*}
   */
  selectedBody: any;

  /**
   * Get Selected Panel
   * @type {*}
   */
  selectedPanel: any;

  /**
   * Get Panel Colours List
   * @type {PanelColoursItems[]}
   */
  panelColoursList: PanelColoursItems[] = [];

  /**
   * Get Saved Special Middy Pattern Details
   * @type {*}
   */
  savedSpecialMiddyPatternDetails: any;

  /**
   * Get Saved Normal Middy Pattern Details
   * @type {*}
   */
  savedNormalMiddyPatternDetails: any;

  /**
   * Get Is Success Snackbar Flag
   */
  isSuccessSnackbar = false;

  /**
   * Get Is Overlay Visible Flag
   */
  isOverlayVisible = false;

  /**
   * Get Inner HTML Message
   */
  innerHTMLMessage = '';

  /**
   * Get Inner HTML Order Id
   */
  innerHTMLOrderId = '';

  /**
   * Get Middy Patterns Form Validations
   */
  middyPatternFormValidation = this.validationService.middyPattern;

  /**
   * Creates an instance of OrdersMiddyPatternModalComponent.
   * @param {ValidationService} validationService
   * @param {FormBuilder} formBuilder
   * @param {SampleOrderService} sampleOrderService
   * @param {OrderService} orderService
   * @param {MastersService} masterService
   * @param {ChargesService} chargesService
   * @param {ChangeDetectorRef} cdr
   */
  constructor(
    private validationService: ValidationService,
    private formBuilder: FormBuilder,
    private sampleOrderService: SampleOrderService,
    private orderService: OrderService,
    private masterService: MastersService,
    private chargesService: ChargesService,
    private cdr: ChangeDetectorRef
  ) {
    /* Get Pattern Details from behavior subject */
    this.orderService.orderPatternDetailsObj.subscribe((val: any) => {
      if (Object.keys(val).length > 0) {
        this.savedSpecialMiddyPatternDetails = val?.specialforMiddy;
        this.savedNormalMiddyPatternDetails = val?.normalforMiddy;
      } else {
        this.savedSpecialMiddyPatternDetails = "";
        this.savedNormalMiddyPatternDetails = "";
      }
    });
  }

  /**
   * Life Cycle Hook Initialization
   */
  ngOnInit(): void {
    this.getColoursList();
    this.middyPatternFormValidations();
    this.middySpecialPatternFormValidations();
    this.middyNormalPatternFormValidations();
  }

  ngAfterViewInit(): void {
  }

  /**
   * Initialize Middy Pattern Form Validations
   */
  middyPatternFormValidations() {
    this.middyPatternForm = this.formBuilder.group({
      pattern: [
        this.selectedMiddyPattern?.patternType || "",
        [Validators.required],
      ],
      dressItem: [
        this.selectedDressItem?.dressItemName || "",
        [Validators.required],
      ],
    });
  }

  /**
   * Initialize Middy Special Pattern Form Validations
   */
  middySpecialPatternFormValidations() {
    let modelNoValue = this.savedSpecialMiddyPatternDetails?.modelId || "";
    let pocketRadioValue = "0";
    let pipingRadioValue = "0";
    let stripedRadioValue = "0";
    let stripedColourRadioValue = "0";
    let stripedCountSelectValue = "";
    let stripedColourSelectValue = "";
    let pipingColourSelectValue = "";
    let innerRopeRadioValue = "0";
    let pocketTypeSelectValue = "";

    if (this.savedSpecialMiddyPatternDetails) {

      pipingRadioValue = this.savedSpecialMiddyPatternDetails?.isPiping ? "1" : "0";
      this.onChangePipingRadio(pipingRadioValue);

      if (this.selectedPipingRadio === 1) {
        pipingColourSelectValue = this.savedSpecialMiddyPatternDetails?.pipingColorID;
      }

      pocketRadioValue = this.savedSpecialMiddyPatternDetails?.isPocket ? "1" : "0";
      this.onChangePocketRadio(pocketRadioValue);

      stripedRadioValue = this.savedSpecialMiddyPatternDetails?.isStripes ? "1" : "0";
      this.onChangeStripedRadio(stripedRadioValue);

      if (this.selectedPocketRadio === 1) {
        pocketTypeSelectValue = this.savedSpecialMiddyPatternDetails?.pocketID;
      }

      innerRopeRadioValue = this.savedSpecialMiddyPatternDetails?.isInnerRope ? "1" : "0";
      this.onChangeInnerRopeRadio(innerRopeRadioValue);

      this.panelColoursList = JSON.parse(localStorage.getItem("middyPanelColors")!) || [];
    } else {
      this.onResetSpecialSelectedFields();
    }

    this.middySpecialPatternForm = this.formBuilder.group({
      modelNo: [modelNoValue, [Validators.required]],
      piping: [pipingRadioValue],
      pipingColourSelect: [pipingColourSelectValue],
      strippedRadio: [stripedRadioValue],
      stripedCountSelect: [stripedCountSelectValue],
      stripedColourRadio: [stripedColourRadioValue],
      stripedColourSelect: [stripedColourSelectValue],
      pocket: [pocketRadioValue],
      pocketTypeSelect: [pocketTypeSelectValue],
      InnerRopeRadio: [innerRopeRadioValue],
      bodySelect: [""],
      panelSelect: [""],
    });
  }

  /**
   * Initialize Middy Normal Pattern Form Validations
   */
  middyNormalPatternFormValidations() {
    let bodyValue = this.savedNormalMiddyPatternDetails?.bodyColorID || "";
    let pipingRadioValue = "0";
    let pipingColorValue = "";
    let pocketValue = this.savedNormalMiddyPatternDetails?.isPocket ? "1" : "0";

    if (this.savedNormalMiddyPatternDetails) {

      if (+this.savedNormalMiddyPatternDetails?.pipingColorID !== 0) {
        pipingRadioValue = "1";
      }
      this.onChangeOpenPatternPipingRadio(pipingRadioValue);

      if (this.selectedNormalPatternPipingRadio === 1) {
        pipingColorValue = this.savedNormalMiddyPatternDetails?.pipingColorID;
      }

      this.onChangeOpenPatternPocketRadio(pocketValue);

    } else {
      this.onResetNormalPatternSelectedFields();
    }

    this.middyNormalPatternForm = this.formBuilder.group({
      openBodySelect: [bodyValue, [Validators.required]],
      openPatternPiping: [pipingRadioValue],
      openPatternPipingColourSelect: [pipingColorValue],
      openPatternPocket: [pocketValue],
      openPatternPocketType: ['']
    });
  }

  /**
   * Get Middy Pattern Form Controls
   * @readonly
   */
  get middyPatternFormControls() {
    return this.middyPatternForm.controls;
  }

  /**
   * Get Middy Special Pattern Form Controls
   * @readonly
   */
  get middySpecialPatternFormControls() {
    return this.middySpecialPatternForm.controls;
  }

  /**
   * Get Middy Normal Pattern Form Controls
   * @readonly
   */
  get middyNormalPatternFormControls() {
    return this.middyNormalPatternForm.controls;
  }

  /**
   * This method is used to open the Middy Pattern Modal
   * @param {*} selectedPattern
   * @param {*} selectedDressItem
   */
  openModal(selectedPattern: any, selectedDressItem: any) {
    this.selectedMiddyPattern = selectedPattern;
    this.selectedDressItem = selectedDressItem;
    this.middyPatternFormValidations();
    this.getColoursList();
    if (this.selectedMiddyPattern?.patternType === "Special") {
      this.middySpecialPatternFormValidations();
      if (this.savedSpecialMiddyPatternDetails) {
        this.getModelNoList("noEvent");
      } else {
        this.getModelNoList("");
      }
    } else {
      this.middyNormalPatternFormValidations();
    }
    document.getElementById("middyPatternModalButton")?.click();
    const modal = document.getElementById("middyPattern") as HTMLElement;
    const snackbar = document.getElementById("middySnackbar") as HTMLElement;
    modal.style.display = "block";
    snackbar.style.zIndex = "9999";
  }

  /**
   * This method is used to reset the selected fields
   */
  onResetSpecialSelectedFields() {
    this.selectedPipingRadio = 0;
    this.selectedStripedRadio = 0;
    this.selectedStripedColourRadio = 0;
    this.selectedPocketRadio = 0;
    this.selectedInnerRopeRadio = 0;
    this.selectedStripedCount = "";
    this.selectedStripedColour = "";
    this.selectedPocketType = "";
    this.selectedPipingColour = "";
    this.selectedModelNo = "";
    this.panelColoursList = [];
  }

  /**
   * This method is used to reset the normal pattern form selected fields
   */
  onResetNormalPatternSelectedFields() {
    this.selectedNormalPatternBody = "";
    this.selectedNormalPatternPocketRadio = 0;
    this.selectedNormalPatternPipingRadio = 0;
    this.selectedNormalPatternPipingColour = "";
  }

  /**
   * This method is used to get colours list
   */
  getColoursList() {
    this.masterService.getColours().subscribe({
      next: (res: any) => {
        this.coloursList = res.result;

        if (this.savedSpecialMiddyPatternDetails) {

          if (this.selectedPipingRadio === 1) {
            let pipingColourSelectValue = this.savedSpecialMiddyPatternDetails?.pipingColorID;
            setTimeout(() => {
              this.middySpecialPatternFormControls["pipingColourSelect"].setValue(pipingColourSelectValue?.toString());
              this.cdr.detectChanges();
            }, 50);
            this.onChangePipingColour(pipingColourSelectValue);
          }

          if (this.selectedStripedColourRadio === 1) {
            let stripedColourSelectValue = this.savedSpecialMiddyPatternDetails?.stripeColorID;
            setTimeout(() => {
              this.middySpecialPatternFormControls["stripedColourSelect"].setValue(stripedColourSelectValue?.toString());
              this.cdr.detectChanges();
            }, 50);
            this.onChangeStripedColour(stripedColourSelectValue);
          }

          const responsePanelColorsItems = this.savedSpecialMiddyPatternDetails?.panelColors?.map(
            (responseData: any, index: any) => {
              const bodyColour = this.coloursList?.find((element: any) => +responseData?.bodyColorId === +element?.colourId);
              const panelColour = this.coloursList?.find((element: any) => +responseData?.panelColorId === +element?.colourId);
              return {
                id: index,
                body: bodyColour,
                panel: panelColour,
              };
            }
          );

          if (responsePanelColorsItems?.length > 0) {
            localStorage.setItem("middyPatternPanelColoursList", JSON.stringify(responsePanelColorsItems));
            this.panelColoursList = responsePanelColorsItems || [];
          } else {
            this.panelColoursList = JSON.parse(localStorage.getItem("middyPatternPanelColoursList")!) || [];
          }

        } else if (this.savedNormalMiddyPatternDetails) {
          let bodyValue = this.savedNormalMiddyPatternDetails?.bodyColorID;
          setTimeout(() => {
            this.middyNormalPatternFormControls["openBodySelect"].setValue(bodyValue?.toString());
            this.cdr.detectChanges();
          }, 50);
          this.onChangeOpenPatternBodySelect(bodyValue);

          let pipingColorValue = this.savedNormalMiddyPatternDetails?.pipingColorID;
          setTimeout(() => {
            this.middyNormalPatternFormControls["openPatternPipingColourSelect"].setValue(pipingColorValue?.toString());
            this.cdr.detectChanges();
          }, 50);
          this.onChangeOpenPatternPipingColour(pipingColorValue);

        }
      },
      error: (err: any) => {
        this.coloursList = [];
      },
    });
  }

  /**
   * This method is used to get striped count list
   */
  getStripedCountList(eventFlag: any) {
    this.sampleOrderService.getStripedCount().subscribe({
      next: (res: any) => {
        this.stripedCountList = res.result;
        if (eventFlag) {
          if (this.selectedStripedRadio === 1) {
            let stripedCountSelectValue = this.savedSpecialMiddyPatternDetails?.stripeCount;
            setTimeout(() => {
              this.middySpecialPatternFormControls["stripedCountSelect"].setValue(stripedCountSelectValue?.toString());
              this.cdr.detectChanges();
            }, 50);
            this.onChangeStripedCount(stripedCountSelectValue);

            let stripedColourRadioValue = this.savedSpecialMiddyPatternDetails?.isStripeColor ? "1" : "0";
            setTimeout(() => {
              this.middySpecialPatternFormControls["stripedColourRadio"].setValue(stripedColourRadioValue?.toString());
              this.cdr.detectChanges();
            }, 50);
            this.onChangeStripedColourRadio(stripedColourRadioValue);

            if (this.selectedStripedColourRadio === 1) {
              let stripedColourSelectValue = this.savedSpecialMiddyPatternDetails?.stripeColorID;
              setTimeout(() => {
                this.middySpecialPatternFormControls["stripedColourSelect"].setValue(stripedColourSelectValue?.toString());
                this.cdr.detectChanges();
              }, 50);
              this.onChangeStripedColour(stripedColourSelectValue);
            }
          }

        }
      },
      error: (err: any) => {
        this.stripedCountList = [];
      },
    });
  }

  /**
   * This method is used to get the Model list
   */
  getModelNoList(eventFlag: any) {
    this.chargesService.getModelsByDressItemId(this.selectedDressItem?.dressItemId).subscribe({
      next: (res: any) => {
        this.modelNoList = res.result;
        if (eventFlag) {
          let modelNoValue = this.savedSpecialMiddyPatternDetails?.modelId;
          setTimeout(() => {
            this.middySpecialPatternFormControls["modelNo"].setValue(modelNoValue?.toString());
            this.cdr.detectChanges();
          }, 50);
          this.onChangeModelNo(modelNoValue);
        }
      },
      error: (err: any) => {
        this.modelNoList = [];
      },
    });
  }

  /**
   * This method is used to get colours list
   */
  getPocketTypesList(eventFlag: any) {
    this.chargesService.getPocketTypesByDressItemId(this.selectedDressItem?.dressItemId).subscribe({
      next: (res: any) => {
        this.pocketTypesList = res.result;
        if (eventFlag) {

          if (this.selectedPocketRadio === 1) {
            let pocketTypeSelectValue = this.savedSpecialMiddyPatternDetails?.pocketID;
            setTimeout(() => {
              this.middySpecialPatternFormControls["pocketTypeSelect"].setValue(pocketTypeSelectValue?.toString());
              this.cdr.detectChanges();
            }, 50);
            this.onChangePocketType(pocketTypeSelectValue);
          }


          if (this.selectedNormalPatternPocketRadio == 1) {
            let pocketTypeSelectValue = this.savedNormalMiddyPatternDetails?.pocketId;
            setTimeout(() => {
              this.middyNormalPatternFormControls["openPatternPocketType"].setValue(pocketTypeSelectValue?.toString());
              this.cdr.detectChanges();
            }, 50);
            this.onChangeNormalPocketType(pocketTypeSelectValue);
          }
        }
      },
      error: (err: any) => {
        this.pocketTypesList = [];
      },
    });
  }

  /**
   * This method is used to add validators
   * @param {*} formControls
   * @param {*} controls
   */
  onAddValidators(formControls: any, controls: any) {
    controls?.forEach((control: any) => {
      formControls[control].addValidators([Validators.required]);
      formControls[control].updateValueAndValidity({ onlySelf: true });
    });
  }

  /**
   * This method is used to remove validators
   * @param {*} formControls
   */
  onRemoveValidators(formControls: any, controls: any) {
    controls?.forEach((control: any) => {
      formControls[control].removeValidators([Validators.required]);
      formControls[control].updateValueAndValidity({ onlySelf: true });
    });
  }

  /**
   * This method is used to update value and validity
   * @param {*} formControls
   */
  onUpdateValueAndValidity(formControls: any, controls: any) {
    controls?.forEach((control: any) => {
      formControls[control].setValue("");
      formControls[control].markAsUntouched({ onlySelf: true });
      formControls[control].updateValueAndValidity({ onlySelf: true });
    });
  }

  /**
   * This method is used to change the model no
   * @param {*} event
   */
  onChangeModelNo(event: any) {
    let modelNoValue = event?.target ? event?.target.value : event;
    this.selectedModelNo = this.modelNoList?.filter(
      (item: any) => +item.modelId === +modelNoValue
    )[0];
  }

  /**
   * This method is used to change the piping radio
   * @param {*} event
   */
  onChangePipingRadio(event: any) {
    let pipingRadioValue = event?.target ? event?.target.value : event;
    this.selectedPipingRadio = +pipingRadioValue;
    if (this.selectedPipingRadio === 1) {
      this.onAddValidators(this.middySpecialPatternFormControls, ["pipingColourSelect"]);
    } else {
      this.onRemoveValidators(this.middySpecialPatternFormControls, ["pipingColourSelect"]);
    }
    if (event?.target) {
      this.selectedPipingColour = "";
      this.onUpdateValueAndValidity(this.middySpecialPatternFormControls, ["pipingColourSelect"]);
    }
  }

  /**
   * This method is used to change the piping colour
   * @param {*} event
   */
  onChangePipingColour(event: any) {
    let pipingColorValue = event?.target ? event?.target.value : event;
    this.selectedPipingColour = this.coloursList?.filter(
      (item: any) => +item.colourId === +pipingColorValue
    )[0];
  }

  /**
   * This method is used to change the  stripped radio
   * @param {*} event
   */
  onChangeStripedRadio(event: any) {
    let stripedRadioValue = event?.target ? event?.target.value : event;
    this.selectedStripedRadio = +stripedRadioValue;
    if (this.selectedStripedRadio === 1) {
      this.onAddValidators(this.middySpecialPatternFormControls, [
        "stripedCountSelect",
      ]);
      if (event?.target) {
        this.getStripedCountList("");
      } else {
        this.getStripedCountList("noEvent");
      }
    } else {
      this.onRemoveValidators(this.middySpecialPatternFormControls, [
        "stripedCountSelect",
      ]);
      this.middySpecialPatternFormControls["stripedColourRadio"].setValue("0");
      this.selectedStripedColourRadio = 0;
      this.onRemoveValidators(this.middySpecialPatternFormControls, [
        "stripedColourSelect",
      ]);
    }
    this.selectedStripedCount = "";
    if (event?.target) {
      this.onUpdateValueAndValidity(this.middySpecialPatternFormControls, ["stripedCountSelect"]);
    }
  }

  /**
   * This method is used to change the striped count
   * @param {*} event
   */
  onChangeStripedCount(event: any) {
    let stripedCountValue = event?.target ? event?.target.value : event;
    this.selectedStripedCount = this.stripedCountList?.filter(
      (item: any) => +item.id === +stripedCountValue
    )[0];
  }

  /**
   * This method is used to change the  stripped color radio
   * @param {*} event
   */
  onChangeStripedColourRadio(event: any) {
    let stripedColorRadioValue = event?.target ? event?.target.value : event;
    this.selectedStripedColourRadio = +stripedColorRadioValue;
    if (this.selectedStripedColourRadio === 1) {
      this.onAddValidators(this.middySpecialPatternFormControls, [
        "stripedColourSelect",
      ]);
    } else {
      this.onRemoveValidators(this.middySpecialPatternFormControls, [
        "stripedColourSelect",
      ]);
    }
    this.selectedStripedColour = "";
    if (event?.target) {
      this.onUpdateValueAndValidity(this.middySpecialPatternFormControls, ["stripedColourSelect"]);
    }
  }

  /**
   * This method is used to change the striped colour
   * @param {*} event
   */
  onChangeStripedColour(event: any) {
    let stripedColorValue = event?.target ? event?.target.value : event;
    this.selectedStripedColour = this.coloursList?.filter(
      (item: any) => +item.colourId === +stripedColorValue
    )[0];
  }

  /**
   * This method is used to change the pocket radio
   * @param {*} event
   */
  onChangePocketRadio(event: any) {
    let pocketRadioValue = event?.target ? event?.target.value : event;
    this.selectedPocketRadio = +pocketRadioValue;
    if (this.selectedPocketRadio === 1) {
      this.onAddValidators(this.middySpecialPatternFormControls, ["pocketTypeSelect"]);
      if (event?.target) {
        this.getPocketTypesList("");
      } else {
        this.getPocketTypesList("noEvent");
      }
    } else {
      this.onRemoveValidators(this.middySpecialPatternFormControls, [
        "pocketTypeSelect",
      ]);
    }
    if (event?.target) {
      this.selectedPocketType = "";
      this.onUpdateValueAndValidity(this.middySpecialPatternFormControls, [
        "pocketTypeSelect",
      ]);
    }
  }

  /**
   * This method is used to change the pocket type
   * @param {*} event
   */
  onChangePocketType(event: any) {
    let pocketTypeValue = event?.target ? event?.target.value : event;
    this.selectedPocketType = this.pocketTypesList?.filter((item: any) => +item.pocketTypeId === +pocketTypeValue)[0];
  }

  /**
   * This method is used to change the inner rope radio
   * @param {*} event
   */
  onChangeInnerRopeRadio(event: any) {
    let innerRopeRadioValue = event?.target ? event?.target.value : event;
    this.selectedInnerRopeRadio = +innerRopeRadioValue;
  }

  /**
   * This method is used to change the body
   * @param {*} event
   */
  onChangeBody(event: any) {
    this.selectedBody = this.coloursList?.filter(
      (item: any) => +item.colourId === +event.target.value
    )[0];
  }

  /**
   * This method is used to change the Panel
   * @param {*} event
   */
  onChangePanel(event: any) {
    this.selectedPanel = this.coloursList?.filter(
      (item: any) => +item.colourId === +event.target.value
    )[0];
  }

  /**
   * This method is used to add the body panels
   */
  onClickAddBodyPanel() {
    this.onAddValidators(this.middySpecialPatternFormControls, [
      "bodySelect",
      "panelSelect",
    ]);

    const body = this.selectedBody;
    const panel = this.selectedPanel;

    if (!body || !panel) {
      this.middySpecialPatternFormControls["bodySelect"].markAsTouched({
        onlySelf: true,
      });
      this.middySpecialPatternFormControls["panelSelect"].markAsTouched({
        onlySelf: true,
      });
      return;
    }

    const existingRecord = this.panelColoursList?.find((item: any) => {
      return (
        item.body?.colourName === body?.colourName &&
        item.panel?.colourName === panel?.colourName
      );
    });

    if (existingRecord) {
      this.showSnackbar("Record Already Exists", '', false, true);
      return;
    }

    /* Prepare the panel colour item object */
    const obj: any = {
      id: this.panelColoursList?.length > 0 ? this.panelColoursList?.length : 0,
      body: this.selectedBody,
      panel: this.selectedPanel,
    };

    /* Push the panel colour item */
    this.panelColoursList.push(obj);
    this.selectedBody = "";
    this.selectedPanel = "";
    this.onRemoveValidators(this.middySpecialPatternFormControls, [
      "bodySelect",
      "panelSelect",
    ]);
    this.onUpdateValueAndValidity(this.middySpecialPatternFormControls, [
      "bodySelect",
      "panelSelect",
    ]);
  }

  /**
   * This method is used to delete the panel colour item
   * @param {*} panelColour
   */
  onClickDeletePanelColourItem(panelColour: any) {
    this.panelColoursList = this.panelColoursList?.filter(
      (item: any) => item.id !== panelColour.id
    );
  }

  /**
   * This method is used to change the normal pattern body
   * @param {*} event
   */
  onChangeOpenPatternBodySelect(event: any) {
    let bodyValue = event?.target ? event?.target.value : event;
    this.selectedNormalPatternBody = this.coloursList?.filter(
      (item: any) => +item.colourId === +bodyValue
    )[0];
  }

  /**
   * This method is used to change the normal pattern piping radio
   * @param {*} event
   */
  onChangeOpenPatternPipingRadio(event: any) {
    let pipingRadioValue = event?.target ? event?.target.value : event;
    this.selectedNormalPatternPipingRadio = +pipingRadioValue;
    if (this.selectedNormalPatternPipingRadio === 1) {
      this.onAddValidators(this.middyNormalPatternFormControls, [
        "openPatternPipingColourSelect",
      ]);
    } else {
      this.onRemoveValidators(this.middyNormalPatternFormControls, [
        "openPatternPipingColourSelect",
      ]);
    }
    this.selectedNormalPatternPipingColour = "";
    this.onUpdateValueAndValidity(this.middyNormalPatternFormControls, [
      "openPatternPipingColourSelect",
    ]);
  }

  /**
   * This method is used to change the normal pattern piping colour
   * @param {*} event
   */
  onChangeOpenPatternPipingColour(event: any) {
    let pipingColorValue = event?.target ? event?.target.value : event;
    this.selectedNormalPatternPipingColour = this.coloursList?.filter(
      (item: any) => +item.colourId === +pipingColorValue
    )[0];
  }

  /**
   * This method is used to change the pocket radio
   * @param {*} event
   */
  onChangeOpenPatternPocketRadio(event: any) {
    let pocketRadioValue = event?.target ? event?.target.value : event;
    this.selectedNormalPatternPocketRadio = +pocketRadioValue;

    if (this.selectedNormalPatternPocketRadio === 1) {
      if (event?.target) {
        this.getPocketTypesList("");
      } else {
        this.getPocketTypesList("noEvent");
      }
      this.onAddValidators(this.middyNormalPatternFormControls, ["openPatternPocketType"]);
    } else {
      this.onRemoveValidators(this.middyNormalPatternFormControls, ["openPatternPocketType"]);
    }
    if (event?.target) {
      this.selectedNormalPocketType = "";
      this.onUpdateValueAndValidity(this.middyNormalPatternFormControls, ["openPatternPocketType"]);
    }
  }

  /**
   * This method is used to change the pocket type
   * @param {*} event
   */
  onChangeNormalPocketType(event: any) {
    let pocketTypeValue = event?.target ? event?.target.value : event;
    this.selectedNormalPocketType = this.pocketTypesList?.filter(
      (item: any) => +item.pocketTypeId === +pocketTypeValue
    )[0];
  }

  /**
   * This method is used to reset the selected color fields
   */
  onResetSpecialColorFields() {
    this.selectedBody = "";
    this.selectedPanel = "";
    this.onRemoveValidators(this.middySpecialPatternFormControls, [
      "bodySelect",
      "panelSelect",
    ]);
    this.onUpdateValueAndValidity(this.middySpecialPatternFormControls, [
      "bodySelect",
      "panelSelect",
    ]);
  }

  /**
   * This method is used to show the snackbar
   * @param {string} message
   * @param {*} orderId
   * @param {boolean} successFlag
   * @param {boolean} isModalOverlay
   */
  showSnackbar(message: string, orderId: any, successFlag: boolean, isModalOverlay: boolean) {
    const snackbar = document.getElementById("middySnackbar") as HTMLElement;
    this.innerHTMLMessage = message;
    this.innerHTMLOrderId = orderId;
    this.isSuccessSnackbar = successFlag;
    this.isOverlayVisible = isModalOverlay;
    snackbar.style.display = "block";
  }

  /**
   * This method is used to hide the snackbar
   */
  onClickSnackbarOkButton() {
    const snackbar = document.getElementById("middySnackbar") as HTMLElement;
    snackbar.style.display = "none";
    this.innerHTMLOrderId = '';
    this.innerHTMLMessage = '';
    this.isOverlayVisible = false;
    this.isSuccessSnackbar = false;
  }

  /**
   * This method is used to save the special middy pattern details
   */
  onClickSaveSpecialPatternDetails() {
    this.onResetSpecialColorFields();

    /** This will return false if form fields are invalid and return */
    if (this.middySpecialPatternForm.invalid) {
      this.validationService.validateAllFormFields(
        this.middySpecialPatternForm
      );
      return;
    }

    /* Prepare Special Model For Nicker Panel Colors Array */
    const panelColors = [];
    console.log(this.panelColoursList);

    for (let index = 0; index < this.panelColoursList?.length; index++) {
      const element = this.panelColoursList[index];
      panelColors.push({
        bodyColorId: +element.body.colourId,
        panelColorId: +element.panel.colourId,
        patternId: +this.selectedMiddyPattern?.patternTypeId,
      });
    }
    console.log(this.selectedModelNo);

    /* Prepare the divider pattern object */
    const SpecialPatternForMiddyObj: any = {
      modelId: +this.selectedModelNo?.modelId
        ? +this.selectedModelNo?.modelId
        : +this.middySpecialPatternFormControls["modelNo"]?.value,
      patternID: +this.selectedMiddyPattern?.patternTypeId,

      isPiping: this.selectedPipingRadio === 1,
      pipingColorID:
        this.selectedPipingRadio === 1
          ? +this.selectedPipingColour?.colourId
            ? +this.selectedPipingColour?.colourId
            : +this.middySpecialPatternFormControls["pipingColourSelect"]?.value
          : 0,
      isPocket: this.selectedPocketRadio === 1,
      pocketID:
        this.selectedPocketRadio === 1
          ? +this.selectedPocketType?.pocketTypeId
            ? +this.selectedPocketType?.pocketTypeId
            : +this.middySpecialPatternFormControls["pocketTypeSelect"]?.value
          : 0,
      isPocketColor: false,
      pocketColorID: 0,
      isStripes: this.selectedStripedRadio === 1,
      stripeCount:
        this.selectedStripedRadio === 1
          ? +this.selectedStripedCount?.id
            ? +this.selectedStripedCount?.id
            : +this.middySpecialPatternFormControls["stripedCountSelect"]?.value
          : 0,
      isStripeColor:
        this.selectedStripedRadio === 1 &&
        this.selectedStripedColourRadio === 1,
      stripeColorID:
        this.selectedStripedRadio === 1 && this.selectedStripedColourRadio === 1
          ? +this.selectedStripedColour?.colourId
            ? +this.selectedStripedColour?.colourId
            : +this.middySpecialPatternFormControls["stripedColourSelect"]
              ?.value
          : 0,
      isInnerRope: this.selectedInnerRopeRadio === 1,
      panelColors: panelColors?.length > 0 ? panelColors : [],
    };

    /* Prepare the middy pattern object */
    const obj = {
      isSave: true,
      specialforMiddy: SpecialPatternForMiddyObj,
    };
    console.log(obj);

    localStorage.setItem(
      "middyPatternPanelColoursList",
      JSON.stringify(this.panelColoursList)
    );
    this.orderService.orderPatternDetailsObj.next(obj);
    document.getElementById("closeMiddyPatternModal")?.click();
  }

  /**
   * This method is used to save the normal middy pattern details
   */
  onClickSaveOpenPatternDetails() {
    /** This will return false if form fields are invalid and return */
    if (this.middyNormalPatternForm.invalid) {
      this.validationService.validateAllFormFields(this.middyNormalPatternForm);
      return;
    }
    console.log(this.selectedNormalPatternBody, "bodycolorid");
    console.log(this.middyNormalPatternFormControls["openBodySelect"]?.value);

    /* Prepare the middy normal pattern object */
    const openPatternForMiddyObj: any = {
      bodyColorID: +this.middyNormalPatternFormControls["openBodySelect"]
        ?.value,
      pipingColorID:
        this.selectedNormalPatternPipingRadio === 1
          ? +this.selectedNormalPatternPipingColour?.colourId
            ? +this.selectedNormalPatternPipingColour?.colourId
            : +this.middyNormalPatternFormControls[
              "openPatternPipingColourSelect"
            ]?.value
          : 0,
      patternID: +this.selectedMiddyPattern?.patternTypeId,
      isPocket: this.selectedNormalPatternPocketRadio === 1,
      pocketId:
        this.selectedNormalPatternPocketRadio === 1
          ? +this.selectedNormalPocketType?.pocketTypeId
            ? +this.selectedNormalPocketType?.pocketTypeId
            : +this.middyNormalPatternFormControls["openPatternPocketType"]?.value
          : 0,
      orderId: 0,
    };

    /* Prepare the middy normal pattern object */
    const obj = {
      isSave: true,
      normalforMiddy: openPatternForMiddyObj,
    };

    console.log(obj);
    this.orderService.orderPatternDetailsObj.next(obj);
    document.getElementById("closeMiddyPatternModal")?.click();
  }
}
