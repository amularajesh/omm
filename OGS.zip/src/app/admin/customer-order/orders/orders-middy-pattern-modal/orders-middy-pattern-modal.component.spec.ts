import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OrdersMiddyPatternModalComponent } from './orders-middy-pattern-modal.component';

describe('OrdersMiddyPatternModalComponent', () => {
  let component: OrdersMiddyPatternModalComponent;
  let fixture: ComponentFixture<OrdersMiddyPatternModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OrdersMiddyPatternModalComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(OrdersMiddyPatternModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
