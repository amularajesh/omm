import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import {
  AlignmentType,
  Document,
  FrameAnchorType,
  Header,
  HorizontalPositionAlign,
  ImageRun,
  Packer,
  Paragraph,
  Table,
  TableCell,
  TableRow,
  TextRun,
  VerticalAlign,
  VerticalPositionAlign,
  WidthType
} from 'docx';

import { SnackbarModalComponent } from 'src/app/core/Dialogues/snackbar-modal/snackbar-modal.component';
import { LoaderService } from 'src/app/core/Services/loader.service';
import { OrderService } from 'src/app/core/Services/order.service';
import { ValidationService } from 'src/app/core/Services/validation.service';

/**
 * Proforma Invoice Component
 * @export
 * @class ProformaInvoiceComponent
 * @implements {OnInit}
 */
@Component({
  selector: 'app-proforma-invoice',
  templateUrl: './proforma-invoice.component.html',
  styleUrls: ['./proforma-invoice.component.scss'],
})
export class ProformaInvoiceComponent implements OnInit {
  /**
   * Get Snackbar Modal Component
   * @type {SnackbarModalComponent}
   */
  @ViewChild("snackbarModalComponent") snackbarModalComponent!: SnackbarModalComponent;

  fromDate: any;
  /**
   * Proforma Invoice Form Declaration
   */
  proformaFormArray: FormGroup[] = [];

  /**
   * Get Proforma Details
   * @type {*}
   */
  proformaDetails: any;

  /**
   * Get Proforma Form Validations
   */
  proformaFormValidation = this.validationService.addOrder;

  /**
   * Get Proforma Form Validations
   */
  patterns = this.validationService.patterns;

  /**
   * Get Order Proforma Details
   */
  orderProformaDetails: any;

  /**
   * Get Total Amount
   */
  totalAmount = 0;
  amountInWords: any;
  totalQuantity: any;
  formattedDate: any;

  /**
   * Creates an instance of ProformaInvoiceComponent.
   * @param {Router} router
   * @param {FormBuilder} formBuilder
   * @param {ValidationService} validationService
   * @param {OrderService} orderService
   * @param {LoaderService} loaderService
   */
  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private validationService: ValidationService,
    private orderService: OrderService,
    private loaderService: LoaderService
  ) {
    this.fromDate = new Date();
    /* Get Order Layout Details from behavior subject*/
    this.orderService.orderProformaDetails.subscribe((res: any) => {
      if (Object.keys(res).length > 0) {
        this.orderProformaDetails = res;
        this.proformaDetails = res?.orderItems || [];
      } else {
        this.orderProformaDetails = null;
        this.onClickNavigateToList();
      }
    });
  }

  /**
   * Life Cycle Hook Initialization
   */
  ngOnInit(): void {
    this.proformaFormArray = this.proformaDetails.map((proforma: any) =>
      this.formBuilder.group({
        quantity: [
          proforma.invoiceQuantity,
          [
            Validators.required,
            Validators.minLength(
              this.proformaFormValidation.quantity.minLength
            ),
            Validators.maxLength(
              this.proformaFormValidation.quantity.maxLength
            ),
            Validators.pattern(this.patterns.quantity),
          ],
        ],
      })
    );

    if (this.proformaDetails?.length > 0) {
      let amount = 0;
      for (let index = 0; index < this.proformaDetails.length; index++) {
        const element = this.proformaDetails[index].amount;
        amount += +element;
      }
      this.totalAmount = amount;
    }
    if (this.proformaDetails?.length > 0) {
      let invoiceQuantity = 0;
      for (let index = 0; index < this.proformaDetails.length; index++) {
        const element = this.proformaDetails[index].invoiceQuantity;
        invoiceQuantity += +element;
      }
      this.totalQuantity = invoiceQuantity;
    }
  }

  /**
   * Create Proforma Controls Initialized
   * @readonly
   */
  proformaFormControls(index: number) {
    return this.proformaFormArray[index].controls;
  }

  /**
   * This method is used to navigate to order list
   */
  onClickNavigateToList() {
    this.router.navigate(['/admin/customer-order/order/orderList']);
  }

  /**
   * This method is used to submit the proforma invoice form
   */
  onSubmitProformaInvoiceForm() {
    let orderItems: any = [];

    /** This will return false if form fields are invalid and stop the service calling */
    for (let index = 0; index < this.proformaDetails.length; index++) {
      const rowForm = this.proformaFormArray[index];
      if (rowForm.invalid) {
        this.validationService.validateAllFormFields(rowForm);
        return;
      }

      /* Prepare the request payload */
      orderItems.push({
        orderColorID: +this.proformaDetails[index].orderColorID,
        invoiceQuantity: +this.proformaFormControls(index)['quantity'].value,
      });
    }

    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    /* To call the service to update the enquiry by passing the obj */
    this.orderService.editProformaDetails(this.orderProformaDetails?.order?.orderId, orderItems).subscribe({
      next: (res: any) => {
        /* Disable the loader if response is success */
        this.loaderService.isLoading.next(false);
        // this.getProformaDetails();
        this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', 'editOrder');
      },
      error: (err: any) => {
        /* Disable the loader if response is error */
        this.loaderService.isLoading.next(false);
        this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message || err, '', '', '');
      },
    });
  }

  /**
   * get proforma details
   */
  getProformaDetails() {
    this.orderService.getProformaDetailsById(this.orderProformaDetails?.order?.orderId).subscribe({
      next: (res: any) => {
        this.orderService.orderLayoutDetails.next(res.result);
        this.orderService.orderLayoutDetails.subscribe((res: any) => {
          this.orderProformaDetails = res;
          this.proformaDetails = res?.orderItems;
          if (this.orderProformaDetails?.order?.dispatchDate) {
            const orderDate = new Date(this.orderProformaDetails?.order?.dispatchDate);
            let day = orderDate.getDate();
            let month = orderDate.getMonth() + 1;
            const year = orderDate.getFullYear();
            this.formattedDate = `${day}-${month}-${year}`;
          }

          if (this.proformaDetails?.length > 0) {
            let amount = 0;
            for (const element of this.proformaDetails) {
              amount += +element.amount;
            }
            this.totalAmount = amount;
            this.amountInWords = this.numberToIndianFormat(this.totalAmount);
          }
          this.ExportToWord(this.orderProformaDetails, this.formattedDate);
          /* Disable the loader if response is success */
          this.loaderService.isLoading.next(false);
        });
      },
      error: (err: any) => {
        /* Disable the loader if response is success */
        this.loaderService.isLoading.next(false);
        this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message || err, '', '', '');
      },
    });
  }

  /**
   * Proforma Export
   */
  ExportToWord(orderProformaDetails: any, orderDate: any) {
    let date = orderDate;
    const tableRows: TableRow[] = [];
    const year = this.fromDate.getFullYear();
    const month = String(this.fromDate.getMonth() + 1).padStart(2, '0');
    const day = String(this.fromDate.getDate()).padStart(2, '0');
    const currentDate = `${year}-${month}-${day}`;
    const IMAGE_PATH =
      '/9j/4AAQSkZJRgABAQEAYABgAAD/2wBDAAIBAQIBAQICAgICAgICAwUDAwMDAwYEBAMFBwYHBwcGBwcICQsJCAgKCAcHCg0KCgsMDAwMBwkODw0MDgsMDAz/2wBDAQICAgMDAwYDAwYMCAcIDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAz/wAARCAAuAKADASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD9/K+eP2wv+CqfwM/YYuzYePvG9pB4g2CRdD06J77UiCMqWijB8oEcgylAexrwn/gvd/wVKvv2A/gXp/hnwVdJB8TPHySpZXO0OdFsk+WW7APHmFiEjzxne3Pl4P8AOpK+tfEjxTNM51PXtb1OV55nbzLq6u5DlndjyzseSScnqTX0mUZD9Zh7as7R6d3/AMA8TMc29hL2VJXl+R++t3/wdXfs7W9y6J4T+Mc6qcCSPSNOCv7jdfA/mBUf/EVr+zx/0Jvxn/8ABTpn/wAn1+CGu+BNc8LwiTU9G1XTo2OA11aSQgn6sBVbQ/DuoeJ737NptjeahcbS3lW0LSvgdThQTivf/wBXMDa+v3nj/wBt4u/T7j9+P+IrX9nj/oTfjP8A+CnTP/k+j/iK1/Z4/wChN+M//gp0z/5Pr8H/APhTXjD/AKFTxJ/4LJv/AImqlj8OPEOp3tzbW2g61cXFkwW4iisZXeAnoHAXKk+9H+ruA8/vD+2sX5fcfvX/AMRWv7PH/Qm/Gf8A8FOmf/J9en/s/wD/AAcV/sxfHfXYdNuPEus+Ary5YJF/wlWni0gZj2aeJ5YY/rI6j3r+b7TPB+pat4st9DjtJI9VurhbRLeYeSwlYhQrbsbeSOuK9V/ap/Yi8S/sbGy0/wAb6ho9r4mu4knfRrafz57VGGQJGHyhgCCRnjcuCcnGdTh3A6QTab21NIZzi/isml5H9Zum6lb6xp8F3aTw3VpdRrNDNC4eOZGGVZWHBUgggjgg1PX89/8Awb/f8FZtb/Zs+OOi/CHxrrFxe/DTxldJp+m/apdw8OX8rbYmjZj8kEjkK652qWDjGH3f0IV8hmWXzwdX2ctV0fc+jwWMhiafPHfqgor8Xf8AgqF8N/j1+xt+0j8G9D0v9qj4r6hZfHDxRc6cU8+S2XQY/tVmiiNRMRIFF4cA7f8AVj14+6dI+NfhD/gj18DdM0z9oL48+JPGN14m1e6l03Xtc0m9u7mQLHDutgtutwVRMbgWIBMhxVVMutThOnLmctkk7u2/ToTDG3nKM48qju21byPrmivyq/4LV/8ABRfxbr/7Mfwb8Z/A3xp4l0T4M/EHUryDxF440DTbiG+s44Z44FRfMWKaElhdEDMbSNAAHA+95n+zR+0l8QNE/Zc/aUvvCH7VkXxm8HaN4EudV0WbVLvUbXxz4ev1WPExiuYyywhmlQslxImVhZdpYrWtPJ6kqKqt2u7Ws+9tdLJ+TInmUFUdNK+l76dr6d15n7Q0V+Qn7D//AAXu1z4S/Bn4FaB8T/h78Qde0bxlLJpd38TNTvG8q9uzeyoxhR4j9pSAPEjt5ysNjhUbYN3T+Ev+Ci3hD9lL9pX9tvxzZ+GviFrup+Cb/T21ey1LxWkun3ZXUF05PscX2cG3AM2752lwqhF2iplk+IjKUWvTbX3uXvoOOZUZJST9fLS/zP1Uor8r/wBpH/gtz8V/H/8AwTw8b/E34cfB7xn8Pba1bRE0fxff+TdW4S5eT7XcJFPbGKWKKWBbUMC283iPhNuK2PBv/BdjxB8Ff2Dfg74i+Ifw713xB8UPibcNpmiW8t9a6XbeJliS036m84jENrFI92iqojIBVs7VBIn+yMTy3sr3ta6vtf0/HTqV/aVC9r6WveztvY/Tiivn/wDYH/bZ1r9srwzr83iH4UeM/hZq3h26S3kh1aMz6fqStvAksr0IkV0oMbBjGMDKHJDg19AVwVacqcnCe6OunUjOPNHY/mx/4OQ/H174x/4KueMtOundoPCmlaVpdmGPCRPZRXZA9vMupD9Sa+af2D9UuNH/AG2fhJNazPBL/wAJhpSbkODta7iVh9CpIPsa+8f+Dpf9lTUPAH7WegfFi2tnfQfH+mRWF1OBxFqNouzYx7brfySuevlyY+6a+Cv2Hhbw/tg/DS7vL2206x0vxJY6jdXNxu2QwwTpNIcKrMTtQ4ABr9KwE4zy6Lj/AC2+dtfxPh8ZGUcbLm/m/XQ/Rf8AaP8A2z/FHgb/AILHN8N9Wlt/EXw08U+IxoOpeHtRt0ntHt7m+e3IVSPlKqFwR0wfWuE0n9jC6/Zj/wCC+fhTwx8OoWt/Duk+J9N1C4Q3ccS22mzXixSxMZGG8MhKbBlm3YAJrf8AidoPw38bf8FXJvjf4g+InhuH4eeG9WbX44k85b3U3jupp4Yo0kjRckmMnLZxnAJ4rxnSP2xrD9pv/gtB4W+Kd/q9v4c8M2Piqx1S4lm850Fla3S3BjCxozudoIHyjJGfl7efShLltTVlya6denzOupOPN77159PT/I+p/wBqz4jftBfB/wDae+KXjXw34t0C18F/Dea71WTS5tQs7xr5W1SW3jt2t43aVFEcsX31ULtA6jFfH3/BNj/goDf/AA//AOCnOleNvE175eh+PNTbTtfSQgxCG5YqJHzwfLdlkJ68E969L/aT+E3hj9pT9vXW/Eq/F/RPDXgDxBqV22o3UVtqX2mezl1C4nKCJbbBYxyJwxxn6V8Y/tO/B/S/gT8XrrT/AA34hh8SaGkzNp2oojxNOitgOUdVdc8Hle5GTgmunB0KU6bpTWso9rf076mOJq1IzVSL0T73Ppr4+/sh6j4c/wCCuuo6Fq7yXGmafqUmu39zIf8AVWdqnnuXboC0aIw9RNH3NfMf7XHx7v8A9pT9oHxJ4sv5nmOoXcnklj0jDHH0zycdBnA4Ar9GP24v2lPC3xP/AGHNE8YeH9Y068+MGueC7LQ/FMMSSq6RQFWeQSMiqzsFRmIbJ8iNfm6V+TtdOXOVSPPUWsVy/wCb+ZhjVGD5YPR6/wCQ+3uJLS4SWJ3jljYOjocMjDkEHsa/sF/Zv8b3XxM/Z38BeJL7JvfEHhzT9SuMj/lpNbRyN+rGv5Mf2ZfgBrf7U/x/8JfD3w7C0ureLNSisYiFyIEJzJM3+xHGHkb/AGUNf14eD/Ctn4F8JaXomnIY9P0ezisbZCclIokCIP8AvlRXg8WTj+7h11+7Q9fh6Mvfl00PkP8A4Kkf8E7PG37bnx6/Z18U+FNU8Lafp/wi8Ry6xrEerXM8U1zC1xp8oW3EcMgZ9tpJw5QZZeeSR9hav4esPECIt/Y2d6sZJQXEKyBCeuNwOKwPjh8VYPgj8J9c8VXFpLfx6Nb+aLaNwhmcsFRSzcICzLljwoycHFcPqX7XMHw6uLnT/HOjLpGtWsF1eGHSNQTVbaS3gm0+IsJCsLq5bUrf5JIkb5XPK7Gf5Sdec4RpvaN7fN3PoY0oxnKa3lv8tDy7/go9+xV8XPjmngzXPgT8UH+HWueD5pPP0C7up4vDXiGF2V9l3bxB0fBDDDxOrrIwOMA18n/Cj/ghJ8XNRu/jh438d+Ivhdp/j34neDLvwzpek+F7SSw0S0luEhQzT+XbpsAEK5EcTlmdnLFuv3Jd/wDBQ/wxFq9pFHomvCzGo3tlqdxObeJ9KjtrK5vGneHzTLgx2spCMqyYUnbkory3H/BRHwdaXUVrJonjJdRM629zZDT42msHeSxjiEuJSv7xtSstu0t/rxnG1tvVRzHEUqfs4W+5X3va5hUwVKpPnlf79Ox8YfE7/giL8VvGn7AP7N/wqtfEHw9j8Q/B/Xr3VNZuJb68FlcxTXks6i3YWpdmCuAQ6IM55I5pvxU/4Ih/Ffxxrv7X11aeIPh7HH8f7q2m8PCa+vAbNYtYivm+14tTsPlIQPL8z5iB0+avs34iftwS6T4Z8K6z4V8Lwa5p2v8Ah3VvFF1/amrHSprG0042wmjVRBMsk5NwQFZ40zGcyYOQ9v8Agov4El/t37LY+KLxdB2CWSOxRIpCZo4ZB5jyKkXlSSqHacxrwxUsFJGizbEra299u8ub80Q8uoP7rfhb8jzvx1/wTn8R/EL/AII2W37ONzrWiWfiuDwpYaQdRiaWXTjd2ksMy/MUWTymeEKW8vcAxO0kYPgHiL/glf8AtF+P/wBgH4X/AA71uf4A6trvwyu5baLSNZ02a+03UtMWOEQZu/IFzb3I2TI/kbVkR0O9GWvr+2/4KIeEDeXaGy1q8SG4jw9jbpKILaRNP8ueUl1GGk1GFMRlz1bG1SwD/wAFH/Aq+HpNSbTfFUUEbWrHzrOGFRBcJdNHcmR5RGsRNlcJ8zhy6AKrbl3ZU8wrw2t8XNt1Zc8FSnv2t8jxj/gjT/wS58Yf8E9br4i614t13w5HN8QLqK4i8LeGHu5NF0JUaVh5b3JMrsBKIxuyQsYy8mcj7npFcOoIIIIyCO9LXNicROvUdWpuzejRjSgqcNkeeftT/sueDv2yfghrPw/8dab/AGjoOsoMlCFns5V5juIXwdkqHkNg9wQVJU/z7/tvf8G+Xx4/ZV8U31z4S0K++KXg0OzWeo6BAZr9I+yz2a5lV8ZyYxInH3hnA/pLorty7Nq+DdoaxfRnLjcupYnWej7n8gF7+zL8T7Sdobj4fePI5EOGjk0K7DKfcFKhX9mz4kIcjwD43B9Rod1/8RX9gtFe1/rZP/n2vv8A+AeX/q9H+f8AA/j9/wCGc/iX/wBCJ45/8El1/wDEU1/2bfiRIfm8A+Nz9dDuv/iK/sEoo/1sn/z7X3/8AP8AV6P8/wCH/BP4/P8AhnH4lbcf8IH44x0x/Yl1/wDEV6X+z9/wSo/aF/aX16Cy8NfCnxfHBM4VtR1WwfTNPiHdjPcBEOByQpZvRSSBX9XFFTPiuq17tNJ+v/DFR4ep396bPh3/AIJBf8EYPDv/AATZ0CfxDrl3Z+KviprEHkXeqxRn7LpcJwTb2gYBsEgb5GAZ8AYUZB+4qKK+axGIqV6jq1Xds9yjRhSgoU1ZFXWtFs/Emj3Wn6ha219YX0LW9zbXEQkiuI2BVkdSCGUgkEEYINcPD+yd8MoNE0/TU8BeE1sdJnlurOEaZFtt5ZdvmSL8vDNsTJ6ny0/ujHoVFYGpxFp+zZ8P7BiYfBnhqIm8/tA7dPiH7/ZJHv6f3JZVx0xI4xhjldG/Zt8AeHbO3t7Dwb4cs4bUgxJDYRoEInhuARgdRNbwP9YY/wC6K7aii4HD+JP2aPh94w07RrTVfBnhzUrTw75n9mwXNhHLFZeYyvIEUggBmRCRjB2jNP1n9nHwD4h1TVL298HeHbm81pke+newjMlyysrKzNjO7ciHPXKKewrtaKLsDyHx7+w78O/Ht9oMjaNb6Xb6BcLcxWun2tvDFMVNrtViYmdAFsrdMwtG2yPbnbxXR6n+zD8O9a09bS78FeGrm2WGK3EUthGyiOIThEwR90C5uBjpieQdGNd3RRdgIqhFAAwBwAO1LRRQB//Z';
    let party = `${orderProformaDetails?.order?.organizationName}`;
    //Logo
    const image = new Header({
      children: [
        new Paragraph({
          children: [
            new ImageRun({
              data: IMAGE_PATH,
              transformation: {
                width: 130,
                height: 40,
              },
            }),
          ],
        }),
      ],
    });

    // Header
    const additionalInfo = new Paragraph({
      alignment: AlignmentType.CENTER,
      children: [
        new TextRun({
          text: `Proforma Invoice`,
          bold: true,
          font: 'Arial Black',
          color: '#000000',
          size: 32,
        }),
      ],
    });

    const OrderNo = new Paragraph({
      frame: {
        position: {
          x: 0,
          y: 800,
        },
        width: 6500,
        height: 300,
        anchor: {
          horizontal: FrameAnchorType.MARGIN,
          vertical: FrameAnchorType.MARGIN,
        },
        alignment: {
          x: HorizontalPositionAlign.LEFT,
          y: VerticalPositionAlign.TOP,
        },
      },

      children: [
        new TextRun({
          text: 'Order No: ',
          bold: true,
          font: 'Arial',
        }),
        new TextRun({
          text: `${orderProformaDetails?.order?.orderNo}`,
          font: 'Arial',
        }),
      ],
    });

    const DressItem = new Paragraph({
      frame: {
        position: {
          x: 0,
          y: 1200,
        },
        width: 6000,
        height: 300,
        anchor: {
          horizontal: FrameAnchorType.MARGIN,
          vertical: FrameAnchorType.MARGIN,
        },
        alignment: {
          x: HorizontalPositionAlign.RIGHT,
          y: VerticalPositionAlign.TOP,
        },
      },

      children: [
        new TextRun({
          style: AlignmentType.END,
          text: 'Dress Item: ',
          bold: true,
          font: 'Arial',
        }),
        new TextRun({
          style: AlignmentType.END,
          text: `${orderProformaDetails?.order?.dressItem}`,
          font: 'Arial',
          bold: true,
          size: 22,
        }),
      ],
    });

    const Date = new Paragraph({
      frame: {
        position: {
          x: 6300,
          y: 800,
        },
        width: 3000,
        height: 450,
        anchor: {
          horizontal: FrameAnchorType.MARGIN,
          vertical: FrameAnchorType.MARGIN,
        },
        alignment: {
          x: HorizontalPositionAlign.CENTER,
          y: VerticalPositionAlign.TOP,
        },
      },

      children: [
        new TextRun({
          text: 'Dispatched Date: ',
          bold: true,
          font: 'Arial',
        }),
        new TextRun({
          text: `${date ? date : ' -'}`,
          font: 'Arial',
        }),
      ],
    });

    const quantityName = new Paragraph({
      frame: {
        position: {
          x: 0,
          y: 1650,
        },
        width: 6000,
        height: 450,
        anchor: {
          horizontal: FrameAnchorType.MARGIN,
          vertical: FrameAnchorType.MARGIN,
        },
        alignment: {
          x: HorizontalPositionAlign.CENTER,
          y: VerticalPositionAlign.TOP,
        },
      },

      children: [
        new TextRun({
          text: 'Quality Name: ',
          bold: true,
          font: 'Arial',
        }),
        new TextRun({
          text: `${orderProformaDetails?.order?.quality}`,
          font: 'Arial',
        }),
      ],
    });

    const Party = new Paragraph({
      frame: {
        position: {
          x: 0,
          y: 2000,
        },
        width: 6500,
        height: 100,
        anchor: {
          horizontal: FrameAnchorType.MARGIN,
          vertical: FrameAnchorType.MARGIN,
        },
        alignment: {
          x: HorizontalPositionAlign.CENTER,
          y: VerticalPositionAlign.TOP,
        },
      },

      children: [
        new TextRun({
          text: 'Party: ',
          bold: true,
          font: 'Arial',
        }),
        new TextRun({
          text: `${party}`,
          font: 'Arial',
        }),
      ],
    });

    const PartyOne = new Paragraph({
      frame: {
        position: {
          x: 600,
          y: 2300,
        },
        width: 6500,
        height: 100,
        anchor: {
          horizontal: FrameAnchorType.MARGIN,
          vertical: FrameAnchorType.MARGIN,
        },
        alignment: {
          x: HorizontalPositionAlign.CENTER,
          y: VerticalPositionAlign.TOP,
        },
      },

      children: [
        new TextRun({
          text: `${orderProformaDetails?.order?.townName}`,
          font: 'Arial',
        }),
      ],
    });

    const PartyTwo = new Paragraph({
      frame: {
        position: {
          x: 600,
          y: 2600,
        },
        width: 6500,
        height: 100,
        anchor: {
          horizontal: FrameAnchorType.MARGIN,
          vertical: FrameAnchorType.MARGIN,
        },
        alignment: {
          x: HorizontalPositionAlign.CENTER,
          y: VerticalPositionAlign.TOP,
        },
      },

      children: [
        new TextRun({
          text: `${orderProformaDetails?.order?.districtName}`,
          font: 'Arial',
        }),
      ],
    });

    const PartyThree = new Paragraph({
      frame: {
        position: {
          x: 600,
          y: 2900,
        },
        width: 6500,
        height: 100,
        anchor: {
          horizontal: FrameAnchorType.MARGIN,
          vertical: FrameAnchorType.MARGIN,
        },
        alignment: {
          x: HorizontalPositionAlign.CENTER,
          y: VerticalPositionAlign.TOP,
        },
      },

      children: [
        new TextRun({
          text: `${orderProformaDetails?.order?.stateName}`,
          font: 'Arial',
        }),
      ],
    });
    const PartyFour = new Paragraph({
      frame: {
        position: {
          x: 600,
          y: 3200,
        },
        width: 6500,
        height: 400,
        anchor: {
          horizontal: FrameAnchorType.MARGIN,
          vertical: FrameAnchorType.MARGIN,
        },
        alignment: {
          x: HorizontalPositionAlign.CENTER,
          y: VerticalPositionAlign.TOP,
        },
      },

      children: [
        new TextRun({
          text: `Ph: ${orderProformaDetails?.order?.phoneNumber}`,
          font: 'Arial',
        }),
      ],
    });

    //creating empty para
    const emptyPara = new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: {
        line: 150,
      },
      children: [
        new TextRun({
          text: ``,
        }),
      ],
    });
    const footerSection = new Paragraph({
      children: [
        new TextRun({
          text: 'Amount Chargeable (in Words):',
          font: 'Arial',
        }),
        new TextRun({
          text: '',
          font: 'Arial',
        }),
        new TextRun({
          text: ` `,
        }),
        new TextRun({
          text: `${this.amountInWords} ${this.totalAmount === 1 ? 'Rupee' : 'Rupees'} Only`,
          font: 'Arial',
          bold: true,
        }),


      ],
    });
    const footerSectionOne = new Paragraph({
      alignment: AlignmentType.END,
      children: [
        new TextRun({
          text: 'E & O.E',
          font: 'Arial',
          bold: true,
        }),
      ],
    });
    const footerSectionTwo = new Paragraph({
      alignment: AlignmentType.END,
      children: [
        new TextRun({
          text: 'For Dev T-Shirts Pvt Ltd.',
          bold: true,
          font: 'Arial',
        }),
      ],
    });
    const footerSectionThree = new Paragraph({
      alignment: AlignmentType.END,
      children: [
        new TextRun({
          text: 'Authorised Signatory',
          // bold: true,
          font: 'Arial',
        }),
      ],
    });
    // Create table headers
    const tableHeader = new TableRow({
      // height: {
      //   value: 400,
      //   rule: HeightRule.EXACT,
      // },
      children: [
        new TableCell({
          margins: { top: 40, bottom: 40 },
          // width: {
          //   size: 1200,
          //   type: WidthType.DXA,
          // },
          verticalAlign: VerticalAlign.CENTER,
          shading: {
            fill: 'D3D3D3', // Specifying the background color
          },
          children: [
            new Paragraph({
              children: [
                new TextRun({
                  text: 'S. No',
                  bold: true,
                  color: '#000000',
                  font: 'Arial',
                }),
              ],
              alignment: AlignmentType.CENTER,
            }),
          ],
        }),
        new TableCell({
          margins: { top: 40, bottom: 40 },
          // width: {
          //   size: 2000,
          //   type: WidthType.DXA,
          // },
          verticalAlign: VerticalAlign.CENTER,
          shading: {
            fill: 'D3D3D3', // Specifying the background color
          },
          children: [
            new Paragraph({
              children: [
                new TextRun({
                  text: 'Colour',
                  bold: true,
                  color: '#000000',
                  font: 'Arial',
                }),
              ],
              alignment: AlignmentType.CENTER, // Center align the text vertically
            }),
          ],
        }),
        new TableCell({
          margins: { top: 40, bottom: 40 },
          // width: {
          //   size: 2000,
          //   type: WidthType.DXA,
          // },
          verticalAlign: VerticalAlign.CENTER,
          shading: {
            fill: 'D3D3D3', // Specifying the background color
          },
          children: [
            new Paragraph({
              children: [
                new TextRun({
                  text: 'Size',
                  bold: true,
                  font: 'Arial',
                  color: '#000000',
                }),
              ],
              alignment: AlignmentType.CENTER, // Center align the text vertically
            }),
          ],
        }),
        new TableCell({
          margins: { top: 40, bottom: 40 },
          // width: {
          //   size: 2000,
          //   type: WidthType.DXA,
          // },
          verticalAlign: VerticalAlign.CENTER,
          shading: {
            fill: 'D3D3D3', // Specifying the background color
          },
          children: [
            new Paragraph({
              children: [
                new TextRun({
                  text: 'Quantity (Pcs)',
                  bold: true,
                  font: 'Arial',
                  color: '#000000',
                }),
              ],
              alignment: AlignmentType.CENTER, // Center align the text vertically
            }),
          ],
        }),
        new TableCell({
          margins: { top: 40, bottom: 40 },
          // width: {
          //   size: 4000,
          //   type: WidthType.DXA,
          // },
          verticalAlign: VerticalAlign.CENTER,
          shading: {
            fill: 'D3D3D3', // Specifying the background color
          },
          children: [
            new Paragraph({
              children: [
                new TextRun({
                  text: 'Rate (Per Pcs)',
                  color: '#000000',
                  font: 'Arial',
                  bold: true,
                }),
              ],
              alignment: AlignmentType.CENTER, // Center align the text vertically
            }),
          ],
        }),

        new TableCell({
          margins: { top: 40, bottom: 40 },
          // width: {
          //   size: 4000,
          //   type: WidthType.DXA,
          // },
          verticalAlign: VerticalAlign.CENTER,
          shading: {
            fill: 'D3D3D3', // Specifying the background color
          },
          children: [
            new Paragraph({
              children: [
                new TextRun({
                  text: 'Amount (Rs)',
                  color: '#000000',
                  font: 'Arial',
                  bold: true,
                }),
              ],
              alignment: AlignmentType.CENTER, // Center align the text vertically
            }),
          ],
        }),
      ],
    });
    //adding header to table rows
    tableRows.push(tableHeader);

    // Create data rows from the inwardFabricList array
    orderProformaDetails?.orderItems?.forEach((item: any, index: number) => {
      const row = new TableRow({
        // height: {
        //   value: 600,
        //   rule: HeightRule.EXACT,
        // },
        children: [
          new TableCell({
            margins: { top: 40, bottom: 40 },
            // width: {
            //   size: 1200,
            //   type: WidthType.DXA,
            // },
            verticalAlign: VerticalAlign.CENTER,
            children: [
              new Paragraph({
                alignment: AlignmentType.CENTER,

                children: [
                  new TextRun({
                    text: `${index + 1}`,
                    color: '#000000',
                    font: 'Arial',
                  }),
                ],
              }),
            ],
          }),
          new TableCell({
            margins: {
              left: 100,
              top: 40, bottom: 40
            },
            // width: {
            //   size: 3505,
            //   type: WidthType.DXA,
            // },
            verticalAlign: VerticalAlign.CENTER,
            children: [
              new Paragraph({
                alignment: AlignmentType.LEFT,

                children: [
                  new TextRun({
                    text: `${item.color}`,
                    color: '#000000',
                    font: 'Arial',
                  }),
                ],
              }),
            ],
          }),
          new TableCell({
            margins: {
              left: 100,
              top: 40, bottom: 40
            },
            // width: {
            //   size: 2000,
            //   type: WidthType.DXA,
            // },
            verticalAlign: VerticalAlign.CENTER,
            children: [
              new Paragraph({
                alignment: AlignmentType.LEFT,

                children: [
                  new TextRun({
                    text: `${item.size}`,
                    color: '#000000',
                    font: 'Arial',
                  }),
                ],
              }),
            ],
          }),
          new TableCell({
            margins: {
              right: 100,
              top: 40, bottom: 40
            },
            // width: {
            //   size: 2000,
            //   type: WidthType.DXA,
            // },
            verticalAlign: VerticalAlign.CENTER,
            children: [
              new Paragraph({
                alignment: AlignmentType.RIGHT,

                children: [
                  new TextRun({
                    text: `${item.invoiceQuantity}`,
                    color: '#000000',
                    font: 'Arial',
                  }),
                ],
              }),
            ],
          }),
          new TableCell({
            margins: {
              right: 100,
              top: 40, bottom: 40
            },
            // width: {
            //   size: 4000,
            //   type: WidthType.DXA,
            // },
            verticalAlign: VerticalAlign.CENTER,
            children: [
              new Paragraph({
                alignment: AlignmentType.RIGHT,

                children: [
                  new TextRun({
                    text: `${(+item.unitPrice)?.toLocaleString('en-IN', {
                      minimumFractionDigits: 2,
                      maximumFractionDigits: 2,
                    })}`,
                    color: '#000000',
                    font: 'Arial',
                  }),
                ],
              }),
            ],
          }),

          new TableCell({
            margins: {
              right: 100,
              top: 40, bottom: 40
            },
            // width: {
            //   size: 4000,
            //   type: WidthType.DXA,
            // },
            verticalAlign: VerticalAlign.CENTER,
            children: [
              new Paragraph({
                alignment: AlignmentType.RIGHT,

                children: [
                  new TextRun({
                    text: `${(+item?.amount)?.toLocaleString('en-IN', {
                      minimumFractionDigits: 2,
                      maximumFractionDigits: 2,
                    })}`,
                    color: '#000000',
                    font: 'Arial',
                  }),
                ],
              }),
            ],
          }),
        ],
      });
      tableRows.push(row);
    });

    //table Footer
    const tableFooter = new TableRow({
      // height: {
      //   value: 300,
      //   rule: HeightRule.EXACT,
      // },
      children: [
        new TableCell({
          margins: {
            right: 100,
            top: 40, bottom: 40
          },
          // width: {
          //   size: 3505, // Adjust the width as needed
          //   type: WidthType.DXA,
          // },
          verticalAlign: VerticalAlign.CENTER,
          columnSpan: 3,
          children: [
            new Paragraph({
              alignment: AlignmentType.RIGHT,
              children: [
                new TextRun({
                  text: `Total: `,
                  color: '#000000',
                  size: 20,
                  font: 'Arial',
                  bold: true,
                }),
              ],
            }),
          ],
        }),
        new TableCell({
          margins: {
            right: 100,
            top: 40, bottom: 40
          },
          // width: {
          //   size: 3505, // Adjust the width as needed
          //   type: WidthType.DXA,
          // },
          verticalAlign: VerticalAlign.CENTER,
          columnSpan: 1,
          children: [
            new Paragraph({
              alignment: AlignmentType.RIGHT,
              children: [
                new TextRun({
                  text: `${this.totalQuantity?.toLocaleString('en-IN')}`,
                  color: '#000000',
                  bold: true,
                  size: 20,
                  font: 'Arial',
                }),
              ],
            }),
          ],
        }),
        new TableCell({
          margins: {
            right: 100,
            top: 40, bottom: 40
          },
          // width: {
          //   size: 3505, // Adjust the width as needed
          //   type: WidthType.DXA,
          // },
          verticalAlign: VerticalAlign.CENTER,
          columnSpan: 2,
          children: [
            new Paragraph({
              alignment: AlignmentType.END,
              children: [
                // new TextRun({
                //   text: `Total Amount: `,
                //   color: '#000000',
                //   size: 20,
                //   font: 'Arial',
                //   bold: true,
                // }),
                new TextRun({
                  text: `${this.totalAmount?.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
                  color: '#000000',
                  bold: true,
                  size: 20,
                  font: 'Arial',
                }),
              ],
            }),
          ],
        }),
      ],
    });

    //adding footer to table rows
    tableRows.push(tableFooter);

    //preparing table
    const table = new Table({
      width: {
        size: 9100, // Adjust the width size as needed
        type: WidthType.DXA,
      },
      rows: tableRows,
    });

    const doc = new Document({
      sections: [
        {
          headers: {
            default: image,
          },
          // children: [additionalInfo, quality, Colour, fromDate, toDate, table],
          children: [
            additionalInfo,
            OrderNo,
            DressItem,
            Date,
            quantityName,
            Party,
            PartyOne,
            PartyTwo,
            PartyThree,
            PartyFour,
            table,
            emptyPara,
            emptyPara,
            footerSection,
            emptyPara,
            emptyPara,
            footerSectionOne,
            emptyPara,
            footerSectionTwo,
            emptyPara,
            emptyPara,
            emptyPara,
            emptyPara,
            emptyPara,
            emptyPara,
            footerSectionThree,
          ],
        },
      ],
    });

    const Year = this.fromDate.getFullYear();
    const Month = (this.fromDate.getMonth() + 1).toString().padStart(2, '0');
    const Day = this.fromDate.getDate().toString().padStart(2, '0');
    const monthNames = [
      "Jan", "Feb", "Mar", "Apr", "May", "Jun",
      "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
    ];
    const Mont = monthNames[(+Month - 1)];
    // Create the readable format
    const readableFormat = `${Year}-${Mont}-${Day}`;
    // Generate the document and offer it for download
    Packer.toBlob(doc).then((blob) => {
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `Proforma_Details_${readableFormat}.docx`;
      a.click();
      window.URL.revokeObjectURL(url);
    });
  }


  /**
   * Method to convert amount to readable text
   * @param {number} number
   * @return {*}  {string}
   */
  numberToIndianFormat(number: number): string {
    if (number === 0) return "Zero";

    const ones = ["", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten",
      "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen"];

    const tens = ["", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"];

    let words = [];

    // Crore calculation
    if (number >= 10000000) {
      words.push(this.numberToIndianFormat(Math.floor(number / 10000000)) + " Crore");
      number %= 10000000;
    }

    // Lakh calculation
    if (number >= 100000) {
      words.push(this.numberToIndianFormat(Math.floor(number / 100000)) + " Lakh");
      number %= 100000;
    }

    // Thousand calculation
    if (number >= 1000) {
      words.push(this.numberToIndianFormat(Math.floor(number / 1000)) + " Thousand");
      number %= 1000;
    }

    // Hundred calculation
    if (number >= 100) {
      words.push(ones[Math.floor(number / 100)] + " Hundred");
      number %= 100;
    }

    // 1 to 99 calculation
    if (number > 0) {
      if (number < 20) {
        words.push(ones[number]);
      } else {
        words.push(tens[Math.floor(number / 10)]);
        if (number % 10 !== 0) {
          words.push(ones[number % 10]);
        }
      }
    }

    return words.join(' ');
  }

}
