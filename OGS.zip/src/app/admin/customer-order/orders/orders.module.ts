import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { MatTooltipModule } from "@angular/material/tooltip";
import { NgSelectModule } from "@ng-select/ng-select";
import { Ng2SearchPipeModule } from "ng2-search-filter";
import { AutosizeModule } from "ngx-autosize";
import { BsDatepickerModule } from "ngx-bootstrap/datepicker";
import { OrderModule } from "ngx-order-pipe";
import { NgxPaginationModule } from "ngx-pagination";

import { ComponentModule } from "src/app/core/Modules/component.module";
import { AddOrdersComponent } from "./add-orders/add-orders.component";
import { EditOrdersComponent } from "./edit-orders/edit-orders.component";
import { OrderLayoutComponent } from './order-layout/order-layout.component';
import { OrdersListComponent } from "./orders-list/orders-list.component";
import { OrdersMiddyPatternModalComponent } from "./orders-middy-pattern-modal/orders-middy-pattern-modal.component";
import { OrdersNickersModelComponent } from "./orders-nickers-model/orders-nickers-model.component";
import { OrdersPantPatternModalComponent } from "./orders-pant-pattern-modal/orders-pant-pattern-modal.component";
import { OrdersPinofersModelComponent } from "./orders-pinofers-model/orders-pinofers-model.component";
import { OrdersRoutingModule } from "./orders-routing.module";
import { OrdersShotsModelComponent } from "./orders-shots-model/orders-shots-model.component";
import { OrdersTShirtsPatternModalComponent } from "./orders-t-shirts-pattern-modal/orders-t-shirts-pattern-modal.component";
import { OrdersComponent } from "./orders.component";
import { ProformaInvoiceComponent } from './proforma-invoice/proforma-invoice.component';

/**
 * Orders Module
 * @export
 * @class OrdersModule
 */
@NgModule({
  declarations: [
    OrdersComponent,
    OrdersListComponent,
    AddOrdersComponent,
    EditOrdersComponent,
    OrdersTShirtsPatternModalComponent,
    OrdersPinofersModelComponent,
    OrdersMiddyPatternModalComponent,
    OrdersNickersModelComponent,
    OrdersShotsModelComponent,
    OrdersPantPatternModalComponent,
    OrderLayoutComponent,
    ProformaInvoiceComponent,
  ],
  imports: [
    CommonModule,
    OrdersRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    MatTooltipModule,
    OrderModule,
    NgSelectModule,
    ComponentModule,
    NgxPaginationModule,
    Ng2SearchPipeModule,
    BsDatepickerModule.forRoot(),
    MatTooltipModule,
    AutosizeModule,
  ],
})
export class OrdersModule { }
