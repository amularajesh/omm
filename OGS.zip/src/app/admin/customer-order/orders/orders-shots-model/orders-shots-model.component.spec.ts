import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OrdersShotsModelComponent } from './orders-shots-model.component';

describe('OrdersShotsModelComponent', () => {
  let component: OrdersShotsModelComponent;
  let fixture: ComponentFixture<OrdersShotsModelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OrdersShotsModelComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(OrdersShotsModelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
