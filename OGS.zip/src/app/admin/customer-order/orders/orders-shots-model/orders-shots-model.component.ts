import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { MasterColourItems, PanelColoursItems, StripePipingItems } from 'src/app/core/Modals/modals';
import { ChargesService } from 'src/app/core/Services/charges.service';
import { MastersService } from 'src/app/core/Services/masters.service';
import { OrderService } from 'src/app/core/Services/order.service';
import { SampleOrderService } from 'src/app/core/Services/sample-order.service';
import { ValidationService } from 'src/app/core/Services/validation.service';

/**
 * Orders Shots Model Component
 * @export
 * @class OrdersShotsModelComponent
 * @implements {OnInit}
 */
@Component({
  selector: 'app-orders-shots-model',
  templateUrl: './orders-shots-model.component.html',
  styleUrls: ['./orders-shots-model.component.scss']
})
export class OrdersShotsModelComponent implements OnInit {
  /**
   * Declare Shorts Pattern Form
   * @type {FormGroup}
   */
  shortsPatternForm!: FormGroup;

  /**
   * Get Panel Colours List
   * @type {PanelColoursItems[]}
   */
  panelColoursList: PanelColoursItems[] = [];

  /**
   * Get Colours List
   * @type {MasterColourItems[]}
   */
  masterColoursList: MasterColourItems[] = [];

  /**
   * Get Striped Count List
   * @type {StripePipingItems[]}
   */
  stripedCountList: StripePipingItems[] = [];

  /**
   * Get Selected Model No.
   * @type {*}
   */
  selectedModelNo: any;

  /**
   * Get Model No. List
   */
  modelNoList: any;

  /**
   * Get Selected Panel
   * @type {*}
   */
  selectedPanel: any;

  /**
   * Get Selected Body
   * @type {*}
   */
  selectedBody: any;

  /**
   * Get Selected Normal Body
   * @type {*}
   */
  selectedNormalBody: any;

  /**
   * Get Selected Piping Colour
   * @type {*}
   */
  selectedPipingColour: any;

  /**
   * Get Selected Piping Radio
   */
  selectedPipingRadio = 0;

  /**
   * Get Selected Inner rope Radio
   */
  selectedInnerRopeRadio = 0;

  /**
   * Get Selected pocket Radio
   */
  selectedPocketRadio = 0;

  /**
   * Get Selected Striped Count
   * @type {*}
   */
  selectedStripedCount: any;

  /**
   * Get Selected pocket type
   */
  selectedPocketType: any;

  /**
   * Get Selected Striped Colour
   * @type {*}
   */
  selectedStripedColour: any;

  /**
   * Get Selected stript Radio
   */
  selectedStripedRadio = 0;

  /**
   * Get Selected strip colour Radio
   */
  selectedStripedColourRadio = 0;

  /**
   * Get Selected Short Pattern
   * @type {*}
   */
  selectedShortPattern: any;

  /**
   * Get Selected Dress Item
   * @type {*}
   */
  selectedDressItem: any;

  /**
   * Get Pocket Types List
   */
  pocketTypesList: any;

  /**
   * Get Saved Shots Pattern Details
   * @type {*}
   */
  savedShotsPatternDetails: any;

  /**
   * Get Is Success Snackbar Flag
   */
  isSuccessSnackbar = false;

  /**
   * Get Is Overlay Visible Flag
   */
  isOverlayVisible = false;

  /**
   * Get Inner HTML Message
   */
  innerHTMLMessage = '';

  /**
   * Get Inner HTML Order Id
   */
  innerHTMLOrderId = '';

  /**
   * Get Short Patterns Form Validations
   */
  shortPatternFormValidation = this.validationService.shortsPattern;

  /**
   * Creates an instance of ShotsModelComponent.
   * @param {ValidationService} validationService
   * @param {FormBuilder} formBuilder
   * @param {MastersService} masterService
   * @param {ChargesService} chargesService
   * @param {SampleOrderService} sampleOrderService
   */
  constructor(
    private validationService: ValidationService,
    private formBuilder: FormBuilder,
    private masterService: MastersService,
    private chargesService: ChargesService,
    private sampleOrderService: SampleOrderService,
    private orderService: OrderService,
  ) {
    /* Get Pattern Details from behavior subject */
    this.orderService.orderPatternDetailsObj.subscribe((val: any) => {
      if (Object.keys(val).length > 0) {
        this.savedShotsPatternDetails = val?.patternforPant;
        console.log(this.savedShotsPatternDetails, "shot");
      } else {
        this.savedShotsPatternDetails = "";
      }
    });
  }

  /**
   * Life Cycle Hook Initialization
   */
  ngOnInit(): void {
    this.getColoursList();
    this.shortsPatternFormValidations();
  }

  /**
   * Initialize Shorts Pattern Form Validations
   */
  shortsPatternFormValidations() {
    let modelNoSelectValue = "";
    let normalBodySelectValue = "";
    let pipingRadioValue = "0";
    let innerRopeRadioValue = "0";
    let stripedRadioValue = "0";
    let stripedColourRadioValue = "0";
    let pocketRadioValue = "0";
    let pipingColourSelectValue = "";
    let stripedCountSelectValue = "";
    let stripedColourSelectValue = "";
    let pocketTypeSelectValue = "";

    if (this.savedShotsPatternDetails) {
      pipingRadioValue = this.savedShotsPatternDetails?.isPiping ? "1" : "0";
      this.onChangePipingRadio(pipingRadioValue);

      pocketRadioValue = this.savedShotsPatternDetails?.isPocket ? "1" : "0";
      this.onChangePocketRadio(pocketRadioValue);

      innerRopeRadioValue = this.savedShotsPatternDetails?.isInnerRope
        ? "1"
        : "0";
      this.onChangeInnerRopeRadio(innerRopeRadioValue);

      if (this.selectedShortPattern?.patternType === "Special") {
        stripedRadioValue = this.savedShotsPatternDetails?.isStripes
          ? "1"
          : "0";
        this.onChangeStripedRadio(stripedRadioValue);
      }
    } else {
      this.onResetShortsPatternForm();
    }

    this.shortsPatternForm = this.formBuilder.group({
      pattern: [
        this.selectedShortPattern?.patternType || this.selectedShortPattern,
        [Validators.required],
      ],
      dressItem: [
        this.selectedDressItem?.dressItemName || this.selectedDressItem,
        [Validators.required],
      ],
      modelNoSelect: [modelNoSelectValue],
      normalBodySelect: [normalBodySelectValue],
      pipingRadio: [pipingRadioValue],
      pipingColourSelect: [pipingColourSelectValue],
      stripedRadio: [stripedRadioValue],
      stripedCountSelect: [stripedCountSelectValue],
      stripedColourRadio: [stripedColourRadioValue],
      stripedColourSelect: [stripedColourSelectValue],
      pocketRadio: [pocketRadioValue],
      pocketTypeSelect: [pocketTypeSelectValue],
      innerRopeRadio: [innerRopeRadioValue],
      bodySelect: [""],
      panelSelect: [""],
    });

    setTimeout(() => {
      console.log(this.savedShotsPatternDetails, "shorts");

      if (this.savedShotsPatternDetails) {
        if (this.savedShotsPatternDetails?.modelId) {
          this.shortsPatternFormControls["modelNoSelect"].setValue(
            this.savedShotsPatternDetails?.modelId.toString()
          );
        }
        if (this.selectedPipingRadio === 1) {
          pipingColourSelectValue = this.savedShotsPatternDetails
            ?.pipingColorid;
          this.onChangePipingColour(pipingColourSelectValue);
        }
        if (this.selectedStripedRadio === 1) {
          stripedCountSelectValue = this.savedShotsPatternDetails?.stripesCount;

          this.shortsPatternFormControls["stripedCountSelect"].setValue(
            stripedCountSelectValue?.toString()
          );
          this.onChangeStripedCount(stripedCountSelectValue);
        }
        if (this.selectedPocketRadio === 1) {
          pocketTypeSelectValue = this.savedShotsPatternDetails?.pocketId;
          this.shortsPatternFormControls["pocketTypeSelect"].setValue(
            pocketTypeSelectValue?.toString()
          );
          this.onChangePocketType(pocketTypeSelectValue);
        }

        if (this.selectedShortPattern?.patternType === "Special") {
          const responsePanelColorsItems = this.savedShotsPatternDetails?.panelColors?.map(
            (responseData: any, index: any) => {
              const bodyColour = this.masterColoursList?.find(
                (element: any) =>
                  +responseData?.bodyColorId === +element?.colourId
              );
              const panelColour = this.masterColoursList?.find(
                (element: any) =>
                  +responseData?.panelColorId === +element?.colourId
              );
              return {
                id: index,
                body: bodyColour,
                panel: panelColour,
              };
            }
          );

          if (responsePanelColorsItems?.length > 0) {
            localStorage.setItem(
              "shotsPatternPanelColours",
              JSON.stringify(responsePanelColorsItems)
            );
            this.panelColoursList = responsePanelColorsItems || [];
          } else {
            this.panelColoursList =
              JSON.parse(localStorage.getItem("shotsPatternPanelColours")!) ||
              [];
          }
        } else {
          console.log(this.savedShotsPatternDetails, "normal short");

          normalBodySelectValue = this.savedShotsPatternDetails?.bodyColorId;
          this.onChangeNormalBodySelect(normalBodySelectValue);
          this.shortsPatternFormControls["normalBodySelect"].setValue(
            normalBodySelectValue?.toString()
          );
          if (this.selectedPipingRadio === 1) {
            pipingColourSelectValue = this.savedShotsPatternDetails
              ?.pipingColorid;
            this.shortsPatternFormControls["pipingColourSelect"].setValue(
              pipingColourSelectValue?.toString()
            );
            this.onChangePipingColour(pipingColourSelectValue);
          }
          if (this.selectedPocketRadio === 1) {
            pocketTypeSelectValue = this.savedShotsPatternDetails?.pocketId;
            this.shortsPatternFormControls["pocketTypeSelect"].setValue(
              pocketTypeSelectValue?.toString()
            );
            this.onChangePocketType(pocketTypeSelectValue);
          }
        }
      }
      this.shortsPatternFormControls["pipingColourSelect"].setValue(
        pipingColourSelectValue?.toString()
      );
    }, 100);
  }

  /**
   * Get Shorts Pattern Model Form Controls
   * @readonly
   */
  get shortsPatternFormControls() {
    return this.shortsPatternForm.controls;
  }

  /**
   * This method is used to open the shorts Modal
   * @param {*} selectedPattern
   * @param {*} selectedDressItem
   */
  openModal(selectedPattern: any, selectedDressItem: any) {
    this.selectedShortPattern = selectedPattern;
    this.selectedDressItem = selectedDressItem;
    this.getColoursList();
    document.getElementById("shortsModalButton")?.click();
    if (this.selectedShortPattern?.patternType === "Special") {
      if (this.savedShotsPatternDetails) {
        this.getPocketTypesList("noEvent");
        this.getModelNoList("noEvent");
      } else {
        this.getPocketTypesList("");
        this.getModelNoList("");
      }
      this.shortsPatternFormValidations();
      this.onAddValidators(this.shortsPatternFormControls, ["modelNoSelect"]);
      this.onRemoveValidators(this.shortsPatternFormControls, [
        "normalBodySelect",
      ]);
    } else {
      if (this.savedShotsPatternDetails) {
        this.getPocketTypesList("noEvent");
      } else {
        this.getPocketTypesList("");
      }
      this.shortsPatternFormValidations();
      this.onAddValidators(this.shortsPatternFormControls, [
        "normalBodySelect",
      ]);
      this.onRemoveValidators(this.shortsPatternFormControls, [
        "modelNoSelect",
      ]);
    }
    const modal = document.getElementById("shortsPattern") as HTMLElement;
    const snackbar = document.getElementById("shotsSnackbar") as HTMLElement;
    modal.style.display = "block";
    snackbar.style.zIndex = "9999";
  }

  /**
   * This method is used to get colours list
   */
  getColoursList() {
    this.masterService.getColours().subscribe({
      next: (res: any) => {
        this.masterColoursList = res.result;
      },
      error: (err: any) => {
        this.masterColoursList = [];
      },
    });
  }

  /**
   * This method is used to get the Model No list
   * @param {*} eventFlag
   */
  getModelNoList(eventFlag: any) {
    this.chargesService
      .getModelsByDressItemId(this.selectedDressItem?.dressItemId)
      .subscribe({
        next: (res: any) => {
          this.modelNoList = res.result;
          if (eventFlag) {
            let modelNoSelectValue = this.savedShotsPatternDetails?.modelId;
            this.shortsPatternFormControls["modelNoSelect"].setValue(
              modelNoSelectValue?.toString()
            );
            this.onChangeModelNo(modelNoSelectValue);
          }
        },
        error: (err: any) => {
          this.modelNoList = [];
        },
      });
  }

  /**
   * This method is used to get colours list
   * @param {*} eventFlag
   */
  getPocketTypesList(eventFlag: any) {
    this.chargesService.getPocketTypesByDressItemId(this.selectedDressItem?.dressItemId).subscribe({
      next: (res: any) => {
        this.pocketTypesList = res.result;
        if (eventFlag) {
          if (this.selectedPocketRadio === 1) {
            let pocketTypeSelectValue = this.savedShotsPatternDetails?.pocketId;
            this.shortsPatternFormControls["pocketTypeSelect"].setValue(
              pocketTypeSelectValue?.toString()
            );
            this.onChangePocketType(pocketTypeSelectValue);
          }
        }
      },
      error: (err: any) => {
        this.pocketTypesList = [];
      },
    });
  }

  /**
   * This method is used to get striped count list
   * @param {*} eventFlag
   */
  getStripedCountList(eventFlag: any) {
    this.sampleOrderService.getStripedCount().subscribe({
      next: (res: any) => {
        this.stripedCountList = res.result;
        if (eventFlag) {
          if (this.selectedStripedRadio === 1) {
            let stripedCountSelectValue = this.savedShotsPatternDetails
              ?.stripesCount;
            this.shortsPatternFormControls["stripedCountSelect"].setValue(
              stripedCountSelectValue?.toString()
            );
            this.onChangeStripedCount(stripedCountSelectValue);
            let stripedColourRadioValue = this.savedShotsPatternDetails
              ?.isStripesColor
              ? "1"
              : "0";
            this.shortsPatternFormControls["stripedColourRadio"].setValue(
              stripedColourRadioValue?.toString()
            );
            this.onChangeStripedColourRadio(stripedColourRadioValue);
            if (this.selectedStripedColourRadio === 1) {
              let stripedColourSelectValue = this.savedShotsPatternDetails
                ?.stripesColorID;
              this.shortsPatternFormControls["stripedColourSelect"].setValue(
                stripedColourSelectValue?.toString()
              );
              this.onChangeStripedColour(stripedColourSelectValue);
            }
          }
        }
      },
      error: (err: any) => {
        this.stripedCountList = [];
      },
    });
  }

  /**
   * This method is used to add validators
   * @param {*} formControls
   * @param {*} controls
   */
  onAddValidators(formControls: any, controls: any) {
    controls?.forEach((control: any) => {
      formControls[control].addValidators([Validators.required]);
      formControls[control].updateValueAndValidity({ onlySelf: true });
    });
  }

  /**
   * This method is used to remove validators
   * @param {*} formControls
   */
  onRemoveValidators(formControls: any, controls: any) {
    controls?.forEach((control: any) => {
      formControls[control].removeValidators([Validators.required]);
    });
  }

  /**
   * This method is used to update value and validity
   * @param {*} formControls
   */
  onUpdateValueAndValidity(formControls: any, controls: any) {
    controls?.forEach((control: any) => {
      formControls[control].setValue("");
      formControls[control].markAsUntouched({ onlySelf: true });
      formControls[control].updateValueAndValidity({ onlySelf: true });
    });
  }

  /**
   * This method is used to reset the shorts pattern form
   */
  onResetShortsPatternForm() {
    this.selectedPipingRadio = 0;
    this.selectedPocketRadio = 0;
    this.selectedStripedRadio = 0;
    this.selectedStripedColourRadio = 0;
    this.selectedInnerRopeRadio = 0;
    this.selectedModelNo = "";
    this.selectedNormalBody = "";
    this.selectedBody = "";
    this.selectedPanel = "";
    this.selectedPipingColour = "";
    this.selectedPocketType = "";
    this.selectedStripedColour = "";
  }

  /**
   * This method is used to change the model no
   * @param {*} event
   */
  onChangeModelNo(event: any) {
    let modelNoValue = event?.target ? event?.target.value : event;
    this.selectedModelNo = this.modelNoList.filter(
      (item: any) => +item.modelId === +modelNoValue
    )[0];
  }

  /**
   * This method is used to change the body
   * @param {*} event
   */
  onChangeNormalBodySelect(event: any) {
    let bodyValue = event?.target ? event?.target.value : event;
    this.selectedNormalBody = this.masterColoursList.filter(
      (item: any) => +item.colourId === +bodyValue
    )[0];
  }

  /**
   * This method is used to change the piping radio
   * @param {*} event
   */
  onChangePipingRadio(event: any) {
    let pipingRadioValue = event?.target ? event?.target.value : event;
    this.selectedPipingRadio = +pipingRadioValue;
    if (this.selectedPipingRadio === 1) {
      this.onAddValidators(this.shortsPatternFormControls, [
        "pipingColourSelect",
      ]);
    } else {
      this.onRemoveValidators(this.shortsPatternFormControls, [
        "pipingColourSelect",
      ]);
    }
    if (event?.target) {
      this.selectedPipingColour = "";
      this.onUpdateValueAndValidity(this.shortsPatternFormControls, [
        "pipingColourSelect",
      ]);
    }
  }

  /**
   * This method is used to change the piping colour colour
   * @param {*} event
   */
  onChangePipingColour(event: any) {
    let pipingColorValue = event?.target ? event?.target.value : event;
    this.selectedPipingColour = this.masterColoursList.filter(
      (item: any) => +item.colourId === +pipingColorValue
    )[0];
  }

  /**
   * This method is used to change the inner rope radio
   * @param {*} event
   */
  onChangeInnerRopeRadio(event: any) {
    let innerRopeRadioValue = event?.target ? event?.target.value : event;
    this.selectedInnerRopeRadio = +innerRopeRadioValue;
  }

  /**
   * This method is used to change the Striped radio
   * @param {*} event
   */
  onChangeStripedRadio(event: any) {
    let stripedRadioValue = event?.target ? event?.target.value : event;
    this.selectedStripedRadio = +stripedRadioValue;
    if (this.selectedStripedRadio === 1) {
      this.onAddValidators(this.shortsPatternFormControls, [
        "stripedCountSelect",
      ]);
      if (event?.target) {
        this.getStripedCountList("");
      } else {
        this.getStripedCountList("noEvent");
      }
    } else {
      this.onRemoveValidators(this.shortsPatternFormControls, [
        "stripedCountSelect",
      ]);
      this.shortsPatternFormControls["stripedColourRadio"].setValue("0");
      this.selectedStripedColourRadio = 0;
      this.onRemoveValidators(this.shortsPatternFormControls, [
        "stripedColourSelect",
      ]);
    }
    if (event?.target) {
      this.selectedStripedCount = "";
      this.onUpdateValueAndValidity(this.shortsPatternFormControls, [
        "stripedCountSelect",
      ]);
    }
  }

  /**
   * This method is used to change the strip count
   * @param {*} event
   */
  onChangeStripedCount(event: any) {
    let stripedCountValue = event?.target ? event?.target.value : event;
    this.selectedStripedCount = this.stripedCountList.filter(
      (item: any) => +item.id === +stripedCountValue
    )[0];
  }

  /**
   * This method is used to change the Striped colour radio
   * @param {*} event
   */
  onChangeStripedColourRadio(event: any) {
    let stripedColorRadioValue = event?.target ? event?.target.value : event;
    this.selectedStripedColourRadio = +stripedColorRadioValue;
    if (this.selectedStripedColourRadio === 1) {
      this.onAddValidators(this.shortsPatternFormControls, [
        "stripedColourSelect",
      ]);
    } else {
      this.onRemoveValidators(this.shortsPatternFormControls, [
        "stripedColourSelect",
      ]);
    }
    if (event?.target) {
      this.selectedStripedColour = "";
      this.onUpdateValueAndValidity(this.shortsPatternFormControls, [
        "stripedColourSelect",
      ]);
    }
  }

  /**
   * This method is used to change the strip colour
   * @param {*} event
   */
  onChangeStripedColour(event: any) {
    let stripedColorValue = event?.target ? event?.target.value : event;
    this.selectedStripedColour = this.masterColoursList.filter(
      (item: any) => +item.colourId === +stripedColorValue
    )[0];
  }

  /**
   * This method is used to change the pocket radio
   * @param {*} event
   */
  onChangePocketRadio(event: any) {
    let pocketRadioValue = event?.target ? event?.target.value : event;
    this.selectedPocketRadio = +pocketRadioValue;
    if (this.selectedPocketRadio === 1) {
      this.onAddValidators(this.shortsPatternFormControls, [
        "pocketTypeSelect",
      ]);
    } else {
      this.onRemoveValidators(this.shortsPatternFormControls, [
        "pocketTypeSelect",
      ]);
    }
    if (event?.target) {
      this.selectedPocketType = "";
      this.onUpdateValueAndValidity(this.shortsPatternFormControls, [
        "pocketTypeSelect",
      ]);
    }
  }

  /**
   * This method is used to change the pocket type
   * @param {*} event
   */
  onChangePocketType(event: any) {
    let pocketTypeValue = event?.target ? event?.target.value : event;
    this.selectedPocketType = this.pocketTypesList.filter(
      (item: any) => +item.pocketTypeId === +pocketTypeValue
    )[0];
  }

  /**
   * This method is used to change the body
   * @param {*} event
   */
  onChangeBody(event: any) {
    this.selectedBody = this.masterColoursList?.filter(
      (item: any) => +item.colourId === +event.target.value
    )[0];
  }

  /**
   * This method is used to change the Panel
   * @param {*} event
   */
  onChangePanel(event: any) {
    this.selectedPanel = this.masterColoursList?.filter(
      (item: any) => +item.colourId === +event.target.value
    )[0];
  }

  /**
   * This method is used to add the body panels
   */
  onClickAddBodyPanel() {
    this.onAddValidators(this.shortsPatternFormControls, [
      "bodySelect",
      "panelSelect",
    ]);
    const body = this.selectedBody;
    const panel = this.selectedPanel;

    if (!body || !panel) {
      this.shortsPatternFormControls["bodySelect"].markAsTouched({
        onlySelf: true,
      });
      this.shortsPatternFormControls["panelSelect"].markAsTouched({
        onlySelf: true,
      });
      return;
    }

    const existingRecord = this.panelColoursList.find((item) => {
      return (
        item.body?.colourName === body?.colourName &&
        item.panel?.colourName === panel?.colourName
      );
    });

    if (existingRecord) {
      this.showSnackbar("Record Already Exists", '', false, true);
      return;
    }

    /* Prepare the panel colour item object */
    const obj: any = {
      id: this.panelColoursList.length > 0 ? this.panelColoursList.length : 0,
      body: body,
      panel: panel,
    };

    /* Push the panel colour item */
    this.panelColoursList.push(obj);
    this.selectedBody = "";
    this.selectedPanel = "";
    this.onRemoveValidators(this.shortsPatternFormControls, [
      "bodySelect",
      "panelSelect",
    ]);
    this.onUpdateValueAndValidity(this.shortsPatternFormControls, [
      "bodySelect",
      "panelSelect",
    ]);
  }

  /**
   * This method is used to delete the panel colour item
   * @param {*} panelColour
   */
  onClickDeletePanelColourItem(panelColour: any) {
    this.panelColoursList = this.panelColoursList.filter(
      (item: any) => item.id !== panelColour.id
    );
  }

  /**
   * This method is used to show the snackbar
   * @param {string} message
   * @param {*} orderId
   * @param {boolean} successFlag
   * @param {boolean} isModalOverlay
   */
  showSnackbar(message: string, orderId: any, successFlag: boolean, isModalOverlay: boolean) {
    const snackbar = document.getElementById("shotsSnackbar") as HTMLElement;
    this.innerHTMLMessage = message;
    this.innerHTMLOrderId = orderId;
    this.isSuccessSnackbar = successFlag;
    this.isOverlayVisible = isModalOverlay;
    snackbar.style.display = "block";
  }

  /**
   * This method is used to hide the snackbar
   */
  onClickSnackbarOkButton() {
    const snackbar = document.getElementById("shotsSnackbar") as HTMLElement;
    snackbar.style.display = "none";
    this.innerHTMLOrderId = '';
    this.innerHTMLMessage = '';
    this.isOverlayVisible = false;
    this.isSuccessSnackbar = false;
  }

  /**
   * This method is used to reset the selected color fields
   */
  onResetSpecialColorFields() {
    this.selectedBody = "";
    this.selectedPanel = "";
    this.onRemoveValidators(this.shortsPatternFormControls, [
      "bodySelect",
      "panelSelect",
    ]);
    this.onUpdateValueAndValidity(this.shortsPatternFormControls, [
      "bodySelect",
      "panelSelect",
    ]);
  }

  /**
   * This method is used to save the special model items
   */
  onClickSaveShortsPatternItems() {
    this.onResetSpecialColorFields();
    if (
      this.shortsPatternFormControls["pipingRadio"]?.value === "0" &&
      this.shortsPatternFormControls["stripedRadio"]?.value === "0" &&
      this.shortsPatternFormControls["innerRopeRadio"]?.value === "0" &&
      this.shortsPatternFormControls["pocketRadio"]?.value === "0"
    ) {
      console.log("yes");
    } else if (this.shortsPatternForm.invalid) {
      /** This will return false if form fields are invalid and return */
      this.validationService.validateAllFormFields(this.shortsPatternForm);
      return;
    }

    /* Prepare Special Model For Nicker Panel Colors Array */
    const panelColors = [];
    for (let index = 0; index < this.panelColoursList?.length; index++) {
      const element = this.panelColoursList[index];
      panelColors.push({
        bodyColorId: +element.body.colourId,
        panelColorId: +element.panel.colourId,
        patternId: +this.selectedShortPattern?.patternTypeId,
      });
    }

    /* Prepare the shots pattern object */
    const patternForShotsObj = {
      dressItemId: +this.selectedDressItem?.dressItemId,
      patternId: +this.selectedShortPattern?.patternTypeId,
      modelId:
        this.selectedShortPattern?.patternType === "Special"
          ? +this.selectedModelNo?.modelId
          : 0,
      bodyColorId:
        this.selectedShortPattern?.patternType === "Normal"
          ? +this.selectedNormalBody?.colourId
          : 0,
      isPiping: this.selectedPipingRadio === 1,
      pipingColorid:
        this.selectedPipingRadio === 1
          ? +this.selectedPipingColour?.colourId
          : 0,
      isStripes:
        this.selectedShortPattern?.patternType === "Special"
          ? this.selectedStripedRadio === 1
          : false,
      stripesCount:
        this.selectedShortPattern?.patternType === "Special" &&
          this.selectedStripedRadio === 1
          ? +this.selectedStripedCount?.id
          : 0,
      isStripesColor:
        this.selectedShortPattern?.patternType === "Special" &&
        this.selectedStripedRadio === 1 &&
        this.selectedStripedColourRadio === 1,
      stripesColorID:
        this.selectedShortPattern?.patternType === "Special" &&
          this.selectedStripedRadio === 1 &&
          this.selectedStripedColourRadio === 1
          ? +this.selectedStripedColour?.colourId
          : 0,
      isPocket: this.selectedPocketRadio === 1,
      pocketId:
        this.selectedPocketRadio === 1 ? +this.selectedPocketType?.pocketTypeId : 0,
      isPocketColor: false,
      pocketColorId: 0,
      isInnerRope: this.selectedInnerRopeRadio === 1,
      panelColors: panelColors?.length > 0 ? panelColors : [],
    };

    /* Prepare the shots pattern obj */
    const obj = {
      patternforPant: patternForShotsObj,
    };

    localStorage.setItem(
      "shotsPatternPanelColours",
      JSON.stringify(this.panelColoursList)
    );

    console.log(obj);

    this.orderService.orderPatternDetailsObj.next(obj);
    document.getElementById("closeShotsModal")?.click();
  }
}
