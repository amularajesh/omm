import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OrdersTShirtsPatternModalComponent } from './orders-t-shirts-pattern-modal.component';

describe('OrdersTShirtsPatternModalComponent', () => {
  let component: OrdersTShirtsPatternModalComponent;
  let fixture: ComponentFixture<OrdersTShirtsPatternModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OrdersTShirtsPatternModalComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(OrdersTShirtsPatternModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
