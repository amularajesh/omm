import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { PanelColoursItems } from 'src/app/core/Modals/modals';
import { ChargesService } from 'src/app/core/Services/charges.service';
import { MastersService } from 'src/app/core/Services/masters.service';
import { OrderService } from 'src/app/core/Services/order.service';
import { SampleOrderService } from 'src/app/core/Services/sample-order.service';
import { ValidationService } from 'src/app/core/Services/validation.service';

/**
 * Orders T Shirts Pattern Modal Component
 * @export
 * @class OrdersTShirtsPatternModalComponent
 * @implements {OnInit}
 */
@Component({
  selector: 'app-orders-t-shirts-pattern-modal',
  templateUrl: './orders-t-shirts-pattern-modal.component.html',
  styleUrls: ['./orders-t-shirts-pattern-modal.component.scss']
})
export class OrdersTShirtsPatternModalComponent implements OnInit {
  /**
   * Get Selected T-Shirt Pattern
   * @type {*}
   */
  selectedTShirtPattern: any;

  /**
   * Get Selected Dress Item
   * @type {*}
   */
  selectedDressItem: any;

  /**
   * Declare T-shirts Pattern Form
   * @type {FormGroup}
   */
  tShirtsPatternForm!: FormGroup;

  /**
   * Declare T-shirts Special Model Form
   * @type {FormGroup}
   */
  tShirtsSpecialModelForm!: FormGroup;

  /**
   * Declare T-shirts Special Pattern Form
   * @type {FormGroup}
   */
  tShirtsSpecialPatternForm!: FormGroup;

  /**
   * Declare T-shirts Normal Pattern Form
   * @type {FormGroup}
   */
  tShirtsNormalPatternForm!: FormGroup;

  /**
   * Get Master Colours List
   */
  masterColoursList: any;

  /**
   * Get Model No. List
   */
  modelNoList: any;

  /**
   * Get Neck Collars List
   */
  neckCollarsList: any;

  /**
   * Get Cuffs List
   */
  cuffsList: any;

  /**
   * Get Cuff Types List
   */
  cuffTypesList: any;

  /**
   * Get Neb Folding Types List
   */
  nebFoldingTypesList: any;

  /**
   * Get Collar Types List
   */
  collarTypesList: any;

  /**
   * Get Striped Collar Types List
   */
  stripedCollarTypesList: any;

  /**
   * Get V-Neck Models List
   */
  vNeckModelsList: any;

  /**
   * Get Cuff NebFolding List
   */
  cuffNebFoldingList: any;

  /**
   * Get T-Shirt Colours List
   */
  tShirtsColoursList: any;

  /**
   * Get Selected Piping Radio
   */
  selectedPipingRadio = 0;

  /**
   * Get Selected Neb Folding Radio
   */
  selectedNebFoldingRadio = 0;

  /**
   * Get Selected Sleeve Radio
   */
  selectedSleeveRadio = 0;

  /**
   * Get Selected Printing Radio
   */
  selectedPrintingRadio = 0;

  /**
   * Get Selected Printing Type Radio
   */
  selectedPrintingTypeRadio = 1;

  /**
   * Get Selected Sublimation Radio
   */
  selectedSublimationRadio = 23;

  /**
   * Get Selected Back Print Radio
   */
  selectedBackPrintRadio = 0;

  /**
   * Get Selected Embroidery Radio
   */
  selectedEmbroideryRadio = 0;

  /**
   * Get Selected Fusing Radio
   */
  selectedFusingRadio = 0;

  /**
   * Get Selected Fusing Type
   */
  selectedFusingType: any;

  /**
   * Get Selected Fusing Type Radio
   */
  selectedFusingTypeRadio = 1;

  /**
   * Get Selected Cuff Radio
   */
  selectedCuffRadio = 0;

  /**
   * Get Selected Model No.
   * @type {*}
   */
  selectedModelNo: any;

  /**
   * Get Selected Neck Collar
   * @type {*}
   */
  selectedNeckCollar: any;

  /**
   * Get Selected V Neck Model
   * @type {*}
   */
  selectedVNeckModel: any;

  /**
   * Get Selected Rib Colour
   * @type {*}
   */
  selectedRibColour: any;

  /**
   * Get Selected Special Model Collar Type
   * @type {*}
   */
  selectedSpecialModelCollarType: any;

  /**
   * Get Selected Special Model Striped Collar Type
   * @type {*}
   */
  selectedSpecialModelStripedCollarType: any;

  /**
   * Get Selected Special Model V Neck Colour
   * @type {*}
   */
  selectedSpecialModelVNeckColour: any;

  /**
   * Get Selected Special Model Collar T-Shirt colour
   * @type {*}
   */
  selectedCollarTShirtColour: any;

  /**
   * Get Selected Special Model Collar colour
   * @type {*}
   */
  selectedCollarColour: any;

  /**
   * Get Selected Special Model Striped Collar colour
   * @type {*}
   */
  selectedStripedCollarColour: any;

  /**
   * Get Selected Piping Colour
   * @type {*}
   */
  selectedPipingColour: any;

  /**
   * Get Selected Neb Folding Type
   * @type {*}
   */
  selectedNebFoldingType: any;

  /**
   * Get Selected Neb Folding Colour
   * @type {*}
   */
  selectedNebFoldingColour: any;

  /**
   * Get Selected Sleeve
   * @type {*}
   */
  selectedRegionSleeve: any;

  /**
   * Get Selected Cuff
   * @type {*}
   */
  selectedCuff: any;

  /**
   * Get Selected Cuff Type
   * @type {*}
   */
  selectedCuffType: any;

  /**
   * Get Selected T-Shirt Colour
   * @type {*}
   */
  selectedTShirtColour: any;

  /**
   * Get Selected Cuff Colour
   * @type {*}
   */
  selectedCuffColour: any;

  /**
   * Get Selected Striped Colour
   * @type {*}
   */
  selectedStripedColour: any;

  /**
   * Get Selected Body
   * @type {*}
   */
  selectedBody: any;

  /**
   * Get Selected Panel
   * @type {*}
   */
  selectedPanel: any;

  /**
   * Get Selected Patti
   * @type {*}
   */
  selectedPatti: any;

  /**
   * Get Selected Special Pattern Body
   * @type {*}
   */
  selectedSpecialPatternBody: any;

  /**
   * Get Selected Special Pattern Sleeve
   * @type {*}
   */
  selectedSpecialPatternSleeve: any;

  /**
   * Get Selected Special Pattern Collar Type
   * @type {*}
   */
  selectedSpecialPatternCollarType: any;

  /**
   * Get Selected Special Pattern Striped Collar
   * @type {*}
   */
  selectedSpecialPatternStripedCollar: any;

  /**
   * Get Selected Pattern T-Shirt Colour
   * @type {*}
   */
  selectedPatternTShirtColour: any;

  /**
   * Get Selected Pattern Collar Colour
   * @type {*}
   */
  selectedPatternCollarColour: any;

  /**
   * Get Selected Pattern Striped Colour
   * @type {*}
   */
  selectedPatternStripedColour: any;

  /**
   * Get Selected Pattern Cuff T-Shirt Colour
   * @type {*}
   */
  selectedPatternCuffTShirtColour: any;

  /**
   * Get Selected Pattern Cuff Colour
   * @type {*}
   */
  selectedPatternCuffColour: any;

  /**
   * Get Selected Pattern Cuff Striped Colour
   * @type {*}
   */
  selectedPatternCuffStripedColour: any;

  /**
   * Get Selected Cuff NebFolding
   * @type {*}
   */
  selectedCuffNebFolding: any;

  /**
   * Get Selected Special Pattern NebFolding
   * @type {*}
   */
  selectedSpecialPatternNebFolding: any;

  /**
   * Get Selected Special Pattern NebFolding Colour
   * @type {*}
   */
  selectedSpecialPatternNebFoldingColour: any;

  /**
   * Get Selected Pattern Cuff
   * @type {*}
   */
  selectedPatternCuff: any;

  /**
   * Get Selected Pattern Cuff Type
   * @type {*}
   */
  selectedPatternCuffType: any;

  /**
   * Get Selected Special Pattern Slit Radio
   */
  selectedSlitRadio = 0;

  /**
   * Get Selected Normal Pattern Collar Type
   * @type {*}
   */
  selectedNormalPatternCollarType: any;

  /**
   * Get Selected Normal Pattern Striped Collar
   * @type {*}
   */
  selectedNormalPatternStripedCollar: any;

  /**
   * Get Selected Normal Pattern T-Shirt Colour
   * @type {*}
   */
  selectedNormalPatternTShirtColour: any;

  /**
   * Get Selected Normal Pattern Collar Colour
   * @type {*}
   */
  selectedNormalPatternCollarColour: any;

  /**
   * Get Selected Normal Pattern Striped Colour
   * @type {*}
   */
  selectedNormalPatternStripedColour: any;

  /**
   * Get Collar Colours List
   * @type {*}
   */
  collarColoursList: any = [];

  /**
   * Get Cuff Colours List
   * @type {*}
   */
  cuffColoursList: any = [];

  /**
   * Get Pattern Colours List
   */
  patternColoursList: any = [];

  /**
   * Get Pattern Cuff Colours List
   */
  patternCuffColoursList: any = [];

  /**
   * Get Panel Colours List
   * @type {PanelColoursItems[]}
   */
  panelColoursList: PanelColoursItems[] = [];

  /**
   * Get Normal Pattern Colours List
   */
  normalPatternColoursList: any[] = [];

  /**
   * Get Fusing Types List
   * @type {*}
   */
  fusingTypesList: any;

  /**
   * Get Saved T-Shirts Special Model Pattern Details
   * @type {*}
   */
  savedSpecialModelPatternDetails: any;

  /**
   * Get Saved T-Shirts Special Pattern Details
   * @type {*}
   */
  savedSpecialPatternDetails: any;

  /**
   * Get Saved T-Shirts Normal Pattern Details
   * @type {*}
   */
  savedNormalPatternDetails: any;

  /**
   * Get Is Success Snackbar Flag
   */
  isSuccessSnackbar = false;

  /**
   * Get Is Overlay Visible Flag
   */
  isOverlayVisible = false;

  /**
   * Get Inner HTML Message
   */
  innerHTMLMessage = '';

  /**
   * Get Inner HTML Order Id
   */
  innerHTMLOrderId = '';

  /**
   * Get T-Shirt Patterns Form Validations
   */
  tShirtsPatternFormValidation = this.validationService.tShirtsPattern;

  /**
   * Get Patterns
   */
  patterns = this.validationService.patterns;

  /**
   * Creates an instance of OrdersTShirtsPatternModalComponent.
   * @param {ValidationService} validationService
   * @param {FormBuilder} formBuilder
   * @param {SampleOrderService} sampleOrderService
   * @param {OrderService} orderService
   * @param {ChargesService} chargesService
   * @param {MastersService} masterService
   * @param {ChangeDetectorRef} cdr
   */
  constructor(
    private validationService: ValidationService,
    private formBuilder: FormBuilder,
    private sampleOrderService: SampleOrderService,
    private orderService: OrderService,
    private chargesService: ChargesService,
    private masterService: MastersService,
    private cdr: ChangeDetectorRef
  ) {
    /* Get Pattern Details from behavior subject */
    this.orderService.orderPatternDetailsObj.subscribe((val: any) => {
      if (Object.keys(val).length > 0) {
        this.savedSpecialModelPatternDetails = val?.specialModelForTShirt;
        this.savedSpecialPatternDetails = val?.specialPatternForTshirt;
        this.savedNormalPatternDetails = val?.normalPatternforTshirt;
      } else {
        this.savedSpecialModelPatternDetails = "";
        this.savedSpecialPatternDetails = "";
        this.savedNormalPatternDetails = "";
      }
    });
  }

  /**
   * Initialize Life Cycle Hook Initialization
   */
  ngOnInit(): void {
    this.getColoursList();
    this.tShirtsPatternFormValidations();
    this.tShirtsSpecialModelFormValidations();
    this.tShirtsSpecialPatternFormValidations();
    this.tShirtsNormalPatternFormValidations();
  }

  /**
   * Initialize T-Shirts Pattern Form Validations
   */
  tShirtsPatternFormValidations() {
    this.tShirtsPatternForm = this.formBuilder.group({
      pattern: [
        this.selectedTShirtPattern?.patternType || "",
        [Validators.required]
      ],
      dressItem: [
        this.selectedDressItem?.dressItemName || "",
        [Validators.required]
      ]
    });
  }

  /**
   * Initialize T-Shirts Special Model Form Validations
   */
  tShirtsSpecialModelFormValidations() {
    let modelValue = this.savedSpecialModelPatternDetails?.modelId || "";
    let neckCollarValue = this.savedSpecialModelPatternDetails?.neckCollarId || "";
    let collarSelectValue = "";
    let vNeckSelectValue = "";
    let ribColourSelectValue = "";
    let neckTypeCollarSelectValue = "";
    let vNeckColourSelectValue = "";
    let vNeckModelNameValue = "";
    let pipingValue = this.savedSpecialModelPatternDetails?.isPiping ? "1" : "0";
    let pipingColorValue = "";
    let nebFoldingValue = this.savedSpecialModelPatternDetails?.isNebfolding ? "1" : "0";
    let nebFoldingTypeValue = "";
    let nebFoldingColorSelectValue = "";
    let sleeveRadioValue = "0";
    let sleeveSelectValue = "";
    let cuffRadioValue = "0";
    let cuffValue = "";
    let cuffCollarTypeValue = "";
    let printingValue = "0";
    let printingTypeValue = "1";
    let sublimationValue = "24";
    let backPrintValue = "0";
    let embroideryValue = "0";
    let fusingValue = "0";
    let fusingTypeValue = "";

    if (this.savedSpecialModelPatternDetails) {
      sleeveRadioValue = this.savedSpecialModelPatternDetails?.sleveId?.toString();
      if (this.savedSpecialModelPatternDetails?.isCuff) {
        cuffRadioValue = "1";
      }
      if (this.savedSpecialModelPatternDetails?.printingId !== 0) {
        printingValue = "1";
      }
      this.onChangePrintingRadio(printingValue);
      if (this.selectedPrintingRadio === 1) {
        printingTypeValue = this.savedSpecialModelPatternDetails?.printingId?.toString();
      }
      this.onChangePrintingTypeRadio(printingTypeValue);
      if (this.selectedPrintingTypeRadio === 2) {
        sublimationValue = this.savedSpecialModelPatternDetails?.sublimationId?.toString();
      }
      this.onChangeSublimationRadio(sublimationValue);
      if (this.selectedSublimationRadio == 23) {
        backPrintValue = this.savedSpecialModelPatternDetails?.isBackPrint ? '1' : '0';
      }
      this.onChangeBackPrintRadio(backPrintValue);
      if (this.savedSpecialModelPatternDetails?.fusingId !== 0) {
        fusingValue = "1";
      }
      this.onChangeFusingRadio(fusingValue);
      if (this.selectedFusingRadio !== 0) {
        fusingTypeValue = this.savedSpecialModelPatternDetails?.fusingId?.toString();
      }
      embroideryValue = this.savedSpecialModelPatternDetails?.isEmbroidery ? '1' : '0';
      this.onChangeEmbroideryRadio(embroideryValue);
    } else {
      this.onResetTShirtSpecialModelForm();
    }

    this.tShirtsSpecialModelForm = this.formBuilder.group({
      modelNoSelect: [modelValue, [Validators.required]],
      neckCollarSelect: [neckCollarValue, [Validators.required]],
      collarSelect: [collarSelectValue],
      vNeckModelSelect: [vNeckSelectValue],
      ribColourSelect: [ribColourSelectValue],
      neckTypeCollarSelect: [neckTypeCollarSelectValue],
      collarTShirtColourSelect: [""],
      collarColourSelect: [""],
      stripedCollarColourSelect: [""],
      vNeckColourSelect: [vNeckColourSelectValue],
      vNeckModelName: [vNeckModelNameValue,
        [
          Validators.minLength(this.tShirtsPatternFormValidation.vNeckModelName.minLength),
          Validators.maxLength(this.tShirtsPatternFormValidation.vNeckModelName.maxLength)
        ]
      ],
      pipingRadio: [pipingValue],
      pipingColourSelect: [pipingColorValue],
      nebFoldingRadio: [nebFoldingValue],
      nebFoldingTypeSelect: [nebFoldingTypeValue],
      nebFoldingColourSelect: [nebFoldingColorSelectValue],
      sleeveRadio: [sleeveRadioValue],
      reglonSleeveColourSelect: [sleeveSelectValue],
      cuffRadio: [cuffRadioValue],
      cuffSelect: [cuffValue],
      cuffTypeSelect: [cuffCollarTypeValue],
      tShirtColourSelect: [""],
      cuffColourSelect: [""],
      stripeColourSelect: [""],
      bodySelect: [""],
      panelSelect: [""],
      printingRadio: [printingValue],
      printingTypeRadio: [printingTypeValue],
      sublimationRadio: [sublimationValue],
      embroideryRadio: [embroideryValue],
      fusingRadio: [fusingValue],
      fusingType: [fusingTypeValue],
      backPrintingRadio: [backPrintValue]
    });

    if (this.savedSpecialModelPatternDetails) {
      this.onChangePipingRadio(pipingValue);
      this.onChangeNebFoldingRadio(nebFoldingValue);
      this.onChangeSleeveRadio(sleeveRadioValue);
      this.onChangeCuffRadio(cuffRadioValue);
    }
  }

  /**
   * Initialize T-Shirts Special Pattern Form Validations
   */
  tShirtsSpecialPatternFormValidations() {
    let pattiSelectValue = "";
    let bodySelectValue = "";
    let sleeveSelectValue = "";
    let collarTypeSelectValue = "";
    let stripedCollarSelectValue = "";
    let cuffNebfoldingSelectValue = "";
    let cuffSelectValue = "";
    let cuffTypeSelectValue = "";
    let nebfoldingSelectValue = "";
    let nebfoldingColourSelectValue = "";
    let nebfoldingSizeValue = "";
    let slitValue = "0";

    if (this.savedSpecialPatternDetails) {
      pattiSelectValue = this.savedSpecialPatternDetails?.pattiColorId;
      bodySelectValue = this.savedSpecialPatternDetails?.bodyColorId;
      sleeveSelectValue = this.savedSpecialPatternDetails?.sleveColorId;
      slitValue = this.savedSpecialPatternDetails?.isSLIT ? "1" : "0";
      this.onChangeSlitRadio(slitValue);
    } else {
      this.onResetTShirtSpecialPatternForm();
    }

    this.tShirtsSpecialPatternForm = this.formBuilder.group({
      pattiSelect: [pattiSelectValue, [Validators.required]],
      specialPatternBodySelect: [bodySelectValue, [Validators.required]],
      sleeveSelect: [sleeveSelectValue, [Validators.required]],
      collarTypeSelect: [collarTypeSelectValue, [Validators.required]],
      stripedCollarSelect: [stripedCollarSelectValue],
      patternTShirtColourSelect: [""],
      collarColourSelect: [""],
      patternStripedColourSelect: [""],
      cuffNebfoldingSelect: [cuffNebfoldingSelectValue, [Validators.required]],
      cuffSelect: [cuffSelectValue],
      cuffTypeSelect: [cuffTypeSelectValue],
      patternCuffTShirtColourSelect: [""],
      patternCuffColourSelect: [""],
      patternCuffStripedColourSelect: [""],
      nebfoldingSelect: [nebfoldingSelectValue],
      nebfoldingColourSelect: [nebfoldingColourSelectValue],
      nebfoldingSize: [nebfoldingSizeValue,
        [
          Validators.minLength(this.tShirtsPatternFormValidation.nebfoldingSize.minLength),
          Validators.maxLength(this.tShirtsPatternFormValidation.nebfoldingSize.maxLength),
          Validators.pattern(this.patterns.sizeRegex)
        ]
      ],
      slit: [slitValue, [Validators.required]]
    });
  }

  /**
   * Initialize T-Shirts Normal Pattern Form Validations
   */
  tShirtsNormalPatternFormValidations() {
    let normalCollarTypeValue = "";
    let normalStripedCollarTypeValue = "";

    if (this.savedNormalPatternDetails) {
    } else {
      this.onResetTShirtNormalPatternForm();
    }

    this.tShirtsNormalPatternForm = this.formBuilder.group({
      normalPatternCollarTypeSelect: [normalCollarTypeValue, [Validators.required]],
      normalPatternStripedCollarSelect: [normalStripedCollarTypeValue],
      normalPatternTShirtColourSelect: [""],
      normalPatternCollarColourSelect: [""],
      normalPatternStripedColourSelect: [""]
    });
  }

  /**
   * Get T-Shirts Special Model Form Controls
   * @readonly
   */
  get tShirtsSpecialModelFormControls() {
    return this.tShirtsSpecialModelForm.controls;
  }

  /**
   * Get T-Shirts Special Pattern Form Controls
   * @readonly
   */
  get tShirtsSpecialPatternFormControls() {
    return this.tShirtsSpecialPatternForm.controls;
  }

  /**
   * Get T-Shirts Normal Pattern Form Controls
   * @readonly
   */
  get tShirtsNormalPatternFormControls() {
    return this.tShirtsNormalPatternForm.controls;
  }

  /**
   * This method is used to open the T-Shirts Pattern Modal
   * @param {*} selectedPattern
   * @param {*} selectedDressItem
   */
  openModal(selectedPattern: any, selectedDressItem: any) {
    this.selectedTShirtPattern = selectedPattern;
    this.selectedDressItem = selectedDressItem;
    this.tShirtsPatternFormValidations();
    this.getColoursList();
    if (this.selectedTShirtPattern?.patternType === "Special Model") {
      this.tShirtsSpecialModelFormValidations();
      if (this.savedSpecialModelPatternDetails) {
        this.getModelNoList("noEvent");
        this.getNeckCollarsList("noEvent");
      } else {
        this.getModelNoList("");
        this.getNeckCollarsList("");
      }
    } else if (this.selectedTShirtPattern?.patternType === "Special Pattern") {
      this.tShirtsSpecialPatternFormValidations();
      if (this.savedSpecialPatternDetails) {
        this.getCollarTypesList("noEvent");
        this.getCuffNebFoldingList("noEvent");
      } else {
        this.getCollarTypesList("");
        this.getCuffNebFoldingList("");
      }
    } else {
      this.tShirtsNormalPatternFormValidations();
      if (this.savedNormalPatternDetails) {
        this.getCollarTypesList("noEvent");
      } else {
        this.getCollarTypesList("");
      }
    }
    document.getElementById("tShirtsPatternModalButton")?.click();
    const savedOrderItemsList = JSON.parse(localStorage.getItem("savedOrdersList")!);
    // Use a Set to store unique colour names
    const uniqueColourNames = new Set(savedOrderItemsList.map((item: any) => item.colourName));
    // Create a new array with unique items based on colourName
    const uniqueArray = Array.from(uniqueColourNames).map(colourName => {
      return savedOrderItemsList.find((item: any) => item.colourName === colourName);
    });
    this.tShirtsColoursList = uniqueArray;

    const modal = document.getElementById("tShirtsPattern") as HTMLElement;
    const snackbar = document.getElementById("tShirtsSnackbar") as HTMLElement;
    modal.style.display = "block";
    snackbar.style.zIndex = "9999";
  }

  /**
   * This method is used to reset the t-shirt special model form
   */
  onResetTShirtSpecialModelForm() {
    this.selectedNeckCollar = "";
    this.selectedPipingRadio = 0;
    this.selectedNebFoldingRadio = 0;
    this.selectedSleeveRadio = 0;
    this.selectedCuffRadio = 0;
    this.selectedPipingColour = "";
    this.selectedNebFoldingType = "";
    this.selectedNebFoldingColour = "";
    this.selectedRegionSleeve = "";
    this.selectedCuff = "";
    this.selectedCuffType = "";
    this.selectedPrintingRadio = 0;
    this.selectedPrintingTypeRadio = 1;
    this.selectedSublimationRadio = 23;
    this.selectedEmbroideryRadio = 0;
    this.selectedFusingRadio = 0;
    this.selectedFusingTypeRadio = 1;
    this.collarColoursList = [];
    this.cuffColoursList = [];
    this.panelColoursList = [];
  }

  /**
   * This method is used to reset the t-shirt special pattern form
   */
  onResetTShirtSpecialPatternForm() {
    this.selectedPatti = "";
    this.selectedSpecialPatternBody = "";
    this.selectedSpecialPatternCollarType = "";
    this.selectedPatternTShirtColour = "";
    this.selectedPatternCollarColour = "";
    this.selectedPatternStripedColour = "";
    this.selectedPatternCuffTShirtColour = "";
    this.selectedPatternCuffColour = "";
    this.selectedPatternCuffStripedColour = "";
    this.selectedCuffNebFolding = "";
    this.selectedPatternCuff = "";
    this.selectedPatternCuffType = "";
    this.selectedSlitRadio = 0;
    this.patternColoursList = [];
    this.patternCuffColoursList = [];
  }

  /**
   * This method is used to reset the t-shirt normal pattern form
   */
  onResetTShirtNormalPatternForm() {
    this.selectedNormalPatternCollarType = "";
    this.normalPatternColoursList = [];
  }

  /**
   * This method is used to get colours list
   */
  getColoursList() {
    this.masterService.getColours().subscribe({
      next: (res: any) => {
        this.masterColoursList = res.result;

        if (this.savedSpecialModelPatternDetails) {

          if (this.selectedPipingRadio === 1) {
            let pipingColorValue = this.savedSpecialModelPatternDetails?.pipingColorId;
            setTimeout(() => {
              this.tShirtsSpecialModelFormControls["pipingColourSelect"].setValue(pipingColorValue?.toString());
              this.cdr.detectChanges();
            }, 50);
            this.onChangePipingColour(pipingColorValue);
          }

          if (this.selectedNebFoldingRadio === 1) {
            let nebFoldingColorSelectValue = this.savedSpecialModelPatternDetails?.nebfoldingColorID;
            setTimeout(() => {
              this.tShirtsSpecialModelFormControls["nebFoldingColourSelect"].setValue(nebFoldingColorSelectValue?.toString());
              this.cdr.detectChanges();
            }, 50);
            this.onChangeNebFoldingColour(nebFoldingColorSelectValue);
          }

          if (this.selectedSleeveRadio === 1) {
            let sleeveSelectValue = this.savedSpecialModelPatternDetails?.sleveColorId?.toString();
            setTimeout(() => {
              this.tShirtsSpecialModelFormControls["reglonSleeveColourSelect"].setValue(sleeveSelectValue?.toString());
              this.cdr.detectChanges();
            }, 50);
            this.onChangeSleeve(sleeveSelectValue);
          }

          const responsePanelItems = this.savedSpecialModelPatternDetails?.panelColors?.map((responseData: any, index: any) => {
            const bodyColour = this.masterColoursList?.find((element: any) => +responseData?.bodyColorId === +element?.colourId);
            const panelColour = this.masterColoursList?.find((element: any) => +responseData?.panelColorId === +element?.colourId);
            return {
              id: index,
              body: bodyColour,
              panel: panelColour
            };
          });

          if (responsePanelItems?.length > 0) {
            localStorage.setItem("tShirtSpecialModelPanel", JSON.stringify(responsePanelItems));
            this.panelColoursList = responsePanelItems || [];
          } else {
            this.panelColoursList = JSON.parse(localStorage.getItem("tShirtSpecialModelPanel")!) || [];
          }

        } else if (this.savedSpecialPatternDetails) {
          let pattiSelectValue = this.savedSpecialPatternDetails?.pattiColorId;
          let bodySelectValue = this.savedSpecialPatternDetails?.bodyColorId;
          let sleeveSelectValue = this.savedSpecialPatternDetails?.sleveColorId;
          let nebfoldingColourSelectValue = this.savedSpecialPatternDetails?.nebfoldingColorId;
          setTimeout(() => {
            this.tShirtsSpecialPatternFormControls["pattiSelect"].setValue(pattiSelectValue?.toString());
            this.tShirtsSpecialPatternFormControls["specialPatternBodySelect"].setValue(bodySelectValue?.toString());
            this.tShirtsSpecialPatternFormControls["sleeveSelect"].setValue(sleeveSelectValue?.toString());
            this.tShirtsSpecialPatternFormControls["nebfoldingColourSelect"].setValue(nebfoldingColourSelectValue?.toString());
            this.cdr.detectChanges();
          }, 50);
          this.onChangePatti(pattiSelectValue);
          this.onChangeSpecialPatternBody(bodySelectValue);
          this.onChangeSpecialPatternSleeve(sleeveSelectValue);
          this.onChangeSpecialPatternNebFoldingColour(nebfoldingColourSelectValue);
        }
      },
      error: (err: any) => {
        this.masterColoursList = [];
      }
    });
  }

  /**
   * This method is used to get the neck collars list
   * @param {*} eventFlag
   */
  getModelNoList(eventFlag: any) {
    this.chargesService.getModelsByDressItemId(this.selectedDressItem?.dressItemId).subscribe({
      next: (res: any) => {
        this.modelNoList = res.result;
        if (eventFlag) {
          let modelValue = this.savedSpecialModelPatternDetails?.modelId;
          setTimeout(() => {
            this.tShirtsSpecialModelFormControls["modelNoSelect"].setValue(modelValue?.toString());
            this.cdr.detectChanges();
          }, 50);
          this.onChangeModelNo(modelValue);
        }
      },
      error: (err: any) => {
        this.modelNoList = [];
      }
    });
  }

  /**
   * This method is used to get the neck collars list
   * @param {*} eventFlag
   */
  getNeckCollarsList(eventFlag: any) {
    this.sampleOrderService.getNeckCollars().subscribe({
      next: (res: any) => {
        this.neckCollarsList = res.result;
        if (eventFlag) {
          if (this.savedSpecialModelPatternDetails) {
            let neckCollarValue = this.savedSpecialModelPatternDetails?.neckCollarId;
            setTimeout(() => {
              this.tShirtsSpecialModelFormControls['neckCollarSelect'].setValue(neckCollarValue?.toString());
              this.cdr.detectChanges();
            }, 50);
            this.onChangeNeckCollar(neckCollarValue);
            if (this.selectedNeckCollar?.name === "Round Neck") {
              let ribColourSelectValue = this.savedSpecialModelPatternDetails?.roundNeckRibColorId;
              setTimeout(() => {
                this.tShirtsSpecialModelFormControls['ribColourSelect'].setValue(ribColourSelectValue?.toString());
                this.cdr.detectChanges();
              }, 50);
              this.onChangeRibColour(ribColourSelectValue);
            }
          }
        }
      },
      error: (err: any) => {
        this.neckCollarsList = [];
      }
    });
  }

  /**
   * This method is used to get the cuff nebfolding list
   * @param {*} eventFlag
   */
  getCuffNebFoldingList(eventFlag: any) {
    this.sampleOrderService.getCuffForNebFolding().subscribe({
      next: (res: any) => {
        this.cuffNebFoldingList = res.result;
        if (eventFlag) {
          /* Cuff Nebfolding */
          let cuffNebfoldingSelectValue = this.savedSpecialPatternDetails?.cuffNameById;
          setTimeout(() => {
            this.tShirtsSpecialPatternFormControls["cuffNebfoldingSelect"].setValue(cuffNebfoldingSelectValue?.toString());
            this.cdr.detectChanges();
          }, 50);
          this.onChangeCuffNebFolding(cuffNebfoldingSelectValue);

          if (this.selectedCuffNebFolding.name === "Nebfolding") {
            let nebfoldingSizeValue = this.savedSpecialPatternDetails?.nebfoldingSize;
            this.tShirtsSpecialPatternFormControls["nebfoldingSize"].setValue(nebfoldingSizeValue?.toString());
          }
        }
      },
      error: (err: any) => {
        this.cuffNebFoldingList = [];
      }
    });
  }

  /**
   * This method is used to get the cuffs list
   * @param {*} eventFlag
   */
  getCuffsList(eventFlag: any) {
    this.sampleOrderService.getCuffs().subscribe({
      next: (res: any) => {
        this.cuffsList = res.result;
        if (eventFlag) {
          if (this.savedSpecialModelPatternDetails) {

            if (this.selectedCuffRadio === 1) {
              let cuffValue = this.savedSpecialModelPatternDetails?.cuffId;
              setTimeout(() => {
                this.tShirtsSpecialModelFormControls["cuffSelect"].setValue(cuffValue?.toString());
                this.cdr.detectChanges();
              }, 50);
              this.onChangeCuff(cuffValue);


            }
          } else if (this.savedSpecialPatternDetails) {

            if (this.selectedCuffNebFolding.name === "Cuff") {
              let cuffSelectValue = this.savedSpecialPatternDetails?.cuffId;
              setTimeout(() => {
                this.tShirtsSpecialPatternFormControls["cuffSelect"].setValue(cuffSelectValue?.toString());
                this.cdr.detectChanges();
              }, 50);
              this.onChangePatternCuff(cuffSelectValue);

              let responseSpecialPatternItems = this.savedSpecialPatternDetails?.specialPatternCuffs?.map((responseData: any, index: any) => {
                const tShirtColour = this.tShirtsColoursList?.find((element: any) => +responseData?.tShirtColorId === +element?.colorId);
                const cuffColour = this.masterColoursList?.find((element: any) => +responseData?.cuffColorId === +element?.colourId);
                const stripeColour = this.masterColoursList?.find((element: any) => +responseData?.cuffStripeColorId === +element?.colourId);
                return {
                  id: index,
                  tShirtColour: tShirtColour,
                  cuffColour: cuffColour,
                  stripeColour: this.selectedPatternCuff?.name === "Stripe Cuff" ? stripeColour : 0
                };
              });

              responseSpecialPatternItems = responseSpecialPatternItems.filter((item: any) => item.tShirtColour);

              if (responseSpecialPatternItems?.length > 0) {
                localStorage.setItem("tShirtsSpecialPatternCuffs", JSON.stringify(responseSpecialPatternItems));
                this.patternCuffColoursList = responseSpecialPatternItems || [];
              }
              // else {
              //   this.patternCuffColoursList = JSON.parse(localStorage.getItem("tShirtsSpecialPatternCuffs")!) || [];
              // }
            }
          }
        }

      },
      error: (err: any) => {
        this.cuffsList = [];
      }
    });
  }

  /**
   * This method is used to get the cuff types list
   */
  getCuffTypesList(eventFlag: any) {
    this.sampleOrderService.getCuffTypes().subscribe({
      next: (res: any) => {
        this.cuffTypesList = res.result;
        if (eventFlag) {
          if (this.savedSpecialModelPatternDetails) {
            if (this.selectedCuff?.name === "Stripe Cuff") {
              let cuffCollarTypeValue = this.savedSpecialModelPatternDetails?.cuffCollarTypeId;
              setTimeout(() => {
                this.tShirtsSpecialModelFormControls["cuffTypeSelect"].setValue(cuffCollarTypeValue?.toString());
                this.cdr.detectChanges();
              }, 50);
              this.onChangeCuffType(cuffCollarTypeValue);
            }

            console.log(this.savedSpecialModelPatternDetails?.specialModelCuffs);

            let responseCuffItems = this.savedSpecialModelPatternDetails?.specialModelCuffs?.map((responseData: any, index: any) => {
              const tShirtColour = this.tShirtsColoursList?.find((element: any) => +responseData?.tShirtColorId === +element?.colorId);
              const cuffColour = this.masterColoursList?.find((element: any) => +responseData?.cuffColorId === +element?.colourId);
              const stripeColour = this.masterColoursList?.find((element: any) => +responseData?.cuffStripeColorId === +element?.colourId);
              return {
                id: index,
                tShirtColour: tShirtColour,
                cuffColour: cuffColour,
                stripeColour: this.selectedCuff?.name === "Stripe Cuff" ? stripeColour : 0
              };
            });

            responseCuffItems = responseCuffItems.filter((item: any) => item.tShirtColour);

            if (responseCuffItems?.length > 0) {
              localStorage.setItem("tShirtSpecialModelCuffs", JSON.stringify(responseCuffItems));
              this.cuffColoursList = responseCuffItems || [];
            }
            //  else {
            //   this.cuffColoursList = JSON.parse(localStorage.getItem("tShirtSpecialModelCuffs")!) || [];
            // }

          } else if (this.savedSpecialPatternDetails) {
            if (this.selectedPatternCuff?.name === "Stripe Cuff") {
              let cuffTypeSelectValue = this.savedSpecialPatternDetails?.cuffTypeId;
              setTimeout(() => {
                this.tShirtsSpecialPatternFormControls["cuffTypeSelect"].setValue(cuffTypeSelectValue?.toString());
                this.cdr.detectChanges();
              }, 50);
              this.onChangePatternCuffType(cuffTypeSelectValue);
            }
          }
        }
      },
      error: (err: any) => {
        this.cuffTypesList = [];
      }
    });
  }

  /**
   * This method is used to get the cuff types list
   */
  getNebFoldingTypesList(eventFlag: any) {
    this.sampleOrderService.getNebFoldingTypes().subscribe({
      next: (res: any) => {
        this.nebFoldingTypesList = res.result;
        if (eventFlag) {
          if (this.savedSpecialModelPatternDetails) {
            if (this.selectedNebFoldingRadio === 1) {
              let nebFoldingTypeValue = this.savedSpecialModelPatternDetails?.nebfoldingId;
              setTimeout(() => {
                this.tShirtsSpecialModelFormControls["nebFoldingTypeSelect"].setValue(nebFoldingTypeValue?.toString());
                this.cdr.detectChanges();
              }, 50);
              this.onChangeNebFoldingType(nebFoldingTypeValue);
            }
          } else if (this.savedSpecialPatternDetails) {
            let nebfoldingSelectValue = this.savedSpecialPatternDetails?.nebfoldingId;
            setTimeout(() => {
              this.tShirtsSpecialPatternFormControls["nebfoldingSelect"].setValue(nebfoldingSelectValue?.toString());
              this.cdr.detectChanges();
            }, 50);
            this.onChangeSpecialPatternNebFolding(nebfoldingSelectValue);
          }
        }
      },
      error: (err: any) => {
        this.nebFoldingTypesList = [];
      }
    });
  }

  /**
   * This method is used to get the collar types list
   * @param {*} eventFlag
   */
  getCollarTypesList(eventFlag: any) {
    this.sampleOrderService.getCollarTypes().subscribe({
      next: (res: any) => {
        this.collarTypesList = res.result;
        if (eventFlag) {
          if (this.selectedTShirtPattern?.patternType === 'Special Model' && (this.selectedNeckCollar?.name === "Collar" || this.selectedNeckCollar?.name === "Collar & Cuff")) {
            /* Collar Type Select */
            let collarSelectValue = this.savedSpecialModelPatternDetails?.collarTypeId;
            setTimeout(() => {
              this.tShirtsSpecialModelFormControls['collarSelect'].setValue(collarSelectValue?.toString());
              this.cdr.detectChanges();
            }, 50);
            this.onChangeSpecialModelCollarType(collarSelectValue);

            let responseModelCollarItems = this.savedSpecialModelPatternDetails?.specialModelCollars?.map((responseData: any, index: any) => {
              const tShirtColour = this.tShirtsColoursList?.find((element: any) => +responseData?.tShirtColorId === +element?.colorId);
              const collarColour = this.masterColoursList?.find((element: any) => +responseData?.collarColorId === +element?.colourId);
              const stripeColour = this.masterColoursList?.find((element: any) => +responseData?.stripeColorId === +element?.colourId);
              return {
                id: index,
                tShirtColour: tShirtColour,
                collarColour: collarColour,
                stripeColour: this.selectedSpecialModelCollarType?.name === 'Striped Collar' ? stripeColour : 0
              };
            });

            responseModelCollarItems = responseModelCollarItems.filter((item: any) => item.tShirtColour);
            if (responseModelCollarItems?.length > 0) {
              localStorage.setItem("tShirtSpecialModelCollars", JSON.stringify(responseModelCollarItems));
              this.collarColoursList = responseModelCollarItems || [];
            }
            // else {
            //   this.collarColoursList = JSON.parse(localStorage.getItem("tShirtSpecialModelCollars")!) || [];
            // }

          } else if (this.selectedTShirtPattern?.patternType === 'Normal') {
            let normalCollarTypeValue = this.savedNormalPatternDetails?.collarTypeId;
            setTimeout(() => {
              this.tShirtsNormalPatternFormControls["normalPatternCollarTypeSelect"].setValue(normalCollarTypeValue?.toString());
              this.cdr.detectChanges();
            }, 50);
            this.onChangeNormalPatternCollarType(normalCollarTypeValue);

            let responseNormalCollarItems = this.savedNormalPatternDetails?.normalPatternCollar?.map((responseData: any, index: any) => {
              const tShirtColour = this.tShirtsColoursList?.find((element: any) => +responseData?.tShirtColorId === +element?.colorId);
              const collarColour = this.masterColoursList?.find((element: any) => +responseData?.collarColorId === +element?.colourId);
              const stripeColour = this.masterColoursList?.find((element: any) => +responseData?.stripeColorId === +element?.colourId);
              return {
                id: index,
                tShirtColour: tShirtColour,
                collarColour: collarColour,
                stripeColour: this.selectedNormalPatternCollarType?.name === "Striped Collar" ? stripeColour : 0
              };
            });

            responseNormalCollarItems = responseNormalCollarItems.filter((item: any) => item.tShirtColour);

            if (responseNormalCollarItems?.length > 0) {
              localStorage.setItem("tShirtsNormalPatternCollar", JSON.stringify(responseNormalCollarItems));
              this.normalPatternColoursList = responseNormalCollarItems || [];
            }
            // else {
            //   this.normalPatternColoursList = JSON.parse(localStorage.getItem("tShirtsNormalPatternCollar")!) || [];
            // }

          } else if (this.selectedTShirtPattern?.patternType === 'Special Pattern') {
            let collarTypeSelectValue = this.savedSpecialPatternDetails?.collarTypeId;
            setTimeout(() => {
              this.tShirtsSpecialPatternFormControls["collarTypeSelect"].setValue(collarTypeSelectValue?.toString());
              this.cdr.detectChanges();
            }, 50);
            this.onChangeCollarType(collarTypeSelectValue);

            let responseSpecialCollarItems = this.savedSpecialPatternDetails?.specialPatternCollars?.map((responseData: any, index: any) => {
              const tShirtColour = this.tShirtsColoursList?.find((element: any) => +responseData?.tShirtColorId === +element?.colorId);
              const collarColour = this.masterColoursList?.find((element: any) => +responseData?.collarColorId === +element?.colourId);
              const stripeColour = this.masterColoursList?.find((element: any) => +responseData?.stripeColorId === +element?.colourId);
              return {
                id: index,
                tShirtColour: tShirtColour,
                collarColour: collarColour,
                stripeColour: this.selectedSpecialPatternCollarType?.name === "Striped Collar" ? stripeColour : 0
              };
            });

            responseSpecialCollarItems = responseSpecialCollarItems.filter((item: any) => item.tShirtColour);

            if (responseSpecialCollarItems?.length > 0) {
              localStorage.setItem("tShirtsSpecialPatternCollars", JSON.stringify(responseSpecialCollarItems));
              this.patternColoursList = responseSpecialCollarItems || [];
            }
            // else {
            //   this.patternColoursList = JSON.parse(localStorage.getItem("tShirtsSpecialPatternCollars")!) || [];
            // }
          }
        }
      },
      error: (err: any) => {
        this.collarTypesList = [];
      }
    });
  }

  /**
   * This method is used to get the striped collar types list
   * @param {*} eventFlag
   */
  getStripedCollarTypesList(eventFlag: any) {
    this.sampleOrderService.getStripedCollarTypes().subscribe({
      next: (res: any) => {
        this.stripedCollarTypesList = res.result;
        if (eventFlag) {
          if (this.selectedTShirtPattern?.patternType === 'Special Model' && this.selectedSpecialModelCollarType?.name === "Striped Collar") {
            let neckTypeCollarSelectValue = this.savedSpecialModelPatternDetails?.collarId;
            setTimeout(() => {
              this.tShirtsSpecialModelFormControls['neckTypeCollarSelect'].setValue(neckTypeCollarSelectValue?.toString());
              this.cdr.detectChanges();
            }, 50);
            this.onChangeSpecialModelStripedCollar(neckTypeCollarSelectValue);
          }

          if (this.selectedTShirtPattern?.patternType === 'Normal' && this.selectedNormalPatternCollarType?.name === "Striped Collar") {
            let normalStripedCollarTypeValue = this.savedNormalPatternDetails?.collarId;
            setTimeout(() => {
              this.tShirtsNormalPatternFormControls["normalPatternStripedCollarSelect"].setValue(normalStripedCollarTypeValue?.toString());
              this.cdr.detectChanges();
            }, 50);
            this.onChangeNormalPatternStripedCollar(normalStripedCollarTypeValue);
          }

          if (this.selectedTShirtPattern?.patternType === 'Special Pattern' && this.selectedSpecialPatternCollarType?.name === "Striped Collar") {
            let stripedCollarSelectValue = this.savedSpecialPatternDetails?.collarId;
            setTimeout(() => {
              this.tShirtsSpecialPatternFormControls["stripedCollarSelect"].setValue(stripedCollarSelectValue?.toString());
              this.cdr.detectChanges();
            }, 50);
            this.onChangeSpecialPatternStripedCollar(stripedCollarSelectValue);
          }
        }
      },
      error: (err: any) => {
        this.stripedCollarTypesList = [];
      }
    });
  }

  /**
   * This method is used to get the V-Neck Models list
   * @param {*} eventFlag
   */
  getVNeckModelsList(eventFlag: any) {
    this.sampleOrderService.getVNeckModels().subscribe({
      next: (res: any) => {
        this.vNeckModelsList = res.result;
        if (eventFlag) {
          if (this.selectedNeckCollar?.name === "V Neck") {
            let vNeckSelectValue = this.savedSpecialModelPatternDetails?.vneckModelId;
            setTimeout(() => {
              this.tShirtsSpecialModelFormControls['vNeckModelSelect'].setValue(vNeckSelectValue?.toString());
              this.cdr.detectChanges();
            }, 50);
            this.onChangeVNeckModel(vNeckSelectValue);
            if (this.selectedVNeckModel?.name === "V Neck") {
              let vNeckColourSelectValue = this.savedSpecialModelPatternDetails?.vneckColorId;
              setTimeout(() => {
                this.tShirtsSpecialModelFormControls['vNeckColourSelect'].setValue(vNeckColourSelectValue?.toString());
                this.cdr.detectChanges();
              }, 50);
              this.onChangeSpecialModelVNeckColour(vNeckColourSelectValue);
            } else {
              let vNeckModelNameValue = this.savedSpecialModelPatternDetails?.vneckModelName;
              this.tShirtsSpecialModelFormControls['vNeckModelName'].setValue(vNeckModelNameValue?.toString());
            }
          }
        }
      },
      error: (err: any) => {
        this.vNeckModelsList = [];
      }
    });
  }

  /**
   * This method is used to get the Fusing Type list
   * @param {*} eventFlag
   */
  getFusingList(eventFlag: any) {
    /* To call the service to get the Fusing Type list */
    this.masterService.getFusingTypes().subscribe({
      next: (res: any) => {
        this.fusingTypesList = res.result;
        if (eventFlag) {
          let fusingTypeValue = this.savedSpecialModelPatternDetails?.fusingId?.toString();
          setTimeout(() => {
            this.tShirtsSpecialModelFormControls["fusingType"].setValue(fusingTypeValue?.toString());
            this.cdr.detectChanges();
          }, 50);
          this.onChangeFusingType(fusingTypeValue);
        }
      },
      error: (err: any) => {
        this.fusingTypesList = [];
      },
    });
  }

  /**
   * This method is used to add validators
   * @param {*} formControls
   * @param {*} controls
   */
  onAddValidators(formControls: any, controls: any) {
    controls?.forEach((control: any) => {
      formControls[control].addValidators([Validators.required]);
      formControls[control].updateValueAndValidity({ onlySelf: true });
    });
  }

  /**
   * This method is used to remove validators
   * @param {*} formControls
   */
  onRemoveValidators(formControls: any, controls: any) {
    controls?.forEach((control: any) => {
      formControls[control].removeValidators([Validators.required]);
      formControls[control].updateValueAndValidity({ onlySelf: true });
    });
  }

  /**
   * This method is used to update value and validity
   * @param {*} formControls
   */
  onUpdateValueAndValidity(formControls: any, controls: any) {
    controls?.forEach((control: any) => {
      formControls[control].setValue("");
      formControls[control].markAsUntouched({ onlySelf: true });
      formControls[control].updateValueAndValidity({ onlySelf: true });
    });
  }

  /**
   * This method is used to change the model no
   * @param {*} event
   */
  onChangeModelNo(event: any) {
    let modelNoValue = event?.target ? event.target.value : event;
    this.selectedModelNo = this.modelNoList.filter((item: any) => +item.modelId === +modelNoValue)[0];
  }

  /**
   * This method is used to change the neck collar
   * @param {*} event
   */
  onChangeNeckCollar(event: any) {
    let neckCollarValue = event?.target ? event.target.value : event;
    this.selectedNeckCollar = this.neckCollarsList.filter((item: any) => +item.id === +neckCollarValue)[0];
    if (this.selectedNeckCollar?.name === "V Neck") {
      this.onAddValidators(this.tShirtsSpecialModelFormControls, ["vNeckModelSelect"]);
      this.onRemoveValidators(this.tShirtsSpecialModelFormControls, ["collarSelect", "ribColourSelect"]);
      if (event?.target) {
        this.getVNeckModelsList("");
      } else {
        this.getVNeckModelsList("noEvent");
      }
    } else if (this.selectedNeckCollar?.name === "Collar" || this.selectedNeckCollar?.name === "Collar & Cuff") {
      this.onAddValidators(this.tShirtsSpecialModelFormControls, ["collarSelect"]);
      this.onRemoveValidators(this.tShirtsSpecialModelFormControls, ["vNeckModelSelect", "ribColourSelect"]);
      if (event?.target) {
        this.getCollarTypesList("");
      } else {
        this.getCollarTypesList("noEvent");
      }
    } else {
      this.onAddValidators(this.tShirtsSpecialModelFormControls, ["ribColourSelect"]);
      this.onRemoveValidators(this.tShirtsSpecialModelFormControls, ["vNeckModelSelect", "collarSelect"]);
    }
    if (event?.target) {
      this.onUpdateValueAndValidity(this.tShirtsSpecialModelFormControls, ["vNeckModelSelect", "collarSelect", "ribColourSelect"]);
    }
    this.onChangeVNeckModel("");
    this.onChangeRibColour("");
    this.onChangeSpecialModelCollarType("");
  }

  /**
   * This method is used to change the v neck model
   * @param {*} event
   */
  onChangeVNeckModel(event: any) {
    if (event) {
      let vNeckCollarValue = event?.target ? event.target.value : event;
      this.selectedVNeckModel = this.vNeckModelsList.filter(
        (item: any) => +item.id === +vNeckCollarValue
      )[0];
      if (this.selectedVNeckModel?.name === "V Neck") {
        this.onAddValidators(this.tShirtsSpecialModelFormControls, [
          "vNeckColourSelect",
        ]);
        this.onRemoveValidators(this.tShirtsSpecialModelFormControls, [
          "vNeckModelName",
        ]);
      } else {
        this.onAddValidators(this.tShirtsSpecialModelFormControls, [
          "vNeckModelName",
        ]);
        this.onRemoveValidators(this.tShirtsSpecialModelFormControls, [
          "vNeckColourSelect",
        ]);
      }
    } else {
      this.onRemoveValidators(this.tShirtsSpecialModelFormControls, [
        "vNeckColourSelect",
        "vNeckModelName",
      ]);
      this.selectedVNeckModel = "";
    }
    this.onUpdateValueAndValidity(this.tShirtsSpecialModelFormControls, [
      "vNeckColourSelect",
      "vNeckModelName",
    ]);
  }

  /**
   * This method is used to change the rib colour
   * @param {*} event
   */
  onChangeRibColour(event: any) {
    if (event) {
      let ribColourValue = event?.target ? event.target.value : event;
      this.selectedRibColour = this.masterColoursList.filter(
        (item: any) => +item.colourId === +ribColourValue
      )[0];
    } else {
      this.selectedRibColour = "";
    }
  }

  /**
   * This method is used to change the special model collar type
   * @param {*} event
   */
  onChangeSpecialModelCollarType(event: any) {
    if (event) {
      let collarTypeValue = event?.target ? event.target.value : event;
      this.selectedSpecialModelCollarType = this.collarTypesList.filter((item: any) => +item.id === +collarTypeValue)[0];
      if (this.selectedSpecialModelCollarType?.name === "Striped Collar") {
        this.onAddValidators(this.tShirtsSpecialModelFormControls, ["neckTypeCollarSelect"]);
        if (event?.target) {
          this.getStripedCollarTypesList("");
        } else {
          this.getStripedCollarTypesList("noEvent");
        }
      } else {
        this.onRemoveValidators(this.tShirtsSpecialModelFormControls, ["neckTypeCollarSelect"]);
      }
    } else {
      this.onRemoveValidators(this.tShirtsSpecialModelFormControls, ["neckTypeCollarSelect"]);
      this.selectedSpecialModelCollarType = "";
    }
    this.onUpdateValueAndValidity(this.tShirtsSpecialModelFormControls, ["neckTypeCollarSelect"]);
    this.collarColoursList = [];
    this.selectedSpecialModelStripedCollarType = "";
    this.onUpdateValueAndValidity(this.tShirtsSpecialModelFormControls, ["collarTShirtColourSelect", "collarColourSelect", "stripedCollarColourSelect"]);
    this.selectedCollarTShirtColour = '';
    this.selectedCollarColour = '';
    this.selectedStripedCollarColour = '';
  }

  /**
   * This method is used to change the special model striped collar
   * @param {*} event
   */
  onChangeSpecialModelStripedCollar(event: any) {
    let stripedCollarTypeValue = event?.target ? event.target.value : event;
    this.selectedSpecialModelStripedCollarType = this.stripedCollarTypesList.filter(
      (item: any) => +item.id === +stripedCollarTypeValue
    )[0];
  }

  /**
   * This method is used to change the special model striped collar
   * @param {*} event
   */
  onChangeSpecialModelVNeckColour(event: any) {
    let vNeckColourValue = event?.target ? event.target.value : event;
    this.selectedSpecialModelVNeckColour = this.masterColoursList.filter(
      (item: any) => +item.colourId === +vNeckColourValue
    )[0];
  }

  /**
   * This method is used to change the Collar T-Shirt Colour
   * @param {*} event
   */
  onChangeCollarTShirtColour(event: any) {
    this.selectedCollarTShirtColour = this.tShirtsColoursList?.filter(
      (item: any) => +item.colorId === +event.target.value
    )[0];
  }

  /**
   * This method is used to change the Collar Colour
   * @param {*} event
   */
  onChangeCollarColour(event: any) {
    this.selectedCollarColour = this.masterColoursList?.filter(
      (item: any) => +item.colourId === +event.target.value
    )[0];
  }

  /**
   * This method is used to change the Collar Colour
   * @param {*} event
   */
  onChangeStripedCollarColour(event: any) {
    this.selectedStripedCollarColour = this.masterColoursList?.filter(
      (item: any) => +item.colourId === +event.target.value
    )[0];
  }

  /**
   * This method is used to add the Collar Colour
   */
  onClickAddCollarColour() {
    this.onAddValidators(this.tShirtsSpecialModelFormControls, [
      "collarTShirtColourSelect",
      "collarColourSelect",
    ]);
    if (this.selectedSpecialModelCollarType?.name === "Striped Collar") {
      this.onAddValidators(this.tShirtsSpecialModelFormControls, ["stripedCollarColourSelect"]);
      this.tShirtsSpecialModelFormControls[
        "stripedCollarColourSelect"
      ].markAsTouched({ onlySelf: true });
    } else {
      this.onRemoveValidators(this.tShirtsSpecialModelFormControls, [
        "stripedCollarColourSelect",
      ]);
      this.tShirtsSpecialModelFormControls[
        "stripedCollarColourSelect"
      ].markAsUntouched({ onlySelf: true });
    }

    const collarTShirtColour = this.selectedCollarTShirtColour;
    const collarColor = this.selectedCollarColour;
    const stripedCollarColor = this.selectedStripedCollarColour;

    if (!collarTShirtColour || !collarColor) {
      this.tShirtsSpecialModelFormControls[
        "collarTShirtColourSelect"
      ].markAsTouched({ onlySelf: true });
      this.tShirtsSpecialModelFormControls["collarColourSelect"].markAsTouched({
        onlySelf: true,
      });
      return;
    }

    if (
      this.selectedSpecialModelCollarType?.name === "Striped Collar" &&
      !stripedCollarColor
    ) {
      this.tShirtsSpecialModelFormControls[
        "stripedCollarColourSelect"
      ].markAsTouched({ onlySelf: true });
      return;
    }

    const existingRecord = this.collarColoursList.find((item: any) => {
      return item.tShirtColour?.colourName === collarTShirtColour?.colourName;
    });

    if (existingRecord) {
      this.showSnackbar("Record Already Exists", '', false, true);
      return;
    }

    /* Prepare the colour item object */
    const obj: any = {
      id: this.collarColoursList?.length > 0 ? this.collarColoursList?.length : 0,
      tShirtColour: collarTShirtColour,
      collarColour: collarColor,
      stripeColour: this.selectedSpecialModelCollarType?.name === "Striped Collar" ? stripedCollarColor : 0,
    };

    console.log(obj);

    /* Push the colour item */
    this.collarColoursList?.push(obj);
    this.selectedCollarTShirtColour = "";
    this.selectedCollarColour = "";
    this.selectedStripedCollarColour = "";
    this.onRemoveValidators(this.tShirtsSpecialModelFormControls, ["collarTShirtColourSelect", "collarColourSelect", "stripedCollarColourSelect"]);
    this.onUpdateValueAndValidity(this.tShirtsSpecialModelFormControls, ["collarTShirtColourSelect", "collarColourSelect", "stripedCollarColourSelect"]);
  }

  /**
   * This method is used to delete the colour item
   * @param {*} colour
   */
  onClickDeleteCollarColourItem(colour: any) {
    this.collarColoursList = this.collarColoursList?.filter(
      (item: any) => item.id !== colour.id
    );
  }

  /**
   * This method is used to change the piping radio
   * @param {*} event
   */
  onChangePipingRadio(event: any) {
    let pipingValue = event?.target ? event.target.value : event;
    this.selectedPipingRadio = +pipingValue;
    this.selectedPipingColour = "";
    if (this.selectedPipingRadio === 1) {
      this.onAddValidators(this.tShirtsSpecialModelFormControls, [
        "pipingColourSelect",
      ]);
    } else {
      this.onRemoveValidators(this.tShirtsSpecialModelFormControls, [
        "pipingColourSelect",
      ]);
    }
    this.onUpdateValueAndValidity(this.tShirtsSpecialModelFormControls, [
      "pipingColourSelect",
    ]);
  }

  /**
   * This method is used to change the piping colour
   * @param {*} event
   */
  onChangePipingColour(event: any) {
    let pipingColorValue = event?.target ? event.target.value : event;
    this.selectedPipingColour = this.masterColoursList.filter(
      (item: any) => +item.colourId === +pipingColorValue
    )[0];
  }

  /**
   * This method is used to change the neb folding radio
   * @param {*} event
   */
  onChangeNebFoldingRadio(event: any) {
    let nebFoldingValue = event?.target ? event.target.value : event;
    this.selectedNebFoldingRadio = +nebFoldingValue;
    this.selectedNebFoldingType = "";
    if (this.selectedNebFoldingRadio === 1) {
      if (event?.target) {
        this.getNebFoldingTypesList("");
      } else {
        this.getNebFoldingTypesList("noEvent");
      }
      this.onAddValidators(this.tShirtsSpecialModelFormControls, ["nebFoldingTypeSelect", "nebFoldingColourSelect"]);
    } else {
      this.onRemoveValidators(this.tShirtsSpecialModelFormControls, ["nebFoldingTypeSelect", 'nebFoldingColourSelect']);
    }
    if (event?.target) {
      this.onUpdateValueAndValidity(this.tShirtsSpecialModelFormControls, ["nebFoldingTypeSelect", "nebFoldingColourSelect"]);
    }
  }

  /**
   * This method is used to change the neb folding type
   * @param {*} event
   */
  onChangeNebFoldingType(event: any) {
    let nebFoldingTypeValue = event?.target ? event.target.value : event;
    this.selectedNebFoldingType = this.nebFoldingTypesList.filter(
      (item: any) => +item.id === +nebFoldingTypeValue
    )[0];
  }

  /**
   * This method is used to change the neb folding colour
   * @param {*} event
   */
  onChangeNebFoldingColour(event: any) {
    let nebFoldingColorValue = event?.target ? event.target.value : event;
    this.selectedNebFoldingColour = this.masterColoursList.filter(
      (item: any) => +item.colourId === +nebFoldingColorValue
    )[0];
  }

  /**
   * This method is used to change the sleeve radio
   * @param {*} event
   */
  onChangeSleeveRadio(event: any) {
    let sleeveValue = event?.target ? event.target.value : event;
    this.selectedSleeveRadio = +sleeveValue;
    if (this.selectedSleeveRadio === 1) {
      this.onAddValidators(this.tShirtsSpecialModelFormControls, [
        "reglonSleeveColourSelect",
      ]);
    } else {
      this.onRemoveValidators(this.tShirtsSpecialModelFormControls, [
        "reglonSleeveColourSelect",
      ]);
    }
    this.onUpdateValueAndValidity(this.tShirtsSpecialModelFormControls, [
      "reglonSleeveColourSelect",
    ]);
  }

  /**
   * This method is used to change the sleeve
   * @param {*} event
   */
  onChangeSleeve(event: any) {
    let sleeveColorValue = event?.target ? event.target.value : event;
    this.selectedRegionSleeve = this.masterColoursList.filter((item: any) => +item.colourId === +sleeveColorValue)[0];
  }

  /**
   * This method is used to change the cuff radio
   * @param {*} event
   */
  onChangeCuffRadio(event: any) {
    let cuffRadioValue = event?.target ? event.target.value : event;
    this.selectedCuffRadio = +cuffRadioValue;
    this.cuffColoursList = [];
    this.selectedCuff = "";
    this.selectedCuffType = "";
    if (this.selectedCuffRadio === 1) {
      if (event?.target) {
        this.getCuffsList("");
      } else {
        this.getCuffsList("noEvent")
      }
      this.onAddValidators(this.tShirtsSpecialModelFormControls, ["cuffSelect"]);
    } else {
      this.onRemoveValidators(this.tShirtsSpecialModelFormControls, ["cuffSelect"]);
      this.onRemoveValidators(this.tShirtsSpecialModelFormControls, ["cuffTypeSelect"]);
    }
    if (event?.target) {
      this.onUpdateValueAndValidity(this.tShirtsSpecialModelFormControls, ["cuffSelect", "cuffTypeSelect"]);
    }
  }

  /**
   * This method is used to change the cuff
   * @param {*} event
   */
  onChangeCuff(event: any) {
    let cuffValue = event?.target ? event.target.value : event;
    this.selectedCuff = this.cuffsList.filter((item: any) => +item.id === +cuffValue)[0];
    this.cuffColoursList = [];
    this.selectedCuffType = "";
    if (this.selectedCuff?.name === "Stripe Cuff") {
      this.onAddValidators(this.tShirtsSpecialModelFormControls, ["cuffTypeSelect"]);
    } else {
      this.onRemoveValidators(this.tShirtsSpecialModelFormControls, ["cuffTypeSelect"]);
    }
    if (event?.target) {
      this.getCuffTypesList("");
    } else {
      this.getCuffTypesList("noEvent");
    }
    if (event?.target) {
      this.onUpdateValueAndValidity(this.tShirtsSpecialModelFormControls, ["cuffTypeSelect"]);
    }
    this.selectedTShirtColour = '';
    this.selectedCuffColour = '';
    this.selectedStripedColour = '';
    this.onUpdateValueAndValidity(this.tShirtsSpecialModelFormControls, ["tShirtColourSelect", "cuffColourSelect", "stripeColourSelect"]);
  }

  /**
   * This method is used to change the cuff type
   * @param {*} event
   */
  onChangeCuffType(event: any) {
    let cuffTypeValue = event?.target ? event.target.value : event;
    this.selectedCuffType = this.cuffTypesList?.filter((item: any) => +item.id === +cuffTypeValue)[0];
  }

  /**
   * This method is used to change the T-Shirt Colour
   * @param {*} event
   */
  onChangeTShirtColour(event: any) {
    this.selectedTShirtColour = this.tShirtsColoursList?.filter(
      (item: any) => +item.colorId === +event.target.value
    )[0];
  }

  /**
   * This method is used to change the Cuff Colour
   * @param {*} event
   */
  onChangeCuffColour(event: any) {
    this.selectedCuffColour = this.masterColoursList?.filter(
      (item: any) => +item.colourId === +event.target.value
    )[0];
  }

  /**
   * This method is used to change the Striped Colour
   * @param {*} event
   */
  onChangeStripedColour(event: any) {
    this.selectedStripedColour = this.masterColoursList?.filter(
      (item: any) => +item.colourId === +event.target.value
    )[0];
  }

  /**
   * This method is used to change the Printing radio
   * @param {*} event
   */
  onChangePrintingRadio(event: any) {
    let printingRadioValue = event?.target ? event.target.value : event;
    this.selectedPrintingRadio = +printingRadioValue;
    if (event?.target) {
      this.tShirtsSpecialModelFormControls["printingTypeRadio"].setValue("1");
      this.tShirtsSpecialModelFormControls["sublimationRadio"].setValue("23");
      this.selectedPrintingTypeRadio = 1;
      this.selectedSublimationRadio = 23;
    }
  }

  /**
   * This method is used to change the Printing type radio
   * @param {*} event
   */
  onChangePrintingTypeRadio(event: any) {
    let printingTypeValue = event?.target ? event.target.value : event;
    this.selectedPrintingTypeRadio = +printingTypeValue;
    if (event?.target) {
      this.tShirtsSpecialModelFormControls["sublimationRadio"].setValue("23");
      this.selectedSublimationRadio = 23;
    }
  }

  /**
   * This method is used to change the Sublimation radio
   * @param {*} event
   */
  onChangeSublimationRadio(event: any) {
    let sublimationValue = event?.target ? event.target.value : event;
    this.selectedSublimationRadio = +sublimationValue;
    if (this.selectedSublimationRadio == 24) {
      this.selectedBackPrintRadio = 0;
      this.tShirtsSpecialModelFormControls["backPrintingRadio"].setValue("0");
    }
  }

  /**
   * This method is used to change the back print radio
   * @param {*} event
   */
  onChangeBackPrintRadio(event: any) {
    let backPrintValue = event?.target ? event.target.value : event;
    this.selectedBackPrintRadio = +backPrintValue;
  }

  /**
   * This method is used to change the Embroidery radio
   * @param {*} event
   */
  onChangeEmbroideryRadio(event: any) {
    let embroideryValue = event?.target ? event.target.value : event;
    this.selectedEmbroideryRadio = +embroideryValue;
  }

  /**
   * This method is used to change the Fusing radio
   * @param {*} event
   */
  onChangeFusingRadio(event: any) {
    let fusingValue = event?.target ? event.target.value : event;
    this.selectedFusingRadio = +fusingValue;
    if (this.selectedFusingRadio === 1) {
      if (event?.target) {
        this.getFusingList("");
      } else {
        this.getFusingList("noEvent");
      }
      this.onAddValidators(this.tShirtsSpecialModelFormControls, ["fusingType"]);
    } else {
      this.onRemoveValidators(this.tShirtsSpecialModelFormControls, ["fusingType"]);
    }
    if (event?.target) {
      this.onUpdateValueAndValidity(this.tShirtsSpecialModelFormControls, ["fusingType"]);
    }
  }

  /**
   * This method is used to change the fusing type
   * @param {*} event
   */
  onChangeFusingType(event: any) {
    let fusingTypeValue = event?.target ? event.target.value : event;
    this.selectedFusingType = this.fusingTypesList?.filter((item: any) => +item.fusingTypeId === +fusingTypeValue)[0];
  }

  /**
   * This method is used to change the body
   * @param {*} event
   */
  onChangeBody(event: any) {
    this.selectedBody = this.masterColoursList?.filter(
      (item: any) => +item.colourId === +event.target.value
    )[0];
  }

  /**
   * This method is used to change the Panel
   * @param {*} event
   */
  onChangePanel(event: any) {
    this.selectedPanel = this.masterColoursList?.filter(
      (item: any) => +item.colourId === +event.target.value
    )[0];
  }

  /**
   * This method is used to add the cuff colours
   */
  onClickAddCuffColour() {
    this.onAddValidators(this.tShirtsSpecialModelFormControls, [
      "tShirtColourSelect",
      "cuffColourSelect",
    ]);
    if (this.selectedCuff?.name === "Stripe Cuff") {
      this.onAddValidators(this.tShirtsSpecialModelFormControls, [
        "stripeColourSelect",
      ]);
      this.tShirtsSpecialModelFormControls["stripeColourSelect"].markAsTouched({
        onlySelf: true,
      });
    } else {
      this.onRemoveValidators(this.tShirtsSpecialModelFormControls, [
        "stripeColourSelect",
      ]);
      this.tShirtsSpecialModelFormControls[
        "stripeColourSelect"
      ].markAsUntouched({ onlySelf: true });
    }

    const tShirtColor = this.selectedTShirtColour;
    const cuffColor = this.selectedCuffColour;
    const stripeColor = this.selectedStripedColour;

    if (!tShirtColor || !cuffColor) {
      this.tShirtsSpecialModelFormControls["tShirtColourSelect"].markAsTouched({
        onlySelf: true,
      });
      this.tShirtsSpecialModelFormControls["cuffColourSelect"].markAsTouched({
        onlySelf: true,
      });
      return;
    }

    if (this.selectedCuff?.name === "Stripe Cuff" && !stripeColor) {
      this.tShirtsSpecialModelFormControls["stripeColourSelect"].markAsTouched({
        onlySelf: true,
      });
      return;
    }

    const existingRecord = this.cuffColoursList?.find((item: any) => {
      return item?.tShirtColour?.colourName === tShirtColor?.colourName;
    });

    if (existingRecord) {
      this.showSnackbar("Record Already Exists", '', false, true);
      return;
    }

    /* Prepare the colour item object */
    const obj: any = {
      id: this.cuffColoursList?.length > 0 ? this.cuffColoursList?.length : 0,
      tShirtColour: tShirtColor,
      cuffColour: cuffColor,
      stripeColour: this.selectedCuff?.name === "Stripe Cuff" ? stripeColor : 0,
    };

    console.log(obj);

    /* Push the colour item */
    this.cuffColoursList?.push(obj);
    this.selectedTShirtColour = "";
    this.selectedCuffColour = "";
    this.selectedStripedColour = "";
    this.onRemoveValidators(this.tShirtsSpecialModelFormControls, [
      "tShirtColourSelect",
      "cuffColourSelect",
      "stripeColourSelect",
    ]);
    this.onUpdateValueAndValidity(this.tShirtsSpecialModelFormControls, [
      "tShirtColourSelect",
      "cuffColourSelect",
      "stripeColourSelect",
    ]);
  }

  /**
   * This method is used to delete the colour item
   * @param {*} colour
   */
  onClickDeleteColourItem(colour: any) {
    this.cuffColoursList = this.cuffColoursList?.filter(
      (item: any) => item.id !== colour.id
    );
  }

  /**
   * This method is used to add the body panels
   */
  onClickAddBodyPanel() {
    this.onAddValidators(this.tShirtsSpecialModelFormControls, [
      "bodySelect",
      "panelSelect",
    ]);
    const body = this.selectedBody;
    const panel = this.selectedPanel;

    if (!body || !panel) {
      this.tShirtsSpecialModelFormControls["bodySelect"].markAsTouched({
        onlySelf: true,
      });
      this.tShirtsSpecialModelFormControls["panelSelect"].markAsTouched({
        onlySelf: true,
      });
      return;
    }

    const existingRecord = this.panelColoursList.find((item) => {
      return (
        item.body?.colourName === body?.colourName &&
        item.panel?.colourName === panel?.colourName
      );
    });

    if (existingRecord) {
      this.showSnackbar("Record Already Exists", '', false, true);
      return;
    }

    /* Prepare the panel colour item object */
    const obj: any = {
      id: this.panelColoursList.length > 0 ? this.panelColoursList.length : 0,
      body: body,
      panel: panel,
    };

    /* Push the panel colour item */
    this.panelColoursList.push(obj);
    this.selectedBody = "";
    this.selectedPanel = "";
    this.onRemoveValidators(this.tShirtsSpecialModelFormControls, [
      "bodySelect",
      "panelSelect",
    ]);
    this.onUpdateValueAndValidity(this.tShirtsSpecialModelFormControls, [
      "bodySelect",
      "panelSelect",
    ]);
  }

  /**
   * This method is used to delete the panel colour item
   * @param {*} panelColour
   */
  onClickDeletePanelColourItem(panelColour: any) {
    this.panelColoursList = this.panelColoursList.filter(
      (item: any) => item.id !== panelColour.id
    );
  }

  /**
   * This method is used to reset the selected color fields
   */
  onResetSpecialModelColorFields() {
    this.selectedBody = '';
    this.selectedPanel = '';
    this.selectedTShirtColour = '';
    this.selectedCuffColour = '';
    this.selectedStripedColour = '';
    this.selectedCollarTShirtColour = '';
    this.selectedCollarColour = '';
    this.selectedStripedCollarColour = '';
    this.onRemoveValidators(this.tShirtsSpecialModelFormControls, [
      "bodySelect",
      "panelSelect",
      "collarTShirtColourSelect",
      "collarColourSelect",
      "stripedCollarColourSelect",
      "tShirtColourSelect",
      "cuffColourSelect",
      "stripeColourSelect",
    ]);
    this.onUpdateValueAndValidity(this.tShirtsSpecialModelFormControls, [
      "bodySelect",
      "panelSelect",
      "collarTShirtColourSelect",
      "collarColourSelect",
      "stripedCollarColourSelect",
      "tShirtColourSelect",
      "cuffColourSelect",
      "stripeColourSelect",
    ]);
  }

  /**
   * This method is used to save the special model items
   */
  onClickSaveSpecialModelItems() {
    this.onResetSpecialModelColorFields();
    /** This will return false if form fields are invalid and return */
    if (this.tShirtsSpecialModelForm.invalid) {
      this.validationService.validateAllFormFields(
        this.tShirtsSpecialModelForm
      );
      return;
    }

    // Extract colourName values from array1
    const colourNamesArray1 = this.tShirtsColoursList.map((item: any) => item.colourName);
    console.log(colourNamesArray1);

    // Check if each colourName in array1 exists in tShirtColour.colourName of array2
    const tShirtColorsForCollarAllExists = colourNamesArray1.every(
      (colourName: any) =>
        this.collarColoursList.some(
          (item: any) => item.tShirtColour.colourName === colourName
        )
    );

    if (this.selectedNeckCollar?.name === "Collar" || this.selectedNeckCollar?.name === "Collar & Cuff") {
      if (this.collarColoursList?.length === 0) {
        this.showSnackbar("Add Order Collar Colours", '', false, true);
        return;
      } else if (!tShirtColorsForCollarAllExists) {
        this.showSnackbar("Add All T-Shirt Colours", '', false, true);
        return;
      }
    }

    // Check if each colourName in array1 exists in tShirtColour.colourName of array2
    const tShirtColorsForCuffAllExists = colourNamesArray1.every(
      (colourName: any) =>
        this.cuffColoursList.some(
          (item: any) => item.tShirtColour.colourName === colourName
        )
    );

    if (this.selectedCuff) {
      if (this.cuffColoursList?.length === 0) {
        this.showSnackbar("Add Order Cuff Colours", '', false, true);
        return;
      } else if (!tShirtColorsForCuffAllExists) {
        this.showSnackbar("Add All T-Shirt Colours", '', false, true);
        return;
      }
    }

    /* Prepare Special Model For TShirt Panel Colors Array */
    const panelColors = [];
    for (let index = 0; index < this.panelColoursList?.length; index++) {
      const element = this.panelColoursList[index];
      panelColors.push({
        bodyColorId: +element.body.colourId,
        panelColorId: +element.panel.colourId,
        patternId: +this.selectedTShirtPattern?.patternTypeId
      });
    }

    /* Prepare Special Model For TShirt Panel Colours Array */
    const specialModelCollars = [];
    for (let index = 0; index < this.collarColoursList?.length; index++) {
      const element = this.collarColoursList[index];
      specialModelCollars.push({
        tShirtColorId: +element?.tShirtColour?.colorId,
        collarColorId: +element?.collarColour?.colourId,
        stripeColorId: element.stripeColour?.colourId ? +element.stripeColour?.colourId : 0
      });
    }

    /* Prepare Special Model For TShirt Panel Colours Array */
    const specialModelCuffs = [];
    for (let index = 0; index < this.cuffColoursList?.length; index++) {
      const element = this.cuffColoursList[index];
      specialModelCuffs.push({
        tShirtColorId: +element?.tShirtColour?.colorId,
        cuffColorId: +element.cuffColour?.colourId,
        cuffStripeColorId: element.stripeColour?.colourId ? +element.stripeColour?.colourId : 0
      });
    }

    /* Prepare Special Model For TShirt Obj */
    const specialModelForTShirtObj = {
      modelId: +this.selectedModelNo?.modelId,
      neckCollarId: +this.selectedNeckCollar?.id,
      collarTypeId: (this.selectedNeckCollar?.name === "Collar" || this.selectedNeckCollar?.name === "Collar & Cuff") ? +this.selectedSpecialModelCollarType?.id : 0,
      collarId: this.selectedSpecialModelCollarType?.name === "Striped Collar" ? +this.selectedSpecialModelStripedCollarType?.id : 0,
      vneckModelId: this.selectedNeckCollar?.name === "V Neck" ? +this.selectedVNeckModel?.id : 0,
      vneckModelName: this.selectedNeckCollar?.name === "V Neck" && this.selectedVNeckModel?.name !== "V Neck" ? this.tShirtsSpecialModelFormControls["vNeckModelName"].value : "",
      vneckColorId: this.selectedNeckCollar?.name === "V Neck" && this.selectedVNeckModel?.name === "V Neck" ? +this.selectedSpecialModelVNeckColour?.colourId : 0,
      roundNeckRibColorId: this.selectedNeckCollar?.name === "Round Neck" ? +this.selectedRibColour?.colourId : 0,
      isPiping: this.selectedPipingRadio === 1,
      pipingColorId: this.selectedPipingRadio === 1 ? +this.selectedPipingColour?.colourId : 0,
      isNebfolding: this.selectedNebFoldingRadio === 1,
      nebfoldingId: this.selectedNebFoldingRadio === 1 ? +this.selectedNebFoldingType?.id : 0,
      isNebfoldingColor: this.selectedNebFoldingRadio === 1,
      nebfoldingColorID: this.selectedNebFoldingRadio === 1 ? +this.selectedNebFoldingColour?.colourId : 0,
      sleveId: this.selectedSleeveRadio,
      sleveColorId: this.selectedSleeveRadio === 1 ? +this.selectedRegionSleeve?.colourId : 0,
      patternId: this.selectedTShirtPattern?.patternTypeId,
      isCuff: false,
      cuffId: 0,
      cuffCollarTypeId: 0,
      printingId: this.selectedPrintingRadio === 1 ? this.selectedPrintingTypeRadio : 0,
      sublimationId: this.selectedPrintingRadio === 1 && this.selectedPrintingTypeRadio === 2 ? this.selectedSublimationRadio : 0,
      isBackPrint: this.selectedPrintingRadio === 1 && this.selectedPrintingTypeRadio === 2 && this.selectedSublimationRadio ? this.selectedBackPrintRadio === 1 : false,
      isEmbroidery: this.selectedEmbroideryRadio === 1,
      fusingId: this.selectedFusingRadio === 1 ? +this.selectedFusingType?.fusingTypeId : 0,
      specialModelCollars: specialModelCollars?.length > 0 ? specialModelCollars : [],
      specialModelCuffs: [],
      panelColors: panelColors?.length > 0 ? panelColors : []
    };

    localStorage.setItem("tShirtSpecialModelCollars", JSON.stringify(this.collarColoursList));
    localStorage.setItem("tShirtSpecialModelCuffs", JSON.stringify(this.cuffColoursList));
    localStorage.setItem("tShirtSpecialModelPanel", JSON.stringify(this.panelColoursList));

    /* Prepare the t-shirt special model object */
    const obj = {
      specialModelForTShirt: specialModelForTShirtObj,
    };

    console.log(obj);
    this.orderService.orderPatternDetailsObj.next(obj);
    document.getElementById("closeTShirtsPatternModal")?.click();
  }

  /**
   * This method is used to change the patti
   * @param {*} event
   */
  onChangePatti(event: any) {
    let pattiValue = event?.target ? event.target.value : event;
    this.selectedPatti = this.masterColoursList?.filter(
      (item: any) => +item.colourId === +pattiValue
    )[0];
  }

  /**
   * This method is used to change the special pattern body
   * @param {*} event
   */
  onChangeSpecialPatternBody(event: any) {
    let patternBodyValue = event?.target ? event.target.value : event;
    this.selectedSpecialPatternBody = this.masterColoursList?.filter(
      (item: any) => +item.colourId === +patternBodyValue
    )[0];
  }

  /**
   * This method is used to change the special pattern sleeve
   * @param {*} event
   */
  onChangeSpecialPatternSleeve(event: any) {
    let patternSleeveValue = event?.target ? event.target.value : event;
    this.selectedSpecialPatternSleeve = this.masterColoursList?.filter(
      (item: any) => +item.colourId === +patternSleeveValue
    )[0];
  }

  /**
   * This method is used to change the collar type
   * @param {*} event
   */
  onChangeCollarType(event: any) {
    let patternCollarValue = event?.target ? event.target.value : event;
    this.selectedSpecialPatternCollarType = this.collarTypesList?.filter((item: any) => +item.id === +patternCollarValue)[0];
    this.patternColoursList = [];
    if (this.selectedSpecialPatternCollarType?.name === "Striped Collar") {
      this.onAddValidators(this.tShirtsSpecialPatternFormControls, ["stripedCollarSelect"]);
      if (event?.target) {
        this.getStripedCollarTypesList("");
      } else {
        this.getStripedCollarTypesList("noEvent");
      }
    } else {
      this.onRemoveValidators(this.tShirtsSpecialPatternFormControls, ["stripedCollarSelect"]);
    }
    this.onUpdateValueAndValidity(this.tShirtsSpecialPatternFormControls, ["stripedCollarSelect"]);
    this.onUpdateValueAndValidity(this.tShirtsSpecialPatternFormControls, ["patternTShirtColourSelect", "collarColourSelect", "patternStripedColourSelect"]);
    this.selectedPatternTShirtColour = '';
    this.selectedPatternCollarColour = '';
    this.selectedPatternStripedColour = '';
  }

  /**
   * This method is used to change the special pattern striped collar
   * @param {*} event
   */
  onChangeSpecialPatternStripedCollar(event: any) {
    let patternStripedCollarValue = event?.target ? event.target.value : event;
    this.selectedSpecialPatternStripedCollar = this.stripedCollarTypesList?.filter(
      (item: any) => +item.id === +patternStripedCollarValue
    )[0];
  }

  /**
   * This method is used to change the pattern t-shirt colour
   * @param {*} event
   */
  onChangePatternTShirtColour(event: any) {
    this.selectedPatternTShirtColour = this.tShirtsColoursList?.filter(
      (item: any) => +item.colorId === +event.target.value
    )[0];
  }

  /**
   * This method is used to change the pattern collar colour
   * @param {*} event
   */
  onChangePatternCollarColour(event: any) {
    this.selectedPatternCollarColour = this.masterColoursList?.filter(
      (item: any) => +item.colourId === +event.target.value
    )[0];
  }

  /**
   * This method is used to change the pattern striped colour
   * @param {*} event
   */
  onChangePatternStripedColour(event: any) {
    this.selectedPatternStripedColour = this.masterColoursList?.filter(
      (item: any) => +item.colourId === +event.target.value
    )[0];
  }

  /**
   * This method is used to change the Cuff NebFolding
   * @param {*} event
   */
  onChangeCuffNebFolding(event: any) {
    let patternCuffNebFoldingValue = event?.target ? event.target.value : event;
    this.selectedCuffNebFolding = this.cuffNebFoldingList?.filter(
      (item: any) => +item.id === +patternCuffNebFoldingValue
    )[0];
    if (this.selectedCuffNebFolding.name === "Cuff") {
      if (event?.target) {
        this.getCuffsList("");
      } else {
        this.getCuffsList("noEvent");
      }
      this.onAddValidators(this.tShirtsSpecialPatternFormControls, ["cuffSelect"]);
      this.onRemoveValidators(this.tShirtsSpecialPatternFormControls, ["nebfoldingSelect", "nebfoldingColourSelect", "nebfoldingSize"]);
    } else if (this.selectedCuffNebFolding.name === "Nebfolding") {
      if (event?.target) {
        this.getNebFoldingTypesList("");
      } else {
        this.getNebFoldingTypesList("noEvent");
      }
      this.onAddValidators(this.tShirtsSpecialPatternFormControls, [
        "nebfoldingSelect",
        "nebfoldingColourSelect",
        "nebfoldingSize",
      ]);
      this.onRemoveValidators(this.tShirtsSpecialPatternFormControls, [
        "cuffSelect",
      ]);
    } else {
      this.onRemoveValidators(this.tShirtsSpecialPatternFormControls, [
        "cuffSelect",
      ]);
      this.onRemoveValidators(this.tShirtsSpecialPatternFormControls, [
        "nebfoldingSelect",
        "nebfoldingColourSelect",
        "nebfoldingSize",
      ]);
    }
    if (event?.target) {
      this.onChangePatternCuff("");
      this.selectedSpecialPatternNebFolding = "";
      this.onUpdateValueAndValidity(this.tShirtsSpecialPatternFormControls, [
        "cuffSelect",
        "nebfoldingSelect",
        "nebfoldingColourSelect",
        "nebfoldingSize",
      ]);
    }
  }

  /**
   * This method is used to change the special pattern Neb Folding
   * @param {*} event
   */
  onChangeSpecialPatternNebFolding(event: any) {
    let patternNebFoldingValue = event?.target ? event.target.value : event;
    this.selectedSpecialPatternNebFolding = this.nebFoldingTypesList?.filter(
      (item: any) => +item.id === +patternNebFoldingValue
    )[0];
  }

  /**
   * This method is used to change the special pattern Neb Folding Colour
   * @param {*} event
   */
  onChangeSpecialPatternNebFoldingColour(event: any) {
    let patternNebFoldingColorValue = event?.target ? event.target.value : event;
    this.selectedSpecialPatternNebFoldingColour = this.masterColoursList?.filter(
      (item: any) => +item.colourId === +patternNebFoldingColorValue
    )[0];
  }

  /**
   * This method is used to change the Pattern Cuff
   * @param {*} event
   */
  onChangePatternCuff(event: any) {
    let patternCuffValue = event?.target ? event.target.value : event;
    if (event) {
      this.selectedPatternCuff = this.cuffsList.filter((item: any) => +item.id === +patternCuffValue)[0];
      if (this.selectedPatternCuff?.name === "Stripe Cuff") {
        if (event?.target) {
          this.getCuffTypesList("");
        } else {
          this.getCuffTypesList("noEvent");
        }
        this.onAddValidators(this.tShirtsSpecialPatternFormControls, ["cuffTypeSelect"]);
      } else {
        this.onRemoveValidators(this.tShirtsSpecialPatternFormControls, ["cuffTypeSelect"]);
      }
    } else {
      this.onRemoveValidators(this.tShirtsSpecialPatternFormControls, [
        "cuffTypeSelect",
      ]);
      this.selectedPatternCuff = "";
    }

    if (event?.target) {
      this.selectedPatternCuffType = "";
      this.patternCuffColoursList = [];
      this.onUpdateValueAndValidity(this.tShirtsSpecialPatternFormControls, [
        "cuffTypeSelect",
      ]);
    }
  }

  /**
   * This method is used to change the Pattern Cuff Type
   * @param {*} event
   */
  onChangePatternCuffType(event: any) {
    let patternCuffTypeValue = event?.target ? event.target.value : event;
    this.selectedPatternCuffType = this.cuffTypesList.filter(
      (item: any) => +item.id === +patternCuffTypeValue
    )[0];
  }

  /**
   * This method is used to change the Pattern Cuff T-Shirt Colour
   * @param {*} event
   */
  onChangePatternCuffTShirtColour(event: any) {
    this.selectedPatternCuffTShirtColour = this.tShirtsColoursList?.filter(
      (item: any) => +item.colorId === +event.target.value
    )[0];
  }

  /**
   * This method is used to change the Pattern Cuff Colour
   * @param {*} event
   */
  onChangePatternCuffColour(event: any) {
    this.selectedPatternCuffColour = this.masterColoursList?.filter(
      (item: any) => +item.colourId === +event.target.value
    )[0];
  }

  /**
   * This method is used to change the Pattern Cuff Striped Colour
   * @param {*} event
   */
  onChangePatternCuffStripedColour(event: any) {
    this.selectedPatternCuffStripedColour = this.masterColoursList?.filter(
      (item: any) => +item.colourId === +event.target.value
    )[0];
  }

  /**
   * This method is used to change the slit radio
   * @param {*} event
   */
  onChangeSlitRadio(event: any) {
    let slitValue = event?.target ? event.target.value : event;
    this.selectedSlitRadio = +slitValue;
  }

  /**
   * This method is used to add the pattern colours
   */
  onClickAddPatternColours() {
    this.onAddValidators(this.tShirtsSpecialPatternFormControls, [
      "patternTShirtColourSelect",
      "collarColourSelect",
    ]);
    if (this.selectedSpecialPatternCollarType?.name === "Striped Collar") {
      this.onAddValidators(this.tShirtsSpecialPatternFormControls, [
        "patternStripedColourSelect",
      ]);
      this.tShirtsSpecialPatternFormControls[
        "patternStripedColourSelect"
      ].markAsTouched({ onlySelf: true });
    } else {
      this.onRemoveValidators(this.tShirtsSpecialPatternFormControls, [
        "patternStripedColourSelect",
      ]);
      this.tShirtsSpecialPatternFormControls[
        "patternStripedColourSelect"
      ].markAsUntouched({ onlySelf: true });
    }

    const patternTShirtColor = this.selectedPatternTShirtColour;
    const patternCollarColor = this.selectedPatternCollarColour;
    const patternStripeColor = this.selectedPatternStripedColour;

    if (!patternTShirtColor || !patternCollarColor) {
      this.tShirtsSpecialPatternFormControls[
        "patternTShirtColourSelect"
      ].markAsTouched({ onlySelf: true });
      this.tShirtsSpecialPatternFormControls[
        "collarColourSelect"
      ].markAsTouched({ onlySelf: true });
      return;
    }

    if (
      this.selectedSpecialPatternCollarType?.name === "Striped Collar" &&
      !patternStripeColor
    ) {
      this.tShirtsSpecialPatternFormControls[
        "patternStripedColourSelect"
      ].markAsTouched({ onlySelf: true });
      return;
    }

    const existingRecord = this.patternColoursList.find((item: any) => {
      return item?.tShirtColour?.colourName === patternTShirtColor?.colourName;
    });

    if (existingRecord) {
      this.showSnackbar("Record Already Exists", '', false, true);
      return;
    }

    /* Prepare the colour item object */
    const obj: any = {
      id:
        this.patternColoursList.length > 0 ? this.patternColoursList.length : 0,
      tShirtColour: patternTShirtColor,
      collarColour: patternCollarColor,
      stripeColour:
        this.selectedSpecialPatternCollarType?.name === "Striped Collar"
          ? patternStripeColor
          : 0,
    };

    console.log(obj);

    /* Push the colour item */
    this.patternColoursList.push(obj);
    this.selectedPatternTShirtColour = "";
    this.selectedPatternCollarColour = "";
    this.selectedPatternStripedColour = "";
    this.onRemoveValidators(this.tShirtsSpecialPatternFormControls, [
      "patternTShirtColourSelect",
      "collarColourSelect",
      "patternStripedColourSelect",
    ]);
    this.onUpdateValueAndValidity(this.tShirtsSpecialPatternFormControls, [
      "patternTShirtColourSelect",
      "collarColourSelect",
      "patternStripedColourSelect",
    ]);
  }

  /**
   * This method is used to delete the pattern colour item
   * @param {*} patternColour
   */
  onClickDeletePatternColourItem(patternColour: any) {
    this.patternColoursList = this.patternColoursList.filter(
      (item: any) => item.id !== patternColour.id
    );
  }

  /**
   * This method is used to add the pattern colours
   */
  onClickAddPatternCuffColours() {
    this.onAddValidators(this.tShirtsSpecialPatternFormControls, [
      "patternCuffTShirtColourSelect",
      "patternCuffColourSelect",
    ]);
    if (this.selectedPatternCuff?.name === "Stripe Cuff") {
      this.onAddValidators(this.tShirtsSpecialPatternFormControls, [
        "patternCuffStripedColourSelect",
      ]);
      this.tShirtsSpecialPatternFormControls[
        "patternCuffStripedColourSelect"
      ].markAsTouched({ onlySelf: true });
    } else {
      this.onRemoveValidators(this.tShirtsSpecialPatternFormControls, [
        "patternCuffStripedColourSelect",
      ]);
      this.tShirtsSpecialPatternFormControls[
        "patternCuffStripedColourSelect"
      ].markAsUntouched({ onlySelf: true });
    }

    const patternCuffTShirtColor = this.selectedPatternCuffTShirtColour;
    const patternCuffColor = this.selectedPatternCuffColour;
    const patternCuffStripeColor = this.selectedPatternCuffStripedColour;

    if (!patternCuffTShirtColor || !patternCuffColor) {
      this.tShirtsSpecialPatternFormControls[
        "patternCuffTShirtColourSelect"
      ].markAsTouched({ onlySelf: true });
      this.tShirtsSpecialPatternFormControls[
        "patternCuffColourSelect"
      ].markAsTouched({ onlySelf: true });
      return;
    }

    if (
      this.selectedPatternCuff?.name === "Stripe Cuff" &&
      !patternCuffStripeColor
    ) {
      this.tShirtsSpecialPatternFormControls[
        "patternCuffStripedColourSelect"
      ].markAsTouched({ onlySelf: true });
      return;
    }

    const existingRecord = this.patternCuffColoursList.find((item: any) => {
      return (
        item.tShirtColour.colourName === patternCuffTShirtColor?.colourName
      );
    });

    if (existingRecord) {
      this.showSnackbar("Record Already Exists", '', false, true);
      return;
    }

    /* Prepare the colour item object */
    const obj: any = {
      id: this.patternCuffColoursList.length > 0 ? this.patternCuffColoursList.length : 0,
      tShirtColour: patternCuffTShirtColor,
      cuffColour: patternCuffColor,
      stripeColour: this.selectedPatternCuff?.name === "Stripe Cuff" ? patternCuffStripeColor : 0,
    };

    console.log(obj);

    /* Push the colour item */
    this.patternCuffColoursList.push(obj);
    this.selectedPatternCuffTShirtColour = "";
    this.selectedPatternCuffColour = "";
    this.selectedPatternCuffStripedColour = "";
    this.onRemoveValidators(this.tShirtsSpecialPatternFormControls, [
      "patternCuffTShirtColourSelect",
      "patternCuffColourSelect",
      "patternCuffStripedColourSelect",
    ]);
    this.onUpdateValueAndValidity(this.tShirtsSpecialPatternFormControls, [
      "patternCuffTShirtColourSelect",
      "patternCuffColourSelect",
      "patternCuffStripedColourSelect",
    ]);
  }

  /**
   * This method is used to delete the pattern colour item
   * @param {*} patternColour
   */
  onClickDeletePatternCuffColourItem(patternColour: any) {
    this.patternCuffColoursList = this.patternCuffColoursList.filter(
      (item: any) => item.id !== patternColour.id
    );
  }

  /**
   * This method is used to reset the selected color fields
   */
  onResetSpecialPatternColorFields() {
    this.selectedPatternCuffTShirtColour = '';
    this.selectedPatternCuffColour = '';
    this.selectedPatternCuffStripedColour = '';
    this.selectedPatternTShirtColour = '';
    this.selectedPatternCollarColour = '';
    this.selectedPatternStripedColour = '';

    this.onRemoveValidators(this.tShirtsSpecialPatternFormControls, [
      "patternTShirtColourSelect",
      "collarColourSelect",
      "patternStripedColourSelect",
      "patternCuffTShirtColourSelect",
      "patternCuffColourSelect",
      "patternCuffStripedColourSelect",
    ]);
    this.onUpdateValueAndValidity(this.tShirtsSpecialPatternFormControls, [
      "patternTShirtColourSelect",
      "collarColourSelect",
      "patternStripedColourSelect",
      "patternCuffTShirtColourSelect",
      "patternCuffColourSelect",
      "patternCuffStripedColourSelect",
    ]);
  }

  /**
   * This method is used to save the special model items
   */
  onClickSaveSpecialPatternItems() {
    this.onResetSpecialPatternColorFields();
    /** This will return false if form fields are invalid and return */
    if (this.tShirtsSpecialPatternForm.invalid) {
      this.validationService.validateAllFormFields(
        this.tShirtsSpecialPatternForm
      );
      return;
    }

    // Extract colourName values from array1
    const colourNamesArray1 = this.tShirtsColoursList.map(
      (item: any) => item.colourName
    );

    // Check if each colourName in array1 exists in tShirtColour.colourName of array2
    const tShirtColorsForCollarAllExists = colourNamesArray1.every(
      (colourName: any) =>
        this.patternColoursList.some(
          (item: any) => item.tShirtColour.colourName === colourName
        )
    );

    if (this.selectedSpecialPatternCollarType) {
      if (this.patternColoursList?.length === 0) {
        this.showSnackbar("Add Order Collar Colours", '', false, true);
        return;
      } else if (!tShirtColorsForCollarAllExists) {
        this.showSnackbar("Add All T-Shirt Colours", '', false, true);
        return;
      }
    }

    // Check if each colourName in array1 exists in tShirtColour.colourName of array2
    const tShirtColorsForCuffAllExists = colourNamesArray1.every(
      (colourName: any) =>
        this.patternCuffColoursList.some(
          (item: any) => item.tShirtColour.colourName === colourName
        )
    );

    if (this.selectedCuffNebFolding?.name === "Cuff") {
      if (this.patternCuffColoursList?.length === 0) {
        this.showSnackbar("Add Order Cuff Colours", '', false, true);
        return;
      } else if (!tShirtColorsForCuffAllExists) {
        this.showSnackbar("Add All T-Shirt Colours", '', false, true);
        return;
      }
    }

    /* Prepare Special Pattern For TShirt Collars Array */
    const specialPatternCollars = [];
    for (let index = 0; index < this.patternColoursList?.length; index++) {
      const element = this.patternColoursList[index];
      specialPatternCollars.push({
        tShirtColorId: +element?.tShirtColour?.colorId,
        collarColorId: +element.collarColour?.colourId,
        stripeColorId: element.stripeColour?.colourId ? +element.stripeColour?.colourId : 0,
      });
    }

    /* Prepare Special Pattern For TShirt Cuffs Array */
    const specialPatternCuffs = [];
    for (let index = 0; index < this.patternCuffColoursList?.length; index++) {
      const element = this.patternCuffColoursList[index];
      specialPatternCuffs.push({
        tShirtColorId: +element?.tShirtColour?.colorId,
        cuffColorId: +element.cuffColour?.colourId,
        cuffStripeColorId: element.stripeColour?.colourId ? +element.stripeColour?.colourId : 0
      });
    }

    /* Prepare Special Pattern For TShirt Obj */
    const specialPatternForTShirtObj = {
      pattiColorId: +this.selectedPatti?.colourId,
      bodyColorId: +this.selectedSpecialPatternBody?.colourId,
      sleveColorId: +this.selectedSpecialPatternSleeve?.colourId,
      collarTypeId: +this.selectedSpecialPatternCollarType?.id,
      collarId: this.selectedSpecialPatternCollarType?.name === "Striped Collar" ? +this.selectedSpecialPatternStripedCollar?.id : 0,
      cuffNameById: +this.selectedCuffNebFolding?.id,
      cuffId: this.selectedCuffNebFolding?.name === "Cuff" ? +this.selectedPatternCuff?.id : 0,
      cuffTypeId: this.selectedCuffNebFolding?.name === "Cuff" && this.selectedPatternCuff?.name === "Stripe Cuff" ? +this.selectedPatternCuffType?.id : 0,
      nebfoldingId: this.selectedCuffNebFolding?.name === "Nebfolding" ? +this.selectedSpecialPatternNebFolding?.id : 0,
      nebfoldingColorId: this.selectedCuffNebFolding?.name === "Nebfolding" ? +this.selectedSpecialPatternNebFoldingColour?.colourId : 0,
      nebfoldingSize: this.selectedCuffNebFolding?.name === "Nebfolding" ? this.tShirtsSpecialPatternFormControls["nebfoldingSize"].value : "",
      isSLIT: this.selectedSlitRadio === 1,
      patternId: this.selectedTShirtPattern?.patternTypeId,
      specialPatternCollars: specialPatternCollars.length > 0 ? specialPatternCollars : [],
      specialPatternCuffs: specialPatternCuffs.length > 0 ? specialPatternCuffs : [],
    };

    localStorage.setItem("tShirtsSpecialPatternCollars", JSON.stringify(this.patternColoursList));
    localStorage.setItem("tShirtsSpecialPatternCuffs", JSON.stringify(this.patternCuffColoursList));

    /* Prepare the t-shirt special pattern object */
    const obj = {
      specialPatternForTshirt: specialPatternForTShirtObj,
    };

    console.log(obj);

    this.orderService.orderPatternDetailsObj.next(obj);
    document.getElementById("closeTShirtsPatternModal")?.click();
  }

  /**
   * This method is used to change the normal pattern collar type
   * @param {*} event
   */
  onChangeNormalPatternCollarType(event: any) {
    let normalCollarTypeValue = event?.target ? event.target.value : event;
    this.selectedNormalPatternCollarType = this.collarTypesList?.filter((item: any) => +item.id === +normalCollarTypeValue)[0];
    this.normalPatternColoursList = [];
    if (this.selectedNormalPatternCollarType?.name === "Striped Collar") {
      this.onAddValidators(this.tShirtsNormalPatternFormControls, ["normalPatternStripedCollarSelect"]);
      if (event?.target) {
        this.getStripedCollarTypesList("");
      } else {
        this.getStripedCollarTypesList("noEvent");
      }
    } else {
      this.onRemoveValidators(this.tShirtsNormalPatternFormControls, ["normalPatternStripedCollarSelect"]);
    }
    this.selectedNormalPatternStripedCollar = "";
    this.onUpdateValueAndValidity(this.tShirtsNormalPatternFormControls, ["normalPatternStripedCollarSelect"]);
  }

  /**
   * This method is used to change the normal pattern striped collar
   * @param {*} event
   */
  onChangeNormalPatternStripedCollar(event: any) {
    let normalStripedCollarTypeValue = event?.target
      ? event.target.value
      : event;
    this.selectedNormalPatternStripedCollar = this.stripedCollarTypesList?.filter(
      (item: any) => +item.id === +normalStripedCollarTypeValue
    )[0];
  }

  /**
   * This method is used to change the normal pattern t-shirt colour
   * @param {*} event
   */
  onChangeNormalPatternTShirtColour(event: any) {
    this.selectedNormalPatternTShirtColour = this.tShirtsColoursList?.filter(
      (item: any) => +item.colorId === +event.target.value
    )[0];
  }

  /**
   * This method is used to change the normal pattern collar colour
   * @param {*} event
   */
  onChangeNormalPatternCollarColour(event: any) {
    this.selectedNormalPatternCollarColour = this.masterColoursList?.filter(
      (item: any) => +item.colourId === +event.target.value
    )[0];
  }

  /**
   * This method is used to change the normal pattern striped colour
   * @param {*} event
   */
  onChangeNormalPatternStripedColour(event: any) {
    this.selectedNormalPatternStripedColour = this.masterColoursList?.filter(
      (item: any) => +item.colourId === +event.target.value
    )[0];
  }

  /**
   * This method is used to add the normal pattern colours
   */
  onClickAddNormalPatternColours() {
    this.onAddValidators(this.tShirtsNormalPatternFormControls, [
      "normalPatternTShirtColourSelect",
      "normalPatternCollarColourSelect",
    ]);
    if (this.selectedNormalPatternCollarType?.name === "Striped Collar") {
      this.onAddValidators(this.tShirtsNormalPatternFormControls, [
        "normalPatternStripedColourSelect",
      ]);
      this.tShirtsNormalPatternFormControls[
        "normalPatternStripedColourSelect"
      ].markAsTouched({ onlySelf: true });
    } else {
      this.onRemoveValidators(this.tShirtsNormalPatternFormControls, [
        "normalPatternStripedColourSelect",
      ]);
      this.tShirtsNormalPatternFormControls[
        "normalPatternStripedColourSelect"
      ].markAsUntouched({ onlySelf: true });
    }

    const normalPatternTShirtColor = this.selectedNormalPatternTShirtColour;
    const normalPatternCollarColor = this.selectedNormalPatternCollarColour;
    const normalPatternStripeColor = this.selectedNormalPatternStripedColour;

    if (!normalPatternTShirtColor || !normalPatternCollarColor) {
      this.tShirtsNormalPatternFormControls[
        "normalPatternTShirtColourSelect"
      ].markAsTouched({ onlySelf: true });
      this.tShirtsNormalPatternFormControls[
        "normalPatternCollarColourSelect"
      ].markAsTouched({ onlySelf: true });
      return;
    }

    if (
      this.selectedNormalPatternCollarType?.name === "Striped Collar" &&
      !normalPatternStripeColor
    ) {
      this.tShirtsNormalPatternFormControls[
        "normalPatternStripedColourSelect"
      ].markAsTouched({ onlySelf: true });
      return;
    }

    const existingRecord = this.normalPatternColoursList.find((item) => {
      return (item.tShirtColour?.colourName === normalPatternTShirtColor?.colourName);
    });

    if (existingRecord) {
      this.showSnackbar("Record Already Exists", '', false, true);
      return;
    }

    /* Prepare the colour item object */
    const obj: any = {
      id: this.normalPatternColoursList.length > 0 ? this.normalPatternColoursList.length : 0,
      tShirtColour: normalPatternTShirtColor,
      collarColour: normalPatternCollarColor,
      stripeColour: this.selectedNormalPatternCollarType?.name === "Striped Collar" ? normalPatternStripeColor : 0
    };

    console.log(obj);

    /* Push the colour item */
    this.normalPatternColoursList.push(obj);
    this.selectedNormalPatternTShirtColour = "";
    this.selectedNormalPatternCollarColour = "";
    this.selectedNormalPatternStripedColour = "";
    this.onRemoveValidators(this.tShirtsNormalPatternFormControls, [
      "normalPatternTShirtColourSelect",
      "normalPatternCollarColourSelect",
      "normalPatternStripedColourSelect",
    ]);
    this.onUpdateValueAndValidity(this.tShirtsNormalPatternFormControls, [
      "normalPatternTShirtColourSelect",
      "normalPatternCollarColourSelect",
      "normalPatternStripedColourSelect",
    ]);
  }

  /**
   * This method is used to delete the normal pattern colour item
   * @param {*} patternColour
   */
  onClickDeleteNormalPatternColourItem(patternColour: any) {
    this.normalPatternColoursList = this.normalPatternColoursList.filter((item: any) => item.id !== patternColour.id);
  }

  /**
   * This method is used to show the snackbar
   * @param {string} message
   * @param {*} orderId
   * @param {boolean} successFlag
   * @param {boolean} isModalOverlay
   */
  showSnackbar(message: string, orderId: any, successFlag: boolean, isModalOverlay: boolean) {
    const snackbar = document.getElementById("tShirtsSnackbar") as HTMLElement;
    this.innerHTMLMessage = message;
    this.innerHTMLOrderId = orderId;
    this.isSuccessSnackbar = successFlag;
    this.isOverlayVisible = isModalOverlay;
    snackbar.style.display = "block";
  }

  /**
   * This method is used to hide the snackbar
   */
  onClickSnackbarOkButton() {
    const snackbar = document.getElementById("tShirtsSnackbar") as HTMLElement;
    snackbar.style.display = "none";
    this.innerHTMLOrderId = '';
    this.innerHTMLMessage = '';
    this.isOverlayVisible = false;
    this.isSuccessSnackbar = false;
  }

  /**
   * This method is used to reset the selected color fields
   */
  onResetNormalPatternColorFields() {
    this.selectedNormalPatternTShirtColour = '';
    this.selectedNormalPatternCollarColour = '';
    this.selectedNormalPatternStripedColour = '';

    this.onRemoveValidators(this.tShirtsNormalPatternFormControls, [
      "normalPatternTShirtColourSelect",
      "normalPatternCollarColourSelect",
      "normalPatternStripedColourSelect",
    ]);
    this.onUpdateValueAndValidity(this.tShirtsNormalPatternFormControls, [
      "normalPatternTShirtColourSelect",
      "normalPatternCollarColourSelect",
      "normalPatternStripedColourSelect",
    ]);
  }

  /**
   * This method is used to save the normal pattern items
   */
  onClickSaveNormalPatternItems() {
    this.onResetNormalPatternColorFields();
    /** This will return false if form fields are invalid and return */
    if (this.tShirtsNormalPatternForm.invalid) {
      this.validationService.validateAllFormFields(this.tShirtsNormalPatternForm);
      return;
    }

    // Extract colourName values from array1
    const colourNamesArray1 = this.tShirtsColoursList.map((item: any) => item.colourName);

    // Check if each colourName in array1 exists in tShirtColour.colourName of array2
    const tShirtColorsForCollarAllExists = colourNamesArray1.every(
      (colourName: any) => this.normalPatternColoursList.some(
        (item: any) => item.tShirtColour.colourName === colourName)
    );

    if (this.selectedNormalPatternCollarType) {
      if (this.normalPatternColoursList?.length === 0) {
        this.showSnackbar("Add Order Collar Colours", '', false, true);
        return;
      } else if (!tShirtColorsForCollarAllExists) {
        this.showSnackbar("Add All T-Shirt Colours", '', false, true);
        return;
      }
    }

    /* Prepare Normal Pattern For TShirt Collars Array */
    const normalPatternCollar = [];
    for (let index = 0; index < this.normalPatternColoursList?.length; index++) {
      const element = this.normalPatternColoursList[index];
      normalPatternCollar.push({
        tShirtColorId: +element?.tShirtColour?.colorId,
        collarColorId: +element.collarColour?.colourId,
        stripeColorId: this.selectedNormalPatternCollarType?.name === "Striped Collar" ? element.stripeColour?.colourId : 0
      });
    }
    console.log(normalPatternCollar);

    /* Prepare Normal Pattern For TShirt Obj */
    const normalPatternForTShirtObj = {
      collarTypeId: +this.selectedNormalPatternCollarType?.id,
      collarId: this.selectedNormalPatternCollarType?.name === "Striped Collar" ? +this.selectedNormalPatternStripedCollar?.id : 0,
      patternId: this.selectedTShirtPattern?.patternTypeId,
      normalPatternCollar: normalPatternCollar.length > 0 ? normalPatternCollar : [],
    };

    localStorage.setItem("tShirtsNormalPatternCollar", JSON.stringify(this.normalPatternColoursList));

    /* Prepare the t-shirt normal pattern object */
    const obj = {
      normalPatternforTshirt: normalPatternForTShirtObj,
    };

    console.log(obj);
    this.orderService.orderPatternDetailsObj.next(obj);
    document.getElementById("closeTShirtsPatternModal")?.click();
  }
}
