import { DatePipe } from "@angular/common";
import { AfterViewInit, ChangeDetectorRef, Component, HostListener, OnDestroy, OnInit, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";

import { SnackbarModalComponent } from "src/app/core/Dialogues/snackbar-modal/snackbar-modal.component";
import { CourierMode, DiagramMode, OrderItems, OrganizationType } from "src/app/core/Modals/modals";
import { ChargesService } from "src/app/core/Services/charges.service";
import { LoaderService } from "src/app/core/Services/loader.service";
import { MastersService } from "src/app/core/Services/masters.service";
import { OrderService } from "src/app/core/Services/order.service";
import { SampleOrderService } from "src/app/core/Services/sample-order.service";
import { ValidationService } from "src/app/core/Services/validation.service";
import { OrdersMiddyPatternModalComponent } from "../orders-middy-pattern-modal/orders-middy-pattern-modal.component";
import { OrdersNickersModelComponent } from "../orders-nickers-model/orders-nickers-model.component";
import { OrdersPantPatternModalComponent } from "../orders-pant-pattern-modal/orders-pant-pattern-modal.component";
import { OrdersPinofersModelComponent } from "../orders-pinofers-model/orders-pinofers-model.component";
import { OrdersShotsModelComponent } from "../orders-shots-model/orders-shots-model.component";
import { OrdersTShirtsPatternModalComponent } from "../orders-t-shirts-pattern-modal/orders-t-shirts-pattern-modal.component";

/**
 * Edit Orders Component
 * @export
 * @class EditOrdersComponent
 * @implements {OnInit}
 */
@Component({
  selector: "app-edit-orders",
  templateUrl: "./edit-orders.component.html",
  styleUrls: ["./edit-orders.component.scss"]
})
export class EditOrdersComponent implements OnInit, AfterViewInit, OnDestroy {
  /**
   * Get Orders T-Shirts Pattern Modal Component
   * @type {OrdersTShirtsPatternModalComponent}
   */
  @ViewChild("tShirtsPatternComponent") tShirtsPatternComponent!: OrdersTShirtsPatternModalComponent;

  /**
   * Get Orders Middy Pattern Modal Component
   * @type {OrdersMiddyPatternModalComponent}
   */
  @ViewChild("middyPatternModalComponent") middyPatternModalComponent!: OrdersMiddyPatternModalComponent;

  /**
   * Get Orders Nickers Pattern Modal Component
   * @type {OrdersNickersModelComponent}
   */
  @ViewChild("nickersComponent") nickersComponent!: OrdersNickersModelComponent;

  /**
   * Get Orders Shots Pattern Modal Component
   * @type {OrdersShotsModelComponent}
   */
  @ViewChild("shortsComponent") shortsComponent!: OrdersShotsModelComponent;

  /**
   * Get Orders Pant Pattern Modal Component
   * @type {OrdersPantPatternModalComponent}
   */
  @ViewChild("pantComponent") pantComponent!: OrdersPantPatternModalComponent;

  /**
   * Get Orders Pinofers Pattern Modal Component
   * @type {OrdersPinofersModelComponent}
   */
  @ViewChild("pinofersComponent") pinofersComponent!: OrdersPinofersModelComponent;

  /**
   * Get Snackbar Modal Component
   * @type {SnackbarModalComponent}
   */
  @ViewChild("snackbarModalComponent") snackbarModalComponent!: SnackbarModalComponent;

  /**
   * Get Is Admin Flag
   */
  isAdmin = false;

  /**
   * Declare the Pattern Dress Items List
   */
  patternDressItemsList = [
    "T-Shirts",
    "Middy",
    "Nicker",
    "Pant",
    "Pinofers",
    "Shots",
  ];

  /**
   * Declare the Pocket Dress Items List
   */
  pocketDressItemsList = ["Pinofers", "Frock", "T-Shirts"];

  /**
   * Declare the Back Print Dress Items List
   */
  backPrintDressItemsList = ["Frock", "T-Shirts", "Pinofers"];

  /**
   * Get Edit Order Details
   * @type {*}
   */
  editOrderDetails: any;

  /**
   * Set Min From Date
   * @type {Date}
   */
  minFromDate: Date;

  /**
   * Set Min Dispatch From Date
   * @type {Date}
   */
  minDispatchFromDate: Date;

  /**
   * Set Min Stitching Start Date
   * @type {Date}
   */
  minStitchingStartDate: Date;

  /**
   * Set Stitching Start Date
   * @type {Date}
   */
  stitchingStartDate: Date;

  /**
   * Set Max From Date
   * @type {Date}
   */
  maxFromDate: Date;

  /**
   * Declare Add Order Form
   * @type {FormGroup}
   */
  addOrderForm!: FormGroup;

  /**
   * Get Order Items List
   */
  orderItemsList: OrderItems[] = [];

  /**
   * Get Saved Order Items List
   */
  savedOrderItemsList: OrderItems[] = [];

  /**
   * Get Total Order value
   */
  totalOrderValue = 0;

  /**
   * Get Total Quantity
   */
  totalQuantity = 0;

  /**
   * Get Average Unit Price
   * @type {*}
   */
  avgUnitPrice: any;

  /**
   * Get Colours List
   * @type {*}
   */
  coloursList: any;

  /**
   * Get Sizes List
   * @type {*}
   */
  sizesList: any;

  /**
   * Get Is Save Order Flag
   */
  isSaveOrder = false;

  /**
   * Get Is Add Order Items Flag
   */
  isAddOrderItems = false;

  /**
   * Get Is Add Pattern Details Flag
   */
  isAddPatternDetails = false;

  /**
   * Get Is Pattern Dress Item Flag
   */
  isPatternDressItem = false;

  /**
   * Get Is Back Print Flag
   */
  isBackPrint = false;

  /**
   * Get Is isCourier Flag
   */
  isCourier = false;

  /**
   * Get Is Print Type Flag
   */
  isPrintType = false;

  /**
   * Diagram List
   * @type {DiagramMode[]}
   */
  diagramList: DiagramMode[] = [
    { id: 0, type: "No Image" },
    { id: 1, type: "1" },
    { id: 2, type: "2" },
    { id: 3, type: "3" },
    { id: 4, type: "4" },
    { id: 5, type: "5" },
    { id: 6, type: "6" }
  ];

  /**
   * Get Selected Diagram
   */
  selectedDiagram: any;

  /**
   * Selected Diagram URL
   */
  diagramURL = '';

  /**
   * Get Is Changes In Pattern Flag
   */
  isChangesInPattern = '';

  /**
   * Get Calculate Points
   */
  calculatePoints = 0;

  /**
   * Get Selected Method
   */
  selectedMethod: any;

  /**
   * Get Selected Quality
   */
  selectedQuality: any;

  /**
   * Selected Previous Order Status
   */
  selectedPreviousOrderStatus: any;

  /**
   * Selected Order Status
   */
  selectedOrderStatus: any;

  /**
   * Is Cutting Order Status Flag
   */
  IsCuttingOrderStatus = false;

  /**
   * Is Fusing Order Status Flag
   */
  IsFusingOrderStatus = false;

  /**
   * Is Film Making Order Status Flag
   */
  IsFilmMakingOrderStatus = false;

  /**
   * Is Screen Making Order Status Flag
   */
  IsScreenMakingOrderStatus = false;

  /**
   * Is Embroidery Order Status Flag
   */
  IsEmbroideryOrderStatus = false;

  /**
   * Is Printing Order Status Flag
   */
  IsPrintingOrderStatus = false;

  /**
   * Is Re-sizing Order Status Flag
   */
  IsReSizingOrderStatus = false;

  /**
   * Is Sublimation Both Side Flag
   */
  IsSublimationBothSide = false;

  /**
   * Is Stitching Order Status Flag
   */
  IsStitchingOrderStatus = false;

  /**
   * Is Knitting Order Status Flag
   */
  IsKnittingOrderStatus = false;

  /**
   * Is Steam Iron Order Status Flag
   */
  IsSteamIronOrderStatus = false;

  /**
   * Is Dispatched Order Status Flag
   */
  IsDispatchedOrderStatus = false;

  /**
   * Is CP Generated Order Status Flag
   */
  IsCPGeneratedOrderStatus = false;

  /**
   * Selected Payment Mode
   */
  selectedPaymentMode: any;

  /**
   * Get Selected Agent
   */
  selectedAgent: any;

  /**
   * Get Selected Agent Type
   */
  selectedAgentType = 1;

  /**
   * Get Is Payment Received Flag
   */
  isPaymentReceived = false;

  /**
   * Get Is Agent Flag
   */
  isAgent = false;

  /**
   * Get Is Through Agent Flag
   */
  isThroughAgent = false;

  /**
   * Get Selected Order Received
   */
  selectedOrderReceived = 0;

  /**
   * Get Selected Order Received
   */
  selectedPaymentReceived = 0;

  /**
   * Get Selected Approved
   */
  selectedApproved = 0;

  /**
   * Get Selected Calculate Points
   */
  selectedCalculatePoints = 0;

  /**
   * Get Selected School Type
   */
  selectedSchoolType = 1;

  /**
   * Selected Staff
   */
  selectedStaff: any;

  /**
   * Selected Transport
   */
  selectedTransport: any;

  /**
   * Get Selected Staff
   */
  selectedIncharge: any;

  /**
   * Get Selected Pattern
   */
  selectedPattern: any;

  /**
   * Selected New Dress Item
   */
  selectedNewDressItem: any;

  /**
   * Selected New Method
   */
  selectedNewMethod: any;

  /**
   * Selected New Pattern
   */
  selectedNewPattern: any;

  /**
   * Get Latest Sales Tax Name
   * @type {*}
   */
  latestSalesTaxName: any;

  /**
   * Get Is TShirt Special Model Flag
   */
  isTShirtSpecialModel = '';

  /**
   * Get Staff Select Flag
   */
  isStaffSelect = true;

  /**
   * Get Dress Items List
   * @type {*}
   */
  dressItemsList: any;

  /**
   * method List
   */
  methodsList: any = [];

  /**
   * quality List
   */
  qualityList: any;

  /**
   * Get Patterns List
   */
  patternsList: any;

  /**
   * Selected Dress Item
   */
  selectedDressItem: any;

  /**
   * Selected Print Type
   */
  selectedPrintType = 2;

  /**
   * Edit Order Form Declaration
   */
  editOrderForm!: FormGroup;

  /**
   * Get Order Form Validations
   */
  editSampleOrderValidation = this.validationService.createOrder;

  /**
   * Get Edit Sample Order Patterns
   * @private
   */
  private patterns = this.validationService.patterns;

  /**
   * Email Pattern Error
   */
  emailPatternError = "";

  /**
   * Get Add Order Form Validations
   */
  addOrderFormValidation = this.validationService.addOrder;

  /**
   * Get Organization Types List
   */
  organizationTypeList: OrganizationType[] = [
    { id: "1", type: "School" },
    { id: "2", type: "Showroom" },
  ];

  /**
   * Get Payment Modes List
   * @type {CourierMode[]}
   */
  paymentModesList: CourierMode[] = [
    { id: "1", type: "With Pass" },
    { id: "2", type: "Bank" }
  ];

  /**
   * Get Order Status List
   */
  orderStatusList: any;

  /**
   * Get Unit Names List
   */
  unitNamesList: any;

  /**
   * Get Cutting Unit Names List
   */
  cuttingUnitNamesList: any;

  /**
   * Get Fusing Unit Names List
   */
  fusingUnitNamesList: any;

  /**
   * Get Film Making Unit Names List
   */
  filmMakingUnitNamesList: any;

  /**
   * Get Screen Making Unit Names List
   */
  screenMakingUnitNamesList: any;

  /**
   * Get Embroidery Unit Names List
   */
  embroideryUnitNamesList: any;

  /**
   * Get Printing Unit Names List
   */
  printingUnitNamesList: any;

  /**
   * Get Resizing Unit Names List
   */
  resizingUnitNamesList: any;

  /**
   * Get Stitching Unit Names List
   */
  stitchingUnitNamesList: any;

  /**
   * Get Printing Unit Names List
   */
  resizingPrintingUnitNamesList: any;

  /**
   * Get Knitting Unit Names List
   */
  knittingUnitNamesList: any;

  /**
   * Get Steam Iron Unit Names List
   */
  steamIronUnitNamesList: any;

  /**
   * Get Print Types List
   */
  printTypesList: any;

  /**
   * Get Fusing Types List
   * @type {*}
   */
  fusingTypesList: any;

  /**
   * Get Collar Types List
   * @type {*}
   */
  collarTypesList: any;

  /**
   * Get Transport  List
   */
  transportList: any;

  /**
   * Get Agents list
   * @type {*}
   */
  agentsList: any;

  /**
  * Get Staffs List
  * @type {*}
  */
  staffList: any;

  /**
   * Get Incharge List
   * @type {*}
   */
  inchargeList: any;

  /**
   * Get Is Success Snackbar Flag
   */
  isSuccessSnackbar = false;

  /**
   * Get Is Overlay Visible Flag
   */
  isOverlayVisible = false;

  /**
   * Get Inner HTML Message
   */
  innerHTMLMessage = '';

  /**
   * Get Inner HTML Order Id
   */
  innerHTMLOrderId = '';

  /**
   * Selected organization
   */
  selectedOrganization: any;

  /**
   * Get Previous Order Status Flag
   * @type {*}
   */
  previousOrderStatus: any;

  /**
   * Creates an instance of EditOrdersComponent.
   * @param {Router} router
   * @param {ValidationService} validationService
   * @param {FormBuilder} formBuilder
   * @param {DatePipe} datePipe
   * @param {MastersService} mastersService
   * @param {ChargesService} chargesService
   * @param {SampleOrderService} sampleOrderService
   * @param {OrderService} orderService
   * @param {LoaderService} loaderService
   * @param {ChangeDetectorRef} cdr
   */
  constructor(
    private router: Router,
    private validationService: ValidationService,
    private formBuilder: FormBuilder,
    private datePipe: DatePipe,
    private mastersService: MastersService,
    private chargesService: ChargesService,
    private sampleOrderService: SampleOrderService,
    private orderService: OrderService,
    private loaderService: LoaderService,
    private cdr: ChangeDetectorRef
  ) {
    if (localStorage.getItem('userTypeId') == '1') {
      this.isAdmin = true;
    }

    localStorage.removeItem("savedOrdersList");
    /* set Min Date */
    this.minDispatchFromDate = new Date();
    this.minStitchingStartDate = new Date();
    this.stitchingStartDate = new Date();
    this.minFromDate = new Date();
    this.maxFromDate = new Date();
    const d = new Date();
    d.setDate(1);
    d.setMonth(0);
    d.setFullYear(2012);
    this.minFromDate = d;

    /* Get Order Details from behavior subject*/
    this.orderService.editOrderDetails.subscribe((val: any) => {
      if (Object.keys(val).length !== 0) {
        this.editOrderDetails = val;
        this.previousOrderStatus = this.editOrderDetails?.order?.orderStatusId;
        if (this.editOrderDetails?.order?.organizationType === 'School') {
          this.isStaffSelect = true;
        } else {
          this.isStaffSelect = false;
        }
      } else {
        this.editOrderDetails = null;
        this.onClickNavigateToOrdersList();
      }
    });

    /* Enable the loader */
    this.loaderService.isLoading.next(true);
  }

  /**
   * Life Cycle Hook Initialization
   */
  ngOnInit(): void {
    this.addOrderFormValidations();
    this.editSampleOrderFormValidations();
    this.getDressItemList();
    this.getColoursList();
    this.getQualityList();
    this.getSaleTax();
    this.getOrderStatusList();
    this.getStaffsList();
    this.getFusingTypes();
    this.getCollarTypes();
    this.getTransportList();

    if (this.isStaffSelect) {
      this.onAddValidators(this.editOrderFormControls, ['staff']);
    } else {
      this.onRemoveValidators(this.editOrderFormControls, ['staff']);
    }
    this.minDispatchFromDate = new Date(this.editOrderDetails?.order?.orderDate);
    if (this.editOrderDetails?.stichingDCDetails?.date) {
      this.onChangeStitchingDate(new Date(this.editOrderDetails?.stichingDCDetails?.date));
    }
    if (this.editOrderDetails?.cuttingDCDetails?.date) {
      this.onChangeCuttingDate(new Date(this.editOrderDetails?.cuttingDCDetails?.date));
    } else {
      this.minStitchingStartDate = this.minDispatchFromDate;
    }

    if (!this.isAdmin) {
      this.editOrderFormControls["approved"].disable({ onlySelf: true });
    }
  }

  /**
   * Life Cycle Hook After View Init Initialization
   */
  ngAfterViewInit(): void {
    /* Disable the loader */
    this.loaderService.isLoading.next(false);
  }

  /**
   * Life Cycle Hook Destroy
   */
  ngOnDestroy(): void {
    this.orderService.orderPatternDetailsObj.next({});
    const localStorageKeys = [
      "savedOrdersList",
      "pinofersSpecialModelCollars",
      "pinofersPanelColors",
      "tShirtSpecialModelCollars",
      "tShirtSpecialModelCuffs",
      "tShirtSpecialModelPanel",
      "tShirtsSpecialPatternCollars",
      "tShirtsSpecialPatternCuffs",
      "tShirtsNormalPatternCollar",
      "pantPatternPanelColoursList",
      "middyPatternPanelColoursList",
      "nickerPatternPanelColours",
      "shotsPatternPanelColours"
    ];
    localStorageKeys.forEach((item: string) => {
      localStorage.removeItem(item);
    });
    /* Disable the loader */
    this.loaderService.isLoading.next(false);
  }

  /**
   * Edit Order Controls Initialized
   * @readonly
   */
  get editOrderFormControls() {
    return this.editOrderForm.controls;
  }

  /**
   * Initialize Edit Sample Order Form Validations
   */
  editSampleOrderFormValidations() {
    let organizationName = '';
    let organizationSelectValue = '';
    let customerId = '';
    let stateName = '';
    let districtName = '';
    let mandalName = '';
    let townName = '';
    let address = '';
    let dressItemId = '';
    let methodId = '';
    let qualityId = '';
    let patternTypeId = '';
    let printTypeId = '2';
    let schoolTypeValue = '1';
    let orderStatusSelectValue = '';
    let backPrint1Value = '';
    let backPrint2Value = '';
    let backPrint3Value = '';
    let backPrint4Value = '';
    let diagramIdValue = '';
    let placeValue = '';
    let paymentModeValue = '';
    let remarksValue = '';
    let staffValue = '';
    let agentValue = '';
    let agentCommissionValue = '';
    let agentTotalCommissionValue = '0';
    let deliveryDateValue: any = '';
    let pointsValue = '0';
    let orderReceivedValue = '0';
    let calculatePointsValue = '0';
    let unitPointsValue = '0';
    let dispatchDateValue: any = '';
    let inchargeDateValue: any = '';
    let paymentReceivedDateValue: any = '';
    let lrValue = '';
    let paymentReceivedValue = '0';
    let paymentApprovedValue = '0';

    if (this.editOrderDetails) {
      organizationName = this.editOrderDetails?.order?.organizationName;
      organizationSelectValue = this.organizationTypeList?.filter((item: any) => item.type == this.editOrderDetails?.order?.organizationType)[0]?.id;
      customerId = this.editOrderDetails?.order?.customerId;
      stateName = this.editOrderDetails?.order?.stateName;
      districtName = this.editOrderDetails?.order?.districtName;
      mandalName = this.editOrderDetails?.order?.mandalName;
      townName = this.editOrderDetails?.order?.townName;
      address = this.editOrderDetails?.order?.address;
      methodId = this.editOrderDetails?.order?.methodId;
      patternTypeId = this.editOrderDetails?.order?.patternTypeId;
      placeValue = this.editOrderDetails?.order?.transportName || '';
      paymentModeValue = this.editOrderDetails?.order?.modeOfPaymentId;
      remarksValue = this.editOrderDetails?.order?.remarks || '';
      staffValue = this.editOrderDetails?.order?.staffId || '';
      agentValue = this.editOrderDetails?.order?.agentId || '';
      agentCommissionValue = this.editOrderDetails?.order?.agentCommPerc || '0';
      agentTotalCommissionValue = this.editOrderDetails?.order?.agentTotCommission || '0';
      printTypeId = this.editOrderDetails?.order?.printtypeId?.toString();
      schoolTypeValue = this.editOrderDetails?.order?.orderTypeId?.toString();
      orderReceivedValue = this.editOrderDetails?.order?.orderRecived?.toString();
      calculatePointsValue = this.editOrderDetails?.order?.calculatePoints?.toString();
      unitPointsValue = this.editOrderDetails?.order?.unitPoints?.toString();
      pointsValue = this.editOrderDetails?.order?.totalPoints?.toString();
      orderStatusSelectValue = this.editOrderDetails?.order?.orderStatusId?.toString() || '';
      deliveryDateValue = this.editOrderDetails?.order?.expectedDDate ? new Date(this.editOrderDetails?.order?.expectedDDate) : '';
      dispatchDateValue = this.editOrderDetails?.order?.dispatchDate ? new Date(this.editOrderDetails?.order?.dispatchDate) : '';
      inchargeDateValue = this.editOrderDetails?.order?.inchargeDate ? new Date(this.editOrderDetails?.order?.inchargeDate) : '';
      paymentReceivedDateValue = this.editOrderDetails?.order?.paymentReceivedDate ? new Date(this.editOrderDetails?.order?.paymentReceivedDate) : '';
      lrValue = this.editOrderDetails?.order?.lrNumber?.toString();
      paymentReceivedValue = this.editOrderDetails?.order?.fullPayment?.toString() || '0';
      paymentApprovedValue = this.editOrderDetails?.order?.paymentApproved?.toString() || '0';
    }

    this.editOrderForm = this.formBuilder.group({
      OrganizationName: [
        organizationName,
        [
          Validators.required,
          Validators.minLength(this.editSampleOrderValidation.OrganizationName.minLength),
          Validators.maxLength(this.editSampleOrderValidation.OrganizationName.maxLength),
        ],
      ],
      CustomerId: [customerId],
      organizationSelect: [organizationSelectValue],
      Address: [address],
      StateName: [stateName],
      DistrictName: [districtName],
      MandalName: [mandalName],
      TownName: [townName],
      email: [""],
      dressItemSelect: [dressItemId, [Validators.required]],
      methodSelect: [methodId, [Validators.required]],
      qualitySelect: [qualityId, [Validators.required]],
      patternSelect: [patternTypeId],
      printType: [printTypeId],
      SchoolType: [schoolTypeValue],
      BackPrintOne: [
        backPrint1Value,
        [
          Validators.minLength(this.editSampleOrderValidation.BackPrintOne.minLength),
          Validators.maxLength(this.editSampleOrderValidation.BackPrintOne.maxLength),
        ],
      ],
      BackPrintTwo: [
        backPrint2Value,
        [
          Validators.minLength(this.editSampleOrderValidation.BackPrintTwo.minLength),
          Validators.maxLength(this.editSampleOrderValidation.BackPrintTwo.maxLength),
        ],
      ],
      BackPrintThree: [
        backPrint3Value,
        [
          Validators.minLength(this.editSampleOrderValidation.BackPrintThree.minLength),
          Validators.maxLength(this.editSampleOrderValidation.BackPrintThree.maxLength),
        ],
      ],
      BackPrintFour: [
        backPrint4Value,
        [
          Validators.minLength(this.editSampleOrderValidation.BackPrintFour.minLength),
          Validators.maxLength(this.editSampleOrderValidation.BackPrintFour.maxLength),
        ],
      ],
      diagramSelect: [diagramIdValue],
      place: [placeValue, [Validators.required]],
      paymentMode: [paymentModeValue, [Validators.required]],
      deliveryDate: [deliveryDateValue, [Validators.required]],
      remarks: [remarksValue,
        [
          Validators.minLength(this.editSampleOrderValidation.remarks.minLength),
          Validators.maxLength(this.editSampleOrderValidation.remarks.maxLength)
        ]
      ],
      orderStatus: [orderStatusSelectValue, [Validators.required]],
      staff: [staffValue],
      incharge: [''],
      inchargeDate: [inchargeDateValue],
      orderReceived: [orderReceivedValue],
      agent: [agentValue],
      calculatePoints: [calculatePointsValue],
      unitPoints: [unitPointsValue,
        [
          Validators.minLength(this.editSampleOrderValidation.unitPoints.minLength),
          Validators.maxLength(this.editSampleOrderValidation.unitPoints.maxLength),
        ]
      ],
      commission: [agentCommissionValue,
        [
          Validators.minLength(this.editSampleOrderValidation.commission.minLength),
          Validators.maxLength(this.editSampleOrderValidation.commission.maxLength),
        ]
      ],
      agentCommission: [agentTotalCommissionValue],
      points: [pointsValue],
      lrDetails: [lrValue,
        [
          Validators.minLength(this.editSampleOrderValidation.lrDetails.minLength),
          Validators.maxLength(this.editSampleOrderValidation.lrDetails.maxLength),
        ]
      ],
      dispatchDate: [dispatchDateValue],
      transport: [''],
      paymentReceived: [paymentReceivedValue],
      paymentDate: [paymentReceivedDateValue],
      invoiceQuantity: ['0'],
      invoiceValue: ['0'],
      agentType: ['0'],
      approved: [paymentApprovedValue],

      cuttingDCNo: [this.editOrderDetails?.cuttingDCDetails?.dcNo || ''],
      cuttingQuantity: [this.editOrderDetails?.cuttingDCDetails?.quantity || '', [Validators.pattern(this.patterns.orderQuantity)]],
      cuttingUnitName: [this.editOrderDetails?.cuttingDCDetails?.unitNameId || ''],
      cuttingResponseUnitName: [this.editOrderDetails?.cuttingDCDetails?.unitName || ''],
      cuttingDateSelect: [this.editOrderDetails?.cuttingDCDetails?.date ? new Date(this.editOrderDetails?.cuttingDCDetails?.date) : ''],

      fusingDCNo: [this.editOrderDetails?.fusingDCDetails?.dcNo || ''],
      fusingType: [this.editOrderDetails?.fusingDCDetails?.fusingTypeId || ''],
      fusingQuantity: [this.editOrderDetails?.fusingDCDetails?.quantity || '', [Validators.pattern(this.patterns.orderQuantity)]],
      fusingUnitName: [this.editOrderDetails?.fusingDCDetails?.unitNameId || ''],
      fusingResponseUnitName: [this.editOrderDetails?.fusingDCDetails?.unitName || ''],
      fusingDateSelect: [this.editOrderDetails?.fusingDCDetails?.date ? new Date(this.editOrderDetails?.fusingDCDetails?.date) : ''],

      filmMakingType: [this.editOrderDetails?.filmMakingDCDetails?.printTypeId || ''],
      filmMakingResponseType: [this.editOrderDetails?.filmMakingDCDetails?.printType || ''],
      filmMakingDCNo: [this.editOrderDetails?.filmMakingDCDetails?.dcNo || ''],
      filmMakingQuantity: [this.editOrderDetails?.filmMakingDCDetails?.quantity || '', [Validators.pattern(this.patterns.orderQuantity)]],
      filmMakingUnitName: [this.editOrderDetails?.filmMakingDCDetails?.unitNameId || ''],
      filmMakingResponseUnitName: [this.editOrderDetails?.filmMakingDCDetails?.unitName || ''],
      filmMakingDateSelect: [this.editOrderDetails?.filmMakingDCDetails?.date ? new Date(this.editOrderDetails?.filmMakingDCDetails?.date) : ''],

      screenMakingType: [this.editOrderDetails?.screenMakingDCDetails?.printTypeId || ''],
      screenMakingResponseType: [this.editOrderDetails?.screenMakingDCDetails?.printType || ''],
      screenMakingDCNo: [this.editOrderDetails?.screenMakingDCDetails?.dcNo || ''],
      screenMakingQuantity: [this.editOrderDetails?.screenMakingDCDetails?.quantity || '', [Validators.pattern(this.patterns.orderQuantity)]],
      screenMakingUnitName: [this.editOrderDetails?.screenMakingDCDetails?.unitNameId || ''],
      screenMakingResponseUnitName: [this.editOrderDetails?.screenMakingDCDetails?.unitName || ''],
      screenMakingDateSelect: [this.editOrderDetails?.screenMakingDCDetails?.date ? new Date(this.editOrderDetails?.screenMakingDCDetails?.date) : ''],

      embroideryType: [this.editOrderDetails?.embroideryDCDetails?.printTypeId || ''],
      embroideryResponseType: [this.editOrderDetails?.embroideryDCDetails?.printType || ''],
      embroideryDCNo: [this.editOrderDetails?.embroideryDCDetails?.dcNo || ''],
      embroideryQuantity: [this.editOrderDetails?.embroideryDCDetails?.quantity || '', [Validators.pattern(this.patterns.orderQuantity)]],
      embroideryUnitName: [this.editOrderDetails?.embroideryDCDetails?.unitNameId || ''],
      embroideryResponseUnitName: [this.editOrderDetails?.embroideryDCDetails?.unitName || ''],
      embroideryDateSelect: [this.editOrderDetails?.embroideryDCDetails?.date ? new Date(this.editOrderDetails?.embroideryDCDetails?.date) : ''],

      printingType: [this.editOrderDetails?.printingDCDetails?.printTypeId || ''],
      printingResponseType: [this.editOrderDetails?.printingDCDetails?.printType || ''],
      printingDCNo: [this.editOrderDetails?.printingDCDetails?.dcNo || ''],
      printingQuantity: [this.editOrderDetails?.printingDCDetails?.quantity || '', [Validators.pattern(this.patterns.orderQuantity)]],
      printingUnitName: [this.editOrderDetails?.printingDCDetails?.unitNameId || ''],
      printingResponseUnitName: [this.editOrderDetails?.printingDCDetails?.unitName || ''],
      printingDateSelect: [this.editOrderDetails?.printingDCDetails?.date ? new Date(this.editOrderDetails?.printingDCDetails?.date) : ''],

      resizingOneSideDCNo: [this.editOrderDetails?.resizingDCDetails[0]?.dcNo || ''],
      resizingOneSideQuantity: [this.editOrderDetails?.resizingDCDetails[0]?.quantity || '', [Validators.pattern(this.patterns.orderQuantity)]],
      resizingOneSideUnitName: [this.editOrderDetails?.resizingDCDetails[0]?.unitNameId || ''],
      resizingOneSideResponseUnitName: [this.editOrderDetails?.resizingDCDetails[0]?.unitName || ''],
      resizingOneSideDateSelect: [this.editOrderDetails?.resizingDCDetails[0]?.date ? new Date(this.editOrderDetails?.resizingDCDetails[0]?.date) : ''],
      resizingOneSidePrintingName: [this.editOrderDetails?.resizingDCDetails[0]?.printingUnitNameId || ''],
      resizingOneSideResponsePrintingName: [this.editOrderDetails?.resizingDCDetails[0]?.printingUnitName || ''],
      resizingOneSideCharge: [this.editOrderDetails?.resizingDCDetails[0]?.charge || ''],

      resizingBothSideDCNo: [this.editOrderDetails?.resizingDCDetails[1]?.dcNo || ''],
      resizingBothSideQuantity: [this.editOrderDetails?.resizingDCDetails[1]?.quantity || '', [Validators.pattern(this.patterns.orderQuantity)]],
      resizingBothSideUnitName: [this.editOrderDetails?.resizingDCDetails[1]?.unitNameId || ''],
      resizingBothSideResponseUnitName: [this.editOrderDetails?.resizingDCDetails[1]?.unitName || ''],
      resizingBothSideDateSelect: [this.editOrderDetails?.resizingDCDetails[1]?.date ? new Date(this.editOrderDetails?.resizingDCDetails[1]?.date) : ''],
      resizingBothSidePrintingName: [this.editOrderDetails?.resizingDCDetails[1]?.printingUnitNameId || ''],
      resizingBothSideResponsePrintingName: [this.editOrderDetails?.resizingDCDetails[1]?.printingUnitName || ''],
      resizingBothSideCharge: [this.editOrderDetails?.resizingDCDetails[1]?.charge || ''],

      stitchingDCNo: [this.editOrderDetails?.stichingDCDetails?.dcNo || ''],
      stitchingQuantity: [this.editOrderDetails?.stichingDCDetails?.quantity ?? ''],
      stitchingUnitName: [this.editOrderDetails?.stichingDCDetails?.unitNameId || ''],
      stitchingResponseUnitName: [this.editOrderDetails?.stichingDCDetails?.unitName || ''],
      stitchingStartDateSelect: [this.editOrderDetails?.stichingDCDetails?.date ? new Date(this.editOrderDetails?.stichingDCDetails?.date) : ''],
      // stitchingEndDateSelect: [this.editOrderDetails?.stichingDCDetails?.endDate ? new Date(this.editOrderDetails?.stichingDCDetails?.endDate) : ''],

      knittingDCNo: [this.editOrderDetails?.knittingDCDetails?.dcNo || ''],
      knittingQuantity: [this.editOrderDetails?.knittingDCDetails?.quantity || '', [Validators.pattern(this.patterns.orderQuantity)]],
      knittingUnitName: [this.editOrderDetails?.knittingDCDetails?.unitNameId || ''],
      knittingResponseUnitName: [this.editOrderDetails?.knittingDCDetails?.unitName || ''],
      knittingDateSelect: [this.editOrderDetails?.knittingDCDetails?.date ? new Date(this.editOrderDetails?.knittingDCDetails?.date) : ''],
      knittingCollarType: [this.editOrderDetails?.knittingDCDetails?.collarTypeId || ''],

      steamIronDCNo: [this.editOrderDetails?.steamIronDCDetails?.dcNo || ''],
      steamIronQuantity: [this.editOrderDetails?.steamIronDCDetails?.quantity || '', [Validators.pattern(this.patterns.orderQuantity)]],
      steamIronUnitName: [this.editOrderDetails?.steamIronDCDetails?.unitNameId || ''],
      steamIronResponseUnitName: [this.editOrderDetails?.steamIronDCDetails?.unitName || ''],
      steamIronDateSelect: [this.editOrderDetails?.steamIronDCDetails?.date ? new Date(this.editOrderDetails?.steamIronDCDetails?.date) : ''],
      steamIronAgeGroup: [this.editOrderDetails?.steamIronDCDetails?.ageGroupId?.toString() || ''],
    });

    if (this.editOrderDetails) {
      this.editOrderFormControls['dressItemSelect'].disable({ onlySelf: true });
      this.editOrderFormControls['methodSelect'].disable({ onlySelf: true });
      this.editOrderFormControls['patternSelect'].disable({ onlySelf: true });
      if (this.editOrderDetails?.order?.orderStatusId > 1) {
        this.editOrderFormControls['qualitySelect'].disable({ onlySelf: true });
        this.editOrderFormControls['deliveryDate'].disable({ onlySelf: true });
        this.editOrderFormControls['place'].disable({ onlySelf: true });
        this.editOrderFormControls['paymentMode'].disable({ onlySelf: true });
      }

      if (this.editOrderDetails?.order?.paymentApproved == 1) {
        this.editOrderFormControls['approved'].disable({ onlySelf: true });
        this.editOrderFormControls['paymentReceived'].disable({ onlySelf: true });
        this.editOrderFormControls['paymentDate'].disable({ onlySelf: true });
      }
      if (this.editOrderDetails?.order?.orderStatusId == 13 && this.editOrderDetails?.order?.fullPayment == '1') {
        this.editOrderFormControls['orderStatus'].disable({ onlySelf: true });
      }
      this.onChangeOrderReceived(orderReceivedValue);
      this.onChangeSchoolType(schoolTypeValue);
      this.onChangePaymentMode(paymentModeValue);
      this.onChangePaymentReceived(paymentReceivedValue);
      this.onChangeCalculatePoints(calculatePointsValue);
      // this.onChangeCommission(agentCommissionValue);
      // this.onChangeUnitPoints(unitPointsValue);
      this.onChangeApprovedRadio(paymentApprovedValue);

      if (this.editOrderDetails?.specialModelForTShirt?.sublimationId == 23) {
        this.IsSublimationBothSide = false;
      } else if (this.editOrderDetails?.specialModelForTShirt?.sublimationId == 24) {
        this.IsSublimationBothSide = true;
      }
      this.editOrderFormControls['SchoolType'].disable({ onlySelf: true });
    }
  }

  /**
   * Initialize Add Order Form Validations
   */
  addOrderFormValidations() {
    this.addOrderForm = this.formBuilder.group({
      colorSelect: ["", [Validators.required]],
      sizeSelect: ["", [Validators.required]],
      quantity: ["", [Validators.required, Validators.pattern(this.patterns.quantity)]],
      unitPrice: ["", [Validators.required, Validators.pattern(this.patterns.orderUnitPrice)]]
    });
  }

  /**
   * Get Add Order Form Controls
   * @readonly
   */
  get addOrderFormControls() {
    return this.addOrderForm.controls;
  }

  /**
   * This method is used to close the snackbar on enter
   */
  @HostListener('document:keypress', ['$event'])
  handleKeyPress(event: KeyboardEvent) {
    if (event.key == 'Enter') {
      this.onClickSnackbarOkButton();
    }
  }

  /**
   * This method is used to get the dress items List
   */
  getDressItemList() {
    this.mastersService.getDressItems().subscribe({
      next: (res: any) => {
        this.dressItemsList = res.result;
        if (this.editOrderDetails) {
          let dressItemId = this.editOrderDetails?.order?.dressItemId;
          this.editOrderFormControls['dressItemSelect'].setValue(dressItemId?.toString());
          this.onChangeDressItem(dressItemId, false);
        }
      },
      error: (err: any) => {
        this.dressItemsList = [];
      },
    });
  }

  /**
   * This method is used to get the method List
   * @param {*} eventFlag
   */
  getMethodList(eventFlag: any) {
    this.mastersService.getMethods().subscribe({
      next: (res: any) => {
        this.methodsList = res.result;
        if (eventFlag) {
          let methodIdValue = this.editOrderDetails?.order?.methodId;
          this.editOrderFormControls['methodSelect'].setValue(methodIdValue?.toString());
          this.onChangeMethod(methodIdValue, false);
          this.getSizesList(eventFlag);
        }
      },
      error: (err: any) => {
        this.methodsList = [];
      },
    });
  }

  /**
   * This method is used to get the colours list
   */
  getColoursList() {
    this.mastersService.getColours().subscribe({
      next: (res: any) => {
        this.coloursList = res.result;
      },
      error: (err: any) => {
        this.coloursList = [];
      },
    });
  }

  /**
   * This method is used to get the patterns list
   * @param {*} eventFlag
   */
  getPatternsList(eventFlag: any) {
    this.chargesService.getStitchingPatternTypesByDressItemId(this.selectedDressItem.dressItemId?.toString()).subscribe({
      next: (res: any) => {
        this.patternsList = res.result;
        if (eventFlag) {
          if (this.isPatternDressItem) {
            let patternValue = this.editOrderDetails?.order?.patternTypeId;
            this.editOrderFormControls['patternSelect'].setValue(patternValue?.toString());
            this.onChangePattern(patternValue, false);
          }

          const obj: any = {};
          if (this.selectedDressItem?.dressItemName == "T-Shirts") {
            if (this.selectedPattern?.patternType === "Special Model") {
              obj.specialModelForTShirt = this.editOrderDetails?.specialModelForTShirt;
            } else if (this.selectedPattern?.patternType === "Special Pattern") {
              obj.specialPatternForTshirt = this.editOrderDetails?.specialPatternForTshirt;
            } else {
              obj.normalPatternforTshirt = this.editOrderDetails?.normalPatternforTshirt;
            }
          } else if (this.selectedDressItem?.dressItemName == "Middy") {
            if (this.selectedPattern?.patternType === "Special") {
              obj.specialforMiddy = this.editOrderDetails?.specialforMiddy;
            } else {
              obj.normalforMiddy = this.editOrderDetails?.normalforMiddy;
            }
          } else if (this.selectedDressItem?.dressItemName == "Pant") {
            obj.patternforPant = this.editOrderDetails?.patternforPant;
          } else if (this.selectedDressItem?.dressItemName == "Nicker") {
            obj.patternforPant = this.editOrderDetails?.patternforPant;
          } else if (this.selectedDressItem?.dressItemName == "Shots") {
            obj.patternforPant = this.editOrderDetails?.patternforPant;
          } else if (this.selectedDressItem?.dressItemName == "Pinofers") {
            obj.patternforPinofer = this.editOrderDetails?.patternforPinofer;
          }
          this.orderService.orderPatternDetailsObj.next(obj);
        }
      },
      error: (err: any) => {
        this.patternsList = [];
      },
    });
  }

  /**
   * Get sales tax
   */
  getSaleTax() {
    this.mastersService.getSalesTax().subscribe({
      next: (res: any) => {
        const salesTaxArray: any[] = res.result || [];
        if (salesTaxArray.length > 0) {
          salesTaxArray.sort((a, b) => new Date(b.createdDate).getTime() - new Date(a.createdDate).getTime());
          this.latestSalesTaxName = salesTaxArray[0].salesTaxName;
        }
      },
      error: (err: any) => { }
    });
  }

  /**
   * This method is used to get staff list
   */
  getStaffsList() {
    /* To call the service to get the staff list */
    this.mastersService.getStaffs().subscribe({
      next: (res: any) => {
        this.staffList = res.result?.filter((item: any) => item.isStaff == '1');
        this.inchargeList = res.result?.filter((item: any) => item.isStaff == '0');
        if (this.editOrderDetails) {
          if (this.isStaffSelect) {
            let staffValue = this.editOrderDetails?.order?.staffId;
            setTimeout(() => {
              this.editOrderFormControls['staff'].setValue(staffValue?.toString() || '');
              this.cdr.detectChanges();
            }, 50);
            this.onChangeStaff(staffValue);
          }
          if (this.editOrderDetails?.order?.inchargeId) {
            let inchargeValue = this.editOrderDetails?.order?.inchargeId;
            setTimeout(() => {
              this.editOrderFormControls['incharge'].setValue(inchargeValue?.toString());
              this.cdr.detectChanges();
            }, 50);
            this.onChangeIncharge(inchargeValue);
          }
        }

      },
      error: (err: any) => {
        this.staffList = [];
        this.inchargeList = [];
      }
    });
  }

  /**
   * This method is used to get Agents List
   * @param {*} eventFlag
   */
  getAgentsList(eventFlag: any) {
    /* To call the service to get the agents list */
    this.mastersService.getAgents().subscribe({
      next: (res: any) => {
        this.agentsList = res.result;
        if (eventFlag) {
          let agentValue = this.editOrderDetails?.order?.agentId;
          this.editOrderFormControls['agent'].setValue(agentValue?.toString());
          this.onChangeAgent(agentValue);
        }
      },
      error: (err: any) => {
        this.agentsList = [];
      }
    });
  }

  /**
   * This method is used to get the quality List
   */
  getQualityList() {
    this.mastersService.getQualities().subscribe({
      next: (res: any) => {
        this.qualityList = res.result;
        if (this.editOrderDetails) {
          let qualityId = this.editOrderDetails?.order?.qualityId;
          this.editOrderFormControls['qualitySelect'].setValue(qualityId?.toString());
          this.onChangeQuality(qualityId);
        }
      },
      error: (err: any) => {
        this.qualityList = [];
      },
    });
  }

  /**
   * This method is used to get the sizes list
   * @param {*} eventFlag
   */
  getSizesList(eventFlag: any) {
    /* Prepare the Request Payload */
    const obj = {
      dressItemId: this.selectedDressItem?.dressItemId,
      methodId: this.selectedMethod?.methodId,
    };
    this.mastersService.getDressItemSizesByDressAndMethod(obj).subscribe({
      next: (res: any) => {
        this.sizesList = res.result;
        if (eventFlag) {
          const responseOrderItems = this.editOrderDetails?.orderColours?.map((responseData: any, index: any) => {
            const colour = this.coloursList.find((element: any) => +responseData?.colorId === +element?.colourId);
            const size = this.sizesList.find((element: any) => +responseData?.sizeId === +element?.sizeId);

            return {
              id: index,
              colorId: +responseData.colorId,
              colourName: colour?.colourName,
              sizeId: +responseData.sizeId,
              size: size?.sizeName,
              quantity: Number(+responseData.quantity),
              unitPrice: Number(+responseData.unitPrice),
            };
          });

          this.savedOrderItemsList = responseOrderItems || [];
          localStorage.setItem("savedOrdersList", JSON.stringify(this.savedOrderItemsList));

          const totalQty = this.getSavedTotalQuantity();
          this.totalQuantity = totalQty;
          // Calculate order value for each item
          const orderValues = this.savedOrderItemsList.map((item) => item.quantity * item.unitPrice);
          // Calculate the total order value
          this.totalOrderValue = orderValues.reduce((sum, value) => sum + value, 0);
          const totalUnitPrice = (this.totalOrderValue * 100) / (100 + Number(this.latestSalesTaxName));
          this.avgUnitPrice = totalUnitPrice / this.totalQuantity;
          this.editOrderFormControls['invoiceQuantity'].setValue(this.totalQuantity);
          this.editOrderFormControls['invoiceValue'].setValue(this.totalOrderValue);
          if (this.editOrderFormControls['resizingBothSideQuantity'].value == '') {
            this.editOrderFormControls['resizingBothSideQuantity'].setValue(this.totalQuantity);
          }
        }

      },
      error: (err: any) => {
        this.sizesList = [];
      },
    });
  }

  /**
   * This method is used to get the order status List
   */
  getOrderStatusList() {
    this.orderService.getOrderStatus(this.editOrderDetails?.order?.orderStatusId, this.editOrderDetails?.order?.organizationTypeId).subscribe({
      next: (res: any) => {
        this.orderStatusList = res.result;
        if (this.editOrderDetails) {
          /*  Order Status Knitting For T-Shirts & Pinofers */
          if (this.editOrderDetails?.order?.dressItemId != 1 && this.editOrderDetails?.order?.dressItemId != 3 ||
            (this.editOrderDetails?.order?.dressItemId == 1 &&
              (this.editOrderDetails?.specialModelForTShirt?.vneckId && this.editOrderDetails?.specialModelForTShirt?.vneckId != 0) ||
              (this.editOrderDetails?.specialModelForTShirt?.roundNeckRibColorId && this.editOrderDetails?.specialModelForTShirt?.roundNeckRibColorId != 0)
            ) ||
            (this.editOrderDetails?.order?.dressItemId == 3 && !this.editOrderDetails?.patternforPinofer?.isNeckCollar)
          ) {
            this.orderStatusList = this.orderStatusList.filter((status: any) => status.orderStatusId != 11);
          }

          /*  Order Status Film Making / Screen Making / Embroidery For Sublimation */
          if (this.editOrderDetails?.specialModelForTShirt?.sublimationId == 24) {
            this.orderStatusList = this.orderStatusList.filter((status: any) => status.orderStatusId != 5 && status.orderStatusId != 6 && status.orderStatusId != 7);
          }

          /*  Order Status Resizing For Sublimation */
          if (!this.editOrderDetails?.specialModelForTShirt?.sublimationId) {
            this.orderStatusList = this.orderStatusList.filter((status: any) => status.orderStatusId != 9);
          }

          let orderStatusSelectValue = this.editOrderDetails?.order?.orderStatusId?.toString() || '';
          this.selectedPreviousOrderStatus = orderStatusSelectValue;
          this.editOrderFormControls['orderStatus'].setValue(orderStatusSelectValue);
          this.onChangeOrderStatus(orderStatusSelectValue);
        }
      },
      error: (err: any) => {
        this.orderStatusList = [];
      }
    });
  }

  /**
   * This method is used to get unit names list
   * @param {*} orderStatusId
   * @param {*} eventFlag
   */
  getUnitNamesList(orderStatusId: any, eventFlag: any) {
    /* To call the service to get the unit names list */
    this.orderService.getUnitNamesByStatus(orderStatusId).subscribe({
      next: (res: any) => {
        this.unitNamesList = res.result;
        if (this.editOrderDetails && eventFlag) {
          const statusFlags: any = {
            3: { control: 'cuttingUnitName', value: this.editOrderDetails?.cuttingDCDetails?.unitNameId || '' },
            4: { control: 'fusingUnitName', value: this.editOrderDetails?.fusingDCDetails?.unitNameId || '' },
            5: { control: 'filmMakingUnitName', value: this.editOrderDetails?.filmMakingDCDetails?.unitNameId || '' },
            6: { control: 'screenMakingUnitName', value: this.editOrderDetails?.screenMakingDCDetails?.unitNameId || '' },
            7: { control: 'embroideryUnitName', value: this.editOrderDetails?.embroideryDCDetails?.unitNameId || '' },
            8: { control: 'printingUnitName', value: this.editOrderDetails?.printingDCDetails?.unitNameId || '' },
            10: { control: 'stitchingUnitName', value: this.editOrderDetails?.stichingDCDetails?.unitNameId || '' },
            11: { control: 'knittingUnitName', value: this.editOrderDetails?.knittingDCDetails?.unitNameId || '' },
            12: { control: 'steamIronUnitName', value: this.editOrderDetails?.steamIronDCDetails?.unitNameId || '' },
          }

          if (orderStatusId != 9) {
            const flags = statusFlags[orderStatusId];
            if (flags) {
              setTimeout(() => {
                this.editOrderFormControls[flags.control].setValue(flags.value?.toString() || '');
                this.cdr.detectChanges();
              }, 50);
            }
          } else {
            setTimeout(() => {
              let oneSideUnitName = this.editOrderDetails?.resizingDCDetails[0]?.unitNameId || '';
              let bothSideUnitName = this.editOrderDetails?.resizingDCDetails[1]?.unitNameId || '';
              this.editOrderFormControls['resizingOneSideUnitName'].setValue(oneSideUnitName?.toString() || '');
              this.editOrderFormControls['resizingBothSideUnitName'].setValue(bothSideUnitName?.toString() || '');
              this.cdr.detectChanges();
            }, 50);
          }
        }
      },
      error: (err: any) => {
        this.unitNamesList = [];
      }
    });
  }

  /**
   * This method is used to get cutting unit names list
   * @param {*} orderStatusId
   * @param {*} eventFlag
   */
  getCuttingUnitNamesList(orderStatusId: any, eventFlag: any) {
    /* To call the service to get the unit names list */
    this.orderService.getUnitNamesByStatus(orderStatusId).subscribe({
      next: (res: any) => {
        this.cuttingUnitNamesList = res.result;
        if (this.editOrderDetails && eventFlag) {
          setTimeout(() => {
            this.editOrderFormControls['cuttingUnitName'].setValue(this.editOrderDetails?.cuttingDCDetails?.unitNameId?.toString() || '');
            this.cdr.detectChanges();
          }, 50);
        }
      },
      error: () => {
        this.cuttingUnitNamesList = [];
      }
    });
  }

  /**
   * This method is used to get fusing unit names list
   * @param {*} orderStatusId
   * @param {*} eventFlag
   */
  getFusingUnitNamesList(orderStatusId: any, eventFlag: any) {
    /* To call the service to get the unit names list */
    this.orderService.getUnitNamesByStatus(orderStatusId).subscribe({
      next: (res: any) => {
        this.fusingUnitNamesList = res.result;
        if (this.editOrderDetails && eventFlag) {
          setTimeout(() => {
            this.editOrderFormControls['fusingUnitName'].setValue(this.editOrderDetails?.fusingDCDetails?.unitNameId?.toString() || '');
            this.cdr.detectChanges();
          }, 50);
        }
      },
      error: () => {
        this.fusingUnitNamesList = [];
      }
    });
  }

  /**
   * This method is used to get film making unit names list
   * @param {*} orderStatusId
   * @param {*} eventFlag
   */
  getFilmMakingUnitNamesList(orderStatusId: any, eventFlag: any) {
    /* To call the service to get the unit names list */
    this.orderService.getUnitNamesByStatus(orderStatusId).subscribe({
      next: (res: any) => {
        this.filmMakingUnitNamesList = res.result;
        if (this.editOrderDetails && eventFlag) {
          setTimeout(() => {
            this.editOrderFormControls['filmMakingUnitName'].setValue(this.editOrderDetails?.filmMakingDCDetails?.unitNameId?.toString() || '');
            this.cdr.detectChanges();
          }, 50);
        }
      },
      error: () => {
        this.filmMakingUnitNamesList = [];
      }
    });
  }

  /**
   * This method is used to get screen making unit names list
   * @param {*} orderStatusId
   * @param {*} eventFlag
   */
  getScreenMakingUnitNamesList(orderStatusId: any, eventFlag: any) {
    /* To call the service to get the unit names list */
    this.orderService.getUnitNamesByStatus(orderStatusId).subscribe({
      next: (res: any) => {
        this.screenMakingUnitNamesList = res.result;
        if (this.editOrderDetails && eventFlag) {
          setTimeout(() => {
            this.editOrderFormControls['screenMakingUnitName'].setValue(this.editOrderDetails?.screenMakingDCDetails?.unitNameId?.toString() || '');
            this.cdr.detectChanges();
          }, 50);
        }
      },
      error: () => {
        this.screenMakingUnitNamesList = [];
      }
    });
  }

  /**
   * This method is used to get embroidery unit names list
   * @param {*} orderStatusId
   * @param {*} eventFlag
   */
  getEmbroideryUnitNamesList(orderStatusId: any, eventFlag: any) {
    /* To call the service to get the unit names list */
    this.orderService.getUnitNamesByStatus(orderStatusId).subscribe({
      next: (res: any) => {
        this.embroideryUnitNamesList = res.result;
        if (this.editOrderDetails && eventFlag) {
          setTimeout(() => {
            this.editOrderFormControls['embroideryUnitName'].setValue(this.editOrderDetails?.embroideryDCDetails?.unitNameId?.toString() || '');
            this.cdr.detectChanges();
          }, 50);
        }
      },
      error: () => {
        this.embroideryUnitNamesList = [];
      }
    });
  }

  /**
   * This method is used to get printing unit names list
   * @param {*} orderStatusId
   * @param {*} eventFlag
   */
  getPrintingUnitNamesList(orderStatusId: any, eventFlag: any) {
    /* To call the service to get the unit names list */
    this.orderService.getUnitNamesByStatus(orderStatusId).subscribe({
      next: (res: any) => {
        this.printingUnitNamesList = res.result;
        if (this.editOrderDetails && eventFlag) {
          setTimeout(() => {
            this.editOrderFormControls['printingUnitName'].setValue(this.editOrderDetails?.printingDCDetails?.unitNameId?.toString() || '');
            this.cdr.detectChanges();
          }, 50);
        }
      },
      error: () => {
        this.printingUnitNamesList = [];
      }
    });
  }

  /**
   * This method is used to get resizing unit names list
   * @param {*} orderStatusId
   * @param {*} eventFlag
   */
  getResizingUnitNamesList(orderStatusId: any, eventFlag: any) {
    /* To call the service to get the unit names list */
    this.orderService.getUnitNamesByStatus(orderStatusId).subscribe({
      next: (res: any) => {
        this.resizingUnitNamesList = res.result;
        if (this.editOrderDetails && eventFlag) {
          setTimeout(() => {
            let oneSideUnitName = this.editOrderDetails?.resizingDCDetails[0]?.unitNameId || '';
            let bothSideUnitName = this.editOrderDetails?.resizingDCDetails[1]?.unitNameId || '';
            this.editOrderFormControls['resizingOneSideUnitName'].setValue(oneSideUnitName?.toString() || '');
            this.editOrderFormControls['resizingBothSideUnitName'].setValue(bothSideUnitName?.toString() || '');
            this.cdr.detectChanges();
          }, 50);
        }
      },
      error: () => {
        this.resizingUnitNamesList = [];
      }
    });
  }

  /**
   * This method is used to get stitching unit names list
   * @param {*} orderStatusId
   * @param {*} eventFlag
   */
  getStitchingUnitNamesList(orderStatusId: any, eventFlag: any) {
    /* To call the service to get the unit names list */
    this.orderService.getUnitNamesByStatus(orderStatusId).subscribe({
      next: (res: any) => {
        this.stitchingUnitNamesList = res.result;
        if (this.editOrderDetails && eventFlag) {
          const statusFlags: any = {
            10: { control: 'stitchingUnitName', value: this.editOrderDetails?.stichingDCDetails?.unitNameId || '' },
          }

          const flags = statusFlags[orderStatusId];
          if (flags) {
            setTimeout(() => {
              this.editOrderFormControls[flags.control].setValue(flags.value?.toString() || '');
              this.cdr.detectChanges();
            }, 50);
          }
        }
      },
      error: () => {
        this.stitchingUnitNamesList = [];
      }
    });
  }

  /**
   * This method is used to get knitting unit names list
   * @param {*} orderStatusId
   * @param {*} eventFlag
   */
  getKnittingUnitNamesList(orderStatusId: any, eventFlag: any) {
    /* To call the service to get the unit names list */
    this.orderService.getUnitNamesByStatus(orderStatusId).subscribe({
      next: (res: any) => {
        this.knittingUnitNamesList = res.result;
        if (this.editOrderDetails && eventFlag) {
          setTimeout(() => {
            let unitName = this.editOrderDetails?.knittingDCDetails?.unitNameId?.toString() != '0' ? this.editOrderDetails?.knittingDCDetails?.unitNameId?.toString() : '';
            this.editOrderFormControls['knittingUnitName'].setValue(unitName);
            this.cdr.detectChanges();
          }, 50);
        }
      },
      error: () => {
        this.knittingUnitNamesList = [];
      }
    });
  }

  /**
   * This method is used to get steam iron unit names list
   * @param {*} orderStatusId
   * @param {*} eventFlag
   */
  getSteamIronUnitNamesList(orderStatusId: any, eventFlag: any) {
    /* To call the service to get the unit names list */
    this.orderService.getUnitNamesByStatus(orderStatusId).subscribe({
      next: (res: any) => {
        this.steamIronUnitNamesList = res.result;
        if (this.editOrderDetails && eventFlag) {
          setTimeout(() => {
            this.editOrderFormControls['steamIronUnitName'].setValue(this.editOrderDetails?.steamIronDCDetails?.unitNameId?.toString() || '');
            this.cdr.detectChanges();
          }, 50);
        }
      },
      error: () => {
        this.steamIronUnitNamesList = [];
      }
    });
  }

  /**
   * This method is used to get resizing printing unit names list
   * @param {*} eventFlag
   */
  getResizingPrintingUnitNamesList(eventFlag: any) {
    /* To call the service to get the printing unit names list */
    this.orderService.getPrintingUnitNames().subscribe({
      next: (res: any) => {
        this.resizingPrintingUnitNamesList = res.result;
        if (this.editOrderDetails && eventFlag) {
          setTimeout(() => {
            this.editOrderFormControls['resizingOneSidePrintingName'].setValue(
              this.editOrderDetails?.resizingDCDetails[0]?.printingUnitNameId?.toString() || ''
            );
            if (this.IsSublimationBothSide) {
              this.editOrderFormControls['resizingBothSidePrintingName'].setValue(
                this.editOrderDetails?.resizingDCDetails[1]?.printingUnitNameId?.toString() || ''
              );
            }
            this.cdr.detectChanges();
          }, 50);
        }
      },
      error: () => {
        this.resizingPrintingUnitNamesList = [];
      }
    });
  }

  /**
   * This method is used to get print types list
   * @param {*} orderStatusId
   * @param {string} eventFlag
   */
  getPrintTypesList(orderStatusId: any, eventFlag: string) {
    /* To call the service to get the unit names list */
    this.orderService.getPrintTypesByStatus(orderStatusId).subscribe({
      next: (res: any) => {
        this.printTypesList = res.result;
        if (this.editOrderDetails && eventFlag) {
          const statusFlags: any = {
            5: { control: 'filmMakingType', value: this.editOrderDetails?.filmMakingDCDetails?.printTypeId },
            6: { control: 'screenMakingType', value: this.editOrderDetails?.screenMakingDCDetails?.printTypeId },
            7: { control: 'embroideryType', value: this.editOrderDetails?.embroideryDCDetails?.printTypeId },
            8: { control: 'printingType', value: this.editOrderDetails?.printingDCDetails?.printTypeId },
          }
          const flags = statusFlags[orderStatusId];
          if (flags) {
            this.editOrderFormControls[flags.control].setValue(flags.value?.toString() || '');
          }
          this.cdr.detectChanges();
        }
      },
      error: () => {
        this.printTypesList = [];
      }
    });
  }

  /**
   * This method is used to get fusing Types List
   */
  getFusingTypes() {
    this.chargesService.getFusingTypes().subscribe({
      next: (res: any) => {
        this.fusingTypesList = res?.result;
      },
      error: () => {
        this.fusingTypesList = [];
      },
    });
  }

  /**
   * This method is used to get Collar Types List
   */
  getCollarTypes() {
    this.chargesService.getCollarTypes().subscribe({
      next: (res: any) => {
        this.collarTypesList = res?.result;
      },
      error: () => {
        this.collarTypesList = [];
      },
    });
  }

  /**
   * This method is used to get transport list
   */
  getTransportList() {
    this.mastersService.getTransports().subscribe({
      next: (res: any) => {
        this.transportList = res.result;
        if (this.editOrderDetails) {
          let transportValue = this.editOrderDetails?.order?.transportId == 0 ? '' : this.editOrderDetails?.order?.transportId?.toString();
          this.editOrderFormControls['transport'].setValue(transportValue);
          this.onChangeTransport(transportValue);
        }
      },
      error: () => {
        this.transportList = [];
      }
    });
  }

  /**
   * This method is used to add validators
   * @param {*} formControls
   * @param {*} controls
   */
  onAddValidators(formControls: any, controls: any) {
    controls?.forEach((control: any) => {
      formControls[control].addValidators([Validators.required]);
      formControls[control].updateValueAndValidity({ onlySelf: true });
    });
  }

  /**
   * This method is used to remove validators
   * @param {*} formControls
   */
  onRemoveValidators(formControls: any, controls: any) {
    controls?.forEach((control: any) => {
      formControls[control].removeValidators([Validators.required]);
      formControls[control].updateValueAndValidity({ onlySelf: true });
    });
  }

  /**
   * This method is used to update value and validity
   * @param {*} formControls
   */
  onUpdateValueAndValidity(formControls: any, controls: any) {
    controls?.forEach((control: any) => {
      formControls[control].setValue("");
      formControls[control].markAsUntouched({ onlySelf: true });
      formControls[control].updateValueAndValidity({ onlySelf: true });
    });
  }

  /**
   * This method is used to remove validators and update value
   * @param {*} formControls
   * @param {*} controls
   */
  onRemoveValidatorsAndUpdateControls(formControls: any, controls: any) {
    controls?.forEach((control: any) => {
      formControls[control].removeValidators([Validators.required]);
      formControls[control].setValue("");
      formControls[control].markAsUntouched({ onlySelf: true });
      formControls[control].updateValueAndValidity({ onlySelf: true });
    });
  }

  /**
   * Set the minimum date selection for ToDate(End Date)
   * @param {Date} e
   */
  setMinDateForToDate(e: Date) {
    const dateFormate: Date = e;
    // this.minToDate = dateFormate;
    // this.userSearchForm.controls["endDate"].setValue("");
  }

  /**
   * This method used to reset Sample Order form
   */
  resetSampleOrder() {
    this.editOrderForm.reset();
    this.editSampleOrderFormValidations();
    this.isBackPrint = false;
    this.isCourier = false;
    this.onClickNavigateToOrdersList();
  }

  /**
   * This method will fired when user selects the Organization
   * @param {*} event
   */
  organizationChange(event: any) {
    for (const element of this.organizationTypeList) {
      if (element.id === event.target.value) {
        this.selectedOrganization = element;
      }
    }
  }

  /**
   * This method will fired when user selects Dress Item
   * @param {*} event
   * @param {boolean} changeFlag
   */
  onChangeDressItem(event: any, changeFlag: boolean) {
    if (!changeFlag) {

      if (localStorage.getItem("savedOrdersList")) {
        this.selectedNewDressItem = event.target?.value;
        this.isChangesInPattern = 'dressItem';
        document.getElementById("alertModalBtn")?.click();
        return;
      }

      let dressItemSizeValue = event?.target ? +event.target?.value : +event;
      this.isAddOrderItems = false;
      if (event?.target) {
        this.onUpdateValueAndValidity(this.editOrderFormControls, ["methodSelect"]);
        this.selectedMethod = "";
        this.onUpdateValueAndValidity(this.editOrderFormControls, ["qualitySelect"]);
      }
      this.orderItemsList = [];
      this.savedOrderItemsList = [];
      localStorage.removeItem("savedOrdersList");
      this.diagramURL = '';

      for (const element of this.dressItemsList) {
        if (+element.dressItemId === +dressItemSizeValue) {
          this.selectedDressItem = element;
          if (this.selectedDressItem && this.selectedMethod) {
            this.isAddOrderItems = true;
          } else {
            this.isAddOrderItems = false;
          }

        }
      }

      if (event?.target) {
        this.getPatternsList("");
        this.getMethodList("");
      } else {
        this.getMethodList("noEvent");
        this.getPatternsList("noEvent");
      }

      const isDressItemContainsPocket = this.pocketDressItemsList.includes(this.selectedDressItem?.dressItemName);
      if (isDressItemContainsPocket) {
        this.editOrderFormControls['printType'].enable({ onlySelf: true });
        this.editOrderFormControls['printType'].setValue('2');
        this.isPrintType = true;
      } else {
        this.editOrderFormControls['printType'].setValue('');
        this.editOrderFormControls['printType'].disable({ onlySelf: true });
        this.isPrintType = false;
      }
      let noEvent = event?.target;

      if (!noEvent && this.isPrintType) {
        let printTypeId = this.editOrderDetails?.order?.printtypeId?.toString();
        this.editOrderFormControls['printType'].setValue(printTypeId?.toString());
        this.printTypeChange(printTypeId);
      }

      const isDressItemContainsBackPrint = this.backPrintDressItemsList.includes(this.selectedDressItem?.dressItemName);
      if (isDressItemContainsBackPrint) {
        this.isBackPrint = true;
        if (!noEvent) {
          let backPrint1Value = this.editOrderDetails?.order?.backPrint1 ?? '';
          let backPrint2Value = this.editOrderDetails?.order?.backPrint2 ?? '';
          let backPrint3Value = this.editOrderDetails?.order?.backPrint3 ?? '';
          let backPrint4Value = this.editOrderDetails?.order?.backPrint4 ?? '';
          let diagramIdValue = this.editOrderDetails?.order?.diagramId ?? '';
          this.editOrderFormControls['BackPrintOne'].setValue(backPrint1Value?.toString());
          this.editOrderFormControls['BackPrintTwo'].setValue(backPrint2Value?.toString());
          this.editOrderFormControls['BackPrintThree'].setValue(backPrint3Value?.toString());
          this.editOrderFormControls['BackPrintFour'].setValue(backPrint4Value?.toString());
          this.editOrderFormControls['diagramSelect'].setValue(diagramIdValue);
          this.diagramChange(diagramIdValue);
        }
        this.onAddValidators(this.editOrderFormControls, ["BackPrintOne", "BackPrintTwo", "diagramSelect"]);
      } else {
        this.isBackPrint = false;
        this.onRemoveValidators(this.editOrderFormControls, ["BackPrintOne", "BackPrintTwo", "diagramSelect"]);
      }


      this.orderService.orderPatternDetailsObj.subscribe((val: any) => {
        if (Object.keys(val).length !== 0) {
          if (val?.specialModelForTShirt) {
            const specialModel = val?.specialModelForTShirt;
            if (specialModel?.printingId === 0) {
              this.onHandleSpecialModel("NoBackPrintDetails", false);
            } else if (specialModel?.printingId === 2) {
              if (specialModel.sublimationId === 23 && specialModel.isBackPrint) {
                this.onHandleSpecialModel("NoBackPrintDetails", true);
              } else {
                this.onHandleSpecialModel("NoBackPrintDetails", false);
              }
            } else {
              if (isDressItemContainsBackPrint) {
                this.onHandleSpecialModel("", true);
              }
            }
          }
        }
      });

      const isDressItemContainsPattern = this.patternDressItemsList.includes(this.selectedDressItem?.dressItemName);
      if (isDressItemContainsPattern) {
        this.isPatternDressItem = true;
        this.onAddValidators(this.editOrderFormControls, ["patternSelect"]);
      } else {
        this.isPatternDressItem = false;
        this.onRemoveValidators(this.editOrderFormControls, ["patternSelect"]);
      }
      if (noEvent) {
        this.selectedPattern = "";
        this.isAddPatternDetails = false;
        this.onUpdateValueAndValidity(this.editOrderFormControls, ["patternSelect", "BackPrintOne", "BackPrintTwo", "BackPrintThree", "BackPrintFour", "diagramSelect"]);
      }
    }
  }

  /**
   * This method is used to handle the back print details
   * @param {*} isTShirtSpecialModel
   * @param {*} isBackPrint
   */
  onHandleSpecialModel(isTShirtSpecialModel: any, isBackPrint: any) {
    this.isTShirtSpecialModel = isTShirtSpecialModel;
    this.isBackPrint = isBackPrint;
    this.isPrintType = isBackPrint;

    const controlsToRemove = ["BackPrintOne", "BackPrintTwo", "diagramSelect"];
    if (!isBackPrint) {
      this.onRemoveValidators(this.editOrderFormControls, controlsToRemove);
    } else {
      this.onAddValidators(this.editOrderFormControls, controlsToRemove);
    }

  }

  /**
   * This method will fired when user selects the method
   * @param {*} event
   * @param {boolean} changeFlag
   */
  onChangeMethod(event: any, changeFlag: boolean) {
    if (!changeFlag) {
      let methodValue = event?.target ? +event.target?.value : +event;
      if (localStorage.getItem("savedOrdersList")) {
        this.selectedNewMethod = methodValue;
        this.isChangesInPattern = 'method';
        document.getElementById("alertModalBtn")?.click();
        return;
      }

      this.isAddPatternDetails = false;
      this.orderItemsList = [];
      this.savedOrderItemsList = [];
      localStorage.removeItem("savedOrdersList");

      for (const element of this.methodsList) {
        if (+element.methodId === +methodValue) {
          this.selectedMethod = element;

        }
      }
      if (this.selectedDressItem && this.selectedMethod) {
        this.isAddOrderItems = true;
      } else {
        this.isAddOrderItems = false;
      }
    }
  }

  /**
   * This method will fired when user selects the quality
   * @param {*} event
   */
  onChangeQuality(event: any) {
    let qualityValue = event?.target ? +event.target?.value : +event;
    if (!this.selectedDressItem && event?.target) {
      this.onUpdateValueAndValidity(this.editOrderFormControls, ["qualitySelect"]);
      this.snackbarModalComponent.onOpenSnackbarModal(false, "Please Select Dress Item", '', '', '');
      return;
    }

    if (!this.selectedMethod && event?.target) {
      this.onUpdateValueAndValidity(this.editOrderFormControls, ["qualitySelect"]);
      this.snackbarModalComponent.onOpenSnackbarModal(false, "Please Select Method", '', '', '');
      return;
    }

    if (this.savedOrderItemsList.length === 0 && event?.target) {
      this.onUpdateValueAndValidity(this.editOrderFormControls, ["qualitySelect"]);
      this.snackbarModalComponent.onOpenSnackbarModal(false, "Please Add Order Items", '', '', '');
      return;
    }

    for (const element of this.qualityList) {
      if (+element.qualityId === +qualityValue) {
        this.selectedQuality = element;
      }
    }
  }

  /**
   * This method will fired when user selects the pattern
   * @param {*} event
   * @param {boolean} changeFlag
   */
  onChangePattern(event: any, changeFlag: boolean) {
    if (!this.selectedMethod && event?.target) {
      this.onUpdateValueAndValidity(this.editOrderDetails, ["patternSelect"]);
      this.snackbarModalComponent.onOpenSnackbarModal(false, "Please Select Method", '', '', '');
      return;
    }

    if (this.savedOrderItemsList.length === 0 && event?.target) {
      this.onUpdateValueAndValidity(this.editOrderDetails, ["patternSelect"]);
      this.snackbarModalComponent.onOpenSnackbarModal(false, "Add Order Items", '', '', '');
      return;
    }

    if (!changeFlag) {
      let patternValue = event?.target ? +event.target?.value : +event;
      let selectedPatternDetails = {};
      this.sampleOrderService.patternDetailsObj.subscribe((val: any) => {
        if (Object.keys(val).length > 0) {
          selectedPatternDetails = val;
        } else {
          selectedPatternDetails = {};
        }
      });

      if (Object.keys(selectedPatternDetails).length > 0 && event?.target) {
        this.selectedNewPattern = event.target?.value;
        this.isChangesInPattern = 'pattern';
        document.getElementById("alertModalBtn")?.click();
        return;
      }

      for (const element of this.patternsList) {
        if (+element.patternTypeId === +patternValue) {
          this.selectedPattern = element;
        }
      }
      if (
        this.selectedDressItem &&
        this.selectedMethod &&
        this.selectedPattern &&
        this.savedOrderItemsList.length > 0
      ) {
        this.isAddPatternDetails = true;
      } else {
        this.isAddPatternDetails = false;
      }
    }
  }

  /**
   * This method is used to open the add patterns modal
   */
  onClickAddPatterns() {
    if (this.selectedDressItem?.dressItemName == "T-Shirts") {
      this.tShirtsPatternComponent.openModal(this.selectedPattern, this.selectedDressItem);
    } else if (this.selectedDressItem?.dressItemName == "Pinofers") {
      this.pinofersComponent.openModal(this.selectedPattern, this.selectedDressItem);
    } else if (this.selectedDressItem?.dressItemName == "Middy") {
      this.middyPatternModalComponent.openModal(this.selectedPattern, this.selectedDressItem);
    } else if (this.selectedDressItem?.dressItemName == "Nicker") {
      this.nickersComponent.openModal(this.selectedPattern, this.selectedDressItem);
    } else if (this.selectedDressItem?.dressItemName == "Shots") {
      this.shortsComponent.openModal(this.selectedPattern, this.selectedDressItem);
    } else if (this.selectedDressItem?.dressItemName == "Pant") {
      this.pantComponent.openModal(this.selectedPattern, this.selectedDressItem);
    }
  }

  /**
   * This method is used to change the print type
   * @param {*} event
   */
  printTypeChange(event: any) {
    let printTypeValue = event?.target ? event.target.value : event;
    this.selectedPrintType = +printTypeValue;
  }

  /**
   * This method is used to change the cutting date
   * @param {*} event
   */
  onChangeCuttingDate(event: any) {
    this.minStitchingStartDate = event;
    const cuttingDateControl = this.editOrderFormControls['cuttingDateSelect'];

    const filmMakingDateControl = this.editOrderFormControls['filmMakingDateSelect'];
    const screenMakingDateControl = this.editOrderFormControls['screenMakingDateSelect'];
    const embroideryDateControl = this.editOrderFormControls['embroideryDateSelect'];
    const printingDateControl = this.editOrderFormControls['printingDateSelect'];
    const resizingOneSideDateControl = this.editOrderFormControls['resizingOneSideDateSelect'];
    const resizingBothSideDateControl = this.editOrderFormControls['resizingBothSideDateSelect'];
    const stitchingDateControl = this.editOrderFormControls['stitchingStartDateSelect'];

    const filmMakingDate: Date = filmMakingDateControl.value || '';
    const screenMakingDate: Date = screenMakingDateControl.value || '';
    const embroideryDate: Date = embroideryDateControl.value || '';
    const printingDate: Date = printingDateControl.value || '';
    const resizingOneSideDate: Date = resizingOneSideDateControl.value || '';
    const resizingBothSideDate: Date = resizingBothSideDateControl.value || '';
    const stitchingDate: Date = stitchingDateControl.value || '';

    /* Current Date */
    const currentDate: Date = new Date();
    currentDate.setHours(0, 0, 0, 0);

    /* Cutting Date */
    const cuttingDate: Date = new Date(cuttingDateControl.value);
    cuttingDate.setHours(0, 0, 0, 0);

    /* Film Making */
    if (this.IsFilmMakingOrderStatus) {
      const filmMakingDateInput: Date = new Date(filmMakingDate);
      filmMakingDateInput.setHours(0, 0, 0, 0);

      // Compare dates directly
      if (filmMakingDateInput < cuttingDate) {
        filmMakingDateControl.setValue('');
        filmMakingDateControl.markAsUntouched({ onlySelf: true });
      } else {
        filmMakingDateControl.setValue(filmMakingDateInput);
      }
    }

    /* Screen Making */
    if (this.IsScreenMakingOrderStatus) {
      const screenMakingDateInput: Date = new Date(screenMakingDate);
      screenMakingDateInput.setHours(0, 0, 0, 0);

      // Compare dates directly
      if (screenMakingDateInput < cuttingDate) {
        screenMakingDateControl.setValue('');
        screenMakingDateControl.markAsUntouched({ onlySelf: true });
      } else {
        screenMakingDateControl.setValue(screenMakingDateInput);
      }
    }

    /* Embroidery */
    if (this.IsEmbroideryOrderStatus) {
      const embroideryDateInput: Date = new Date(embroideryDate);
      embroideryDateInput.setHours(0, 0, 0, 0);

      // Compare dates directly
      if (embroideryDateInput < cuttingDate) {
        embroideryDateControl.setValue('');
        embroideryDateControl.markAsUntouched({ onlySelf: true });
      } else {
        embroideryDateControl.setValue(embroideryDateInput);
      }
    }

    /* Printing */
    if (this.IsPrintingOrderStatus) {
      const printingDateInput: Date = new Date(printingDate);
      printingDateInput.setHours(0, 0, 0, 0);

      // Compare dates directly
      if (printingDateInput < cuttingDate) {
        printingDateControl.setValue('');
        printingDateControl.markAsUntouched({ onlySelf: true });
      } else {
        printingDateControl.setValue(printingDateInput);
      }
    }

    /* ReSizing */
    if (this.IsReSizingOrderStatus) {
      const resizingOneSideDateInput: Date = new Date(resizingOneSideDate);
      resizingOneSideDateInput.setHours(0, 0, 0, 0);

      // Compare dates directly
      if (resizingOneSideDateInput < cuttingDate) {
        resizingOneSideDateControl.setValue('');
        resizingOneSideDateControl.markAsUntouched({ onlySelf: true });
      } else {
        resizingOneSideDateControl.setValue(resizingOneSideDateInput);
      }

      if (this.IsSublimationBothSide && resizingBothSideDate) {

        const resizingBothSideDateInput: Date = new Date(resizingBothSideDate);
        resizingBothSideDateInput.setHours(0, 0, 0, 0);

        // Compare dates directly
        if (resizingBothSideDateInput < cuttingDate) {
          resizingOneSideDateControl.setValue('');
          resizingOneSideDateControl.markAsUntouched({ onlySelf: true });
        } else {
          resizingOneSideDateControl.setValue(resizingBothSideDateInput);
        }

      }
    }

    /* Stitching */
    if (this.IsStitchingOrderStatus) {
      const stitchingDateInput: Date = new Date(stitchingDate);
      stitchingDateInput.setHours(0, 0, 0, 0);

      // Compare dates directly
      if (stitchingDateInput < cuttingDate) {
        stitchingDateControl.setValue('');
        stitchingDateControl.markAsUntouched({ onlySelf: true });
      } else {
        stitchingDateControl.setValue(stitchingDateInput);
      }
    }
  }

  /**
   * This method is used to compare the stitching dates to other dates
   * @param {*} dateControl
   * @param {Date} event
   * @param {string} errorMessage
   */
  onCompareDates(dateControl: any, event: any, errorMessage: string) {
    const stitchingDateControl = this.editOrderFormControls['stitchingStartDateSelect'];

    if (this.IsStitchingOrderStatus && stitchingDateControl.value !== '') {
      const currentDate: Date = new Date();
      const inputDate: Date = new Date(event);
      const controlDate: Date = new Date(stitchingDateControl.value);

      currentDate.setHours(0, 0, 0, 0);
      inputDate.setHours(0, 0, 0, 0);
      controlDate.setHours(0, 0, 0, 0);

      if (controlDate < inputDate) {
        dateControl.setValue('');
        dateControl.markAsUntouched({ onlySelf: true });
        this.snackbarModalComponent.onOpenSnackbarModal(false, errorMessage, '', '', '');
      }
    }
  }

  /**
   * This method is used to change the fusing date
   * @param {*} event
   */
  onChangeFusingDate(event: any) {
    this.onCompareDates(this.editOrderFormControls['filmMakingDateSelect'], event,
      'Fusing Date Should Not Be Greater than Stitching Date'
    );
  }

  /**
   * This method is used to change the film making date
   * @param {*} event
   */
  onChangeFilmMakingDate(event: any) {
    this.onCompareDates(this.editOrderFormControls['filmMakingDateSelect'], event,
      'Film Making Date Should Not Be Greater than Stitching Date'
    );
  }

  /**
   * This method is used to change the screen making date
   * @param {*} event
   */
  onChangeScreenMakingDate(event: any) {
    this.onCompareDates(this.editOrderFormControls['screenMakingDateSelect'], event,
      'Screen Making Date Should Not Be Greater than Stitching Date'
    );
  }

  /**
   * This method is used to change the embroidery date
   * @param {*} event
   */
  onChangeEmbroideryDate(event: any) {
    this.onCompareDates(this.editOrderFormControls['embroideryDateSelect'], event,
      'Embroidery Date Should Not Be Greater than Stitching Date'
    );
  }

  /**
   * This method is used to change the printing date
   * @param {*} event
   */
  onChangePrintingDate(event: any) {
    this.onCompareDates(this.editOrderFormControls['printingDateSelect'], event,
      'Printing Date Should Not Be Greater than Stitching Date'
    );
  }

  /**
   * This method is used to change the resizing one side date
   * @param {*} event
   */
  onChangeResizingOneSideDate(event: any) {
    this.onCompareDates(this.editOrderFormControls['resizingOneSideDateSelect'], event,
      'Resizing Date Should Not Be Greater than Stitching Date'
    );
  }

  /**
   * This method is used to change the resizing both date
   * @param {*} event
   */
  onChangeResizingBothSideDate(event: any) {
    this.onCompareDates(this.editOrderFormControls['resizingBothSideDateSelect'], event,
      'Resizing Date Should Not Be Greater than Stitching Date'
    );
  }

  /**
   * This method is used to change the stitching date
   * @param {*} event
   */
  onChangeStitchingDate(event: any) {
    this.stitchingStartDate = event;
    const dispatchDateControl = this.editOrderFormControls['dispatchDate'];
    const currentDate: Date = new Date();
    const inputDate: Date = new Date(event);
    const dispatchDate: Date = new Date(dispatchDateControl.value ?? '');

    currentDate.setHours(0, 0, 0, 0);
    inputDate.setHours(0, 0, 0, 0);
    dispatchDate.setHours(0, 0, 0, 0);

    if (dispatchDate < inputDate) {
      dispatchDateControl.setValue('');
      dispatchDateControl.markAsUntouched({ onlySelf: true });
    }

    /* Film Making */
    if (this.IsFilmMakingOrderStatus && this.editOrderFormControls['filmMakingDateSelect'].value != '') {
      const filmMakingDateControl = this.editOrderFormControls['filmMakingDateSelect'];
      const controlDate: Date = new Date(filmMakingDateControl.value ?? '');
      controlDate.setHours(0, 0, 0, 0);

      if (inputDate < controlDate) {
        filmMakingDateControl.setValue('');
        filmMakingDateControl.markAsUntouched({ onlySelf: true });
      }
    }

    /* Screen Making */
    if (this.IsScreenMakingOrderStatus && this.editOrderFormControls['screenMakingDateSelect'].value != '') {
      const screenMakingDateControl = this.editOrderFormControls['screenMakingDateSelect'];
      const controlDate: Date = new Date(screenMakingDateControl.value ?? '');
      controlDate.setHours(0, 0, 0, 0);

      if (inputDate < controlDate) {
        screenMakingDateControl.setValue('');
        screenMakingDateControl.markAsUntouched({ onlySelf: true });
      }
    }

    /* Embroidery */
    if (this.IsEmbroideryOrderStatus && this.editOrderFormControls['embroideryDateSelect'].value != '') {
      const embroideryDateControl = this.editOrderFormControls['embroideryDateSelect'];
      const controlDate: Date = new Date(embroideryDateControl.value ?? '');
      controlDate.setHours(0, 0, 0, 0);

      if (inputDate < controlDate) {
        embroideryDateControl.setValue('');
        embroideryDateControl.markAsUntouched({ onlySelf: true });
      }
    }

    /* Printing */
    if (this.IsPrintingOrderStatus && this.editOrderFormControls['printingDateSelect'].value != '') {
      const printingDateControl = this.editOrderFormControls['printingDateSelect'];
      const controlDate: Date = new Date(printingDateControl.value ?? '');
      controlDate.setHours(0, 0, 0, 0);

      if (inputDate < controlDate) {
        printingDateControl.setValue('');
        printingDateControl.markAsUntouched({ onlySelf: true });
      }
    }

    /* Knitting */
    if (this.IsKnittingOrderStatus && this.editOrderFormControls['knittingDateSelect'].value != '') {
      const knittingDateControl = this.editOrderFormControls['knittingDateSelect'];
      const controlDate: Date = new Date(knittingDateControl.value ?? '');
      controlDate.setHours(0, 0, 0, 0);

      if (controlDate < inputDate) {
        knittingDateControl.setValue('');
        knittingDateControl.markAsUntouched({ onlySelf: true });
      }
    }

    /* Steam Ironing */
    if (this.IsSteamIronOrderStatus && this.editOrderFormControls['steamIronDateSelect'].value != '') {
      const steamIroningDateControl = this.editOrderFormControls['steamIronDateSelect'];
      const controlDate: Date = new Date(steamIroningDateControl.value ?? '');
      controlDate.setHours(0, 0, 0, 0);

      console.log(controlDate);
      console.log(inputDate);


      if (controlDate < inputDate) {
        steamIroningDateControl.setValue('');
        steamIroningDateControl.markAsUntouched({ onlySelf: true });
      }
    }
  }


  /**
   * This method will fired when user selects the order status
   * @param {*} event
   */
  onChangeOrderStatus(event: any) {
    let orderStatusValue = event?.target ? +event.target?.value : +event;
    for (const element of this.orderStatusList) {
      if (+element.orderStatusId === +orderStatusValue) {
        this.selectedOrderStatus = element;
      }
    }

    let cuttingValue = this.editOrderDetails?.cuttingDCDetails?.unitName;
    let fusingValue = this.editOrderDetails?.fusingDCDetails?.unitName;
    let filmMakingValue = this.editOrderDetails?.filmMakingDCDetails?.unitName;
    let screenMakingValue = this.editOrderDetails?.screenMakingDCDetails?.unitName;
    let embroideryValue = this.editOrderDetails?.embroideryDCDetails?.unitName;
    let printingValue = this.editOrderDetails?.printingDCDetails?.unitName;
    let resizingValue = this.editOrderDetails?.resizingDCDetails[0]?.unitName;
    let stitchingValue = this.editOrderDetails?.stichingDCDetails?.unitName;
    let knittingValue = this.editOrderDetails?.knittingDCDetails?.unitName;
    let steamIronValue = this.editOrderDetails?.steamIronDCDetails?.unitName;
    let dispatchValue = this.editOrderDetails?.order?.lrNumber;

    const statusFlags: any = {
      3: {
        cutting: true, fusing: !!fusingValue, filmMaking: !!filmMakingValue, screenMaking: !!screenMakingValue,
        embroidery: !!embroideryValue, printing: !!printingValue, resizing: !!resizingValue, stitching: !!stitchingValue,
        knitting: !!knittingValue, steamIron: !!steamIronValue, dispatched: !!dispatchValue
      },
      4: {
        cutting: !!cuttingValue, fusing: true, filmMaking: !!filmMakingValue, screenMaking: !!screenMakingValue,
        embroidery: !!embroideryValue, printing: !!printingValue, resizing: !!resizingValue, stitching: !!stitchingValue,
        knitting: !!knittingValue, steamIron: !!steamIronValue, dispatched: !!dispatchValue
      },
      5: {
        cutting: !!cuttingValue, fusing: !!fusingValue, filmMaking: true, screenMaking: !!screenMakingValue,
        embroidery: !!embroideryValue, printing: !!printingValue, resizing: !!resizingValue, stitching: !!stitchingValue,
        knitting: !!knittingValue, steamIron: !!steamIronValue, dispatched: !!dispatchValue
      },
      6: {
        cutting: !!cuttingValue, fusing: !!fusingValue, filmMaking: !!filmMakingValue, screenMaking: true, embroidery: !!embroideryValue,
        printing: !!printingValue, resizing: !!resizingValue, stitching: !!stitchingValue, knitting: !!knittingValue,
        steamIron: !!steamIronValue, dispatched: !!dispatchValue
      },
      7: {
        cutting: !!cuttingValue, fusing: !!fusingValue, filmMaking: !!filmMakingValue, screenMaking: !!screenMakingValue,
        embroidery: true, printing: !!printingValue, resizing: !!resizingValue, stitching: !!stitchingValue, knitting: !!knittingValue,
        steamIron: !!steamIronValue, dispatched: !!dispatchValue
      },
      8: {
        cutting: !!cuttingValue, fusing: !!fusingValue, filmMaking: !!filmMakingValue, screenMaking: !!screenMakingValue,
        embroidery: !!embroideryValue, printing: true, resizing: !!resizingValue, stitching: !!stitchingValue, knitting: !!knittingValue,
        steamIron: !!steamIronValue, dispatched: !!dispatchValue
      },
      9: {
        cutting: !!cuttingValue, fusing: !!fusingValue, filmMaking: !!filmMakingValue, screenMaking: !!screenMakingValue,
        embroidery: !!embroideryValue, printing: !!printingValue, resizing: true, stitching: !!stitchingValue, knitting: !!knittingValue,
        steamIron: !!steamIronValue, dispatched: !!dispatchValue
      },
      10: {
        cutting: !!cuttingValue, fusing: !!fusingValue, filmMaking: !!filmMakingValue, screenMaking: !!screenMakingValue,
        embroidery: !!embroideryValue, printing: !!printingValue, resizing: !!resizingValue, stitching: true, knitting: !!knittingValue,
        steamIron: !!steamIronValue, dispatched: !!dispatchValue
      },
      11: {
        cutting: !!cuttingValue, fusing: !!fusingValue, filmMaking: !!filmMakingValue, screenMaking: !!screenMakingValue,
        embroidery: !!embroideryValue, printing: !!printingValue, resizing: !!resizingValue, stitching: !!stitchingValue,
        knitting: true, steamIron: !!steamIronValue, dispatched: !!dispatchValue
      },
      12: {
        cutting: !!cuttingValue, fusing: !!fusingValue, filmMaking: !!filmMakingValue, screenMaking: !!screenMakingValue,
        embroidery: !!embroideryValue, printing: !!printingValue, resizing: !!resizingValue, stitching: !!stitchingValue,
        knitting: !!knittingValue, steamIron: true, dispatched: !!dispatchValue
      },
      13: {
        cutting: !!cuttingValue, fusing: !!fusingValue, filmMaking: !!filmMakingValue, screenMaking: !!screenMakingValue,
        embroidery: !!embroideryValue, printing: !!printingValue, resizing: !!resizingValue, stitching: !!stitchingValue,
        knitting: !!knittingValue, steamIron: !!steamIronValue, dispatched: true
      }
    };

    const flags = statusFlags[this.selectedOrderStatus?.orderStatusId];
    const values = {
      cutting: cuttingValue, fusing: fusingValue, filmMaking: filmMakingValue, screenMaking: screenMakingValue,
      embroidery: embroideryValue, printing: printingValue, resizing: resizingValue, stitching: stitchingValue,
      knitting: knittingValue, steamIron: steamIronValue, dispatched: dispatchValue
    }
    this.onManageOrderStatusFields(flags, values, event);
  }

  /**
   * This method is used to manage the order status fields based on order status id
   * @param {*} flags
   * @param {*} values
   */
  onManageOrderStatusFields(flags: any, values: any, event: any) {
    this.IsCuttingOrderStatus = flags?.cutting || false;
    this.IsFusingOrderStatus = flags?.fusing || false;
    this.IsFilmMakingOrderStatus = flags?.filmMaking || false;
    this.IsScreenMakingOrderStatus = flags?.screenMaking || false;
    this.IsEmbroideryOrderStatus = flags?.embroidery || false;
    this.IsPrintingOrderStatus = flags?.printing || false;
    this.IsReSizingOrderStatus = flags?.resizing || false;
    this.IsStitchingOrderStatus = flags?.stitching || false;
    this.IsKnittingOrderStatus = flags?.knitting || false;
    this.IsSteamIronOrderStatus = flags?.steamIron || false;
    this.IsDispatchedOrderStatus = flags?.dispatched || false;

    if (
      (
        this.IsPrintingOrderStatus || this.IsFusingOrderStatus || this.IsFilmMakingOrderStatus || this.IsScreenMakingOrderStatus ||
        this.IsEmbroideryOrderStatus || this.IsReSizingOrderStatus || this.IsSteamIronOrderStatus || this.IsStitchingOrderStatus ||
        this.IsKnittingOrderStatus || this.IsDispatchedOrderStatus
      ) && !this.IsCuttingOrderStatus
    ) {
      this.IsPrintingOrderStatus = false;
      this.IsFusingOrderStatus = false;
      this.IsFilmMakingOrderStatus = false;
      this.IsScreenMakingOrderStatus = false;
      this.IsEmbroideryOrderStatus = false;
      this.IsSteamIronOrderStatus = false;
      this.IsKnittingOrderStatus = false;
      this.IsReSizingOrderStatus = false;
      this.IsStitchingOrderStatus = false;
      this.IsDispatchedOrderStatus = false;
      this.onSetValueAndShowSnackbar("Please Enter Cutting Details");
    } else if (this.editOrderDetails?.specialModelForTShirt?.sublimationId && !this.IsReSizingOrderStatus &&
      (this.IsStitchingOrderStatus || this.IsKnittingOrderStatus || this.IsSteamIronOrderStatus || this.IsDispatchedOrderStatus)) {
      this.IsStitchingOrderStatus = false;
      this.IsKnittingOrderStatus = false;
      this.IsSteamIronOrderStatus = false;
      this.IsDispatchedOrderStatus = false;
      this.onSetValueAndShowSnackbar("Please Enter Resizing Details");
    }
    else if (this.IsReSizingOrderStatus && this.IsSublimationBothSide && this.editOrderDetails?.resizingDCDetails.length == 2 &&
      !this.editOrderDetails?.resizingDCDetails[1]?.dcNo &&
      (this.IsStitchingOrderStatus || this.IsKnittingOrderStatus || this.IsSteamIronOrderStatus || this.IsDispatchedOrderStatus)) {
      this.IsStitchingOrderStatus = false;
      this.IsKnittingOrderStatus = false;
      this.IsSteamIronOrderStatus = false;
      this.IsDispatchedOrderStatus = false;
      this.onSetValueAndShowSnackbar("Please Enter All Resizing Details");
    } else if (
      (this.IsKnittingOrderStatus || this.IsSteamIronOrderStatus || this.IsDispatchedOrderStatus)
      && !this.IsStitchingOrderStatus
    ) {
      this.IsKnittingOrderStatus = false;
      this.IsSteamIronOrderStatus = false;
      this.IsDispatchedOrderStatus = false;
      this.onSetValueAndShowSnackbar("Please Enter Stitching Details");
    }

    if (this.selectedOrderStatus?.orderStatusId >= 2 && this.selectedOrderStatus?.orderStatusId != 14) {
      this.IsCPGeneratedOrderStatus = true;
      this.onAddValidators(this.editOrderFormControls, ['incharge', 'inchargeDate']);
    } else {
      this.IsCPGeneratedOrderStatus = false;
      this.onRemoveValidators(this.editOrderFormControls, ['incharge', 'inchargeDate']);
    }

    /* Get Cutting Unit Names */
    if (this.selectedOrderStatus?.orderStatusId >= 3 && !this.editOrderDetails?.order?.paymentReceivedDate) {
      this.getCuttingUnitNamesList(3, 'noEvent');
    }
    /* Get Fusing Unit Names */
    if (this.selectedOrderStatus?.orderStatusId >= 4 && !this.editOrderDetails?.order?.paymentReceivedDate) {
      this.getFusingUnitNamesList(4, 'noEvent');
    }
    /* Get Film Making Unit Names */
    if (this.selectedOrderStatus?.orderStatusId >= 5 && !this.editOrderDetails?.order?.paymentReceivedDate) {
      this.getFilmMakingUnitNamesList(5, 'noEvent');
    }
    /* Get Screen Making Unit Names */
    if (this.selectedOrderStatus?.orderStatusId >= 6 && !this.editOrderDetails?.order?.paymentReceivedDate) {
      this.getScreenMakingUnitNamesList(6, 'noEvent');
    }
    /* Get Embroidery Unit Names */
    if (this.selectedOrderStatus?.orderStatusId >= 7 && !this.editOrderDetails?.order?.paymentReceivedDate) {
      this.getEmbroideryUnitNamesList(7, 'noEvent');
    }
    /* Get Printing Unit Names */
    if (this.selectedOrderStatus?.orderStatusId >= 8 && !this.editOrderDetails?.order?.paymentReceivedDate) {
      this.getPrintingUnitNamesList(8, 'noEvent');
    }
    /* Get Resizing Unit Names */
    if (this.selectedOrderStatus?.orderStatusId >= 9 && !this.editOrderDetails?.order?.paymentReceivedDate) {
      this.getResizingUnitNamesList(9, 'noEvent');
      this.getResizingPrintingUnitNamesList('noEvent');
    }
    /* Get Stitching Unit Names */
    if (this.selectedOrderStatus?.orderStatusId >= 10 && !this.editOrderDetails?.order?.paymentReceivedDate) {
      this.getStitchingUnitNamesList(10, 'noEvent');
    }
    /* Get Knitting Unit Names */
    if (this.selectedOrderStatus?.orderStatusId >= 11 && !this.editOrderDetails?.order?.paymentReceivedDate) {
      this.getKnittingUnitNamesList(11, 'noEvent');
    }
    /* Get Steam Iron Unit Names */
    if (this.selectedOrderStatus?.orderStatusId >= 12 && !this.editOrderDetails?.order?.paymentReceivedDate) {
      this.getSteamIronUnitNamesList(12, 'noEvent');
    }

    // if (this.selectedOrderStatus?.orderStatusId != 13 && this.selectedOrderStatus?.orderStatusId != 2 && this.selectedOrderStatus?.orderStatusId != 10) {
    //   this.getUnitNamesList(this.selectedOrderStatus?.orderStatusId, 'noEvent');
    // }

    // if (this.selectedOrderStatus?.orderStatusId >= 9) {
    //   this.getResizingPrintingUnitNamesList('noEvent');
    // }
    const allowedStatusIds = [5, 6, 7, 8];
    if (allowedStatusIds.includes(this.selectedOrderStatus?.orderStatusId)) {
      if (event?.target) {
        this.getPrintTypesList(this.selectedOrderStatus?.orderStatusId, '');
      } else {
        this.getPrintTypesList(this.selectedOrderStatus?.orderStatusId, 'noEvent');
      }
    }

    const valueControlPairs = [
      {
        flag: this.IsCuttingOrderStatus, value: values?.cutting, controls:
          ['cuttingDCNo', 'cuttingQuantity', 'cuttingUnitName', 'cuttingDateSelect']
      },
      {
        flag: this.IsFusingOrderStatus, value: values?.fusing, controls:
          ['fusingDCNo', 'fusingType', 'fusingQuantity', 'fusingUnitName', 'fusingDateSelect']
      },
      {
        flag: this.IsFilmMakingOrderStatus, value: values?.filmMaking, controls:
          ['filmMakingType', 'filmMakingDCNo', 'filmMakingQuantity', 'filmMakingUnitName', 'filmMakingDateSelect']
      },
      {
        flag: this.IsScreenMakingOrderStatus, value: values?.screenMaking, controls:
          ['screenMakingType', 'screenMakingDCNo', 'screenMakingQuantity', 'screenMakingUnitName', 'screenMakingDateSelect']
      },
      {
        flag: this.IsEmbroideryOrderStatus, value: values?.embroidery, controls:
          ['embroideryType', 'embroideryDCNo', 'embroideryQuantity', 'embroideryUnitName', 'embroideryDateSelect']
      },
      {
        flag: this.IsPrintingOrderStatus, value: values?.printing, controls:
          ['printingType', 'printingDCNo', 'printingQuantity', 'printingUnitName', 'printingDateSelect']
      },
      {
        flag: this.IsReSizingOrderStatus, value: values?.resizing, controls:
          [
            'resizingOneSideDCNo', 'resizingOneSideQuantity', 'resizingOneSideUnitName', 'resizingOneSideDateSelect',
            'resizingOneSidePrintingName', 'resizingOneSideCharge',
            'resizingBothSideDCNo', 'resizingBothSideQuantity', 'resizingBothSideUnitName', 'resizingBothSideDateSelect',
            'resizingBothSidePrintingName', 'resizingBothSideCharge'
          ]
      },
      {
        flag: this.IsStitchingOrderStatus, value: values?.stitching, controls:
          ['stitchingDCNo', 'stitchingQuantity', 'stitchingUnitName', 'stitchingStartDateSelect']
      },
      {
        flag: this.IsKnittingOrderStatus, value: values?.knitting, controls:
          ['knittingDCNo', 'knittingQuantity', 'knittingUnitName', 'knittingDateSelect', 'knittingCollarType']
      },
      {
        flag: this.IsSteamIronOrderStatus, value: values?.steamIron, controls:
          ['steamIronDCNo', 'steamIronQuantity', 'steamIronUnitName', 'steamIronDateSelect', 'steamIronAgeGroup']
      },
      {
        flag: this.IsDispatchedOrderStatus, value: values?.dispatched, controls:
          ['lrDetails', 'dispatchDate', 'transport']
      }
    ];

    const disablePairs: any = [];
    valueControlPairs.forEach((pair: any) => {
      if (!pair.value) {
        if (pair.flag) {
          this.onAddValidators(this.editOrderFormControls, pair.controls);
          this.onUpdateValueAndValidity(this.editOrderFormControls, pair.controls);
          if (this.IsStitchingOrderStatus && this.editOrderDetails?.stichingDCDetails?.dcNo) {
            this.editOrderFormControls['stitchingDCNo'].setValue(this.editOrderDetails?.stichingDCDetails?.dcNo);
          }
          if (this.IsKnittingOrderStatus && this.editOrderDetails?.knittingDCDetails?.dcNo) {
            this.editOrderFormControls['knittingDCNo'].setValue(this.editOrderDetails?.knittingDCDetails?.dcNo);
          }
          if (this.IsReSizingOrderStatus) {
            if (this.editOrderDetails?.resizingDCDetails[0]?.charge) {
              this.editOrderFormControls['resizingOneSideCharge'].setValue(this.editOrderDetails?.resizingDCDetails[0]?.charge);
            }
            if (this.editOrderDetails?.resizingDCDetails[1]?.charge) {
              this.editOrderFormControls['resizingBothSideCharge'].setValue(this.editOrderDetails?.resizingDCDetails[1]?.charge);
            }
          }
          pair.controls.forEach((control: any) => {
            if (control.includes('Quantity')) {
              this.editOrderFormControls[control].setValue(this.totalQuantity);
            }
          });
          this.editOrderFormControls['stitchingQuantity'].setValue(this.editOrderDetails?.stichingDCDetails?.quantity);
          this.editOrderFormControls['filmMakingQuantity'].setValue(this.editOrderDetails?.filmMakingDCDetails?.quantity || '');
          this.editOrderFormControls['screenMakingQuantity'].setValue(this.editOrderDetails?.screenMakingDCDetails?.quantity || '');
        } else {
          this.onRemoveValidatorsAndUpdateControls(this.editOrderFormControls, pair.controls);
        }
      }
      if (pair.flag && pair.value) {
        disablePairs.push(pair);
      }
    });

    if (!this.IsDispatchedOrderStatus) {
      this.onRemoveValidatorsAndUpdateControls(this.editOrderFormControls, ['paymentDate']);
    }

    if (disablePairs.length > 0) {
      for (const element of disablePairs) {
        element.controls.forEach((control: any) => {
          this.editOrderFormControls[control].disable({ onlySelf: true });
          if (localStorage.getItem('userTypeId') == '1' &&
            (this.IsKnittingOrderStatus || this.IsSteamIronOrderStatus ||
              (this.IsDispatchedOrderStatus && !this.editOrderDetails?.order?.lrNumber)
            )
          ) {
            this.editOrderFormControls['stitchingUnitName'].enable({ onlySelf: true });
            this.editOrderFormControls['stitchingStartDateSelect'].enable({ onlySelf: true });
          }

          if (!this.editOrderDetails?.order?.paymentReceivedDate) {
            if (control.includes('UnitName')) {
              this.editOrderFormControls[control].enable({ onlySelf: true });
            }
            if (control.includes('DateSelect')) {
              this.editOrderFormControls[control].enable({ onlySelf: true });
            }
          }
        });
        // if (this.editOrderDetails?.stichingDCDetails?.endDate && 
        // (this.IsKnittingOrderStatus || this.IsSteamIronOrderStatus || this.IsDispatchedOrderStatus)
        // ) {
        //   this.editOrderFormControls['stitchingEndDateSelect'].disable({ onlySelf: true });
        // }
      }
      disablePairs[disablePairs.length - 1].controls?.forEach((control: any) => {
        this.editOrderFormControls[control].enable({ onlySelf: true });
        if (this.IsStitchingOrderStatus) {
          this.editOrderFormControls['stitchingDCNo'].disable({ onlySelf: true });
          this.editOrderFormControls['stitchingQuantity'].disable({ onlySelf: true });
        }
        if (this.IsKnittingOrderStatus) {
          this.editOrderFormControls['knittingDCNo'].disable({ onlySelf: true });
        }
        if (this.IsReSizingOrderStatus) {
          this.editOrderFormControls['resizingOneSideCharge'].disable({ onlySelf: true });
          this.editOrderFormControls['resizingBothSideCharge'].disable({ onlySelf: true });
        }
      });
    }

    if (this.IsReSizingOrderStatus && this.IsSublimationBothSide &&
      (this.IsStitchingOrderStatus || this.IsKnittingOrderStatus || this.IsDispatchedOrderStatus)
    ) {
      if (this.editOrderDetails?.resizingDCDetails.length == 1 && !this.editOrderDetails?.resizingDCDetails[1].unitName) {
        this.onAddValidators(this.editOrderFormControls, ['resizingBothSideDCNo', 'resizingBothSideQuantity', 'resizingBothSideUnitName',
          'resizingBothSideDateSelect', 'resizingBothSidePrintingName', 'resizingBothSideCharge']);
        this.editOrderFormControls['resizingBothSideQuantity'].setValue(this.totalQuantity);
      }
    } else {
      if (this.editOrderDetails?.resizingDCDetails[1] && !this.editOrderDetails?.resizingDCDetails[1].unitName) {
        this.onRemoveValidatorsAndUpdateControls(this.editOrderFormControls, ['resizingBothSideDCNo', 'resizingBothSideQuantity', 'resizingBothSideUnitName',
          'resizingBothSideDateSelect', 'resizingBothSidePrintingName', 'resizingBothSideCharge']);
      } else {
        this.onRemoveValidators(this.editOrderFormControls, ['resizingBothSideDCNo', 'resizingBothSideQuantity', 'resizingBothSideUnitName',
          'resizingBothSideDateSelect', 'resizingBothSidePrintingName', 'resizingBothSideCharge']);
      }
      this.editOrderFormControls['resizingBothSideQuantity'].setValue(this.totalQuantity);
      this.editOrderFormControls['resizingBothSideCharge'].setValue(this.editOrderDetails?.resizingDCDetails[1]?.charge);
    }

    // if (this.IsDispatchedOrderStatus && values?.stitching) {
    //   this.onAddValidators(this.editOrderFormControls, ['stitchingEndDateSelect']);
    // } else if (!this.editOrderDetails?.stichingDCDetails?.endDate) {
    //   this.onRemoveValidatorsAndUpdateControls(this.editOrderFormControls, ['stitchingEndDateSelect']);
    // }
  }

  /**
   * This method is used to set the order status value and show snackbar
   * @param {string} message
   */
  onSetValueAndShowSnackbar(message: string) {
    for (const element of this.orderStatusList) {
      if (+element.orderStatusId === +this.selectedPreviousOrderStatus) {
        this.selectedOrderStatus = element;
      }
    }
    this.editOrderFormControls['orderStatus'].setValue(this.selectedOrderStatus?.orderStatusId?.toString());
    this.snackbarModalComponent.onOpenSnackbarModal(false, message, '', '', '');
  }

  /**
   * This method will fired when user selects the payment
   * @param {*} event
   */
  onChangePaymentMode(event: any) {
    let paymentModeValue = event?.target ? +event.target?.value : +event;
    for (const element of this.paymentModesList) {
      if (+element.id === +paymentModeValue) {
        this.selectedPaymentMode = element;
      }
    }
  }

  /**
   * This method is used to change the school type radio
   * @param {*} event
   */
  onChangeSchoolType(event: any) {
    let schoolTypeValue = event?.target ? +event.target?.value : +event;
    this.selectedSchoolType = +schoolTypeValue;
  }

  /**
   * This method is used to change the staff select
   * @param {*} event
   */
  onChangeStaff(event: any) {
    let staffValue = event?.target ? +event.target?.value : +event;
    for (const element of this.staffList) {
      if (+element.staffId === +staffValue) {
        this.selectedStaff = element;
      }
    }
  }

  /**
   * This method is used to change the transport select
   * @param {*} event
   */
  onChangeTransport(event: any) {
    let transportValue = event?.target ? +event.target?.value : +event;
    for (const element of this.transportList) {
      if (+element.transportId === +transportValue) {
        this.selectedTransport = element;
      }
    }
  }

  /**
   * This method is used to change the incharge select
   * @param {*} event
   */
  onChangeIncharge(event: any) {
    let inchargeValue = event?.target ? +event.target?.value : +event;
    for (const element of this.inchargeList) {
      if (+element.staffId === +inchargeValue) {
        this.selectedIncharge = element;
      }
    }
  }

  /**
   * This method is used to change the Order received radio
   * @param {*} event
   */
  onChangeOrderReceived(event: any) {
    let orderReceivedValue = event?.target ? event.target?.value : event;
    this.selectedOrderReceived = +orderReceivedValue;
    if (this.selectedOrderReceived === 1) {
      this.isAgent = true;
      this.onAddValidators(this.editOrderFormControls, ['commission', 'agent']);
      if (event?.target) {
        this.getAgentsList("");
      } else {
        this.getAgentsList("noEvent");
      }
    } else {
      this.isAgent = false;
      this.onRemoveValidators(this.editOrderFormControls, ['commission', 'agent']);
    }
    if (event?.target) {
      this.onUpdateValueAndValidity(this.editOrderFormControls, ['agent']);
      this.selectedAgent = '';
      this.onChangeAgentType(1);
      this.editOrderFormControls['agentType'].setValue('1');
    } else {
      if (this.isAgent) {
        let agentTypeValue = this.editOrderDetails?.order?.agentThroughId;
        this.onChangeAgentType(agentTypeValue);
        this.editOrderFormControls['agentType'].setValue(agentTypeValue?.toString());
      }
    }
  }

  /**
   * This method is used to change the Agent select
   * @param {*} event
   */
  onChangeAgent(event: any) {
    let agentValue = event?.target ? +event.target?.value : +event;
    for (const element of this.agentsList) {
      if (+element.agentId === +agentValue) {
        this.selectedAgent = element;
      }
    }
  }

  /**
   * This method is used to change the commission
   * @param {*} event
   */
  onChangeCommission(event: any) {
    let commissionValue = event?.target ? +event.target?.value : +event;
    this.editOrderFormControls['agentCommission'].setValue(+commissionValue * this.totalQuantity);
  }

  /**
   * This method is used to change the Payment received radio
   * @param {*} event
   */
  onChangePaymentReceived(event: any) {
    let paymentReceivedValue = event?.target ? event.target?.value : event;
    this.selectedPaymentReceived = +paymentReceivedValue;
    if (this.selectedPaymentReceived === 1) {
      this.isPaymentReceived = true;
      this.onAddValidators(this.editOrderFormControls, ['paymentDate']);
    } else {
      this.isPaymentReceived = false;
      this.onRemoveValidators(this.editOrderFormControls, ['paymentDate']);
    }
    if (event?.target) {
      this.onUpdateValueAndValidity(this.editOrderFormControls, ['paymentDate']);
    }
  }

  /**
   * This method is used to change the Approved radio
   * @param {*} event
   */
  onChangeApprovedRadio(event: any) {
    let approvedValue = event?.target ? event.target?.value : event;
    this.selectedApproved = +approvedValue;
  }

  /**
   * This method is used to change the Agent type radio
   * @param {*} event
   */
  onChangeAgentType(event: any) {
    let agentTypeValue = event?.target ? event.target?.value : event;
    this.selectedAgentType = +agentTypeValue;
    if (this.selectedAgentType === 2) {
      this.isThroughAgent = true;
    } else {
      this.isThroughAgent = false;
    }
  }

  /**
   * This method is used to change the calculate Points radio
   * @param {*} event
   */
  onChangeCalculatePoints(event: any) {
    let calculatePointsValue = event?.target ? +event.target?.value : +event;
    this.selectedCalculatePoints = +calculatePointsValue;
  }

  /**
   * This method is used to change the unit points
   * @param {*} event
   */
  onChangeUnitPoints(event: any) {
    let unitPointsValue = event?.target ? +event.target?.value : +event;
    this.editOrderFormControls['points'].setValue(+unitPointsValue * this.totalQuantity);
  }

  /**
   * This method will fired when user selects the diagram
   * @param {*} event
   */
  diagramChange(event: any) {
    let diagramValue = event?.target ? event.target.value : event;
    for (const element of this.diagramList) {
      if (+element.id === +diagramValue) {
        this.selectedDiagram = element;
      }
    }

    /* Assign diagram URL based on selected diagram */
    if (this.selectedDiagram?.id === 1) {
      this.diagramURL = '../../../../../assets/Images/1.jpg';
    } else if (this.selectedDiagram?.id === 2) {
      this.diagramURL = '../../../../../assets/Images/2.jpg';
    } else if (this.selectedDiagram?.id === 3) {
      this.diagramURL = '../../../../../assets/Images/3.jpg';
    } else if (this.selectedDiagram?.id === 4) {
      this.diagramURL = '../../../../../assets/Images/4.jpg';
    } else if (this.selectedDiagram?.id === 5) {
      this.diagramURL = '../../../../../assets/Images/5.jpg';
    } else if (this.selectedDiagram?.id === 6) {
      this.diagramURL = '../../../../../assets/Images/6.jpg';
    } else {
      this.diagramURL = '';
    }
  }

  /**
   * This method is used to open the add order modal
   */
  onClickOpenAddOrderModal() {
    this.getColoursList();
    this.getSizesList('');
    document.getElementById("addOrderItemModal")?.click();
    this.isSaveOrder = false;
    if (JSON.parse(localStorage.getItem("savedOrdersList")!)) {
      this.orderItemsList = JSON.parse(localStorage.getItem("savedOrdersList")!);
    } else {
      this.orderItemsList = [];
    }
    const modal = document.getElementById("addOrderDetailsForm") as HTMLElement;
    const snackbar = document.getElementById("snackbar") as HTMLElement;
    modal.style.display = "block";
    snackbar.style.zIndex = "9999";
  }

  /**
    * This method is used to get the unique sizes for the table
    * @return {*}  {string[]}
    */
  getUniqueSizes(): string[] {
    return Array.from(new Set(this.savedOrderItemsList.map(item => item.size)));
  }

  /**
   * This method is used to get the unique colors for the table
   * @return {*}  {string[]}
   */
  getUniqueColors(): string[] {
    return Array.from(new Set(this.savedOrderItemsList.map(item => item.colourName)));
  }

  /**
   * This method is used to get the quantity for the table
   * @param {string} color
   * @param {string} size
   * @return {*}  {number}
   */
  getQuantity(color: string, size: string): number {
    const item = this.savedOrderItemsList.find(item => item.colourName === color && item.size === size);
    return item ? parseInt(item.quantity?.toString(), 10) : 0;
  }

  /**
   * This method is used to get the row total for the table
   * @param {string} color
   * @return {*}  {number}
   */
  getRowTotal(color: string): number {
    return this.getUniqueSizes().reduce((total: any, size: any) => total + this.getQuantity(color, size), 0);
  }

  /**
   * This method is used to get the column total for the table
   * @param {string} size
   * @return {*}  {number}
   */
  getColumnTotal(size: string): number {
    return this.getUniqueColors().reduce((total: any, color: any) => total + this.getQuantity(color, size), 0);
  }

  /**
   * This method is used to get the grand total for the table
   * @return {*}  {number}
   */
  getGrandTotal(): number {
    return this.getUniqueSizes().reduce((total, size) => total + this.getColumnTotal(size), 0);
  }

  /**
   * This method is used to get the orders total quantity
   * @return {*}  {number}
   */
  getTotalQuantity(): number {
    let orderTotalQuantity = 0;
    for (const order of this.orderItemsList) {
      orderTotalQuantity += order.quantity;
    }
    this.totalQuantity = orderTotalQuantity;
    return orderTotalQuantity;
  }

  /**
   * This method is used to get the saved orders total quantity
   * @return {*}  {number}
   */
  getSavedTotalQuantity(): number {
    let orderTotalQuantity = 0;
    for (const order of this.savedOrderItemsList) {
      if (order && order.quantity) {
        orderTotalQuantity += order.quantity;
      }
    }
    this.totalQuantity = orderTotalQuantity;
    return orderTotalQuantity;
  }

  /**
   * This method is used to change the colour
   * @param {*} event
   */
  onChangeColour(event: any) {
    if (event?.target.value == '') {
      this.addOrderFormControls['colorSelect'].markAsUntouched({ onlySelf: true });
    }
  }

  /**
   * This method is used to change the size
   * @param {*} event
   */
  onChangeSize(event: any) {
    if (event?.target.value == '') {
      this.addOrderFormControls['sizeSelect'].markAsUntouched({ onlySelf: true });
    }
  }


  /**
   * This method is used to add the order items
   */
  onClickAdd() {
    document.getElementById('quantity')?.blur();
    document.getElementById('unitPrice')?.blur();
    if (this.addOrderForm.invalid) {
      this.validationService.validateAllFormFields(this.addOrderForm);
      return;
    }

    let errorMessage = '';
    if (+this.addOrderFormControls["quantity"].value > 5000) {
      errorMessage = 'Quantity should not exceed 5000';
    }

    if (+this.addOrderFormControls["unitPrice"].value > 999) {
      errorMessage = 'Unit Price should not exceed 999';
    }

    /* Get Selected Colour */
    const selectedColour = this.coloursList.filter((item: any) => (+item.colourId) === (+this.addOrderFormControls['colorSelect'].value));

    /* Get Selected Size */
    const selectedSize = this.sizesList.filter((item: any) => (+item.sizeId) === (+this.addOrderFormControls['sizeSelect'].value));

    for (let index = 0; index < this.orderItemsList?.length; index++) {
      const element = this.orderItemsList[index].colourName + this.orderItemsList[index].size;
      if (element == (selectedColour[0].colourName + selectedSize[0].sizeName)) {
        errorMessage = 'Order Item Already Exists';
      }
    }

    if (errorMessage) {
      this.showSnackbar(errorMessage, '', false, true);
      document.getElementById('addButton')?.blur();
      return;
    }

    /* Prepare the orderItem Object */
    const obj = {
      id: this.orderItemsList.length > 0 ? this.orderItemsList.length : 0,
      colorId: +selectedColour[0].colourId,
      sizeId: +selectedSize[0].sizeId,
      size: selectedSize[0].sizeName,
      colourName: selectedColour[0].colourName,
      quantity: Number(this.addOrderFormControls['quantity'].value),
      unitPrice: Number(this.addOrderFormControls['unitPrice'].value),
    };

    /* Push the Order Item */
    this.orderItemsList.push(obj);
    this.addOrderFormValidations();
  }

  /**
   * This method is used to delete the order item
   * @param {*} order
   */
  onClickDeleteOrderItem(order: any) {
    this.orderItemsList = this.orderItemsList.filter(
      (item: any) => item.id !== order.id
    );
    this.orderItemsList = this.orderItemsList.map((item, index) => ({
      ...item,
      id: index,
    }));
  }

  /**
   * This method is used to save the order items
   */
  onClickSaveOrderItems() {
    if (this.orderItemsList.length === 0) {
      if (this.addOrderForm.invalid) {
        this.validationService.validateAllFormFields(this.addOrderForm);
        return;
      }
      this.showSnackbar("Add Order Items", '', false, true);
      document.getElementById('saveButton')?.blur();
      return;
    } else {
      if (this.totalQuantity > 5000) {
        this.showSnackbar("Total Quantity should not exceed 5000", '', false, true);
        document.getElementById('saveButton')?.blur();
        return;
      }
      this.isSaveOrder = true;
    }

    const storedValue: any = this.orderItemsList;
    localStorage.setItem("savedOrdersList", JSON.stringify(storedValue));
    this.savedOrderItemsList = JSON.parse(localStorage.getItem("savedOrdersList")!);
    document.getElementById("closeOrdersModal")?.click();
    // Calculate order value for each item
    const orderValues = this.orderItemsList.map((item) => item.quantity * item.unitPrice);
    // Calculate the total order value
    this.totalOrderValue = orderValues.reduce((sum, value) => sum + value, 0);

    const totalQty = this.getTotalQuantity();
    this.totalQuantity = totalQty;
    const totalUnitPrice = (this.totalOrderValue * 100) / (100 + Number(this.latestSalesTaxName));
    this.avgUnitPrice = totalUnitPrice / this.totalQuantity;
    this.editOrderFormControls['invoiceQuantity'].setValue(this.totalQuantity);
    this.editOrderFormControls['invoiceValue'].setValue(this.totalOrderValue);
  }

  /**
   * This method is used to close the orders modal
   */
  closeAddOrderModal() {
    this.addOrderForm.reset();
    this.addOrderFormValidations();
  }

  /**
   *This Method used to navigate user to organizationList Page
   */
  navigateToUserList() {
    this.router.navigate(["/admin/customer-order/organizationlist"]);
  }

  /**
   * This Method used to navigate user to orders List Page
   */
  onClickNavigateToOrdersList() {
    this.router.navigate(["/admin/customer-order/order/orderList"]);
  }

  /**
   * This method will be fired when user selects no in alert modal
   */
  onClickNo() {
    if (this.isChangesInPattern === 'pattern') {
      this.editOrderFormControls["patternSelect"].setValue(this.selectedPattern?.patternTypeId);
      this.onChangePattern(this.selectedPattern?.patternTypeId, true);
    } else if (this.isChangesInPattern === 'method') {
      this.editOrderFormControls["methodSelect"].setValue(this.selectedMethod?.methodId);
      this.onChangeMethod(this.selectedMethod?.methodId, true);
    } else {
      this.editOrderFormControls["dressItemSelect"].setValue(this.selectedDressItem?.dressItemId);
      this.onChangeDressItem(this.selectedDressItem?.dressItemId, true);
    }
    document.getElementById("closeAlertModal")?.click();
  }

  /**
   * This method will be fired when user selects yes in alert modal
   */
  onClickYes() {
    this.orderService.orderPatternDetailsObj.next({});
    if (this.isChangesInPattern === 'pattern') {
      this.editOrderFormControls["patternSelect"].setValue(this.selectedNewPattern);
      this.onChangePattern(this.selectedNewPattern, false);
    } else if (this.isChangesInPattern === 'method') {
      localStorage.removeItem("savedOrdersList");
      this.editOrderFormControls["methodSelect"].setValue(this.selectedNewMethod);
      this.onChangeMethod(this.selectedNewMethod, false);
      this.editOrderFormControls["patternSelect"].setValue('');
    } else {
      localStorage.removeItem("savedOrdersList");
      this.editOrderFormControls["dressItemSelect"].setValue(this.selectedNewDressItem);
      this.onChangeDressItem(this.selectedNewDressItem, false);
    }
    const isDressItemContainsBackPrint = this.backPrintDressItemsList.includes(this.selectedDressItem?.dressItemName);
    if (isDressItemContainsBackPrint) {
      this.onHandleSpecialModel("", true);
    }
    document.getElementById("closeAlertModal")?.click();
  }

  /**
   * This method is used to show the snackbar
   * @param {string} message
   * @param {*} orderId
   * @param {boolean} successFlag
   * @param {boolean} isModalOverlay
   */
  showSnackbar(message: string, orderId: any, successFlag: boolean, isModalOverlay: boolean) {
    const snackbar = document.getElementById("snackbar") as HTMLElement;
    this.innerHTMLMessage = message;
    this.innerHTMLOrderId = orderId;
    this.isSuccessSnackbar = successFlag;
    this.isOverlayVisible = isModalOverlay;
    snackbar.style.display = "block";
  }

  /**
   * This method is used to hide the snackbar
   */
  onClickSnackbarOkButton() {
    const snackbar = document.getElementById("snackbar") as HTMLElement;
    snackbar.style.display = "none";
    this.innerHTMLOrderId = '';
    this.innerHTMLMessage = '';
    this.isOverlayVisible = false;
    this.isSuccessSnackbar = false;
  }

  /**
   * Edit Sample Order Form Submit
   * @return {*}
   */
  onSubmitEditOrderForm(): any {
    this.editOrderForm.updateValueAndValidity();

    if (this.editOrderDetails?.order?.paymentApproved == 1) {
      this.snackbarModalComponent.onOpenSnackbarModal(false, "Order Already Approved", '', '', '');
      return;
    }

    // if (this.IsDispatchedOrderStatus && this.IsStitchingOrderStatus && this.editOrderFormControls['stitchingEndDateSelect'].value == '') {
    //   this.snackbarModalComponent.onOpenSnackbarModal(false, 'Please Enter Stitching End Date', '', '', '');
    //   return;
    // }

    if (this.IsStitchingOrderStatus && this.editOrderFormControls['stitchingDCNo'].value == '') {
      this.snackbarModalComponent.onOpenSnackbarModal(false, 'Stitching DC Not Generated', '', '', '');
      return;
    }

    if (this.IsKnittingOrderStatus && this.editOrderFormControls['knittingDCNo'].value == '') {
      this.snackbarModalComponent.onOpenSnackbarModal(false, 'Knitting DC Not Generated', '', '', '');
      return;
    }


    if (this.IsSteamIronOrderStatus && this.editOrderFormControls['steamIronAgeGroup'].value == '') {
      this.snackbarModalComponent.onOpenSnackbarModal(false, 'Please Select Age Group', '', '', '');
      return;
    }

    let isBothSideExists = false;
    if (this.IsSublimationBothSide &&
      (
        this.editOrderFormControls['resizingBothSideDCNo'].value ||
        this.editOrderFormControls['resizingBothSideUnitName'].value ||
        this.editOrderFormControls['resizingBothSideDateSelect'].value ||
        this.editOrderFormControls['resizingBothSidePrintingName'].value
      )
    ) {
      isBothSideExists = true;
    }

    if (isBothSideExists &&
      (this.editOrderFormControls['resizingBothSideDCNo'].value == '' ||
        this.editOrderFormControls['resizingBothSideUnitName'].value == '' ||
        this.editOrderFormControls['resizingBothSideDateSelect'].value == '' ||
        this.editOrderFormControls['resizingBothSidePrintingName'].value == ''
      )
    ) {
      this.snackbarModalComponent.onOpenSnackbarModal(false, 'Please Enter All Resizing Fields', '', '', '');
      return
    }

    if (this.IsFilmMakingOrderStatus && this.editOrderFormControls['filmMakingDateSelect'].value == '') {
      this.snackbarModalComponent.onOpenSnackbarModal(false, 'Please Select Film Making Date', '', '', '');
      return;
    }

    if (this.IsScreenMakingOrderStatus && this.editOrderFormControls['screenMakingDateSelect'].value == '') {
      this.snackbarModalComponent.onOpenSnackbarModal(false, 'Please Select Screen Making Date', '', '', '');
      return;
    }

    if (this.IsEmbroideryOrderStatus && this.editOrderFormControls['embroideryDateSelect'].value == '') {
      this.snackbarModalComponent.onOpenSnackbarModal(false, 'Please Select Embroidery Date', '', '', '');
      return;
    }

    if (this.IsPrintingOrderStatus && this.editOrderFormControls['printingDateSelect'].value == '') {
      this.snackbarModalComponent.onOpenSnackbarModal(false, 'Please Select Printing Date', '', '', '');
      return;
    }

    if (this.IsReSizingOrderStatus && this.editOrderFormControls['resizingOneSideDateSelect'].value == '') {
      this.snackbarModalComponent.onOpenSnackbarModal(false, 'Please Select Resizing Date', '', '', '');
      return;
    }

    if (this.IsStitchingOrderStatus && this.editOrderFormControls['stitchingStartDateSelect'].value == '') {
      this.snackbarModalComponent.onOpenSnackbarModal(false, 'Please Select Stitching Start Date', '', '', '');
      return;
    }

    if (this.IsKnittingOrderStatus && this.editOrderFormControls['knittingDateSelect'].value == '') {
      this.snackbarModalComponent.onOpenSnackbarModal(false, 'Please Select Knitting Date', '', '', '');
      return;
    }

    if (this.IsSteamIronOrderStatus && this.editOrderFormControls['steamIronDateSelect'].value == '') {
      this.snackbarModalComponent.onOpenSnackbarModal(false, 'Please Select Steam Iron Date', '', '', '');
      return;
    }

    /** This will return false if form fields are invalid and stop the service calling */
    if (this.editOrderForm.invalid) {
      this.validationService.validateAllFormFields(this.editOrderForm);
      return;
    }

    /* Check whether order items added or not */
    if (this.savedOrderItemsList.length === 0) {
      this.snackbarModalComponent.onOpenSnackbarModal(false, "Add Order Items", '', '', '');
      return;
    }

    /* Prepare Pattern Details Obj */
    let patternDetails: any;
    let patternDetailsInvalid = false;
    if (this.isPatternDressItem) {
      this.orderService.orderPatternDetailsObj.subscribe((val: any) => {
        if (Object.keys(val).length > 0) {
          patternDetails = val;
          patternDetailsInvalid = false;
        } else {
          patternDetails = {};
          patternDetailsInvalid = true;
        }
      });
    }

    if (patternDetailsInvalid) {
      this.snackbarModalComponent.onOpenSnackbarModal(false, "Add Pattern Details", '', '', '');
      return;
    }

    let orderItemsMisMatch = '';
    const orderItemsColorIdsArray = this.savedOrderItemsList.map((item: any) => item.colorId);

    // Use a Set to store unique colour names
    const uniqueColourNames = new Set(this.savedOrderItemsList.map((item: any) => item.colourName));
    // Create a new array with unique items based on colourName
    const uniqueArray = Array.from(uniqueColourNames).map(colourName => {
      return this.savedOrderItemsList.find((item: any) => item.colourName === colourName);
    });
    const tShirtsColoursList = uniqueArray;

    if (this.selectedDressItem?.dressItemName == "T-Shirts") {

      if (patternDetails?.specialModelForTShirt) {

        /* Check whether special model collar colors present in order items */
        if (patternDetails?.specialModelForTShirt?.specialModelCollars?.length > 0) {
          // Check if each colourId in orderItemsColorIdsArray exists in tShirtColour.colourName of array2
          const tShirtColorsForCollarAllExists = orderItemsColorIdsArray.every((colorId: any) =>
            patternDetails?.specialModelForTShirt?.specialModelCollars.some((item: any) =>
              item.tShirtColorId === colorId
            ));

          if (!tShirtColorsForCollarAllExists) {
            orderItemsMisMatch = 'Add All T-Shirt Collar Colours';
          }

          let responseSpecialModelCollarItems = patternDetails?.specialModelForTShirt?.specialModelCollars?.map((responseData: any, index: any) => {
            const tShirtColour = tShirtsColoursList?.find((element: any) => +responseData?.tShirtColorId === +element?.colorId);
            const collarColour = this.coloursList?.find((element: any) => +responseData?.collarColorId === +element?.colourId);
            const stripeColour = this.coloursList?.find((element: any) => +responseData?.stripeColorId === +element?.colourId);
            return {
              tShirtColorId: tShirtColour?.colorId,
              collarColorId: +collarColour?.colourId,
              stripeColorId: stripeColour ? +stripeColour?.colourId : 0
            };
          });
          responseSpecialModelCollarItems = responseSpecialModelCollarItems.filter((item: any) => item.tShirtColorId);
          patternDetails.specialModelForTShirt.specialModelCollars = responseSpecialModelCollarItems;

        } else {
          if (patternDetails?.specialModelForTShirt?.collarTypeId && patternDetails?.specialModelForTShirt?.collarTypeId !== 0) {
            orderItemsMisMatch = 'Add T-Shirt Collar Colours';
          }
        }

        /* Check whether special model cuff colors present in order items */
        if (patternDetails?.specialModelForTShirt?.specialModelCuffs?.length > 0) {
          // Check if each colourId in orderItemsColorIdsArray exists in tShirtColour.colourName of array2
          const tShirtColorsForCuffAllExists = orderItemsColorIdsArray.every((colorId: any) =>
            patternDetails?.specialModelForTShirt?.specialModelCuffs.some((item: any) =>
              item.tShirtColorId === colorId
            ));

          if (!tShirtColorsForCuffAllExists) {
            orderItemsMisMatch = 'Add All T-Shirt Cuff Colours';
          }

          let responseSpecialModelCuffItems = patternDetails?.specialModelForTShirt?.specialModelCuffs?.map((responseData: any, index: any) => {
            const tShirtColour = tShirtsColoursList?.find((element: any) => +responseData?.tShirtColorId === +element?.colorId);
            const cuffColour = this.coloursList?.find((element: any) => +responseData?.cuffColorId === +element?.colourId);
            const stripeColour = this.coloursList?.find((element: any) => +responseData?.cuffStripeColorId === +element?.colourId);
            return {
              tShirtColorId: tShirtColour?.colorId,
              cuffColorId: +cuffColour?.colourId,
              cuffStripeColorId: stripeColour ? +stripeColour?.colourId : 0
            };
          });
          responseSpecialModelCuffItems = responseSpecialModelCuffItems.filter((item: any) => item.tShirtColorId);
          patternDetails.specialModelForTShirt.specialModelCuffs = responseSpecialModelCuffItems;
        } else {
          if (patternDetails?.specialModelForTShirt?.isCuff) {
            orderItemsMisMatch = 'Add T-Shirt Cuff Colours';
          }
        }

      } else if (patternDetails?.specialPatternForTshirt) {

        /* Check whether special pattern collar colors present in order items */
        if (patternDetails?.specialPatternForTshirt?.specialPatternCollars?.length > 0) {
          // Check if each colourId in orderItemsColorIdsArray exists in tShirtColour.colourName of array2
          const tShirtColorsForCollarAllExists = orderItemsColorIdsArray.every((colorId: any) =>
            patternDetails?.specialPatternForTshirt?.specialPatternCollars.some((item: any) =>
              item.tShirtColorId === colorId
            ));

          if (!tShirtColorsForCollarAllExists) {
            orderItemsMisMatch = 'Add All T-Shirt Collar Colours';
          }

          let responseSpecialPatternCollarItems = patternDetails?.specialPatternForTshirt?.specialPatternCollars?.map((responseData: any, index: any) => {
            const tShirtColour = tShirtsColoursList?.find((element: any) => +responseData?.tShirtColorId === +element?.colorId);
            const cuffColour = this.coloursList?.find((element: any) => +responseData?.collarColorId === +element?.colourId);
            const stripeColour = this.coloursList?.find((element: any) => +responseData?.stripeColorId === +element?.colourId);
            return {
              tShirtColorId: tShirtColour?.colorId,
              collarColorId: +cuffColour?.colourId,
              stripeColorId: stripeColour ? +stripeColour?.colourId : 0
            };
          });
          responseSpecialPatternCollarItems = responseSpecialPatternCollarItems.filter((item: any) => item.tShirtColorId);
          patternDetails.specialPatternForTshirt.specialPatternCollars = responseSpecialPatternCollarItems;

        } else {
          if (patternDetails?.specialPatternForTshirt?.collarTypeId && patternDetails?.specialPatternForTshirt?.collarTypeId !== 0) {
            orderItemsMisMatch = 'Add T-Shirt Collar Colours';
          }
        }

        /* Check whether special pattern cuff colors present in order items */
        if (patternDetails?.specialPatternForTshirt?.specialPatternCuffs?.length > 0) {
          // Check if each colourId in orderItemsColorIdsArray exists in tShirtColour.colourName of array2
          const tShirtColorsForCuffAllExists = orderItemsColorIdsArray.every((colorId: any) =>
            patternDetails?.specialPatternForTshirt?.specialPatternCuffs.some((item: any) =>
              item.tShirtColorId === colorId
            ));

          if (!tShirtColorsForCuffAllExists) {
            orderItemsMisMatch = 'Add All T-Shirt Cuff Colours';
          }

          let responseSpecialPatternCuffItems = patternDetails?.specialPatternForTshirt?.specialPatternCuffs?.map((responseData: any, index: any) => {
            const tShirtColour = tShirtsColoursList?.find((element: any) => +responseData?.tShirtColorId === +element?.colorId);
            const cuffColour = this.coloursList?.find((element: any) => +responseData?.cuffColorId === +element?.colourId);
            const stripeColour = this.coloursList?.find((element: any) => +responseData?.cuffStripeColorId === +element?.colourId);
            return {
              tShirtColorId: tShirtColour?.colorId,
              cuffColorId: +cuffColour?.colourId,
              cuffStripeColorId: stripeColour ? +stripeColour?.colourId : 0
            };
          });
          responseSpecialPatternCuffItems = responseSpecialPatternCuffItems.filter((item: any) => item.tShirtColorId);
          patternDetails.specialPatternForTshirt.specialPatternCuffs = responseSpecialPatternCuffItems;
        } else {
          if (patternDetails?.specialModelForTShirt?.cuffId && patternDetails?.specialModelForTShirt?.cuffId !== 0) {
            orderItemsMisMatch = 'Add T-Shirt Cuff Colours';
          }
        }

      } else if (patternDetails?.normalPatternforTshirt) {

        /* Check whether normal pattern collar colors present in order items */
        if (patternDetails?.normalPatternforTshirt?.normalPatternCollar?.length > 0) {
          // Check if each colourId in orderItemsColorIdsArray exists in tShirtColour.colourName of array2
          const tShirtColorsForCollarAllExists = orderItemsColorIdsArray.every((colorId: any) =>
            patternDetails?.normalPatternforTshirt?.normalPatternCollar.some((item: any) =>
              item.tShirtColorId === colorId
            ));

          if (!tShirtColorsForCollarAllExists) {
            orderItemsMisMatch = 'Add All T-Shirt Collar Colours';
          }

          let responseNormalCollarItems = patternDetails?.normalPatternforTshirt?.normalPatternCollar?.map((responseData: any, index: any) => {
            const tShirtColour = tShirtsColoursList?.find((element: any) => +responseData?.tShirtColorId === +element?.colorId);
            const collarColour = this.coloursList?.find((element: any) => +responseData?.collarColorId === +element?.colourId);
            const stripeColour = this.coloursList?.find((element: any) => +responseData?.stripeColorId === +element?.colourId);
            return {
              tShirtColorId: tShirtColour?.colorId,
              collarColorId: +collarColour?.colourId,
              stripeColorId: stripeColour ? +stripeColour?.colourId : 0
            };
          });
          responseNormalCollarItems = responseNormalCollarItems.filter((item: any) => item.tShirtColorId);
          patternDetails.normalPatternforTshirt.normalPatternCollar = responseNormalCollarItems;
        } else {
          if (patternDetails?.normalPatternforTshirt?.collarTypeId && patternDetails?.normalPatternforTshirt?.collarTypeId !== 0) {
            orderItemsMisMatch = 'Add T-Shirt Collar Colours';
          }
        }

      }

    } else if (this.selectedDressItem?.dressItemName == "Pinofers" && patternDetails?.patternforPinofer) {

      /* Check whether special collar colors present in order items */
      if (patternDetails?.patternforPinofer?.specialModelCollars?.length > 0) {
        // Check if each colourId in orderItemsColorIdsArray exists in tShirtColour.colourName of array2
        const pinofersColorsForCollarAllExists = orderItemsColorIdsArray.every((colorId: any) =>
          patternDetails?.patternforPinofer?.specialModelCollars.some((item: any) =>
            item.tShirtColorId === colorId
          ));

        if (!pinofersColorsForCollarAllExists) {
          orderItemsMisMatch = 'Add All T-Shirt Collar Colours';
        }

        let responsePinofersSpecialModelCollarItems = patternDetails?.patternforPinofer?.specialModelCollars?.map((responseData: any, index: any) => {
          const tShirtColour = tShirtsColoursList?.find((element: any) => +responseData?.tShirtColorId === +element?.colorId);
          const collarColour = this.coloursList?.find((element: any) => +responseData?.collarColorId === +element?.colourId);
          const stripeColour = this.coloursList?.find((element: any) => +responseData?.stripeColorId === +element?.colourId);
          return {
            tShirtColorId: tShirtColour?.colorId,
            collarColorId: +collarColour?.colourId,
            stripeColorId: stripeColour ? +stripeColour?.colourId : 0
          };
        });
        responsePinofersSpecialModelCollarItems = responsePinofersSpecialModelCollarItems.filter((item: any) => item.tShirtColorId);
        patternDetails.patternforPinofer.specialModelCollars = responsePinofersSpecialModelCollarItems;

      } else {
        if (patternDetails?.patternforPinofer?.collarTypeId && patternDetails?.patternforPinofer?.collarTypeId !== 0) {
          orderItemsMisMatch = 'Add T-Shirt Collar Colours';
        }
      }
    }

    if (orderItemsMisMatch) {
      this.snackbarModalComponent.onOpenSnackbarModal(false, orderItemsMisMatch, '', '', '');
      return;
    }

    /* Re-format the saved order items list array */
    let newSavedOrderItemsList = this.savedOrderItemsList.map(
      ({ id, colourName, size, ...rest }) => ({ ...rest })
    );

    /* Prepare Order Obj */
    const OrderObj = {
      orderId: +this.editOrderDetails?.order?.orderId,
      orderNo: +this.editOrderDetails?.order?.orderNo,
      schoolId: +this.editOrderDetails?.order?.schoolId,
      organizationName: this.editOrderDetails?.order?.organizationName || "",
      organizationType: this.editOrderDetails?.order?.organizationType || "",
      customerId: this.editOrderDetails?.order?.customerId || "",
      stateName: this.editOrderDetails?.order?.stateName || "",
      districtName: this.editOrderDetails?.order?.districtName || "",
      mandalName: this.editOrderDetails?.order?.mandalName || "",
      townName: this.editOrderDetails?.order?.townName || "",
      address: this.editOrderDetails?.order?.address || "",
      dressItemId: +this.selectedDressItem?.dressItemId,
      dressItem: this.selectedDressItem?.dressItemName,
      methodId: +this.selectedMethod?.methodId,
      method: this.selectedMethod?.methodName,
      qualityId: +this.selectedQuality?.qualityId,
      quality: this.selectedQuality?.qualityName,
      patternTypeId: this.isPatternDressItem ? this.selectedPattern?.patternTypeId : 0,
      patternType: this.isPatternDressItem ? this.selectedPattern?.patternType : '',
      backPrint1: this.isBackPrint ? this.editOrderFormControls["BackPrintOne"].value?.trim() : "",
      backPrint2: this.isBackPrint ? this.editOrderFormControls["BackPrintTwo"].value?.trim() : "",
      backPrint3: this.isBackPrint ? this.editOrderFormControls["BackPrintThree"].value?.trim() : "",
      backPrint4: this.isBackPrint ? this.editOrderFormControls["BackPrintFour"].value?.trim() : "",
      diagramId: this.isBackPrint ? this.selectedDiagram?.id : 0,
      printtypeId: this.isPrintType ? this.selectedPrintType : 0,
      expectedDDate: this.datePipe.transform(this.editOrderFormControls['deliveryDate'].value, 'yyyy-MM-dd', 'en-US'),
      modeOfPaymentId: +this.selectedPaymentMode?.id,
      remarks: this.editOrderFormControls['remarks'].value?.trim(),
      staffId: this.isStaffSelect ? +this.selectedStaff?.staffId : 0,
      orderRecived: this.isStaffSelect ? this.selectedOrderReceived : 0,
      agentThroughId: this.isStaffSelect && this.selectedOrderReceived == 1 ? this.selectedAgentType : 0,
      agentId: this.isStaffSelect && this.selectedOrderReceived == 1 ? +this.selectedAgent?.agentId : 0,
      agentCommPerc: this.isStaffSelect && this.selectedOrderReceived == 1 ? +this.editOrderFormControls["commission"].value : 0,
      agentTotCommission: this.isStaffSelect && this.selectedOrderReceived == 1 ? +this.editOrderFormControls["agentCommission"].value : 0,
      calculatePoints: this.isStaffSelect ? this.selectedCalculatePoints : 0,
      unitPoints: this.isStaffSelect && this.selectedCalculatePoints == 1 ? +this.editOrderFormControls['unitPoints'].value : 0,
      totalPoints: this.isStaffSelect && this.selectedCalculatePoints == 1 ? +this.editOrderFormControls['points'].value : 0,
      inchargeId: this.IsCPGeneratedOrderStatus ? +this.selectedIncharge?.staffId : 0,
      inchargeDate: this.IsCPGeneratedOrderStatus ? this.datePipe.transform(this.editOrderFormControls['inchargeDate'].value, "yyyy-MM-dd", 'en-US') : null,
      orderTypeId: this.isStaffSelect ? this.selectedSchoolType : 0,
      transportName: this.editOrderFormControls['place'].value?.trim(),
      orderStatusId: +this.selectedOrderStatus?.orderStatusId,
      orderStatus: this.selectedOrderStatus?.orderStatusName,
      orderValue: +this.totalOrderValue,
      lrNumber: this.IsDispatchedOrderStatus ? this.editOrderFormControls['lrDetails'].value : '',
      dispatchDate: this.IsDispatchedOrderStatus ? this.datePipe.transform(this.editOrderFormControls['dispatchDate'].value, "yyyy-MM-dd", 'en-US') : null,
      transportId: this.IsDispatchedOrderStatus ? +this.selectedTransport?.transportId : 0,
      fullPayment: this.IsDispatchedOrderStatus ? this.selectedPaymentReceived : 0,
      paymentReceivedDate: this.IsDispatchedOrderStatus && this.isPaymentReceived ? this.datePipe.transform(this.editOrderFormControls['paymentDate'].value, "yyyy-MM-dd", 'en-US') : null,
      paymentApproved: this.IsDispatchedOrderStatus && this.isPaymentReceived ? +this.selectedApproved : 0,
      voucherGenFlag: 0,
      transport: this.IsDispatchedOrderStatus ? this.selectedTransport?.transportName : '',
    }

    /* Prepare the request payload */
    const obj: any = {
      order: OrderObj,
      orderColours: newSavedOrderItemsList
    };

    /* Cutting Obj */
    const cuttingObj = {
      dcNo: this.editOrderFormControls['cuttingDCNo'].value || '',
      quantity: +this.editOrderFormControls['cuttingQuantity'].value || 0,
      unitNameId: +this.editOrderFormControls['cuttingUnitName'].value || 0,
      date: this.datePipe.transform(this.editOrderFormControls['cuttingDateSelect'].value, "yyyy-MM-dd", 'en-US') || ''
    }

    /* Fusing Obj */
    const fusingObj = {
      dcNo: this.editOrderFormControls['fusingDCNo'].value || '',
      fusingTypeId: +this.editOrderFormControls['fusingType'].value || 0,
      quantity: +this.editOrderFormControls['fusingQuantity'].value || 0,
      unitNameId: +this.editOrderFormControls['fusingUnitName'].value || 0,
      date: this.datePipe.transform(this.editOrderFormControls['fusingDateSelect'].value, "yyyy-MM-dd", 'en-US') || ''
    }

    /* Film Making Obj */
    const filmMakingObj = {
      printTypeId: +this.editOrderFormControls['filmMakingType'].value || 0,
      dcNo: this.editOrderFormControls['filmMakingDCNo'].value || '',
      quantity: +this.editOrderFormControls['filmMakingQuantity'].value || 0,
      unitNameId: +this.editOrderFormControls['filmMakingUnitName'].value || 0,
      date: this.datePipe.transform(this.editOrderFormControls['filmMakingDateSelect'].value, "yyyy-MM-dd", 'en-US') || '',
    }

    /* Screen Making Obj */
    const screenMakingObj = {
      printTypeId: +this.editOrderFormControls['screenMakingType'].value || 0,
      dcNo: this.editOrderFormControls['screenMakingDCNo'].value || '',
      quantity: +this.editOrderFormControls['screenMakingQuantity'].value || 0,
      unitNameId: +this.editOrderFormControls['screenMakingUnitName'].value || 0,
      date: this.datePipe.transform(this.editOrderFormControls['screenMakingDateSelect'].value, "yyyy-MM-dd", 'en-US') || '',
    }

    /* Embroidery Obj */
    const embroideryObj = {
      printTypeId: +this.editOrderFormControls['embroideryType'].value || 0,
      dcNo: this.editOrderFormControls['embroideryDCNo'].value || '',
      quantity: +this.editOrderFormControls['embroideryQuantity'].value || 0,
      unitNameId: +this.editOrderFormControls['embroideryUnitName'].value || 0,
      date: this.datePipe.transform(this.editOrderFormControls['embroideryDateSelect'].value, "yyyy-MM-dd", 'en-US') || '',
    }

    /* Printing Obj */
    const printingObj = {
      printTypeId: +this.editOrderFormControls['printingType'].value || 0,
      dcNo: this.editOrderFormControls['printingDCNo'].value || '',
      quantity: +this.editOrderFormControls['printingQuantity'].value || 0,
      unitNameId: +this.editOrderFormControls['printingUnitName'].value || 0,
      date: this.datePipe.transform(this.editOrderFormControls['printingDateSelect'].value, "yyyy-MM-dd", 'en-US') || '',
    }

    /* Stitching Obj */
    const stitchingObj = {
      dcNo: this.editOrderFormControls['stitchingDCNo'].value || '',
      quantity: +this.editOrderDetails?.stichingDCDetails?.quantity || 0,
      unitNameId: +this.editOrderFormControls['stitchingUnitName'].value || 0,
      date: this.datePipe.transform(this.editOrderFormControls['stitchingStartDateSelect'].value, "yyyy-MM-dd", 'en-US') || '',
      // endDate: this.datePipe.transform(this.editOrderFormControls['stitchingEndDateSelect'].value, "yyyy-MM-dd", 'en-US') || ''
    }

    /* Knitting Obj */
    const knittingObj = {
      dcNo: this.editOrderFormControls['knittingDCNo'].value || '',
      quantity: +this.editOrderFormControls['knittingQuantity'].value || 0,
      unitNameId: +this.editOrderFormControls['knittingUnitName'].value || 0,
      date: this.datePipe.transform(this.editOrderFormControls['knittingDateSelect'].value, "yyyy-MM-dd", 'en-US') || '',
      collarTypeId: +this.editOrderFormControls['knittingCollarType'].value || 0,
    }

    /* Steam Iron */
    const steamIronObj = {
      dcNo: this.editOrderFormControls['steamIronDCNo'].value || '',
      quantity: +this.editOrderFormControls['steamIronQuantity'].value || 0,
      unitNameId: +this.editOrderFormControls['steamIronUnitName'].value || 0,
      date: this.datePipe.transform(this.editOrderFormControls['steamIronDateSelect'].value, "yyyy-MM-dd", 'en-US') || '',
      ageGroupId: +this.editOrderFormControls['steamIronAgeGroup'].value || 0,
    }

    /* Prepare Order Status Keys */
    const orderStatusPayload = [
      {
        flag: this.IsCuttingOrderStatus, obj: cuttingObj, objKey: 'cuttingDCDetails',
      },
      {
        flag: this.IsFusingOrderStatus, obj: fusingObj, objKey: 'fusingDCDetails',
      },
      {
        flag: this.IsFilmMakingOrderStatus, obj: filmMakingObj, objKey: 'filmMakingDCDetails',
      },
      {
        flag: this.IsScreenMakingOrderStatus, obj: screenMakingObj, objKey: 'screenMakingDCDetails',
      },
      {
        flag: this.IsEmbroideryOrderStatus, obj: embroideryObj, objKey: 'embroideryDCDetails',
      },
      {
        flag: this.IsPrintingOrderStatus, obj: printingObj, objKey: 'printingDCDetails',
      },
      {
        flag: this.IsStitchingOrderStatus, obj: stitchingObj, objKey: 'stichingDCDetails',
      },
      {
        flag: this.IsKnittingOrderStatus, obj: knittingObj, objKey: 'knittingDCDetails',
      },
      {
        flag: this.IsSteamIronOrderStatus, obj: steamIronObj, objKey: 'steamIronDCDetails',
      },
    ]

    for (const element of orderStatusPayload) {
      obj[element.objKey] = element.obj;
    }

    /* Resizing */
    obj.resizingDCDetails = [
      {
        dcId: this.editOrderDetails?.resizingDCDetails[0]?.dcId ? this.editOrderDetails?.resizingDCDetails[0]?.dcId : 0,
        dcNo: this.editOrderFormControls['resizingOneSideDCNo'].value || '',
        quantity: +this.editOrderFormControls['resizingOneSideQuantity'].value || 0,
        unitNameId: +this.editOrderFormControls['resizingOneSideUnitName'].value || 0,
        printingUnitNameId: +this.editOrderFormControls['resizingOneSidePrintingName'].value || 0,
        charge: +this.editOrderDetails?.resizingDCDetails[0]?.charge,
        date: this.datePipe.transform(this.editOrderFormControls['resizingOneSideDateSelect'].value, "yyyy-MM-dd", 'en-US') ?? '',
      }
    ]
    if (this.IsSublimationBothSide &&
      (
        this.editOrderFormControls['resizingBothSideDCNo'].value &&
        this.editOrderFormControls['resizingBothSideUnitName'].value &&
        this.editOrderFormControls['resizingBothSideDateSelect'].value &&
        this.editOrderFormControls['resizingBothSidePrintingName'].value
      )
    ) {
      obj.resizingDCDetails.push({
        dcId: this.editOrderDetails?.resizingDCDetails[1]?.dcId ? this.editOrderDetails?.resizingDCDetails[1]?.dcId : 0,
        dcNo: this.editOrderFormControls['resizingBothSideDCNo'].value || '',
        quantity: +this.editOrderFormControls['resizingBothSideQuantity'].value || 0,
        unitNameId: +this.editOrderFormControls['resizingBothSideUnitName'].value || 0,
        printingUnitNameId: +this.editOrderFormControls['resizingBothSidePrintingName'].value || 0,
        charge: +this.editOrderDetails?.resizingDCDetails[1]?.charge || 0,
        date: this.datePipe.transform(this.editOrderFormControls['resizingBothSideDateSelect'].value, "yyyy-MM-dd", 'en-US') ?? '',
      });
    }

    if (this.selectedDressItem?.dressItemName == "T-Shirts") {
      if (this.selectedPattern?.patternType === "Special Model") {
        obj.specialModelForTShirt = patternDetails?.specialModelForTShirt;
      } else if (this.selectedPattern?.patternType === "Special Pattern") {
        obj.specialPatternForTshirt = patternDetails?.specialPatternForTshirt;
      } else {
        obj.normalPatternforTshirt = patternDetails?.normalPatternforTshirt;
      }
    } else if (this.selectedDressItem?.dressItemName == "Middy") {
      if (this.selectedPattern?.patternType === "Special") {
        obj.specialforMiddy = patternDetails?.specialforMiddy;
      } else {
        obj.normalforMiddy = patternDetails?.normalforMiddy;
      }
    } else if (this.selectedDressItem?.dressItemName == "Pant") {
      obj.patternforPant = patternDetails?.patternforPant;
    } else if (this.selectedDressItem?.dressItemName == "Nicker") {
      obj.patternforPant = patternDetails?.patternforPant;
    } else if (this.selectedDressItem?.dressItemName == "Shots") {
      obj.patternforPant = patternDetails?.patternforPant;
    } else if (this.selectedDressItem?.dressItemName == "Pinofers") {
      obj.patternforPinofer = patternDetails?.patternforPinofer;
    }

    console.log("Final Obj", obj);

    // return;

    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    /* To call the service to edit the sample order by passing the data object */
    this.orderService.editOrder(obj).subscribe({
      next: (res: any) => {
        /* Disable the loader if response is error */
        this.loaderService.isLoading.next(false);
        this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', 'editOrder');
      },
      error: (err: any) => {
        /* Disable the loader if response is error */
        this.loaderService.isLoading.next(false);
        this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message || err, '', '', '');
      }
    });
  }
}
