import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";

import { CustomerOrderComponent } from "./customer-order.component";



const routes: Routes = [
  {
    path: "",
    component: CustomerOrderComponent,
    children: [
      { path: '', redirectTo: `${localStorage.getItem('customerOrderModule')}`, pathMatch: 'full' },
      {
        path: "organizationlist",
        loadChildren: () =>
          import("./organization/organization.module").then((m) => m.OrganizationModule),
      },
      {
        path: "sampleorder", loadChildren: () => import("./sample-orders/sample-orders.module").then((m) => m.SampleOrdersModule)
      },

      {
        path: "cuttingprogram", loadChildren: () => import("./cutting-program/cutting-program.module").then((m) => m.CuttingProgramModule)
      },

      {
        path: "dc", loadChildren: () => import("./dc/dc.module").then((m) => m.DcModule)
      },
      {
        path: "knittingdc", loadChildren: () => import("./knitting-dc/knitting-dc.module").then((m) => m.KnittingDcModule)
      },

      {
        path: "knittingprogram", loadChildren: () => import("./knitting-program/knitting-program.module").then((m) => m.KnittingProgramModule)
      },

      {
        path: "order", loadChildren: () => import("./orders/orders.module").then((m) => m.OrdersModule)
      },
     
    ]
  }
];

/**
 * Customer Order Routing Module
 * @export
 * @class CustomerOrderRoutingModule
 */
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CustomerOrderRoutingModule { }
