import { Component, OnInit, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";

import { SnackbarModalComponent } from "src/app/core/Dialogues/snackbar-modal/snackbar-modal.component";
import { CustomersService } from "src/app/core/Services/customers.service";
import { LoaderService } from "src/app/core/Services/loader.service";
import { MastersService } from "src/app/core/Services/masters.service";
import { ValidationService } from "src/app/core/Services/validation.service";

/**
 * Add Organization Component
 * @export
 * @class AddOrganizationComponent
 * @implements {OnInit}
 */
@Component({
  selector: 'app-addorganization',
  templateUrl: './addorganization.component.html',
  styleUrls: ['./addorganization.component.scss']
})
export class AddorganizationComponent implements OnInit {
  /**
   * Get Snackbar Modal Component
   * @type {SnackbarModalComponent}
   */
  @ViewChild("snackbarModalComponent") snackbarModalComponent!: SnackbarModalComponent;

  /**
  * Get Organization Types List
  * @type {*}
  */
  organizationTypesList: any;

  /**
   * Get States List
   * @type {*}
   */
  statesList: any;

  /**
   * Get Districts List
   * @type {*}
   */
  districtsList: any;

  /**
   * Get Mandals List
   * @type {*}
   */
  mandalsList: any;

  /**
   * Get Towns List
   * @type {*}
   */
  townsList: any;

  /**
   * Create Organization Form Declaration
   * @type {FormGroup}
   */
  createOrganizationForm!: FormGroup;

  /**
   * Get Organization Form Validations
   */
  createOrganizationValidation = this.validationService.createOrganization;

  /**
   * Get Location Validations
   */
  locationValidation = this.validationService.locationSelect;

  /**
   * Get Patterns
   * @private
   */
  private patterns = this.validationService.patterns;

  /**
   * Creates an instance of AddOrganizationComponent.
   * @param {Router} router
   * @param {LoaderService} loaderService
   * @param {ValidationService} validationService
   * @param {FormBuilder} formBuilder
   * @param {CustomersService} customerService
   * @param {MastersService} mastersService
   */
  constructor(
    private router: Router,
    private loaderService: LoaderService,
    private validationService: ValidationService,
    private formBuilder: FormBuilder,
    private customerService: CustomersService,
    private mastersService: MastersService
  ) { }

  /**
   * Life Cycle Hook Initialization
   */
  ngOnInit(): void {
    this.createOrganizationFormValidations();
    this.getOrganizationTypes();
    this.getStates();
  }

  /**
   * Create Organization Controls Initialized
   * @readonly
   */
  get createOrganizationFormControls() {
    return this.createOrganizationForm.controls;
  }

  /**
   * Initialize Create Organization Form Validations
   */
  createOrganizationFormValidations() {
    this.createOrganizationForm = this.formBuilder.group({
      organizationType: ["", [Validators.required]],
      stateSelect: ["", [Validators.required]],
      districtSelect: ["", [Validators.required]],
      mandalSelect: ["", [Validators.required]],
      townSelect: ["", [Validators.required]],
      OrganizationName: [
        "",
        [
          Validators.required,
          Validators.minLength(this.createOrganizationValidation.OrganizationName.minLength),
          Validators.maxLength(this.createOrganizationValidation.OrganizationName.maxLength)
        ]
      ],
      Address: [
        "",
        [
          Validators.required,
          Validators.minLength(this.createOrganizationValidation.Address.minLength),
          Validators.maxLength(this.createOrganizationValidation.Address.maxLength)
        ]
      ],
      Pin: [
        '',
        [
          Validators.required,
          Validators.minLength(this.createOrganizationValidation.Pin.minLength),
          Validators.maxLength(this.createOrganizationValidation.Pin.maxLength),
          Validators.pattern(this.patterns.number)
        ]
      ],
      MobileNo: [
        "",
        [
          Validators.required,
          Validators.minLength(this.createOrganizationValidation.mobileNo.minLength),
          Validators.maxLength(this.createOrganizationValidation.mobileNo.maxLength),
          Validators.pattern(this.patterns.mobileNo)
        ]
      ]
    });
  }

  /**
   * This method is used to reset organization form
   */
  onResetOrganizationForm() {
    this.createOrganizationForm.reset();
    this.districtsList = [];
    this.mandalsList = [];
    this.townsList = [];
    this.createOrganizationFormValidations();
  }

  /**
   * This method is used to navigate user to organization list page
   */
  onNavigateToOrganizationList() {
    this.router.navigate(["/admin/customer-order"]);
  }

  /**
   * This method is used to update value and validity
   * @param {*} formControls
   */
  onUpdateValueAndValidity(formControls: any, controls: any) {
    controls?.forEach((control: any) => {
      formControls[control].setValue("");
      formControls[control].markAsUntouched({ onlySelf: true });
      formControls[control].updateValueAndValidity({ onlySelf: true });
    });
  }

  /**
   * This method is used to get the organization types List
   */
  getOrganizationTypes() {
    this.customerService.getOrganizationTypes().subscribe({
      next: (res: any) => {
        this.organizationTypesList = res.result;
      },
      error: () => {
        this.organizationTypesList = [];
      }
    });
  }

  /**
   * This method is used to get states list
   */
  getStates() {
    this.mastersService.getStates().subscribe({
      next: (res: any) => {
        this.statesList = res.result;
      },
      error: () => {
        this.statesList = [];
      }
    });
  }

  /**
   * This method will fired when user selects organization type
   * @param {*} event
   */
  OrganizationTypeChange(event: any) {
    if (event.target?.value == '') {
      this.createOrganizationFormControls["organizationType"].markAsUntouched({ onlySelf: true });
    }
  }

  /**
   * This method will fired when user selects the state
   * @param {*} event
   */
  onChangeState(event: any) {
    this.onUpdateValueAndValidity(this.createOrganizationFormControls, ['districtSelect', 'mandalSelect', 'townSelect']);
    this.districtsList = [];
    this.mandalsList = [];
    this.townsList = [];

    if (event?.target?.value == '') {
      this.createOrganizationFormControls["stateSelect"].markAsUntouched({ onlySelf: true });
      return;
    }

    /* To call the service to get the districts list by passing stateId */
    this.mastersService.getDistrictsByStateId(event?.target?.value?.toString()).subscribe({
      next: (res: any) => {
        this.districtsList = res.result;
      },
      error: () => {
        this.districtsList = [];
      }
    });
  }

  /**
   * This method will fired when user selects the district
   * @param {*} event
   */
  onChangeDistrict(event: any) {
    this.onUpdateValueAndValidity(this.createOrganizationFormControls, ['mandalSelect', 'townSelect']);
    this.mandalsList = [];
    this.townsList = [];

    if (event.target?.value == '') {
      this.createOrganizationFormControls["districtSelect"].markAsUntouched({ onlySelf: true });
      return;
    }

    /* To call the service to get the mandals list by passing districtId */
    this.mastersService.getMandalsByDistrictId(event?.target?.value?.toString()).subscribe({
      next: (res: any) => {
        this.mandalsList = res.result;
      },
      error: () => {
        this.mandalsList = [];
      }
    });
  }

  /**
   * This method will fired when user selects the mandal
   * @param {*} event
   */
  onChangeMandal(event: any) {
    this.onUpdateValueAndValidity(this.createOrganizationFormControls, ['townSelect']);
    this.townsList = [];

    if (event.target?.value == '') {
      this.createOrganizationFormControls["mandalSelect"].markAsUntouched({ onlySelf: true });
      return;
    }

    /* To call the service to get the towns list by passing mandalId */
    this.mastersService.getTownsByMandalId(event.target?.value?.toString()).subscribe({
      next: (res: any) => {
        this.townsList = res.result;
      },
      error: () => {
        this.townsList = [];
      }
    });
  }

  /**
   * This method will fired when user selects town
   * @param {*} event
   */
  onChangeTown(event: any) {
    if (event.target?.value == '') {
      this.createOrganizationFormControls["townSelect"].markAsUntouched({ onlySelf: true });
    }
  }

  /**
   * This method is used to submit the create organization form
   */
  onSubmitCreateOrganizationForm() {

    /** This will return false if form fields are invalid and stop the service calling */
    if (this.createOrganizationForm.invalid) {
      this.validationService.validateAllFormFields(this.createOrganizationForm);
      return;
    }

    /* Prepare the request payload */
    const obj = {
      organizationId: 0,
      organizationName: this.createOrganizationFormControls["OrganizationName"]?.value?.toString(),
      organizationTypeId: +this.createOrganizationFormControls["organizationType"].value,
      townId: +this.createOrganizationFormControls["townSelect"]?.value,
      address: this.createOrganizationFormControls['Address']?.value?.toString(),
      pin: this.createOrganizationFormControls["Pin"]?.value?.toString(),
      mobileNo: this.createOrganizationFormControls["MobileNo"]?.value?.toString(),
      // stateId: this.selectedState.stateId?.toString(),
      // stateName: this.selectedState.stateName?.toString(),
      // districtId: this.selectedDistrict?.districtId?.toString(),
      // districtName: this.selectedDistrict?.districtName?.toString(),
      // mandalId: this.selectedMandal?.mandalId?.toString(),
      // mandalName: this.selectedMandal?.mandalName?.toString(),
      // status: "0",
    };

    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    /* To call the service to add the organization by passing obj */
    this.customerService.addOrganization(obj).subscribe({
      next: (res: any) => {
        /* Disable the loader if response is success */
        this.loaderService.isLoading.next(false);
        this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', 'organization');
      },
      error: (err: any) => {
        /* Disable the loader if response is error */
        this.loaderService.isLoading.next(false);
        this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message || err, '', '', '');
      }
    });
  }
}
