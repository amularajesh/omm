import { ChangeDetectorRef, Component, OnInit, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";

import { SnackbarModalComponent } from "src/app/core/Dialogues/snackbar-modal/snackbar-modal.component";
import { CustomersService } from "src/app/core/Services/customers.service";
import { LoaderService } from "src/app/core/Services/loader.service";
import { MastersService } from "src/app/core/Services/masters.service";
import { ValidationService } from "src/app/core/Services/validation.service";

/**
 * Edit Organization Component
 * @export
 * @class EditOrganizationComponent
 * @implements {OnInit}
 */
@Component({
  selector: "app-editorganization",
  templateUrl: "./editorganization.component.html",
  styleUrls: ["./editorganization.component.scss"],
})
export class EditorganizationComponent implements OnInit {
  /**
   * Get Snackbar Modal Component
   * @type {SnackbarModalComponent}
   */
  @ViewChild("snackbarModalComponent") snackbarModalComponent!: SnackbarModalComponent;

  /**
   * Get Organization Types List
   * @type {*}
   */
  organizationTypesList: any;

  /**
   * Get States List
   * @type {*}
   */
  statesList: any;

  /**
   * Get Districts List
   * @type {*}
   */
  districtsList: any;

  /**
   * Get Mandals List
   * @type {*}
   */
  mandalsList: any;

  /**
   * Get Towns List
   * @type {*}
   */
  townsList: any;

  /**
   * Get Edit Organization Details
   */
  editOrganizationDetails: any;

  /**
   * Edit Organization Form Declaration
   */
  editOrganizationForm!: FormGroup;

  /**
   * Get Organization Form Validations
   */
  createOrganizationValidation = this.validationService.createOrganization;

  /**
   * Get Location Validations
   */
  locationValidation = this.validationService.locationSelect;

  /**
   * Get Patterns
   * @private
   */
  private patterns = this.validationService.patterns;

  /**
   * Creates an instance of EditOrganizationComponent.
   * @param {Router} router
   * @param {LoaderService} loaderService
   * @param {ValidationService} validationService
   * @param {FormBuilder} formBuilder
   * @param {CustomersService} customerService
   * @param {MastersService} mastersService
   */
  constructor(
    private router: Router,
    private loaderService: LoaderService,
    private validationService: ValidationService,
    private formBuilder: FormBuilder,
    private customerService: CustomersService,
    private mastersService: MastersService,
    private cdr: ChangeDetectorRef
  ) {
    this.customerService.OrganizationDetails.subscribe((res: any) => {
      if (Object.keys(res).length !== 0) {
        this.editOrganizationDetails = res;
      } else {
        this.editOrganizationDetails = null;
        this.onNavigateToOrganizationList();
      }
      this.editOrganizationDetails = res;
    });
  }

  /**
   * Life Cycle Hook Initialization
   */
  ngOnInit(): void {
    this.editOrganizationFormValidations();
    this.getOrganizationTypes();
    this.getStates();
  }

  /**
   * Initialize Create Organization Form Validations
   */
  editOrganizationFormValidations() {
    this.editOrganizationForm = this.formBuilder.group({
      OrganizationName: [
        this.editOrganizationDetails?.organizationName || "",
        [
          Validators.required,
          Validators.minLength(this.createOrganizationValidation.OrganizationName.minLength),
          Validators.maxLength(this.createOrganizationValidation.OrganizationName.maxLength),
        ]
      ],
      organizationType: [this.editOrganizationDetails?.organizationTypeId || "", [Validators.required]],
      stateSelect: [this.editOrganizationDetails?.stateId || "", [Validators.required]],
      districtSelect: [this.editOrganizationDetails?.districtId || "", [Validators.required]],
      mandalSelect: [this.editOrganizationDetails?.mandalId || "", [Validators.required]],
      townSelect: [this.editOrganizationDetails?.townId || "", [Validators.required]],
      Address: [
        this.editOrganizationDetails?.address || "",
        [
          Validators.required,
          Validators.minLength(this.createOrganizationValidation.Address.minLength),
          Validators.maxLength(this.createOrganizationValidation.Address.maxLength)
        ]
      ],
      Pin: [
        this.editOrganizationDetails?.pin || "",
        [
          Validators.required,
          Validators.minLength(this.createOrganizationValidation.Pin.minLength),
          Validators.maxLength(this.createOrganizationValidation.Pin.maxLength),
          Validators.pattern(this.patterns.number)
        ]
      ],
      MobileNo: [
        this.editOrganizationDetails?.mobileNo || "",
        [
          Validators.required,
          Validators.minLength(this.createOrganizationValidation.mobileNo.minLength),
          Validators.maxLength(this.createOrganizationValidation.mobileNo.maxLength),
          Validators.pattern(this.patterns.mobileNo)
        ]
      ],
      active: [this.editOrganizationDetails?.status ? '1' : '0' || "0",]
    });

    if (this.editOrganizationDetails) {
      this.editOrganizationFormControls["organizationType"].disable({ onlySelf: true });
    }
  }

  /**
   * Create Organization Controls Initialized
   * @readonly
   */
  get editOrganizationFormControls() {
    return this.editOrganizationForm.controls;
  }

  /**
   * This method is used to update value and validity
   * @param {*} formControls
   */
  onUpdateValueAndValidity(formControls: any, controls: any) {
    controls?.forEach((control: any) => {
      formControls[control].setValue("");
      formControls[control].markAsUntouched({ onlySelf: true });
      formControls[control].updateValueAndValidity({ onlySelf: true });
    });
  }

  /**
   * This method is used to navigate user to organization list page
   */
  onNavigateToOrganizationList() {
    this.router.navigate(["/admin/customer-order"]);
  }

  /**
   * This method is used to get the organization types List
   */
  getOrganizationTypes() {
    this.customerService.getOrganizationTypes().subscribe({
      next: (res: any) => {
        this.organizationTypesList = res.result;
      },
      error: () => {
        this.organizationTypesList = [];
      }
    });
  }

  /**
   * This method is used to get states list
   */
  getStates() {
    this.mastersService.getStates().subscribe({
      next: (res: any) => {
        this.statesList = res.result;
        this.editOrganizationFormControls["stateSelect"].setValue(this.editOrganizationDetails?.stateId);
        this.onChangeState(this.editOrganizationDetails?.stateId);
      },
      error: () => {
        this.statesList = [];
      }
    });
  }

  /**
   * This method will fired when user selects the state
   * @param {*} event
   */
  onChangeState(event: any) {
    if (event?.target) {
      this.onUpdateValueAndValidity(this.editOrganizationFormControls, ['districtSelect', 'mandalSelect', 'townSelect']);
      this.districtsList = [];
      this.mandalsList = [];
      this.townsList = [];
    }

    const stateValue = event?.target ? event.target?.value : event;
    const eventFlag = event?.target;

    if (stateValue == '') {
      this.editOrganizationFormControls["stateSelect"].markAsUntouched({ onlySelf: true });
      return;
    }

    /* To call the service to get the districts list by passing stateId */
    this.mastersService.getDistrictsByStateId(stateValue?.toString()).subscribe({
      next: (res: any) => {
        this.districtsList = res.result;
        if (!eventFlag) {
          this.editOrganizationFormControls["districtSelect"].setValue(this.editOrganizationDetails?.districtId);
          this.cdr.detectChanges();
          this.onChangeDistrict(this.editOrganizationDetails?.districtId);
        }
      },
      error: () => {
        this.districtsList = [];
      }
    });
  }

  /**
   * This method will fired when user selects the district
   * @param {*} event
   */
  onChangeDistrict(event: any) {
    if (event?.target) {
      this.onUpdateValueAndValidity(this.editOrganizationFormControls, ['mandalSelect', 'townSelect']);
      this.mandalsList = [];
      this.townsList = [];
    }

    if (event.target?.value == '') {
      this.editOrganizationFormControls["districtSelect"].markAsUntouched({ onlySelf: true });
      return;
    }

    const districtValue = event?.target ? event.target?.value : event;
    const eventFlag = event?.target;

    /* To call the service to get the mandals list by passing districtId */
    this.mastersService.getMandalsByDistrictId(districtValue?.toString()).subscribe({
      next: (res: any) => {
        this.mandalsList = res.result;
        if (!eventFlag) {
          this.editOrganizationFormControls["mandalSelect"].setValue(this.editOrganizationDetails?.mandalId);
          this.onChangeMandal(this.editOrganizationDetails?.mandalId);
        }
      },
      error: () => {
        this.mandalsList = [];
      }
    });
  }

  /**
   * This method will fired when user selects the mandal
   * @param {*} event
   */
  onChangeMandal(event: any) {
    if (event?.target) {
      this.onUpdateValueAndValidity(this.editOrganizationFormControls, ['townSelect']);
      this.townsList = [];
    }

    if (event.target?.value == '') {
      this.editOrganizationFormControls["mandalSelect"].markAsUntouched({ onlySelf: true });
      return;
    }
    const eventFlag = event?.target;
    const mandalValue = event?.target ? event.target?.value : event;

    /* To call the service to get the towns list by passing mandalId */
    this.mastersService.getTownsByMandalId(mandalValue?.toString()).subscribe({
      next: (res: any) => {
        this.townsList = res.result;
        if (!eventFlag) {
          this.editOrganizationFormControls["townSelect"].setValue(this.editOrganizationDetails?.townId);
        }
      },
      error: () => {
        this.townsList = [];
      }
    });
  }

  /**
   * This method will fired when user selects town
   * @param {*} event
   */
  onChangeTown(event: any) {
    if (event.target?.value == '') {
      this.editOrganizationFormControls["townSelect"].markAsUntouched({ onlySelf: true });
    }
  }

  /**
   * This method is used to submit the edit organization form
   */
  onEditOrganizationFormSubmit() {
    /** This will return false if form fields are invalid and stop the service calling */
    if (this.editOrganizationForm.invalid) {
      this.validationService.validateAllFormFields(this.editOrganizationForm);
      return;
    }

    /* Prepare the request payload */
    const obj = {
      organizationId: this.editOrganizationDetails?.organizationId,
      organizationName: this.editOrganizationFormControls["OrganizationName"]?.value?.toString(),
      organizationTypeId: +this.editOrganizationFormControls["organizationType"].value,
      townId: +this.editOrganizationFormControls["townSelect"]?.value,
      address: this.editOrganizationFormControls["Address"]?.value?.toString(),
      pin: this.editOrganizationFormControls["Pin"]?.value?.toString(),
      mobileNo: this.editOrganizationFormControls["MobileNo"]?.value?.toString(),
      "isActive": this.editOrganizationFormControls["active"]?.value === '1'
    };

    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    /* To call the service to edit the organization by passing obj */
    this.customerService.editOrganization(obj).subscribe({
      next: (res: any) => {
        /* Disable the loader if response is success */
        this.loaderService.isLoading.next(false);
        this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', 'organization');
      },
      error: (err: any) => {
        /* Disable the loader if response is error */
        this.loaderService.isLoading.next(false);
        this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message || err, '', '', '');
      }
    });
  }
}
