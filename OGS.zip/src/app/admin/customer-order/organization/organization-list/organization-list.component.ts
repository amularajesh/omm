import { Location } from "@angular/common";
import { Component, OnInit, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";

import { SnackbarModalComponent } from "src/app/core/Dialogues/snackbar-modal/snackbar-modal.component";
import { WhatsappModalComponent } from "src/app/core/Dialogues/whatsapp-modal/whatsapp-modal.component";
import { CustomersService } from "src/app/core/Services/customers.service";
import { LoaderService } from "src/app/core/Services/loader.service";
import { OrderService } from "src/app/core/Services/order.service";
import { SampleOrderService } from "src/app/core/Services/sample-order.service";
import { ValidationService } from "src/app/core/Services/validation.service";

/**
 * Organization List Component
 * @export
 * @class OrganizationListComponent
 * @implements {OnInit}
 */
@Component({
  selector: "app-organization-list",
  templateUrl: "./organization-list.component.html",
  styleUrls: ["./organization-list.component.scss"]
})
export class OrganizationListComponent implements OnInit {
  /**
   * Get Snackbar Modal Component
   * @type {SnackbarModalComponent}
   */
  @ViewChild("snackbarModalComponent") snackbarModalComponent!: SnackbarModalComponent;

  /**
   * Get Whatsapp Modal Component
   * @type {WhatsappModalComponent}
   */
  @ViewChild("whatsappModalComponent") whatsappModalComponent!: WhatsappModalComponent;

  /**
  * Initialize Status List
  * @type {any[]}
  */
  statusList: any[] = [
    { statusId: 1, statusValue: 'Active' },
    { statusId: 2, statusValue: 'In-Active' },
    // { statusId: 3, statusValue: 'Finish' },
  ];

  /**
   * Get Is Admin Or Manager Flag
   */
  isAdminOrManager = false;

  // search organization
  searchObj = {
    organizationName: "",
    status: 0,
    phoneNumber: "",
  };

  /**
   * Records Count
   */
  recordsCount = 0;

  /**
   * Organization List
   */
  organizationList: any[] = [];

  /**
   * Default Page Number
   */
  currentPage = 1;

  /**
   * Search Term
   */
  searchTerm = "";

  /**
   * Default Sorting Key
   */
  sortingKeyColumn = "organizationName";

  /**
   * Default Sort Order
   */
  sortingOrder = true;

  /**
   * OrganizationSearch Form Declaration
   */
  organizationSearchForm!: FormGroup;

  /**
   * Get OrganizationSearch Form Validations
   */
  organizationSearchValidation = this.validationService.searchOrganization;

  /**
   * Get OrganizationSearch Patterns
   * @private
   */
  private patterns = this.validationService.patterns;

  /**
   * Creates an instance of OrganizationListComponent.
   * @param {Router} router
   * @param {ValidationService} validationService
   * @param {FormBuilder} formBuilder
   * @param {Location} location
   * @param {LoaderService} loaderService
   * @param {CustomersService} customerService
   * @param {SampleOrderService} sampleOrderService
   * @param {OrderService} orderService
   */
  constructor(
    private router: Router,
    private validationService: ValidationService,
    private formBuilder: FormBuilder,
    private location: Location,
    private loaderService: LoaderService,
    private customerService: CustomersService,
    private sampleOrderService: SampleOrderService,
    private orderService: OrderService,
  ) {
    if (localStorage.getItem('userTypeId') == '1' || localStorage.getItem('userTypeId') == '4') {
      this.isAdminOrManager = true;
    }
    
    /* Get snackbar details from behavior subject */
    this.customerService.snackbarDetails.subscribe((res: any) => {
      if (res) {
        this.snackbarModalComponent.onOpenSnackbarModal(res?.flag, res?.message, '', '', '');
      }
    });
  }

  /**
   * Life Cycle Hook Initialization
   */
  ngOnInit(): void {
    this.organizationSearchValidations();
    this.getOrganizationList();
  }

  /**
   * This method is used to get Organization list
   */
  getOrganizationList() {
    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    /* To call the service to get the Organization list */
    this.customerService.getOrganizationList(this.searchObj).subscribe({
      next: (res: any) => {
        /* Disable the loader if response is success */
        this.loaderService.isLoading.next(false);
        this.organizationList = res.result;
        this.recordsCount = this.organizationList.length;
      },
      error: (err: any) => {
        /* Disable the loader if response is error */
        this.loaderService.isLoading.next(false);
        this.organizationList = [];
        this.recordsCount = 0;
      }
    });
  }

  /**
   * OrganizationSearch Validations
   */
  organizationSearchValidations() {
    this.organizationSearchForm = this.formBuilder.group({
      status: [''],
      PhoneNo: [
        "",
        [
          Validators.minLength(this.organizationSearchValidation.phoneNo.minLength),
          Validators.maxLength(this.organizationSearchValidation.phoneNo.maxLength),
        ]
      ],
      organizationName: ["", []]
    });
  }

  /**
   * OrganizationSearch Controls Initialized
   * @readonly
   */
  get organizationSearchFormControls() {
    return this.organizationSearchForm.controls;
  }

  /**
   *This Method Used to for filtering table
   * @param {*} event
   */
  searchSubmit(event: any) {
    const obj = {
      organizationName:
        this.organizationSearchFormControls["organizationName"].value || "",
      status: this.organizationSearchFormControls['status'].value || 0,

      phoneNumber: this.organizationSearchFormControls["PhoneNo"].value || "",
    };
    this.searchObj = obj;

    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    /* To call the service to get the Organization list */
    this.customerService.getOrganizationList(this.searchObj).subscribe({
      next: (res: any) => {
        /* Disable the loader if response is success */
        this.loaderService.isLoading.next(false);
        this.organizationList = res.result;
        this.recordsCount = this.organizationList.length;
        this.currentPage = 1;
      },
      error: (err: any) => {
        /* Disable the loader if response is success */
        this.loaderService.isLoading.next(false);
        this.organizationList = [];
        this.recordsCount = 0;
      },
    });
  }

  /**
   * This method is used to sort column
   * @param key : value of which column based we need to sort the rows
   */
  sort(key: string) {
    const componentName = this.location.path();
    let value = key;
    sessionStorage.setItem(`${componentName}_property`, value);
    this.sortingKeyColumn = key;
    if (sessionStorage.getItem(componentName + "_order") == "desc") {
      this.sortingOrder = false;
    } else {
      this.sortingOrder = true;
    }
  }

  /**
   * This method is used to change the pagination controls
   * @param {*} event
   */
  onPageChange(event: any) {
    this.currentPage = event;
  }

  /**
   * This method is used for navigate to create course page when user clicked on edit Organization
   */
  onClickEditUser(user: any) {
    /* Enable the loader */
    this.loaderService.isLoading.next(true);
    this.customerService.getOrganizationById(user?.organizationId).subscribe({
      next: (res: any) => {
        /* Disable the loader */
        this.loaderService.isLoading.next(false);
        this.customerService.OrganizationDetails.next(res.result);
        localStorage.setItem("OrgId", res?.result?.organizationId);
        localStorage.setItem("OrgTypeId", res?.result?.organizationTypeId);
        this.router.navigate(["/admin/customer-order/organizationlist/editorganization"]);
      },
      error: (err: any) => {
        /* Disable the loader */
        this.loaderService.isLoading.next(false);

        this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message || err, '', '', '');
      }
    });
  }

  /**
   * This method is used for navigate to create Organization
   */
  onClickCreateOrganization() {
    this.router.navigate(["/admin/customer-order/organizationlist/addorganization"]);
  }

  /**
   * This method is used to navigate to the add sample order page
   * @param {*} organization
   */
  navigateToSampleOrders(organization: any) {
    this.sampleOrderService.organizationDetails.next(organization);
    this.router.navigate(["/admin/customer-order/sampleorder/addsampleorder"]);
  }

  /**
   * This method is used to navigate to the add order page
   * @param {*} organization
   */
  navigateToOrders(organization: any) {
    this.orderService.organizationDetails.next(organization);
    this.router.navigate(["/admin/customer-order/order/addOrder"]);
  }

  /**
   * This method is used to show the whatsapp modal
   */
  onClickOpenWhatsappModal() {
    const activeOrganizations = this.organizationList.filter((organization: any) => organization.status);
    this.whatsappModalComponent.onOpenWhatsappModal(activeOrganizations);
  }
}
