import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Ng2SearchPipeModule } from "ng2-search-filter";

import { OrganizationRoutingModule } from './organization-routing.module';
import { OrganizationComponent } from './organization.component';
import { OrganizationListComponent } from './organization-list/organization-list.component';
import { AddorganizationComponent } from './addorganization/addorganization.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatTooltipModule } from '@angular/material/tooltip';
import { NgSelectModule } from '@ng-select/ng-select';
import { ComponentModule } from 'src/app/core/Modules/component.module';
import { NgxPaginationModule } from 'ngx-pagination';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { OrderModule } from 'ngx-order-pipe';
import { EditorganizationComponent } from './editorganization/editorganization.component';


@NgModule({
  declarations: [
    OrganizationComponent,
    AddorganizationComponent,
    OrganizationListComponent,
    EditorganizationComponent,
  
  ],
  imports: [
    CommonModule,
    OrganizationRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    MatTooltipModule,
    OrderModule,
    NgSelectModule,
    ComponentModule,
    NgxPaginationModule,
    Ng2SearchPipeModule,
    BsDatepickerModule.forRoot(),
  ]
})
export class OrganizationModule { }
