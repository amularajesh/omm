import { DatePipe, Location } from "@angular/common";
import { Component, OnInit, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";

import { SnackbarModalComponent } from "src/app/core/Dialogues/snackbar-modal/snackbar-modal.component";
import { CustomersService } from "src/app/core/Services/customers.service";
import { LoaderService } from "src/app/core/Services/loader.service";
import { ValidationService } from "src/app/core/Services/validation.service";

/**
 * Knitting Program List Component
 * @export
 * @class KnittingProgramListComponent
 * @implements {OnInit}
 */
@Component({
  selector: 'app-knitting-program-list',
  templateUrl: './knitting-program-list.component.html',
  styleUrls: ['./knitting-program-list.component.scss']
})
export class KnittingProgramListComponent implements OnInit {
  /**
   * Get Snackbar Modal Component
   * @type {SnackbarModalComponent}
   */
  @ViewChild("snackbarModalComponent") snackbarModalComponent!: SnackbarModalComponent;

  /**
   * Get Knitting program  List
   * @type {*}
   */
  knittingProgramList: any[] = [];

  /**
   * Set Min From Date
   * @type {Date}
   */
  minFromDate: Date;

  /**
   * Set Max From Date
   * @type {Date}
   */
  maxFromDate: Date;

  /**
   * Initialize Sorting Order Flag
   */
  sortingOrder = false;

  /**
   * Initialize Sorting Key Column
   */
  sortingKeyColumn = "kpNo";

  /**
   * Records Count
   */
  recordsCount = 0;

  /**
   * Default Page Number
   */
  currentPage = 1;

  /**
   * Search Term
   */
  searchTerm = "";

  /**
   * Create search KnittingProgram Form Declaration
   * @type {FormGroup}
   */
  searchKnittingProgramForm!: FormGroup;

  /**
   * Get search search KnittingProgram Form Validations
   */
  searchKnittingProgramValidation = this.validationService.searchKnittingProgram;

  /**
   * Get Create search KnittingProgram Patterns
   * @private
   */
  private patterns = this.validationService.patterns;

  /**
   * Creates an instance of KnittingProgramListComponent.
   * @param {Router} router
   * @param {LoaderService} loaderService
   * @param {ValidationService} validationService
   * @param {FormBuilder} formBuilder
   * @param {DatePipe} datePipe
   * @param {CustomersService} customerService
   * @param {Location} location
   */
  constructor(
    private router: Router,
    private loaderService: LoaderService,
    private validationService: ValidationService,
    private formBuilder: FormBuilder,
    private datePipe: DatePipe,
    private customerService: CustomersService,
    private location: Location
  ) {
    /* set Min Date */
    this.minFromDate = new Date();
    this.maxFromDate = new Date();
    const d = new Date();
    d.setDate(1);
    d.setMonth(0);
    d.setFullYear(2012);
    this.minFromDate = d;
  }

  /**
   * Life Cycle Hook Initialization
   */
  ngOnInit(): void {
    this.searchKnittingProgramFormValidations();
    this.getKnittingProgramList("initial");
  }

  /**
   * Create search KnittingProgram Controls Initialized
   * @readonly
   */
  get searchKnittingProgramFormControls() {
    return this.searchKnittingProgramForm.controls;
  }

  /**
   * Initialize Create Search Knitting Program Form Validations
   */
  searchKnittingProgramFormValidations() {
    this.searchKnittingProgramForm = this.formBuilder.group({
      orderNumber: [
        '',
        [
          Validators.minLength(this.searchKnittingProgramValidation.orderNumber.minLength),
          Validators.maxLength(this.searchKnittingProgramValidation.orderNumber.maxLength),
          Validators.pattern(this.patterns.number),
        ],
      ],
      SelectDate: ['']
    });
  }

  /**
   * This method is used to get the active knitting program List
   * @param {string} initialFlag
   */
  getKnittingProgramList(initialFlag: string) {
    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    /* Prepare request payload */
    const obj = {
      kpNo: initialFlag ? 0 : +this.searchKnittingProgramFormControls["orderNumber"]?.value || 0,
      date: initialFlag ? '' : this.datePipe.transform(this.searchKnittingProgramFormControls["SelectDate"].value, "YYYY-MM-dd") || '',
    };

    /* To call the service to get the Organization list */
    this.customerService.getKnittingProgramList(obj).subscribe({
      next: (res: any) => {
        /* Disable the loader if response is success */
        this.loaderService.isLoading.next(false);
        this.knittingProgramList = res.result;
        this.recordsCount = this.knittingProgramList.length;
      },
      error: (err: any) => {
        this.loaderService.isLoading.next(false);
        this.knittingProgramList = [];
        this.recordsCount = 0;
      }
    });
  }

  /**
   * This method is used to change the pagination controls
   * @param {*} event
   */
  onPageChange(event: any) {
    this.currentPage = event;
  }

  /**
   * This method is used to submit search knitting program Form
   */
  onSearchKnittingProgramFormSubmit() {
    this.getKnittingProgramList("");
  }

  /**
   * This method is used to show search results
   */
  navigateToSearchResult() {
    this.currentPage = 1;
  }

  /**
   * This method is used to sort column
   * @param key : value of which column based we need to sort the rows
   */
  sort(key: string) {
    const componentName = this.location.path();
    let value = key;
    sessionStorage.setItem(`${componentName}_property`, value);
    this.sortingKeyColumn = key;
    if (sessionStorage.getItem(componentName + "_order") == "desc") {
      this.sortingOrder = false;
    } else {
      this.sortingOrder = true;
    }
  }

  /**
   * This method is used for navigate to create knitting order page when user clicked on add knitting program
   */
  onClickCreateKnittingProgram() {
    this.router.navigate(["/admin/customer-order/knittingprogram/addKnittingProgram"]);
  }

  /**
   * This method is used to view the kp layout
   * @param {*} knitting
   */
  onClickKPlayout(knitting: any) {
    this.customerService.getKnittingProgramById(knitting?.knittingProgramID).subscribe({
      next: (res: any) => {
        this.customerService.CuttingProgramDetails.next(res.result);
        this.router.navigate(["/admin/customer-order/knittingprogram/kpLayout"]);
      },
      error: (err: any) => {
        this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
      }
    });
  }
}
