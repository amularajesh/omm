import { ComponentFixture, TestBed } from '@angular/core/testing';

import { KnittingProgramListComponent } from './knitting-program-list.component';

describe('KnittingProgramListComponent', () => {
  let component: KnittingProgramListComponent;
  let fixture: ComponentFixture<KnittingProgramListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ KnittingProgramListComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(KnittingProgramListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
