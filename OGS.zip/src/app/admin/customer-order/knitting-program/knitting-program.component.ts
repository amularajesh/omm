import { Component } from '@angular/core';

/**
 * Knitting Program Component
 * @export
 * @class KnittingProgramComponent
 */
@Component({
  selector: 'app-knitting-program',
  templateUrl: './knitting-program.component.html',
  styleUrls: ['./knitting-program.component.scss']
})
export class KnittingProgramComponent { }