import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddKnittingProgramComponent } from './add-knitting-program.component';

describe('AddKnittingProgramComponent', () => {
  let component: AddKnittingProgramComponent;
  let fixture: ComponentFixture<AddKnittingProgramComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddKnittingProgramComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddKnittingProgramComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
