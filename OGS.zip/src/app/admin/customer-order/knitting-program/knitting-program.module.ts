import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatTooltipModule } from '@angular/material/tooltip';
import { NgSelectModule } from '@ng-select/ng-select';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { AutosizeModule } from 'ngx-autosize';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { OrderModule } from 'ngx-order-pipe';
import { NgxPaginationModule } from 'ngx-pagination';

import { ComponentModule } from 'src/app/core/Modules/component.module';
import { AddKnittingProgramComponent } from './add-knitting-program/add-knitting-program.component';
import { KnittingProgramListComponent } from './knitting-program-list/knitting-program-list.component';
import { KnittingProgramRoutingModule } from './knitting-program-routing.module';
import { KnittingProgramComponent } from './knitting-program.component';
import { KpLayoutComponent } from './kp-layout/kp-layout.component';

/**
 * Knitting Program Module
 * @export
 * @class KnittingProgramModule
 */
@NgModule({
  declarations: [
    KnittingProgramComponent,
    KnittingProgramListComponent,
    AddKnittingProgramComponent,
    KpLayoutComponent,
  ],
  imports: [
    CommonModule,
    KnittingProgramRoutingModule,
    FormsModule,
    OrderModule,
    ComponentModule,
    NgSelectModule,
    NgxPaginationModule,
    Ng2SearchPipeModule,
    ReactiveFormsModule,
    BsDatepickerModule.forRoot(),
    MatTooltipModule,
    AutosizeModule
  ]
})
export class KnittingProgramModule { }
