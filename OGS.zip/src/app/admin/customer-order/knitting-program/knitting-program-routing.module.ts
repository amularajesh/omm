import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AddKnittingProgramComponent } from './add-knitting-program/add-knitting-program.component';
import { KnittingProgramListComponent } from './knitting-program-list/knitting-program-list.component';
import { KnittingProgramComponent } from './knitting-program.component';
import { KpLayoutComponent } from './kp-layout/kp-layout.component';

const routes: Routes = [
  {
    path: '',
    component: KnittingProgramComponent,
    children: [
      { path: '', redirectTo: "knittingProgramList", pathMatch: 'full' },
      { path: 'knittingProgramList', component: KnittingProgramListComponent },
      { path: 'addKnittingProgram', component: AddKnittingProgramComponent },
      { path: 'kpLayout', component: KpLayoutComponent }
    ]
  }
];

/**
 * Knitting Program Routing Module
 * @export
 * @class KnittingProgramRoutingModule
 */
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class KnittingProgramRoutingModule { }
