import { ComponentFixture, TestBed } from '@angular/core/testing';

import { KnittingProgramComponent } from './knitting-program.component';

describe('KnittingProgramComponent', () => {
  let component: KnittingProgramComponent;
  let fixture: ComponentFixture<KnittingProgramComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ KnittingProgramComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(KnittingProgramComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
