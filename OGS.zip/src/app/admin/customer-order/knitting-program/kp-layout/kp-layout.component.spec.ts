import { ComponentFixture, TestBed } from '@angular/core/testing';

import { KpLayoutComponent } from './kp-layout.component';

describe('KpLayoutComponent', () => {
  let component: KpLayoutComponent;
  let fixture: ComponentFixture<KpLayoutComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ KpLayoutComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(KpLayoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
