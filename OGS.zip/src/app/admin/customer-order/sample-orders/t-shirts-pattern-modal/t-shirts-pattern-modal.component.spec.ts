import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TShirtsPatternModalComponent } from './t-shirts-pattern-modal.component';

describe('TShirtsPatternModalComponent', () => {
  let component: TShirtsPatternModalComponent;
  let fixture: ComponentFixture<TShirtsPatternModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TShirtsPatternModalComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TShirtsPatternModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
