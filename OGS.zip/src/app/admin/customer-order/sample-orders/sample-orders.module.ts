import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatTooltipModule } from '@angular/material/tooltip';
import { NgSelectModule } from '@ng-select/ng-select';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { AutosizeModule } from 'ngx-autosize';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { OrderModule } from 'ngx-order-pipe';
import { NgxPaginationModule } from 'ngx-pagination';

import { ComponentModule } from 'src/app/core/Modules/component.module';
import { AddSampleOrderComponent } from './add-sample-order/add-sample-order.component';
import { EditSampleOrderComponent } from './edit-sample-order/edit-sample-order.component';
import { MiddyPatternModalComponent } from './middy-pattern-modal/middy-pattern-modal.component';
import { NickersModelComponent } from './nickers-model/nickers-model.component';
import { PantPatternModalComponent } from './pant-pattern-modal/pant-pattern-modal.component';
import { PinofersModelComponent } from './pinofers-model/pinofers-model.component';
import { SampleOrderLayoutComponent } from './sample-order-layout/sample-order-layout.component';
import { SampleOrdersListComponent } from './sample-orders-list/sample-orders-list.component';
import { SampleOrdersRoutingModule } from './sample-orders-routing.module';
import { SampleOrdersComponent } from './sample-orders.component';
import { ShotsModelComponent } from './shots-model/shots-model.component';
import { TShirtsPatternModalComponent } from './t-shirts-pattern-modal/t-shirts-pattern-modal.component';

/**
 * Sample Orders Module
 * @export
 * @class SampleOrdersModule
 */
@NgModule({
  declarations: [
    SampleOrdersComponent,
    SampleOrdersListComponent,
    AddSampleOrderComponent,
    EditSampleOrderComponent,
    TShirtsPatternModalComponent,
    PinofersModelComponent,
    MiddyPatternModalComponent,
    NickersModelComponent,
    ShotsModelComponent,
    PantPatternModalComponent,
    SampleOrderLayoutComponent
  ],
  imports: [
    CommonModule,
    SampleOrdersRoutingModule,
    FormsModule,
    OrderModule,
    ComponentModule,
    NgSelectModule,
    NgxPaginationModule,
    Ng2SearchPipeModule,
    ReactiveFormsModule,
    BsDatepickerModule.forRoot(),
    MatTooltipModule,
    AutosizeModule
  ]
})
export class SampleOrdersModule { }
