import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NickersModelComponent } from './nickers-model.component';

describe('NickersModelComponent', () => {
  let component: NickersModelComponent;
  let fixture: ComponentFixture<NickersModelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NickersModelComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(NickersModelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
