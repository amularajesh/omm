import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sample-orders',
  templateUrl: './sample-orders.component.html',
  styleUrls: ['./sample-orders.component.scss']
})
export class SampleOrdersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
