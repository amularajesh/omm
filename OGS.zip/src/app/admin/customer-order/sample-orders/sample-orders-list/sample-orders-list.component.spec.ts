import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SampleOrdersListComponent } from './sample-orders-list.component';

describe('SampleOrdersListComponent', () => {
  let component: SampleOrdersListComponent;
  let fixture: ComponentFixture<SampleOrdersListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SampleOrdersListComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SampleOrdersListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
