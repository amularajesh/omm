import { DatePipe, Location } from "@angular/common";
import { Component, OnInit, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";

import { SnackbarModalComponent } from "src/app/core/Dialogues/snackbar-modal/snackbar-modal.component";
import { StatusMode } from "src/app/core/Modals/modals";
import { LoaderService } from "src/app/core/Services/loader.service";
import { OrderService } from "src/app/core/Services/order.service";
import { SampleOrderService } from "src/app/core/Services/sample-order.service";
import { ValidationService } from "src/app/core/Services/validation.service";

/**
 * Sample Orders List Component
 * @export
 * @class SampleOrdersListComponent
 * @implements {OnInit}
 */
@Component({
  selector: "app-sample-orders-list",
  templateUrl: "./sample-orders-list.component.html",
  styleUrls: ["./sample-orders-list.component.scss"],
})
export class SampleOrdersListComponent implements OnInit {
  /**
   * Get Snackbar Modal Component
   * @type {SnackbarModalComponent}
   */
  @ViewChild("snackbarModalComponent") snackbarModalComponent!: SnackbarModalComponent;

  /**
   * Get Is Admin Or Manager Flag
   */
  isAdminOrManager = false;

  /**
   * Declare Search Object
   */
  searchObj = {
    sampleOrderNo: 0,
    sampleOrderDate: "",
    statusId: null,
    MobileNo: ''
  };

  /**
   * Set Min From Date
   * @type {Date}
   */
  minFromDate: Date;

  /**
   * Set Max From Date
   * @type {Date}
   */
  maxFromDate: Date;

  /**
   *Var declared to store data of fabrics on click od add button
   * @type {any[]}
   * @memberof SampleOrdersListComponent
   */
  sampleOrderList: any[] = [];

  /**
   * Get Sorting Order
   */
  sortingOrder = true;
  sortingKeyColumn = "sampleOrderNo";

  /**
   * Records Count
   */
  recordsCount = 0;

  /**
   * Payment mode List
   * @type {StatusMode[]}
   */
  statusModesList: StatusMode[] = [
    { id: "2", type: "Completed" },
    { id: "1", type: "Not Completed" },
    { id: "3", type: "Cancelled" },
  ];

  /**
   * Selected Status
   */
  selectedStatus: any;
  selectedStatusId: any;

  /**
   * Default Page Number
   */
  currentPage = 1;

  /**
   * Search Term
   */
  searchTerm = "";

  /**
   * Create City Form Declaration
   */
  searchSampleOrderForm!: FormGroup;

  /**
   * Get City Form Validations
   */
  searchSampleOrderValidation = this.validationService.sampleOrderSearch;

  /**
   * Get Create Student Patterns
   * @private
   */
  private patterns = this.validationService.patterns;

  /**
   * Creates an instance of SampleOrdersListComponent.
   * @param {Router} router
   * @param {LoaderService} loaderService
   * @param {ValidationService} validationService
   * @param {FormBuilder} formBuilder
   * @param {DatePipe} datePipe
   * @param {SampleOrderService} sampleOrderService
   * @param {OrderService} orderService
   * @param {Location} location
   */
  constructor(
    private router: Router,
    private loaderService: LoaderService,
    private validationService: ValidationService,
    private formBuilder: FormBuilder,
    private datePipe: DatePipe,
    private sampleOrderService: SampleOrderService,
    private orderService: OrderService,
    private location: Location
  ) {

    if (localStorage.getItem('userTypeId') == '1' || localStorage.getItem('userTypeId') == '4') {
      this.isAdminOrManager = true;
    }

    /* set Min Date */
    this.minFromDate = new Date();
    this.maxFromDate = new Date();
    const d = new Date();
    d.setDate(1);
    d.setMonth(0);
    d.setFullYear(2012);
    this.minFromDate = d;
  }

  /**
   * Life Cycle Hook Initialization
   */
  ngOnInit(): void {
    this.searchSampleOrderFormValidations();
    this.getSampleOrdersList();
  }

  /**
   * Create Search Sample Order Form Controls Initialized
   * @readonly
   */
  get searchSampleFormControls() {
    return this.searchSampleOrderForm.controls;
  }

  /**
   * Initialize Search Sample Order Form Validations
   */
  searchSampleOrderFormValidations() {
    this.searchSampleOrderForm = this.formBuilder.group({
      orderNumber: [
        "",
        [
          Validators.minLength(
            this.searchSampleOrderValidation.orderNumber.minLength
          ),
          Validators.maxLength(
            this.searchSampleOrderValidation.orderNumber.maxLength
          ),
          Validators.pattern(this.patterns.number),
        ],
      ],
      SelectDate: [""],
      statusSelect: [""],
      phoneNo: [
        "",
        [
          Validators.minLength(this.searchSampleOrderValidation.phoneNo.minLength),
          Validators.maxLength(this.searchSampleOrderValidation.phoneNo.maxLength),
          // Validators.pattern(this.patterns.mobileNo)
        ],
      ],
    });
  }

  /**
   * This method is used to change the pagination controls
   * @param {*} event
   */
  onPageChange(event: any) {
    this.currentPage = event;
  }

  /**
   * Set the minimum date selection for ToDate(End Date)
   * @param {Date} e
   */
  setMinDateForToDate(e: Date) {
    const dateFormate: Date = e;
    // this.minToDate = dateFormate;
    // this.userSearchForm.controls["endDate"].setValue("");
  }

  /**
   * This method will fired when user selects the status
   * @param {*} event
   */
  statusChange(event: any) {
    if (event?.target?.value == '') {
      this.selectedStatus = '';
      this.selectedStatusId = '';
      return;
    }
    for (const element of this.statusModesList) {
      if (element.id === event.target.value) {
        this.selectedStatus = element.type;
        this.selectedStatusId = element.id;
      }
    }
  }

  /**
   * This method is used to get the active cutting program List
   */
  getSampleOrdersList() {
    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    /* To call the service to get the cutting program list */
    this.sampleOrderService.getSampleOrders(this.searchObj).subscribe({
      next: (res: any) => {
        /* Disable the loader if response is success */
        this.loaderService.isLoading.next(false);
        this.sampleOrderList = res.result;
        this.recordsCount = this.sampleOrderList.length;
      },
      error: (err: any) => {
        /* Disable the loader if response is error */
        this.loaderService.isLoading.next(false);
        this.sampleOrderList = [];
        this.recordsCount = 0;
      },
    });
  }

  /**
   * Create mandal Form Submit
   */
  onSearchSampleOrderFormSubmit() {
    /* Prepare the request payload */
    const obj: any = {
      sampleOrderNo: Number(this.searchSampleFormControls["orderNumber"]?.value || 0),
      sampleOrderDate: this.datePipe.transform(this.searchSampleFormControls["SelectDate"].value, "YYYY-MM-dd") || "",
      statusId: Number(this.selectedStatusId) || null,
      MobileNo: this.searchSampleFormControls["phoneNo"].value,
    };

    this.searchObj = obj;

    // return;

    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    //method to send payload to service for add district
    this.sampleOrderService.getSampleOrders(this.searchObj).subscribe({
      next: (res: any) => {
        /* Disable the loader if response is success */
        this.loaderService.isLoading.next(false);
        this.sampleOrderList = res.result;
        this.recordsCount = this.sampleOrderList.length;
        this.currentPage = 1;
      },
      error: (err: any) => {
        /* Disable the loader if response is error */
        this.loaderService.isLoading.next(false);
        this.sampleOrderList = [];
        this.recordsCount = 0;
        this.currentPage = 1;
      },
    });
  }

  /**
   * This method is used to show search results
   */
  navigateToSearchResult() {
    this.currentPage = 1;
  }

  /**
   * This method is used to sort column
   * @param key : value of which column based we need to sort the rows
   */
  sort(key: string) {
    const componentName = this.location.path();
    let value = key;
    console.log(value);

    sessionStorage.setItem(`${componentName}_property`, value);
    this.sortingKeyColumn = key;

    if (sessionStorage.getItem(componentName + "_order") == "desc") {
      console.log(sessionStorage.getItem(componentName + "_order"));
      this.sortingOrder = false;
    } else {
      console.log(sessionStorage.getItem(componentName + "_order"));
      this.sortingOrder = true;
    }
  }

  /**
   * This method is used for navigate to create sample order page when user clicked on add Sample order
   */
  onClickCreateSampleOrder() {
    this.router.navigate(["/admin/customer-order/sampleorder/addsampleorder"]);
  }

  /**
   * This method is used for navigate to create sample order page when user clicked on edit Sample order
   * @param {*} sampleOrder
   */
  onClickEditSampleOrder(sampleOrder: any) {
    /* To call the service to get the sample order details by passing order id */
    this.sampleOrderService.getSampleOrderById(sampleOrder?.sampleOrderId).subscribe({
      next: (res: any) => {
        this.sampleOrderService.editSampleOrderDetails.next(res?.result);
        this.router.navigate(["/admin/customer-order/sampleorder/editsampleorder"]);
      },
      error: (err: any) => {
        this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message || err, '', '', '');
      },
    });
  }

  /**
   * This method is used for navigate to add order page when user clicked on copy Sample order
   * @param {*} order
   */
  onClickCopySampleOrder(order: any) {
    /* To call the service to get the sample order details by passing order id */
    this.sampleOrderService.getSampleOrderById(order?.sampleOrderId).subscribe({
      next: (res: any) => {
        this.orderService.copySampleOrderDetails.next(res?.result);
        this.router.navigate(["/admin/customer-order/order/addOrder"]);
      },
      error: (err: any) => {
        this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message || err, '', '', '');
      }
    });
  }

  /**
   * This method is used to navigate to sample order Layout
   * @param {*} sampleOrder
   */
  navigateToSampleOrderLayout(sampleOrder: any) {
    /* To call the service to get the order layout details by passing order id */
    this.sampleOrderService.getSampleOrderLayout(sampleOrder?.sampleOrderId).subscribe({
      next: (res: any) => {
        this.sampleOrderService.sampleOrderLayoutDetails.next(res.result);
        this.router.navigate(['/admin/customer-order/sampleorder/sampleOrderLayout']);
      },
      error: (err: any) => {
        this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message || err, '', '', '');
      }
    });
  }
}
