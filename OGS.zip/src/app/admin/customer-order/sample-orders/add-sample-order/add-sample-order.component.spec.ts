import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddSampleOrderComponent } from './add-sample-order.component';

describe('AddSampleOrderComponent', () => {
  let component: AddSampleOrderComponent;
  let fixture: ComponentFixture<AddSampleOrderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddSampleOrderComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddSampleOrderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
