import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShotsModelComponent } from './shots-model.component';

describe('ShotsModelComponent', () => {
  let component: ShotsModelComponent;
  let fixture: ComponentFixture<ShotsModelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ShotsModelComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ShotsModelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
