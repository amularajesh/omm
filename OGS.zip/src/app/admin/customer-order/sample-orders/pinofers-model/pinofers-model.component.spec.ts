import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PinofersModelComponent } from './pinofers-model.component';

describe('PinofersModelComponent', () => {
  let component: PinofersModelComponent;
  let fixture: ComponentFixture<PinofersModelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PinofersModelComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PinofersModelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
