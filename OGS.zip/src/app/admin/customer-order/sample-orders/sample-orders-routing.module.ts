import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AddSampleOrderComponent } from './add-sample-order/add-sample-order.component';
import { EditSampleOrderComponent } from './edit-sample-order/edit-sample-order.component';
import { SampleOrderLayoutComponent } from './sample-order-layout/sample-order-layout.component';
import { SampleOrdersListComponent } from './sample-orders-list/sample-orders-list.component';
import { SampleOrdersComponent } from './sample-orders.component';

const routes: Routes = [
  {
    path: '',
    component: SampleOrdersComponent,
    children: [
      { path: '', redirectTo: "sampleorderlist", pathMatch: 'full' },
      { path: 'sampleorderlist', component: SampleOrdersListComponent },
      { path: 'addsampleorder', component: AddSampleOrderComponent },
      { path: 'editsampleorder', component: EditSampleOrderComponent },
      { path: 'sampleOrderLayout', component: SampleOrderLayoutComponent },
    ]
  }
];

/**
 * Sample Orders Routing Module
 * @export
 * @class SampleOrdersRoutingModule
 */
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SampleOrdersRoutingModule { }
