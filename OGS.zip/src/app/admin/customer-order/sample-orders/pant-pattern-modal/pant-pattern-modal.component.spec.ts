import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PantPatternModalComponent } from './pant-pattern-modal.component';

describe('PantPatternModalComponent', () => {
  let component: PantPatternModalComponent;
  let fixture: ComponentFixture<PantPatternModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [PantPatternModalComponent]
    })
      .compileComponents();

    fixture = TestBed.createComponent(PantPatternModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
