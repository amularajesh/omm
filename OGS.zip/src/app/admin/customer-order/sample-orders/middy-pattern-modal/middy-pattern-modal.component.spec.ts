import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MiddyPatternModalComponent } from './middy-pattern-modal.component';

describe('MiddyPatternModalComponent', () => {
  let component: MiddyPatternModalComponent;
  let fixture: ComponentFixture<MiddyPatternModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MiddyPatternModalComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MiddyPatternModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
