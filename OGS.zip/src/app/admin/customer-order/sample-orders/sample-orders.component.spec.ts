import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SampleOrdersComponent } from './sample-orders.component';

describe('SampleOrdersComponent', () => {
  let component: SampleOrdersComponent;
  let fixture: ComponentFixture<SampleOrdersComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SampleOrdersComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SampleOrdersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
