import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SampleOrderLayoutComponent } from './sample-order-layout.component';

describe('SampleOrderLayoutComponent', () => {
  let component: SampleOrderLayoutComponent;
  let fixture: ComponentFixture<SampleOrderLayoutComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SampleOrderLayoutComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SampleOrderLayoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
