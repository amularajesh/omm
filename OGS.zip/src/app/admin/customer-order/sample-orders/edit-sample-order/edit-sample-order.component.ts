import { DatePipe } from "@angular/common";
import { AfterViewInit, Component, HostListener, OnInit, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";

import { SnackbarModalComponent } from "src/app/core/Dialogues/snackbar-modal/snackbar-modal.component";
import { CourierMode, DiagramMode, OrderItems, OrganizationType, StatusMode } from "src/app/core/Modals/modals";
import { ChargesService } from "src/app/core/Services/charges.service";
import { LoaderService } from "src/app/core/Services/loader.service";
import { MastersService } from "src/app/core/Services/masters.service";
import { SampleOrderService } from "src/app/core/Services/sample-order.service";
import { ValidationService } from "src/app/core/Services/validation.service";
import { MiddyPatternModalComponent } from "../middy-pattern-modal/middy-pattern-modal.component";
import { NickersModelComponent } from "../nickers-model/nickers-model.component";
import { PantPatternModalComponent } from "../pant-pattern-modal/pant-pattern-modal.component";
import { PinofersModelComponent } from "../pinofers-model/pinofers-model.component";
import { ShotsModelComponent } from "../shots-model/shots-model.component";
import { TShirtsPatternModalComponent } from "../t-shirts-pattern-modal/t-shirts-pattern-modal.component";

/**
 * Edit Sample Order Component
 * @export
 * @class EditSampleOrderComponent
 * @implements {OnInit}
 */
@Component({
  selector: 'app-edit-sample-order',
  templateUrl: './edit-sample-order.component.html',
  styleUrls: ['./edit-sample-order.component.scss']
})
export class EditSampleOrderComponent implements OnInit, AfterViewInit {
  /**
   * Get T-Shirts Pattern Modal Component
   * @type {TShirtsPatternModalComponent}
   */
  @ViewChild("tShirtsPatternComponent") tShirtsPatternComponent!: TShirtsPatternModalComponent;

  /**
   * Get Middy Pattern Modal Component
   * @type {MiddyPatternModalComponent}
   */
  @ViewChild("middyPatternModalComponent") middyPatternModalComponent!: MiddyPatternModalComponent;

  /**
   * Get Nickers Pattern Modal Component
   * @type {NickersModelComponent}
   */
  @ViewChild("nickersComponent") nickersComponent!: NickersModelComponent;

  /**
   * Get Nickers Pattern Modal Component
   * @type {ShotsModelComponent}
   */
  @ViewChild("shortsComponent") shortsComponent!: ShotsModelComponent;

  /**
   * Get Nickers Pattern Modal Component
   * @type {ShotsModelComponent}
   */
  @ViewChild("pantComponent") pantComponent!: PantPatternModalComponent;

  /**
   * Get Pinofers Pattern Modal Component
   * @type {PinofersModelComponent}
   */
  @ViewChild("pinofersComponent") pinofersComponent!: PinofersModelComponent;

  /**
   * Get Snackbar Modal Component
   * @type {SnackbarModalComponent}
   */
  @ViewChild("snackbarModalComponent") snackbarModalComponent!: SnackbarModalComponent;

  /**
   * Declare the Pattern Dress Items List
   */
  patternDressItemsList = [
    "T-Shirts",
    "Middy",
    "Nicker",
    "Pant",
    "Pinofers",
    "Shots",
  ];

  /**
   * Declare the Pocket Dress Items List
   */
  pocketDressItemsList = ["Pinofers", "Frock", "T-Shirts"];

  /**
   * Declare the Back Print Dress Items List
   */
  backPrintDressItemsList = ["Frock", "T-Shirts", "Pinofers"];

  /**
   * Get Order Items List
   */
  orderItemsList: OrderItems[] = [];

  /**
   * Get Total Order value
   */
  totalOrderValue = 0;

  /**
   * Get Total Quantity
   */
  totalQuantity = 0;

  /**
   * Get Average Unit Price
   * @type {*}
   */
  avgUnitPrice: any;

  /**
   * Get Saved Order Items List
   */
  savedOrderItemsList: OrderItems[] = [];

  /**
   * Get Master Colors List
   * @type {*}
   */
  masterColorsList: any;

  /**
   * Get Sizes List
   * @type {*}
   */
  sizesList: any;

  /**
   * Get Is Save Order Flag
   */
  isSaveOrder = false;

  /**
   * Get Is Add Order Items Flag
   */
  isAddOrderItems = false;

  /**
   * Get Is Add Pattern Details Flag
   */
  isAddPatternDetails = false;

  /**
   * Get Is Pattern Dress Item Flag
   */
  isPatternDressItem = false;

  /**
   * Get Is Back Print Flag
   */
  isBackPrint = false;

  /**
   * Get Is Print Type Flag
   */
  isPrintType = false;

  /**
   * Get Is TShirt Special Model Flag
   */
  isTShirtSpecialModel = '';

  /**
   * Diagram List
   * @type {DiagramMode[]}
   */
  diagramList: DiagramMode[] = [
    { id: 0, type: "No Image" },
    { id: 1, type: "1" },
    { id: 2, type: "2" },
    { id: 3, type: "3" },
    { id: 4, type: "4" },
    { id: 5, type: "5" },
    { id: 6, type: "6" }
  ];

  /**
   * Selected Diagram
   */
  selectedDiagram: any;

  /**
   * Selected Diagram URL
   */
  diagramURL = '';

  /**
   * Selected Print Type
   */
  selectedPrintType = 2;

  /**
   * Get Selected Method
   */
  selectedMethod: any;

  /**
   * Get Selected Quality
   */
  selectedQuality: any;

  /**
   * Get Selected Pattern
   */
  selectedPattern: any;

  /**
   * Get Dress Items List
   * @type {*}
   */
  dressItemsList: any;

  /**
   * method List
   */
  methodsList: any = [];

  /**
   * quality List
   */
  qualityList: any;

  /**
   * Get Patterns List
   */
  patternsList: any;

  /**
   * Selected Dress Item
   */
  selectedDressItem: any;

  /**
   * Get Organization Types List
   */
  organizationTypeList: OrganizationType[] = [
    { id: "1", type: "School" },
    { id: "2", type: "Showroom" },
  ];

  /**
   * Selected organization
   */
  selectedOrganization: any;

  /**
   * Selected New Dress Item
   */
  selectedNewDressItem: any;

  /**
   * Selected New Method
   */
  selectedNewMethod: any;

  /**
   * Selected New Pattern
   */
  selectedNewPattern: any;

  /**
   * Get Is Changes In Pattern Flag
   */
  isChangesInPattern = '';

  /**
   * Get Edit Sample Order Details
   * @type {*}
   */
  editSampleOrderDetails: any;

  /**
   * Get Latest Sales Tax Name
   * @type {*}
   */
  latestSalesTaxName: any;

  /**
  * Set Min From Date
  * @type {Date}
  */
  minFromDate: Date;

  /**
   * Set Max From Date
   * @type {Date}
   */
  maxFromDate: Date;

  /**
   * Status mode List
   * @type {StatusMode[]}
   */
  statusModesList: StatusMode[] = [
    { id: "1", type: "Not Completed" },
    { id: "2", type: "Completed" },
    { id: "3", type: "Cancelled" },
  ];

  /**
   * courier mode List
   * @type {StatusMode[]}
   */
  courierList: CourierMode[] = [
    { id: "1", type: "DHL" },
    { id: "2", type: "DTDC" },
  ];

  /**
   * Get Selected status
   */
  selectedStatus: any;

  /**
   * Get Selected courier
   */
  selectedCourier: any;

  /**
   * Declare Add Order Form
   * @type {FormGroup}
   */
  addOrderForm!: FormGroup;

  /**
   * Get Courier Flag
   */
  Courier = false;

  /**
   * order Received
   */
  // orderReceived: number = 0;

  /**
   * order Received
   */
  calculatePoints = 0;

  /**
   * Get Is Success Snackbar Flag
   */
  isSuccessSnackbar = false;

  /**
   * Get Is Overlay Visible Flag
   */
  isOverlayVisible = false;

  /**
   * Get Inner HTML Message
   */
  innerHTMLMessage = '';

  /**
   * Get Inner HTML Order Id
   */
  innerHTMLOrderId = '';

  /**
   * Edit Sample Order Form Declaration
   */
  editSampleOrderForm!: FormGroup;

  /**
   * Get Sample Order Form Validations
   */
  editSampleOrderValidation = this.validationService.editSampleOrder;

  /**
   * Get Edit Sample Order Patterns
   * @private
   */
  private patterns = this.validationService.patterns;

  /**
   * Get Add Order Form Validations
   */
  addOrderFormValidation = this.validationService.addOrder;

  /**
   * Creates an instance of EditSampleOrderComponent.
   * @param {Router} router
   * @param {ValidationService} validationService
   * @param {FormBuilder} formBuilder
   * @param {DatePipe} datePipe
   * @param {MastersService} mastersService
   * @param {ChargesService} chargesService
   * @param {SampleOrderService} sampleOrderService
   * @param {LoaderService} loaderService
   */
  constructor(
    private router: Router,
    private validationService: ValidationService,
    private formBuilder: FormBuilder,
    private datePipe: DatePipe,
    private mastersService: MastersService,
    private chargesService: ChargesService,
    private sampleOrderService: SampleOrderService,
    private loaderService: LoaderService
  ) {
    localStorage.removeItem('savedOrdersList');
    /* set Min Date */
    this.minFromDate = new Date();
    this.maxFromDate = new Date();
    const d = new Date();
    d.setDate(1);
    d.setMonth(0);
    d.setFullYear(2012);
    this.minFromDate = d;
    /* Get Sample Order Details from behavior subject*/
    this.sampleOrderService.editSampleOrderDetails.subscribe((val: any) => {
      if (Object.keys(val).length !== 0) {
        this.editSampleOrderDetails = val;
      } else {
        this.editSampleOrderDetails = null;
        this.onClickNavigateToList();
      }
    });
    /* Enable the loader */
    this.loaderService.isLoading.next(true);
  }

  /**
   * Life Cycle Hook Initialization
   */
  ngOnInit(): void {
    this.addOrderFormValidations();
    this.editSampleOrderFormValidations();
    this.getDressItemList();
    this.getColoursList();
    this.getQualityList();
    this.getSaleTax();
  }

  /**
   * Life Cycle Hook After View Init Initialization
   */
  ngAfterViewInit(): void {
    /* Disable the loader */
    this.loaderService.isLoading.next(false);
  }

  /**
   * Life Cycle Hook Destroy
   */
  ngOnDestroy(): void {
    this.sampleOrderService.patternDetailsObj.next({});
    const localStorageKeys = [
      "savedOrdersList",
      "pinofersSpecialModelCollars",
      "pinofersPanelColors",
      "tShirtSpecialModelCollars",
      "tShirtSpecialModelCuffs",
      "tShirtSpecialModelPanel",
      "tShirtsSpecialPatternCollars",
      "tShirtsSpecialPatternCuffs",
      "tShirtsNormalPatternCollar",
      "pantPatternPanelColoursList",
      "middyPatternPanelColoursList",
      "nickerPatternPanelColours",
      "shotsPatternPanelColours"
    ];
    localStorageKeys.forEach((item: string) => {
      localStorage.removeItem(item);
    });
  }

  /**
   * Edit Sample Order Controls Initialized
   * @readonly
   */
  get editSampleOrderFormControls() {
    return this.editSampleOrderForm.controls;
  }

  /**
   * Initialize Edit Sample Order Form Validations
   */
  editSampleOrderFormValidations() {
    let organizationName = '';
    let organizationSelectValue = '';
    let customerId = '';
    let stateName = '';
    let districtName = '';
    let mandalName = '';
    let townName = '';
    let address = '';
    let dressItemId = '';
    let methodId = '';
    let qualityId = '';
    let patternTypeId = '';
    let printTypeId = '';
    let statusSelectValue = '';
    let backPrint1Value = '';
    let backPrint2Value = '';
    let backPrint3Value = '';
    let backPrint4Value = '';
    let diagramIdValue = '';
    let courierValue = '';
    let docketValue = '';
    let courierDateValue: any = '';

    if (this.editSampleOrderDetails) {
      organizationName = this.editSampleOrderDetails?.sampleOrder?.organizationName;
      organizationSelectValue = this.organizationTypeList?.filter((item: any) => item.type == this.editSampleOrderDetails?.sampleOrder?.organizationType)[0]?.id;
      customerId = this.editSampleOrderDetails?.sampleOrder?.customerId;
      stateName = this.editSampleOrderDetails?.sampleOrder?.stateName;
      districtName = this.editSampleOrderDetails?.sampleOrder?.districtName;
      mandalName = this.editSampleOrderDetails?.sampleOrder?.mandalName;
      townName = this.editSampleOrderDetails?.sampleOrder?.townName;
      address = this.editSampleOrderDetails?.sampleOrder?.address;
      methodId = this.editSampleOrderDetails?.sampleOrder?.methodId;
      patternTypeId = this.editSampleOrderDetails?.sampleOrder?.patternTypeId;
      printTypeId = this.editSampleOrderDetails?.sampleOrder?.printtypeId?.toString();
      statusSelectValue = this.editSampleOrderDetails?.sampleOrder?.orderStatusId?.toString() || '';
      courierValue = this.editSampleOrderDetails?.sampleOrder?.courierId?.toString() || '';
      this.onChangeCourier(courierValue);
      docketValue = this.editSampleOrderDetails?.sampleOrder?.docketNo?.toString() || '';
      courierDateValue = this.editSampleOrderDetails?.sampleOrder?.courierDate ? new Date(this.editSampleOrderDetails?.sampleOrder?.courierDate) : '';
    }

    this.editSampleOrderForm = this.formBuilder.group({
      OrganizationName: [
        organizationName,
        [
          Validators.required,
          Validators.minLength(this.editSampleOrderValidation.OrganizationName.minLength),
          Validators.maxLength(this.editSampleOrderValidation.OrganizationName.maxLength),
        ],
      ],
      CustomerId: [customerId],
      organizationSelect: [organizationSelectValue],
      Address: [address],
      StateName: [stateName],
      DistrictName: [districtName],
      MandalName: [mandalName],
      TownName: [townName],
      email: [""],
      dressItemSelect: [dressItemId, [Validators.required]],
      methodSelect: [methodId, [Validators.required]],
      qualitySelect: [qualityId, [Validators.required]],
      patternSelect: [patternTypeId],
      printType: [printTypeId],
      BackPrintOne: [
        backPrint1Value,
        [
          Validators.minLength(this.editSampleOrderValidation.BackPrintOne.minLength),
          Validators.maxLength(this.editSampleOrderValidation.BackPrintOne.maxLength),
        ],
      ],
      BackPrintTwo: [
        backPrint2Value,
        [
          Validators.minLength(this.editSampleOrderValidation.BackPrintTwo.minLength),
          Validators.maxLength(this.editSampleOrderValidation.BackPrintTwo.maxLength),
        ],
      ],
      BackPrintThree: [
        backPrint3Value,
        [
          Validators.minLength(this.editSampleOrderValidation.BackPrintThree.minLength),
          Validators.maxLength(this.editSampleOrderValidation.BackPrintThree.maxLength),
        ],
      ],
      BackPrintFour: [
        backPrint4Value,
        [
          Validators.minLength(this.editSampleOrderValidation.BackPrintFour.minLength),
          Validators.maxLength(this.editSampleOrderValidation.BackPrintFour.maxLength),
        ],
      ],
      diagramSelect: [diagramIdValue],
      deliveryDate: [""],
      statusSelect: [statusSelectValue],
      courierSelect: [courierValue],
      SelectDate: [courierDateValue],
      DocketNo: [docketValue,
        [
          Validators.minLength(this.editSampleOrderValidation.DocketNo.minLength),
          Validators.maxLength(this.editSampleOrderValidation.DocketNo.maxLength),
        ],
      ]
    });

    if (this.editSampleOrderDetails) {
      this.editSampleOrderFormControls['dressItemSelect'].disable({ onlySelf: true });
      this.editSampleOrderFormControls['methodSelect'].disable({ onlySelf: true });
      this.editSampleOrderFormControls['patternSelect'].disable({ onlySelf: true });
      let statusSelectValue = this.editSampleOrderDetails?.sampleOrder?.orderStatusId?.toString();
      this.editSampleOrderFormControls['statusSelect'].setValue(statusSelectValue);
      this.onChangeStatus(this.editSampleOrderDetails?.sampleOrder?.orderStatusId);
      if (+statusSelectValue == 2) {
        this.editSampleOrderFormControls['qualitySelect'].disable({ onlySelf: true });
      }
    }
  }

  /**
   * Initialize Add Order Form Validations
   */
  addOrderFormValidations() {
    this.addOrderForm = this.formBuilder.group({
      colorSelect: ['', [Validators.required]],
      sizeSelect: ['', [Validators.required]],
      quantity: ['', [Validators.required, Validators.pattern(this.patterns.quantity)]],
      unitPrice: ['', [Validators.required, Validators.pattern(this.patterns.orderUnitPrice)]]
    })
  }

  /**
   * Get Add Order Form Controls
   * @readonly
   */
  get addOrderFormControls() {
    return this.addOrderForm.controls;
  }

  /**
   * This method is used to close the snackbar on enter
   */
  @HostListener('document:keypress', ['$event'])
  handleKeyPress(event: KeyboardEvent) {
    if (event.key == 'Enter') {
      this.onClickSnackbarOkButton();
    }
  }

  /**
   * This method is used to get the dress items List
   */
  getDressItemList() {
    this.mastersService.getDressItems().subscribe({
      next: (res: any) => {
        this.dressItemsList = res.result;
        if (this.editSampleOrderDetails) {
          let dressItemId = this.editSampleOrderDetails?.sampleOrder?.dressItemId;
          this.editSampleOrderFormControls['dressItemSelect'].setValue(dressItemId?.toString());
          this.onChangeDressItem(dressItemId, false);
        }
      },
      error: (err: any) => {
        this.dressItemsList = [];
      },
    });
  }

  /**
   * This method is used to get the method List
   * @param {*} eventFlag
   */
  getMethodList(eventFlag: any) {
    this.mastersService.getMethods().subscribe({
      next: (res: any) => {
        this.methodsList = res.result;
        if (eventFlag) {
          let methodIdValue = this.editSampleOrderDetails?.sampleOrder?.methodId;
          this.editSampleOrderFormControls['methodSelect'].setValue(methodIdValue?.toString());
          this.onChangeMethod(methodIdValue, false);
          this.getSizesList(eventFlag);
        }
      },
      error: (err: any) => {
        this.methodsList = [];
      },
    });
  }

  /**
   * This method is used to get the quality List
   */
  getQualityList() {
    this.mastersService.getQualities().subscribe({
      next: (res: any) => {
        this.qualityList = res.result;
        if (this.editSampleOrderDetails) {
          let qualityId = this.editSampleOrderDetails?.sampleOrder?.qualityId;
          this.editSampleOrderFormControls['qualitySelect'].setValue(qualityId?.toString());
          this.onChangeQuality(qualityId);
        }
      },
      error: (err: any) => {
        this.qualityList = [];
      },
    });
  }

  /**
   * This method is used to get the patterns list
   * @param {*} eventFlag
   */
  getPatternsList(eventFlag: any) {
    this.chargesService.getStitchingPatternTypesByDressItemId(this.selectedDressItem.dressItemId?.toString()).subscribe({
      next: (res: any) => {
        this.patternsList = res.result;
        if (eventFlag) {
          if (this.isPatternDressItem) {
            let patternValue = this.editSampleOrderDetails?.sampleOrder?.patternTypeId;
            this.editSampleOrderFormControls['patternSelect'].setValue(patternValue?.toString());
            this.onChangePattern(patternValue, false);
          }

          const obj: any = {};
          if (this.selectedDressItem?.dressItemName == "T-Shirts") {
            if (this.selectedPattern?.patternType === "Special Model") {
              obj.specialModelForTShirt = this.editSampleOrderDetails?.specialModelForTShirt;
            } else if (this.selectedPattern?.patternType === "Special Pattern") {
              obj.specialPatternForTshirt = this.editSampleOrderDetails?.specialPatternForTshirt;
            } else {
              obj.normalPatternforTshirt = this.editSampleOrderDetails?.normalPatternforTshirt;
            }
          } else if (this.selectedDressItem?.dressItemName == "Middy") {
            if (this.selectedPattern?.patternType === "Special") {
              obj.specialforMiddy = this.editSampleOrderDetails?.specialforMiddy;
            } else {
              obj.normalforMiddy = this.editSampleOrderDetails?.normalforMiddy;
            }
          } else if (this.selectedDressItem?.dressItemName == "Pant") {
            obj.patternforPant = this.editSampleOrderDetails?.patternforPant;
          } else if (this.selectedDressItem?.dressItemName == "Nicker") {
            obj.patternforPant = this.editSampleOrderDetails?.patternforPant;
          } else if (this.selectedDressItem?.dressItemName == "Shots") {
            obj.patternforPant = this.editSampleOrderDetails?.patternforPant;
          } else if (this.selectedDressItem?.dressItemName == "Pinofers") {
            obj.patternforPinofer = this.editSampleOrderDetails?.patternforPinofer;
          }
          this.sampleOrderService.patternDetailsObj.next(obj);
        }
      },
      error: (err: any) => {
        this.patternsList = [];
      },
    });
  }

  /**
   * This method is used to get the colours list
   */
  getColoursList() {
    this.mastersService.getColours().subscribe({
      next: (res: any) => {
        this.masterColorsList = res.result;
      },
      error: (err: any) => {
        this.masterColorsList = [];
      },
    });
  }

  /**
   * This method is used to get the sizes list
   * @param {*} eventFlag
   */
  getSizesList(eventFlag: any) {
    /* Prepare the Request Payload */
    const obj = {
      dressItemId: this.selectedDressItem?.dressItemId,
      methodId: this.selectedMethod?.methodId,
    };
    this.mastersService.getDressItemSizesByDressAndMethod(obj).subscribe({
      next: (res: any) => {
        this.sizesList = res.result;
        if (eventFlag) {
          const responseOrderItems = this.editSampleOrderDetails?.orderColours?.map((responseData: any, index: any) => {
            const colour = this.masterColorsList.find((element: any) => +responseData?.colorId === +element?.colourId);
            const size = this.sizesList.find((element: any) => +responseData?.sizeId === +element?.sizeId);

            return {
              id: index,
              colorId: +responseData.colorId,
              colourName: colour?.colourName,
              sizeId: +responseData.sizeId,
              size: size?.sizeName,
              quantity: Number(+responseData.quantity),
              unitPrice: Number(+responseData.unitPrice),
            };
          });

          this.savedOrderItemsList = responseOrderItems || [];
          localStorage.setItem("savedOrdersList", JSON.stringify(this.savedOrderItemsList));

          const totalQty = this.getSavedTotalQuantity();
          this.totalQuantity = totalQty;
          // Calculate order value for each item
          const orderValues = this.savedOrderItemsList.map((item) => item.quantity * item.unitPrice);
          // Calculate the total order value
          this.totalOrderValue = orderValues.reduce((sum, value) => sum + value, 0);
          const totalUnitPrice = (this.totalOrderValue * 100) / (100 + Number(this.latestSalesTaxName));
          this.avgUnitPrice = totalUnitPrice / this.totalQuantity;
        }

      },
      error: (err: any) => {
        this.sizesList = [];
      },
    });
  }

  /**
   * Get sales tax
   */
  getSaleTax() {
    this.mastersService.getSalesTax().subscribe({
      next: (res: any) => {
        const salesTaxArray: any[] = res.result || [];
        if (salesTaxArray.length > 0) {
          salesTaxArray.sort((a, b) => new Date(b.createdDate).getTime() - new Date(a.createdDate).getTime());
          this.latestSalesTaxName = salesTaxArray[0].salesTaxName;
        }
      },
      error: (err: any) => { }
    });
  }

  /**
   * This method is used to add validators
   * @param {*} formControls
   * @param {*} controls
   */
  onAddValidators(formControls: any, controls: any) {
    controls?.forEach((control: any) => {
      formControls[control].addValidators([Validators.required]);
      formControls[control].updateValueAndValidity({ onlySelf: true });
    });
  }

  /**
   * This method is used to remove validators
   * @param {*} formControls
   */
  onRemoveValidators(formControls: any, controls: any) {
    controls?.forEach((control: any) => {
      formControls[control].removeValidators([Validators.required]);
      formControls[control].updateValueAndValidity({ onlySelf: true });
    });
  }

  /**
   * This method is used to update value and validity
   * @param {*} formControls
   */
  onUpdateValueAndValidity(formControls: any, controls: any) {
    controls?.forEach((control: any) => {
      formControls[control].setValue("");
      formControls[control].markAsUntouched({ onlySelf: true });
      formControls[control].updateValueAndValidity({ onlySelf: true });
    });
  }

  /**
  * This method will fired when user selects the status
  * @param {*} event
  */
  onChangeStatus(event: any) {
    let statusValue = event?.target ? +event.target?.value : +event;
    for (const element of this.statusModesList) {
      if (+element.id === +statusValue) {
        this.selectedStatus = element;
      }
    }
    if (+this.selectedStatus?.id === 2) {
      this.Courier = true;
    } else {
      this.Courier = false;
    }
    let isEvent = event?.target;

    if (this.Courier) {
      this.onAddValidators(this.editSampleOrderFormControls, ['courierSelect']);
      this.onAddValidators(this.editSampleOrderFormControls, ['SelectDate']);
      this.onAddValidators(this.editSampleOrderFormControls, ['DocketNo']);
      if (isEvent) {
        this.onUpdateValueAndValidity(this.editSampleOrderFormControls, ['courierSelect', 'SelectDate', 'DocketNo']);
      }
    } else {
      this.onRemoveValidators(this.editSampleOrderFormControls, ['courierSelect']);
      this.onRemoveValidators(this.editSampleOrderFormControls, ['SelectDate']);
      this.onRemoveValidators(this.editSampleOrderFormControls, ['DocketNo']);
      this.onUpdateValueAndValidity(this.editSampleOrderFormControls, ['courierSelect', 'SelectDate', 'DocketNo']);
    }
  }

  /**
   * This method will fired when user selects the courier
   * @param {*} event
   */
  onChangeCourier(event: any) {
    let courierValue = event?.target ? +event.target?.value : +event;
    for (const element of this.courierList) {
      if (+element.id === +courierValue) {
        this.selectedCourier = element;
      }
    }
  }

  /**
   * Set the minimum date selection for ToDate(End Date)
   * @param {Date} e
   */
  setMinDateForToDate(e: Date) {
    const dateFormate: Date = e;
    // this.minToDate = dateFormate;
    // this.userSearchForm.controls["endDate"].setValue("");
  }

  /**
   * This method used to reset Sample Order form
   */
  resetSampleOrder() {
    this.editSampleOrderForm.reset();
    this.editSampleOrderFormValidations();
    this.isBackPrint = false;
    this.Courier = false
    this.router.navigate(["/admin/customer-order/sampleorder/sampleorderlist"]);
  }

  /**
   * This method will fired when user selects the Organization
   * @param {*} event
   */
  organizationChange(event: any) {
    for (const element of this.organizationTypeList) {
      if (element.id === event.target.value) {
        this.selectedOrganization = element;
      }
    }
  }

  /**
   * This method will fired when user selects Dress Item
   * @param {*} event
   * @param {boolean} changeFlag
   */
  onChangeDressItem(event: any, changeFlag: boolean) {
    if (!changeFlag) {

      if (localStorage.getItem("savedOrdersList")) {
        this.selectedNewDressItem = event.target?.value;
        this.isChangesInPattern = 'dressItem';
        document.getElementById("alertModalBtn")?.click();
        return;
      }

      let dressItemSizeValue = event?.target ? +event.target?.value : +event;
      this.isAddOrderItems = false;
      if (event?.target) {
        this.onUpdateValueAndValidity(this.editSampleOrderFormControls, ["methodSelect"]);
        this.selectedMethod = "";
        this.onUpdateValueAndValidity(this.editSampleOrderFormControls, ["qualitySelect"]);
      }
      this.orderItemsList = [];
      this.savedOrderItemsList = [];
      localStorage.removeItem("savedOrdersList");
      this.diagramURL = '';

      for (const element of this.dressItemsList) {
        if (+element.dressItemId === +dressItemSizeValue) {
          this.selectedDressItem = element;
          if (this.selectedDressItem && this.selectedMethod) {
            this.isAddOrderItems = true;
          } else {
            this.isAddOrderItems = false;
          }

        }
      }
      if (event?.target) {
        this.getPatternsList("");
        this.getMethodList("");
      } else {
        this.getMethodList("noEvent");
        this.getPatternsList("noEvent");
      }

      const isDressItemContainsPocket = this.pocketDressItemsList.includes(this.selectedDressItem?.dressItemName);
      if (isDressItemContainsPocket) {
        this.editSampleOrderFormControls['printType'].enable({ onlySelf: true });
        this.editSampleOrderFormControls['printType'].setValue('2');
        this.isPrintType = true;
      } else {
        this.editSampleOrderFormControls['printType'].setValue('');
        this.editSampleOrderFormControls['printType'].disable({ onlySelf: true });
        this.isPrintType = false;
      }
      let noEvent = event?.target;

      if (!noEvent && this.isPrintType) {
        let printTypeId = this.editSampleOrderDetails?.sampleOrder?.printtypeId?.toString();
        this.editSampleOrderFormControls['printType'].setValue(printTypeId?.toString());
        this.printTypeChange(printTypeId);
      }

      const isDressItemContainsBackPrint = this.backPrintDressItemsList.includes(this.selectedDressItem?.dressItemName);
      if (isDressItemContainsBackPrint) {
        this.isBackPrint = true;
        if (!noEvent) {
          let backPrint1Value = this.editSampleOrderDetails?.sampleOrder?.backPrint1 || '';
          let backPrint2Value = this.editSampleOrderDetails?.sampleOrder?.backPrint2 || '';
          let backPrint3Value = this.editSampleOrderDetails?.sampleOrder?.backPrint3 || '';
          let backPrint4Value = this.editSampleOrderDetails?.sampleOrder?.backPrint4 || '';
          let diagramIdValue = this.editSampleOrderDetails?.sampleOrder?.diagramId || '';
          this.editSampleOrderFormControls['BackPrintOne'].setValue(backPrint1Value?.toString());
          this.editSampleOrderFormControls['BackPrintTwo'].setValue(backPrint2Value?.toString());
          this.editSampleOrderFormControls['BackPrintThree'].setValue(backPrint3Value?.toString());
          this.editSampleOrderFormControls['BackPrintFour'].setValue(backPrint4Value?.toString());
          this.editSampleOrderFormControls['diagramSelect'].setValue(diagramIdValue?.toString());
          this.diagramChange(diagramIdValue);
        }
        this.onAddValidators(this.editSampleOrderFormControls, ["BackPrintOne", "BackPrintTwo", "diagramSelect"]);
      } else {
        this.isBackPrint = false;
        this.onRemoveValidators(this.editSampleOrderFormControls, ["BackPrintOne", "BackPrintTwo", "diagramSelect"]);
      }


      this.sampleOrderService.patternDetailsObj.subscribe((val: any) => {
        if (Object.keys(val).length !== 0) {
          if (val?.specialModelForTShirt) {
            const specialModel = val?.specialModelForTShirt;
            if (specialModel?.printingId === 0) {
              this.onHandleSpecialModel("NoBackPrintDetails", false);
            } else if (specialModel?.printingId === 2) {
              if (specialModel.sublimationId === 23 && specialModel.isBackPrint) {
                this.onHandleSpecialModel("NoBackPrintDetails", true);
              } else {
                this.onHandleSpecialModel("NoBackPrintDetails", false);
              }
            } else {
              if (isDressItemContainsBackPrint) {
                this.onHandleSpecialModel("", true);
              }
            }
          }
        }
      });

      const isDressItemContainsPattern = this.patternDressItemsList.includes(this.selectedDressItem?.dressItemName);
      if (isDressItemContainsPattern) {
        this.isPatternDressItem = true;
        this.onAddValidators(this.editSampleOrderFormControls, ["patternSelect"]);
      } else {
        this.isPatternDressItem = false;
        this.onRemoveValidators(this.editSampleOrderFormControls, ["patternSelect"]);
      }
      if (noEvent) {
        this.selectedPattern = "";
        this.isAddPatternDetails = false;
        this.onUpdateValueAndValidity(this.editSampleOrderFormControls, ["patternSelect", "BackPrintOne", "BackPrintTwo", "BackPrintThree", "BackPrintFour", "diagramSelect"]);
      }
    }
  }

  /**
   * This method is used to handle the back print details
   * @param {*} isTShirtSpecialModel
   * @param {*} isBackPrint
   */
  onHandleSpecialModel(isTShirtSpecialModel: any, isBackPrint: any) {
    this.isTShirtSpecialModel = isTShirtSpecialModel;
    this.isBackPrint = isBackPrint;
    this.isPrintType = isBackPrint;

    const controlsToRemove = ["BackPrintOne", "BackPrintTwo", "diagramSelect"];
    const controlsToUpdate = ["BackPrintOne", "BackPrintTwo", "BackPrintThree", "BackPrintFour", "diagramSelect"];

    if (!isBackPrint) {
      this.onRemoveValidators(this.editSampleOrderFormControls, controlsToRemove);
    } else {
      this.onAddValidators(this.editSampleOrderFormControls, controlsToRemove);
    }

    // this.onUpdateValueAndValidity(this.editSampleOrderFormControls, controlsToUpdate);
  }

  /**
   * This method will fired when user selects the method
   * @param {*} event
   * @param {boolean} changeFlag
   */
  onChangeMethod(event: any, changeFlag: boolean) {
    if (!changeFlag) {
      let methodValue = event?.target ? +event.target?.value : +event;
      if (localStorage.getItem("savedOrdersList")) {
        this.selectedNewMethod = methodValue;
        this.isChangesInPattern = 'method';
        document.getElementById("alertModalBtn")?.click();
        return;
      }

      this.isAddPatternDetails = false;
      this.orderItemsList = [];
      this.savedOrderItemsList = [];
      localStorage.removeItem("savedOrdersList");

      for (const element of this.methodsList) {
        if (+element.methodId === +methodValue) {
          this.selectedMethod = element;

        }
      }
      if (this.selectedDressItem && this.selectedMethod) {
        this.isAddOrderItems = true;
      } else {
        this.isAddOrderItems = false;
      }
    }
  }

  /**
   * This method will fired when user selects the quality
   * @param {*} event
   */
  onChangeQuality(event: any) {
    let qualityValue = event?.target ? +event.target?.value : +event;
    if (!this.selectedDressItem && event?.target) {
      this.onUpdateValueAndValidity(this.editSampleOrderFormControls, ["qualitySelect"]);
      this.snackbarModalComponent.onOpenSnackbarModal(false, "Please Select Dress Item", '', '', '');
      return;
    }

    if (!this.selectedMethod && event?.target) {
      this.onUpdateValueAndValidity(this.editSampleOrderFormControls, ["qualitySelect"]);
      this.snackbarModalComponent.onOpenSnackbarModal(false, "Please Select Method", '', '', '');
      return;
    }

    if (this.savedOrderItemsList.length === 0 && event?.target) {
      this.onUpdateValueAndValidity(this.editSampleOrderFormControls, ["qualitySelect"]);
      this.snackbarModalComponent.onOpenSnackbarModal(false, "Please Add Order Items", '', '', '');
      return;
    }

    for (const element of this.qualityList) {
      if (+element.qualityId === +qualityValue) {
        this.selectedQuality = element;
      }
    }
  }

  /**
   * This method will fired when user selects the pattern
   * @param {*} event
   * @param {boolean} changeFlag
   */
  onChangePattern(event: any, changeFlag: boolean) {
    if (!this.selectedMethod && event?.target) {
      this.onUpdateValueAndValidity(this.editSampleOrderFormControls, ["patternSelect"]);
      this.snackbarModalComponent.onOpenSnackbarModal(false, "Please Select Method", '', '', '');
      return;
    }

    if (this.savedOrderItemsList.length === 0 && event?.target) {
      this.onUpdateValueAndValidity(this.editSampleOrderFormControls, ["patternSelect"]);
      this.snackbarModalComponent.onOpenSnackbarModal(false, "Add Order Items", '', '', '');
      return;
    }

    if (!changeFlag) {
      let patternValue = event?.target ? +event.target?.value : +event;
      let selectedPatternDetails = {};
      this.sampleOrderService.patternDetailsObj.subscribe((val: any) => {
        if (Object.keys(val).length > 0) {
          selectedPatternDetails = val;
        } else {
          selectedPatternDetails = {};
        }
      });

      if (Object.keys(selectedPatternDetails).length > 0 && event?.target) {
        this.selectedNewPattern = event.target?.value;
        this.isChangesInPattern = 'pattern';
        document.getElementById("alertModalBtn")?.click();
        return;
      }

      for (const element of this.patternsList) {
        if (+element.patternTypeId === +patternValue) {
          this.selectedPattern = element;
        }
      }
      if (
        this.selectedDressItem &&
        this.selectedMethod &&
        this.selectedPattern &&
        this.savedOrderItemsList.length > 0
      ) {
        this.isAddPatternDetails = true;
      } else {
        this.isAddPatternDetails = false;
      }
    }
  }

  /**
   * This method is used to open the add patterns modal
   */
  onClickAddPatterns() {
    if (this.selectedDressItem?.dressItemName == "T-Shirts") {
      this.tShirtsPatternComponent.openModal(this.selectedPattern, this.selectedDressItem);
    } else if (this.selectedDressItem?.dressItemName == "Pinofers") {
      this.pinofersComponent.openModal(this.selectedPattern, this.selectedDressItem);
    } else if (this.selectedDressItem?.dressItemName == "Middy") {
      this.middyPatternModalComponent.openModal(this.selectedPattern, this.selectedDressItem);
    } else if (this.selectedDressItem?.dressItemName == "Nicker") {
      this.nickersComponent.openModal(this.selectedPattern, this.selectedDressItem);
    } else if (this.selectedDressItem?.dressItemName == "Shots") {
      this.shortsComponent.openModal(this.selectedPattern, this.selectedDressItem);
    } else if (this.selectedDressItem?.dressItemName == "Pant") {
      this.pantComponent.openModal(this.selectedPattern, this.selectedDressItem);
    }
  }

  /**
   * This method is used to change the print type
   * @param {*} event
   */
  printTypeChange(event: any) {
    let printTypeValue = event?.target ? event.target.value : event;
    this.selectedPrintType = +printTypeValue;
  }

  /**
   * This method is used to change the calculate points
   * @param {*} event
   */
  calculatePointsChange(event: any) {
    this.calculatePoints = event.target.value;
  }

  /**
   * This method will fired when user selects the diagram
   * @param {*} event
   */
  diagramChange(event: any) {
    let diagramValue = event?.target ? event.target.value : event;
    for (const element of this.diagramList) {
      if (+element.id === +diagramValue) {
        this.selectedDiagram = element;
      }
    }

    /* Assign diagram URL based on selected diagram */
    if (this.selectedDiagram?.id === 1) {
      this.diagramURL = '../../../../assets/Images/1.jpg';
    } else if (this.selectedDiagram?.id === 2) {
      this.diagramURL = '../../../../assets/Images/2.jpg';
    } else if (this.selectedDiagram?.id === 3) {
      this.diagramURL = '../../../../assets/Images/3.jpg';
    } else if (this.selectedDiagram?.id === 4) {
      this.diagramURL = '../../../../assets/Images/4.jpg';
    } else if (this.selectedDiagram?.id === 5) {
      this.diagramURL = '../../../../assets/Images/5.jpg';
    } else if (this.selectedDiagram?.id === 6) {
      this.diagramURL = '../../../../assets/Images/6.jpg';
    } else {
      this.diagramURL = '';
    }
  }

  /**
   * This method is used to open the add order modal
   */
  onClickOpenAddOrderModal() {
    this.getColoursList();
    this.getSizesList('');
    document.getElementById("addOrderItemModal")?.click();
    this.isSaveOrder = false;
    if (JSON.parse(localStorage.getItem("savedOrdersList")!)) {
      this.orderItemsList = JSON.parse(localStorage.getItem("savedOrdersList")!);
    } else {
      this.orderItemsList = [];
    }
    const modal = document.getElementById("addOrderDetailsForm") as HTMLElement;
    const snackbar = document.getElementById("snackbar") as HTMLElement;
    modal.style.display = "block";
    snackbar.style.zIndex = "9999";
  }

  /**
   * This method is used to get the unique sizes for the table
   * @return {*}  {string[]}
   */
  getUniqueSizes(): string[] {
    return Array.from(new Set(this.savedOrderItemsList.map(item => item.size)));
  }

  /**
   * This method is used to get the unique colors for the table
   * @return {*}  {string[]}
   */
  getUniqueColors(): string[] {
    return Array.from(new Set(this.savedOrderItemsList.map(item => item.colourName)));
  }

  /**
   * This method is used to get the quantity for the table
   * @param {string} color
   * @param {string} size
   * @return {*}  {number}
   */
  getQuantity(color: string, size: string): number {
    const item = this.savedOrderItemsList.find(item => item.colourName === color && item.size === size);
    return item ? parseInt(item.quantity?.toString(), 10) : 0;
  }

  /**
   * This method is used to get the row total for the table
   * @param {string} color
   * @return {*}  {number}
   */
  getRowTotal(color: string): number {
    return this.getUniqueSizes().reduce((total: any, size: any) => total + this.getQuantity(color, size), 0);
  }

  /**
   * This method is used to get the column total for the table
   * @param {string} size
   * @return {*}  {number}
   */
  getColumnTotal(size: string): number {
    return this.getUniqueColors().reduce((total: any, color: any) => total + this.getQuantity(color, size), 0);
  }

  /**
   * This method is used to get the grand total for the table
   * @return {*}  {number}
   */
  getGrandTotal(): number {
    return this.getUniqueSizes().reduce((total, size) => total + this.getColumnTotal(size), 0);
  }

  /**
   * This method is used to change the colour
   * @param {*} event
   */
  onChangeColour(event: any) {
    if (event?.target.value == '') {
      this.addOrderFormControls['colorSelect'].markAsUntouched({ onlySelf: true });
    }
  }

  /**
   * This method is used to change the size
   * @param {*} event
   */
  onChangeSize(event: any) {
    if (event?.target.value == '') {
      this.addOrderFormControls['sizeSelect'].markAsUntouched({ onlySelf: true });
    }
  }

  /**
   * This method is used to add the order items
   */
  onClickAdd() {
    document.getElementById('quantity')?.blur();
    document.getElementById('unitPrice')?.blur();
    if (this.addOrderForm.invalid) {
      this.validationService.validateAllFormFields(this.addOrderForm);
      return;
    }

    if (+this.addOrderFormControls["quantity"].value > 5000) {
      this.showSnackbar("Quantity should not exceed 5000", '', false, true);
      return;
    }

    if (+this.addOrderFormControls["unitPrice"].value > 999) {
      this.showSnackbar("Unit Price should not exceed 999", '', false, true);
      return;
    }

    /* Get Selected Colour */
    const selectedColour = this.masterColorsList.filter((item: any) => (+item.colourId) === (+this.addOrderFormControls['colorSelect'].value));

    /* Get Selected Size */
    const selectedSize = this.sizesList.filter((item: any) => (+item.sizeId) === (+this.addOrderFormControls['sizeSelect'].value));

    let sizeExists = false;
    for (let index = 0; index < this.orderItemsList?.length; index++) {
      const element = this.orderItemsList[index].colourName + this.orderItemsList[index].size;
      if (element == (selectedColour[0].colourName + selectedSize[0].sizeName)) {
        sizeExists = true;
      }
    }

    if (sizeExists) {
      this.showSnackbar("Order Item Already Exists", '', false, true);
      return;
    }

    /* Prepare the orderItem Object */
    const obj = {
      id: this.orderItemsList.length > 0 ? this.orderItemsList.length : 0,
      colorId: +selectedColour[0].colourId,
      sizeId: +selectedSize[0].sizeId,
      size: selectedSize[0].sizeName,
      colourName: selectedColour[0].colourName,
      quantity: Number(this.addOrderFormControls['quantity'].value),
      unitPrice: Number(this.addOrderFormControls['unitPrice'].value),
    };

    /* Push the Order Item */
    this.orderItemsList.push(obj);
    this.addOrderFormValidations();
  }

  /**
   * This method is used to get the orders total quantity
   * @return {*}  {number}
   */
  getTotalQuantity(): number {
    let orderTotalQuantity = 0;
    for (const order of this.orderItemsList) {
      if (order && order.quantity) {
        orderTotalQuantity += order.quantity;
      }
    }
    this.totalQuantity = orderTotalQuantity;
    return orderTotalQuantity;
  }

  /**
   * This method is used to get the saved orders total quantity
   * @return {*}  {number}
   */
  getSavedTotalQuantity(): number {
    let orderTotalQuantity = 0;
    for (const order of this.savedOrderItemsList) {
      if (order && order.quantity) {
        orderTotalQuantity += order.quantity;
      }
    }
    this.totalQuantity = orderTotalQuantity;
    return orderTotalQuantity;
  }

  /**
   * This method is used to delete the order item
   * @param {*} order
   */
  onClickDeleteOrderItem(order: any) {
    this.orderItemsList = this.orderItemsList.filter((item: any) => item.id !== order.id);
    this.orderItemsList = this.orderItemsList.map((item, index) => ({
      ...item,
      id: index,
    }));
  }

  /**
   * This method is used to save the order items
   */
  onClickSaveOrderItems() {
    if (this.orderItemsList.length === 0) {
      if (this.addOrderForm.invalid) {
        this.validationService.validateAllFormFields(this.addOrderForm);
        return;
      }
      this.showSnackbar("Add Order Items", '', false, true);
      document.getElementById('saveButton')?.blur();
      return;
    } else {
      if (this.totalQuantity > 5000) {
        this.showSnackbar("Total Quantity should not exceed 5000", '', false, true);
        document.getElementById('saveButton')?.blur();
        return;
      }
      this.isSaveOrder = true;
    }

    const storedValue: any = this.orderItemsList;
    localStorage.setItem("savedOrdersList", JSON.stringify(storedValue));
    this.savedOrderItemsList = JSON.parse(localStorage.getItem("savedOrdersList")!);
    document.getElementById("closeOrdersModal")?.click();
    // Calculate order value for each item
    const orderValues = this.orderItemsList.map((item) => item.quantity * item.unitPrice);
    // Calculate the total order value
    this.totalOrderValue = orderValues.reduce((sum, value) => sum + value, 0);

    const totalQty = this.getTotalQuantity();
    this.totalQuantity = totalQty;
    const totalUnitPrice = (this.totalOrderValue * 100) / (100 + Number(this.latestSalesTaxName));
    this.avgUnitPrice = totalUnitPrice / this.totalQuantity;
  }

  /**
   * This method is used to close the orders modal
   */
  closeAddOrderModal() {
    this.addOrderForm.reset();
    this.addOrderFormValidations();
  }

  /**
   * This Method used to navigate user to organizationList Page
   */
  navigateToUserList() {
    this.router.navigate(["/admin/customer-order/organizationlist"]);
  }

  /**
   * This method is used to navigate to sample order list
   */
  onClickNavigateToList() {
    this.router.navigate(["/admin/customer-order/sampleorder/sampleorderlist"]);
  }

  /**
   * This method will be fired when user selects no in alert modal
   */
  onClickNo() {
    if (this.isChangesInPattern === 'pattern') {
      this.editSampleOrderFormControls["patternSelect"].setValue(this.selectedPattern?.patternTypeId);
      this.onChangePattern(this.selectedPattern?.patternTypeId, true);
    } else if (this.isChangesInPattern === 'method') {
      this.editSampleOrderFormControls["methodSelect"].setValue(this.selectedMethod?.methodId);
      this.onChangeMethod(this.selectedMethod?.methodId, true);
    } else {
      this.editSampleOrderFormControls["dressItemSelect"].setValue(this.selectedDressItem?.dressItemId);
      this.onChangeDressItem(this.selectedDressItem?.dressItemId, true);
    }
    document.getElementById("closeAlertModal")?.click();
  }

  /**
   * This method will be fired when user selects yes in alert modal
   */
  onClickYes() {
    this.sampleOrderService.patternDetailsObj.next({});
    if (this.isChangesInPattern === 'pattern') {
      this.editSampleOrderFormControls["patternSelect"].setValue(this.selectedNewPattern);
      this.onChangePattern(this.selectedNewPattern, false);
      this.onHandleSpecialModel("", true);
    } else if (this.isChangesInPattern === 'method') {
      localStorage.removeItem("savedOrdersList");
      this.editSampleOrderFormControls["methodSelect"].setValue(this.selectedNewMethod);
      this.onChangeMethod(this.selectedNewMethod, false);
      this.onHandleSpecialModel("", true);
    } else {
      localStorage.removeItem("savedOrdersList");
      this.editSampleOrderFormControls["dressItemSelect"].setValue(this.selectedNewDressItem);
      this.onChangeDressItem(this.selectedNewDressItem, false);
    }
    const isDressItemContainsBackPrint = this.backPrintDressItemsList.includes(this.selectedDressItem?.dressItemName);
    if (isDressItemContainsBackPrint) {
      this.onHandleSpecialModel("", true);
    }
    document.getElementById("closeAlertModal")?.click();
  }

  /**
   * This method is used to show the snackbar
   * @param {string} message
   * @param {*} orderId
   * @param {boolean} successFlag
   * @param {boolean} isModalOverlay
   */
  showSnackbar(message: string, orderId: any, successFlag: boolean, isModalOverlay: boolean) {
    const snackbar = document.getElementById("snackbar") as HTMLElement;
    this.innerHTMLMessage = message;
    this.innerHTMLOrderId = orderId;
    this.isSuccessSnackbar = successFlag;
    this.isOverlayVisible = isModalOverlay;
    snackbar.style.display = "block";
  }

  /**
   * This method is used to hide the snackbar
   */
  onClickSnackbarOkButton() {
    const snackbar = document.getElementById("snackbar") as HTMLElement;
    snackbar.style.display = "none";
    this.innerHTMLOrderId = '';
    this.innerHTMLMessage = '';
    this.isOverlayVisible = false;
    this.isSuccessSnackbar = false;
  }

  /**
   * Edit Sample Order Form Submit
   * @return {*}
   */
  onCreateSampleOrderFormSubmit(): any {
    this.editSampleOrderForm.updateValueAndValidity();

    /** This will return false if form fields are invalid and stop the service calling */
    if (this.editSampleOrderForm.invalid) {
      this.validationService.validateAllFormFields(this.editSampleOrderForm);
      return;
    }

    /* Check whether order items added or not */
    if (this.savedOrderItemsList.length === 0) {
      this.snackbarModalComponent.onOpenSnackbarModal(false, "Add Order Items", '', '', '');
      return;
    }

    /* Prepare Pattern Details Obj */
    let patternDetails: any;
    let patternDetailsInvalid = false;
    if (this.isPatternDressItem) {
      this.sampleOrderService.patternDetailsObj.subscribe((val: any) => {
        if (Object.keys(val).length > 0) {
          patternDetails = val;
          patternDetailsInvalid = false;
        } else {
          patternDetails = {};
          patternDetailsInvalid = true;
        }
      });
    }

    if (patternDetailsInvalid) {
      this.snackbarModalComponent.onOpenSnackbarModal(false, "Add Pattern Details", '', '', '');
      return;
    }

    let orderItemsMisMatch = '';
    const orderItemsColorIdsArray = this.savedOrderItemsList.map((item: any) => item.colorId);

    // Use a Set to store unique colour names
    const uniqueColourNames = new Set(this.savedOrderItemsList.map((item: any) => item.colourName));
    // Create a new array with unique items based on colourName
    const uniqueArray = Array.from(uniqueColourNames).map(colourName => {
      return this.savedOrderItemsList.find((item: any) => item.colourName === colourName);
    });
    const tShirtsColoursList = uniqueArray;

    if (this.selectedDressItem?.dressItemName == "T-Shirts") {

      if (patternDetails?.specialModelForTShirt) {

        /* Check whether special model collar colors present in order items */
        if (patternDetails?.specialModelForTShirt?.specialModelCollars?.length > 0) {
          // Check if each colourId in orderItemsColorIdsArray exists in tShirtColour.colourName of array2
          const tShirtColorsForCollarAllExists = orderItemsColorIdsArray.every((colorId: any) =>
            patternDetails?.specialModelForTShirt?.specialModelCollars.some((item: any) =>
              item.tShirtColorId === colorId
            ));

          if (!tShirtColorsForCollarAllExists) {
            orderItemsMisMatch = 'Add All T-Shirt Collar Colours';
          }

          let responseSpecialModelCollarItems = patternDetails?.specialModelForTShirt?.specialModelCollars?.map((responseData: any, index: any) => {
            const tShirtColour = tShirtsColoursList?.find((element: any) => +responseData?.tShirtColorId === +element?.colorId);
            const collarColour = this.masterColorsList?.find((element: any) => +responseData?.collarColorId === +element?.colourId);
            const stripeColour = this.masterColorsList?.find((element: any) => +responseData?.stripeColorId === +element?.colourId);
            return {
              tShirtColorId: tShirtColour?.colorId,
              collarColorId: +collarColour?.colourId,
              stripeColorId: stripeColour ? +stripeColour?.colourId : 0
            };
          });
          responseSpecialModelCollarItems = responseSpecialModelCollarItems.filter((item: any) => item.tShirtColorId);
          patternDetails.specialModelForTShirt.specialModelCollars = responseSpecialModelCollarItems;

        } else {
          if (patternDetails?.specialModelForTShirt?.collarTypeId && patternDetails?.specialModelForTShirt?.collarTypeId !== 0) {
            orderItemsMisMatch = 'Add T-Shirt Collar Colours';
          }
        }

        /* Check whether special model cuff colors present in order items */
        if (patternDetails?.specialModelForTShirt?.specialModelCuffs?.length > 0) {
          // Check if each colourId in orderItemsColorIdsArray exists in tShirtColour.colourName of array2
          const tShirtColorsForCuffAllExists = orderItemsColorIdsArray.every((colorId: any) =>
            patternDetails?.specialModelForTShirt?.specialModelCuffs.some((item: any) =>
              item.tShirtColorId === colorId
            ));

          if (!tShirtColorsForCuffAllExists) {
            orderItemsMisMatch = 'Add All T-Shirt Cuff Colours';
          }

          let responseSpecialModelCuffItems = patternDetails?.specialModelForTShirt?.specialModelCuffs?.map((responseData: any, index: any) => {
            const tShirtColour = tShirtsColoursList?.find((element: any) => +responseData?.tShirtColorId === +element?.colorId);
            const cuffColour = this.masterColorsList?.find((element: any) => +responseData?.cuffColorId === +element?.colourId);
            const stripeColour = this.masterColorsList?.find((element: any) => +responseData?.cuffStripeColorId === +element?.colourId);
            return {
              tShirtColorId: tShirtColour?.colorId,
              cuffColorId: +cuffColour?.colourId,
              cuffStripeColorId: stripeColour ? +stripeColour?.colourId : 0
            };
          });
          responseSpecialModelCuffItems = responseSpecialModelCuffItems.filter((item: any) => item.tShirtColorId);
          patternDetails.specialModelForTShirt.specialModelCuffs = responseSpecialModelCuffItems;
        } else {
          if (patternDetails?.specialModelForTShirt?.isCuff) {
            orderItemsMisMatch = 'Add T-Shirt Cuff Colours';
          }
        }

      } else if (patternDetails?.specialPatternForTshirt) {

        /* Check whether special pattern collar colors present in order items */
        if (patternDetails?.specialPatternForTshirt?.specialPatternCollars?.length > 0) {
          // Check if each colourId in orderItemsColorIdsArray exists in tShirtColour.colourName of array2
          const tShirtColorsForCollarAllExists = orderItemsColorIdsArray.every((colorId: any) =>
            patternDetails?.specialPatternForTshirt?.specialPatternCollars.some((item: any) =>
              item.tShirtColorId === colorId
            ));

          if (!tShirtColorsForCollarAllExists) {
            orderItemsMisMatch = 'Add All T-Shirt Collar Colours';
          }

          let responseSpecialPatternCollarItems = patternDetails?.specialPatternForTshirt?.specialPatternCollars?.map((responseData: any, index: any) => {
            const tShirtColour = tShirtsColoursList?.find((element: any) => +responseData?.tShirtColorId === +element?.colorId);
            const cuffColour = this.masterColorsList?.find((element: any) => +responseData?.collarColorId === +element?.colourId);
            const stripeColour = this.masterColorsList?.find((element: any) => +responseData?.stripeColorId === +element?.colourId);
            return {
              tShirtColorId: tShirtColour?.colorId,
              collarColorId: +cuffColour?.colourId,
              stripeColorId: stripeColour ? +stripeColour?.colourId : 0
            };
          });
          responseSpecialPatternCollarItems = responseSpecialPatternCollarItems.filter((item: any) => item.tShirtColorId);
          patternDetails.specialPatternForTshirt.specialPatternCollars = responseSpecialPatternCollarItems;

        } else {
          if (patternDetails?.specialPatternForTshirt?.collarTypeId && patternDetails?.specialPatternForTshirt?.collarTypeId !== 0) {
            orderItemsMisMatch = 'Add T-Shirt Collar Colours';
          }
        }

        /* Check whether special pattern cuff colors present in order items */
        if (patternDetails?.specialPatternForTshirt?.specialPatternCuffs?.length > 0) {
          // Check if each colourId in orderItemsColorIdsArray exists in tShirtColour.colourName of array2
          const tShirtColorsForCuffAllExists = orderItemsColorIdsArray.every((colorId: any) =>
            patternDetails?.specialPatternForTshirt?.specialPatternCuffs.some((item: any) =>
              item.tShirtColorId === colorId
            ));

          if (!tShirtColorsForCuffAllExists) {
            orderItemsMisMatch = 'Add All T-Shirt Cuff Colours';
          }

          let responseSpecialPatternCuffItems = patternDetails?.specialPatternForTshirt?.specialPatternCuffs?.map((responseData: any, index: any) => {
            const tShirtColour = tShirtsColoursList?.find((element: any) => +responseData?.tShirtColorId === +element?.colorId);
            const cuffColour = this.masterColorsList?.find((element: any) => +responseData?.cuffColorId === +element?.colourId);
            const stripeColour = this.masterColorsList?.find((element: any) => +responseData?.cuffStripeColorId === +element?.colourId);
            return {
              tShirtColorId: tShirtColour?.colorId,
              cuffColorId: +cuffColour?.colourId,
              cuffStripeColorId: stripeColour ? +stripeColour?.colourId : 0
            };
          });
          responseSpecialPatternCuffItems = responseSpecialPatternCuffItems.filter((item: any) => item.tShirtColorId);
          patternDetails.specialPatternForTshirt.specialPatternCuffs = responseSpecialPatternCuffItems;
        } else {
          if (patternDetails?.specialModelForTShirt?.cuffId && patternDetails?.specialModelForTShirt?.cuffId !== 0) {
            orderItemsMisMatch = 'Add T-Shirt Cuff Colours';
          }
        }

      } else if (patternDetails?.normalPatternforTshirt) {

        /* Check whether normal pattern collar colors present in order items */
        if (patternDetails?.normalPatternforTshirt?.normalPatternCollar?.length > 0) {
          // Check if each colourId in orderItemsColorIdsArray exists in tShirtColour.colourName of array2
          const tShirtColorsForCollarAllExists = orderItemsColorIdsArray.every((colorId: any) =>
            patternDetails?.normalPatternforTshirt?.normalPatternCollar.some((item: any) =>
              item.tShirtColorId === colorId
            ));

          if (!tShirtColorsForCollarAllExists) {
            orderItemsMisMatch = 'Add All T-Shirt Collar Colours';
          }

          let responseNormalCollarItems = patternDetails?.normalPatternforTshirt?.normalPatternCollar?.map((responseData: any, index: any) => {
            const tShirtColour = tShirtsColoursList?.find((element: any) => +responseData?.tShirtColorId === +element?.colorId);
            const collarColour = this.masterColorsList?.find((element: any) => +responseData?.collarColorId === +element?.colourId);
            const stripeColour = this.masterColorsList?.find((element: any) => +responseData?.stripeColorId === +element?.colourId);
            return {
              tShirtColorId: tShirtColour?.colorId,
              collarColorId: +collarColour?.colourId,
              stripeColorId: stripeColour ? +stripeColour?.colourId : 0
            };
          });
          responseNormalCollarItems = responseNormalCollarItems.filter((item: any) => item.tShirtColorId);
          patternDetails.normalPatternforTshirt.normalPatternCollar = responseNormalCollarItems;
        } else {
          if (patternDetails?.normalPatternforTshirt?.collarTypeId && patternDetails?.normalPatternforTshirt?.collarTypeId !== 0) {
            orderItemsMisMatch = 'Add T-Shirt Collar Colours';
          }
        }

      }

    } else if (this.selectedDressItem?.dressItemName == "Pinofers" && patternDetails?.patternforPinofer) {

      /* Check whether special collar colors present in order items */
      if (patternDetails?.patternforPinofer?.specialModelCollars?.length > 0) {
        // Check if each colourId in orderItemsColorIdsArray exists in tShirtColour.colourName of array2
        const pinofersColorsForCollarAllExists = orderItemsColorIdsArray.every((colorId: any) =>
          patternDetails?.patternforPinofer?.specialModelCollars.some((item: any) =>
            item.tShirtColorId === colorId
          ));

        if (!pinofersColorsForCollarAllExists) {
          orderItemsMisMatch = 'Add All T-Shirt Collar Colours';
        }

        let responsePinofersSpecialModelCollarItems = patternDetails?.patternforPinofer?.specialModelCollars?.map((responseData: any, index: any) => {
          const tShirtColour = tShirtsColoursList?.find((element: any) => +responseData?.tShirtColorId === +element?.colorId);
          const collarColour = this.masterColorsList?.find((element: any) => +responseData?.collarColorId === +element?.colourId);
          const stripeColour = this.masterColorsList?.find((element: any) => +responseData?.stripeColorId === +element?.colourId);
          return {
            tShirtColorId: tShirtColour?.colorId,
            collarColorId: +collarColour?.colourId,
            stripeColorId: stripeColour ? +stripeColour?.colourId : 0
          };
        });
        responsePinofersSpecialModelCollarItems = responsePinofersSpecialModelCollarItems.filter((item: any) => item.tShirtColorId);
        patternDetails.patternforPinofer.specialModelCollars = responsePinofersSpecialModelCollarItems;

      } else {
        if (patternDetails?.patternforPinofer?.collarTypeId && patternDetails?.patternforPinofer?.collarTypeId !== 0) {
          orderItemsMisMatch = 'Add T-Shirt Collar Colours';
        }
      }
    }

    if (orderItemsMisMatch) {
      this.snackbarModalComponent.onOpenSnackbarModal(false, orderItemsMisMatch, '', '', '');
      return;
    }


    /* Re-format the saved order items list array */
    let newSavedOrderItemsList = this.savedOrderItemsList.map(
      ({ id, colourName, size, ...rest }) => ({ ...rest })
    );

    /* Prepare the request payload */
    const sampleOrderObj = {
      orderId: this.editSampleOrderDetails?.sampleOrder?.orderId,
      orderNo: this.editSampleOrderDetails?.sampleOrder?.orderNo,
      schoolId: this.editSampleOrderDetails?.sampleOrder?.schoolId,
      organizationName: this.editSampleOrderDetails?.sampleOrder?.organizationName,
      customerId: this.editSampleOrderDetails?.sampleOrder?.customerId,
      organizationType: this.editSampleOrderDetails?.sampleOrder?.organizationType,
      stateName: this.editSampleOrderDetails?.sampleOrder?.stateName,
      districtName: this.editSampleOrderDetails?.sampleOrder?.districtName,
      mandalName: this.editSampleOrderDetails?.sampleOrder?.mandalName,
      townName: this.editSampleOrderDetails?.sampleOrder?.townName,
      address: this.editSampleOrderDetails?.sampleOrder?.address,
      dressItemId: this.selectedDressItem?.dressItemId,
      dressItem: this.selectedDressItem?.dressItemName,
      methodId: this.selectedMethod?.methodId,
      method: this.selectedMethod?.methodName,
      qualityId: this.selectedQuality?.qualityId,
      quality: this.selectedQuality?.qualityName,
      patternTypeId: this.isPatternDressItem ? this.selectedPattern?.patternTypeId : 0,
      patternType: this.isPatternDressItem ? this.selectedPattern?.patternType : '',
      backPrint1: this.isBackPrint ? this.editSampleOrderFormControls["BackPrintOne"].value : "",
      backPrint2: this.isBackPrint ? this.editSampleOrderFormControls["BackPrintTwo"].value : "",
      backPrint3: this.isBackPrint ? this.editSampleOrderFormControls["BackPrintThree"].value : "",
      backPrint4: this.isBackPrint ? this.editSampleOrderFormControls["BackPrintFour"].value : "",
      diagramId: this.isBackPrint ? this.selectedDiagram?.id : 0,
      printtypeId: this.isPrintType ? this.selectedPrintType : 0,
      orderStatusId: +this.selectedStatus?.id,
      orderStatus: this.selectedStatus?.type,
      courierId: this.selectedCourier ? +this.selectedCourier?.id : 0,
      docketNo: this.editSampleOrderFormControls["DocketNo"].value,
      courierDate: this.datePipe.transform(this.editSampleOrderFormControls['SelectDate'].value, "YYYY-MM-dd"),
      orderValue: 0
    };

    /* Prepare the request payload */
    const obj: any = {
      sampleOrder: sampleOrderObj,
      orderColours: newSavedOrderItemsList
    };

    if (this.selectedDressItem?.dressItemName == "T-Shirts") {
      if (this.selectedPattern?.patternType === "Special Model") {
        obj.specialModelForTShirt = patternDetails?.specialModelForTShirt;
      } else if (this.selectedPattern?.patternType === "Special Pattern") {
        obj.specialPatternForTshirt = patternDetails?.specialPatternForTshirt;
      } else {
        obj.normalPatternforTshirt = patternDetails?.normalPatternforTshirt;
      }
    } else if (this.selectedDressItem?.dressItemName == "Middy") {
      if (this.selectedPattern?.patternType === "Special") {
        obj.specialforMiddy = patternDetails?.specialforMiddy;
      } else {
        obj.normalforMiddy = patternDetails?.normalforMiddy;
      }
    } else if (this.selectedDressItem?.dressItemName == "Pant") {
      obj.patternforPant = patternDetails?.patternforPant;
    } else if (this.selectedDressItem?.dressItemName == "Nicker") {
      obj.patternforPant = patternDetails?.patternforPant;
    } else if (this.selectedDressItem?.dressItemName == "Shots") {
      obj.patternforPant = patternDetails?.patternforPant;
    } else if (this.selectedDressItem?.dressItemName == "Pinofers") {
      obj.patternforPinofer = patternDetails?.patternforPinofer;
    }

    console.log('Edit Sample Order', obj);

    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    /* To call the service to edit the sample order by passing the data object */
    this.sampleOrderService.editSampleOrder(obj).subscribe({
      next: (res: any) => {
        /* Disable the loader if response is error */
        this.loaderService.isLoading.next(false);
        this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', 'editSampleOrder');
      },
      error: (err: any) => {
        /* Disable the loader if response is error */
        this.loaderService.isLoading.next(false);
        this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message || err, '', '', '');
      }
    });
  }
}
