import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditSampleOrderComponent } from './edit-sample-order.component';

describe('EditSampleOrderComponent', () => {
  let component: EditSampleOrderComponent;
  let fixture: ComponentFixture<EditSampleOrderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EditSampleOrderComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EditSampleOrderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
