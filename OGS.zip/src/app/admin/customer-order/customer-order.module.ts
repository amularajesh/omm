import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { MatTooltipModule } from "@angular/material/tooltip";
import { AutosizeModule } from "ngx-autosize";
import { BsDatepickerModule } from "ngx-bootstrap/datepicker";

import { CustomerOrderRoutingModule, } from "./customer-order-routing.module";
import { CustomerOrderComponent } from "./customer-order.component";

import { CuttingProgramComponent } from './cutting-program/cutting-program.component';

import { OrderModule } from "ngx-order-pipe";
import { NgSelectModule } from "@ng-select/ng-select";
import { ComponentModule } from "src/app/core/Modules/component.module";
import { NgxPaginationModule } from "ngx-pagination";
import { Ng2SearchPipeModule } from "ng2-search-filter";
import { KnittingDcComponent } from './knitting-dc/knitting-dc.component';

/**
 * Customer Order Module
 * @export
 * @class CustomerOrderModule
 */
@NgModule({
  declarations: [
    CustomerOrderComponent,
    CuttingProgramComponent,
    KnittingDcComponent,
  
  
  ],
  imports: [
    CommonModule,
    CustomerOrderRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    BsDatepickerModule.forRoot(),
    MatTooltipModule,
    AutosizeModule,
    OrderModule,
    NgSelectModule,
    ComponentModule,
    NgxPaginationModule,
    Ng2SearchPipeModule,
  ]
})
export class CustomerOrderModule { }
