import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { KnittingDcComponent } from './knitting-dc.component';
import { KnittingDcListComponent } from './knitting-dc-list/knitting-dc-list.component';
import { KnittingDcGenerateComponent } from './knitting-dc-generate/knitting-dc-generate.component';

const routes: Routes = [
  {
    path: '',
    component: KnittingDcComponent,
    children: [
      { path: '', redirectTo: "knittingDcList", pathMatch: 'full' },
      { path: 'knittingDcList', component: KnittingDcListComponent },
      { path: 'knittingDcGenerate', component: KnittingDcGenerateComponent },

    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class KnittingDcRoutingModule { }
