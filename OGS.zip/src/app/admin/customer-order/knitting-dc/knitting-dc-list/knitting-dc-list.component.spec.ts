import { ComponentFixture, TestBed } from '@angular/core/testing';

import { KnittingDcListComponent } from './knitting-dc-list.component';

describe('KnittingDcListComponent', () => {
  let component: KnittingDcListComponent;
  let fixture: ComponentFixture<KnittingDcListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ KnittingDcListComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(KnittingDcListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
