import { Location } from "@angular/common";
import { Component, OnInit, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";

import { SnackbarModalComponent } from "src/app/core/Dialogues/snackbar-modal/snackbar-modal.component";
import { CustomersService } from "src/app/core/Services/customers.service";
import { LoaderService } from "src/app/core/Services/loader.service";
import { MastersService } from "src/app/core/Services/masters.service";
import { UsersService } from "src/app/core/Services/users.service";
import { ValidationService } from "src/app/core/Services/validation.service";

/**
 * Knitting Dc List Component
 * @export
 * @class KnittingDcListComponent
 * @implements {OnInit}
 */
@Component({
  selector: 'app-knitting-dc-list',
  templateUrl: './knitting-dc-list.component.html',
  styleUrls: ['./knitting-dc-list.component.scss']
})
export class KnittingDcListComponent implements OnInit {
  /**
   * Get Snackbar Modal Component
   * @type {SnackbarModalComponent}
   */
  @ViewChild("snackbarModalComponent") snackbarModalComponent!: SnackbarModalComponent;

  /**
   * Declare Search Obj
   */
  searchObj = {
    financialYear: '',
    orderNo: 0,
    stateId: 0,
    districtId: 0,
    mandalId: 0,
    townId: 0,
    schoolId: 0,
    phoneNo: '',
  };

  /**
   * Get orders List
   * @type {*}
   */
  ordersList: any;

  /**
   * Get financial years List
   * @type {*}
   */
  financialYearsList: any;

  /**
   * Get States List
   * @type {*}
   */
  statesList: any;

  /**
   * Get Districts List
   * @type {*}
   */
  districtsList: any;

  /**
   * Get Mandals List
   * @type {*}
   */
  mandalsList: any;

  /**
   * Get Towns List
   * @type {*}
   */
  townsList: any;

  /**
   * Get Dress Items List
   * @type {*}
   */
  dressItemsList: any;

  /**
   * Get Organizations List
   * @type {*}
   */
  organizationList: any;

  /**
   * Declare Sorting Order Flag
   */
  sortingOrder = false;

  /**
   * Declare Sorting Key Column
   */
  sortingKeyColumn = "orderNo";

  /**
   * Records Count
   */
  recordsCount = 0;

  /**
   * Default Page Number
   */
  currentPage = 1;

  /**
   * Search Term
   */
  searchTerm = "";

  /**
   * Create City Form Declaration
   * @type {FormGroup}
   */
  searchKnittingDcForm!: FormGroup;

  /**
   * Get search orders Validations
   */
  searchKnittingDcValidation = this.validationService.searchDcKnitting;

  /**
   * Get Location Validations
   */
  locationValidation = this.validationService.locationSelect;

  /**
   * Get Create Student Patterns
   * @private
   */
  private patterns = this.validationService.patterns;

  /**
   * Creates an instance of KnittingDcListComponent.
   * @param {Router} router
   * @param {LoaderService} loaderService
   * @param {ValidationService} validationService
   * @param {FormBuilder} formBuilder
   * @param {CustomersService} customerService
   * @param {MastersService} mastersService
   * @param {Location} location
   */
  constructor(
    private router: Router,
    private loaderService: LoaderService,
    private validationService: ValidationService,
    private formBuilder: FormBuilder,
    private customerService: CustomersService,
    private mastersService: MastersService,
    private location: Location
  ) { }

  /**
   * Life Cycle Hook Initialization
   */
  ngOnInit(): void {
    this.searchOrdersFormValidations();
    this.getFinancialYears();
    this.getTowns();
    this.getStates();
  }

  /**
   * Create city Controls Initialized
   * @readonly
   */
  get knittingDcSearchFormControls() {
    return this.searchKnittingDcForm.controls;
  }

  /**
   * Initialize search orders Form Validations
   */
  searchOrdersFormValidations() {
    this.searchKnittingDcForm = this.formBuilder.group({
      financialYear: ["", [Validators.required]],
      stateSelect: [""],
      districtSelect: [""],
      mandalSelect: [""],
      townSelect: [""],
      organizationSelect: [""],
      orderNumber: [
        '',
        [

          Validators.minLength(this.searchKnittingDcValidation.orderNumber.minLength),
          Validators.maxLength(this.searchKnittingDcValidation.orderNumber.maxLength),
          Validators.pattern(this.patterns.number),
        ],
      ],
      MobileNo: [
        "",
        [
          Validators.minLength(this.searchKnittingDcValidation.mobileNo.minLength),
          Validators.maxLength(this.searchKnittingDcValidation.mobileNo.maxLength),
          Validators.pattern(this.patterns.mobileNo),
        ],
      ],
    });
  }

  /**
   * This method used to reset search orders form
   */
  onResetSearchKnittingDcForm() {
    this.searchKnittingDcForm.reset();
    this.districtsList = [];
    this.mandalsList = [];
    this.getTowns();
    this.searchOrdersFormValidations();
  }

  /**
   * This method is used to update value and validity
   * @param {*} formControls
   */
  onUpdateValueAndValidity(formControls: any, controls: any) {
    controls?.forEach((control: any) => {
      formControls[control].setValue("");
      formControls[control].markAsUntouched({ onlySelf: true });
      formControls[control].updateValueAndValidity({ onlySelf: true });
    });
  }

  /**
   * This method is used to get the financial years List
   */
  getFinancialYears() {
    this.customerService.GetFinancialYears().subscribe({
      next: (res: any) => {
        this.financialYearsList = res.result;
        let currentDate = new Date();
        let currentMonth = currentDate.getMonth(); // Month is zero-based
        let currentYear;
        if (currentMonth <= 2) { // January (0) and February (1)
          currentYear = currentDate.getFullYear() - 1;
        } else {
          currentYear = currentDate.getFullYear();
        }
        this.knittingDcSearchFormControls['financialYear'].setValue(currentYear.toString());
        this.onChangeFinancialYear(currentYear);
        this.getKnittingDcList();
      },
      error: () => {
        this.financialYearsList = [];
      },
    });
  }

  /**
   * This method is used to get the states List
   */
  getStates() {
    this.mastersService.getStates().subscribe({
      next: (res: any) => {
        this.statesList = res.result;
      },
      error: () => {
        this.statesList = [];
      }
    });
  }

  /**
   * This method is used to get the towns List
   */
  getTowns() {
    this.mastersService.getTowns().subscribe({
      next: (res: any) => {
        this.townsList = res.result;
      },
      error: (err: any) => {
        this.townsList = [];
      },
    });
  }

  /**
   * This method is used to get the knitting dc list
   */
  getKnittingDcList() {
    /* Enable the loader */
    this.loaderService.isLoading.next(true);
    let currentDate = new Date();
    let currentMonth = currentDate.getMonth(); // Month is zero-based
    let currentYear;
    if (currentMonth <= 2) { // January (0) and February (1)
      currentYear = currentDate.getFullYear() - 1;
    } else {
      currentYear = currentDate.getFullYear();
    }
    this.searchObj.financialYear = currentYear?.toString();

    /* To call the service to get the cutting program list */
    this.customerService.getKnittingDcList(this.searchObj).subscribe({
      next: (res: any) => {
        /* Disable the loader if response is success */
        this.loaderService.isLoading.next(false);
        this.ordersList = res.result;
        this.recordsCount = this.ordersList.length;
      },
      error: (err: any) => {
        /* Disable the loader if response is error */
        this.loaderService.isLoading.next(false);
        this.ordersList = [];
        this.recordsCount = 0;
      }
    });
  }

  /**
   * This method will fired when user selects financial year
   * @param {*} event
   */
  onChangeFinancialYear(event: any) {
    if (event?.target?.value == '') {
      this.knittingDcSearchFormControls["financialYear"].markAsUntouched({ onlySelf: true });
    }
  }

  /**
   * This method will fired when user selects the state
   * @param {*} event
   */
  onChangeState(event: any) {
    this.onUpdateValueAndValidity(this.knittingDcSearchFormControls, ['districtSelect', 'mandalSelect', 'townSelect', 'organizationSelect']);
    this.districtsList = [];
    this.mandalsList = [];
    this.townsList = [];
    this.organizationList = [];

    if (event?.target?.value == '') {
      this.knittingDcSearchFormControls["stateSelect"].markAsUntouched({ onlySelf: true });
      return;
    }

    /* To call the service to get the districts list by passing stateId */
    this.mastersService.getDistrictsByStateId(event?.target?.value?.toString()).subscribe({
      next: (res: any) => {
        this.districtsList = res.result;
      },
      error: () => {
        this.districtsList = [];
      }
    });
  }

  /**
   * This method will fired when user selects the district
   * @param {*} event
   */
  onChangeDistrict(event: any) {
    this.onUpdateValueAndValidity(this.knittingDcSearchFormControls, ['mandalSelect', 'townSelect']);
    this.mandalsList = [];
    this.townsList = [];

    if (event.target?.value == '') {
      this.knittingDcSearchFormControls["districtSelect"].markAsUntouched({ onlySelf: true });
      return;
    }

    /* To call the service to get the mandals list by passing districtId */
    this.mastersService.getMandalsByDistrictId(event?.target?.value?.toString()).subscribe({
      next: (res: any) => {
        this.mandalsList = res.result;
      },
      error: () => {
        this.mandalsList = [];
      }
    });
  }

  /**
   * This method will fired when user selects the mandal
   * @param {*} event
   */
  onChangeMandal(event: any) {
    this.onUpdateValueAndValidity(this.knittingDcSearchFormControls, ['townSelect']);
    this.townsList = [];

    if (event.target?.value == '') {
      this.knittingDcSearchFormControls["mandalSelect"].markAsUntouched({ onlySelf: true });
      return;
    }

    /* To call the service to get the towns list by passing mandalId */
    this.mastersService.getTownsByMandalId(event.target?.value?.toString()).subscribe({
      next: (res: any) => {
        this.townsList = res.result;
      },
      error: () => {
        this.townsList = [];
      }
    });
  }

  /**
   * This method will fired when user selects the city for districts mandal
   * @param {*} event
   */
  cityChange(event: any) {
    this.organizationList = [];
    this.onUpdateValueAndValidity(this.knittingDcSearchFormControls, ["organizationSelect"]);
    if (event.target?.value != '') {
      this.customerService.getOrganizationByTownId(event.target?.value?.toString()).subscribe({
        next: (res: any) => {
          this.organizationList = res.result;
        },
        error: () => {
          this.organizationList = [];
        }
      });
    }
  }

  /**
   * This method is used to change the pagination controls
   * @param {*} event
   */
  onPageChange(event: any) {
    this.currentPage = event;
  }

  /**
   * This method is used to show search results
   */
  navigateToSearchResult() {
    this.currentPage = 1;
  }

  /**
   * This method is used to sort column
   * @param key : value of which column based we need to sort the rows
   */
  sort(key: string) {
    const componentName = this.location.path();
    let value = key;
    sessionStorage.setItem(`${componentName}_property`, value);
    this.sortingKeyColumn = key;
    if (sessionStorage.getItem(componentName + "_order") == "desc") {
      this.sortingOrder = false;
    } else {
      this.sortingOrder = true;
    }
  }

  /**
   * This method is used to submit the search knitting dc form
   */
  onSearchKnittingDcFormSubmit() {
    /** This will return false if form fields are invalid and stop the service calling */
    if (this.searchKnittingDcForm.invalid) {
      this.validationService.validateAllFormFields(this.searchKnittingDcForm);
      return;
    }

    /* Prepare the request payload */
    const obj = {
      financialYear: this.knittingDcSearchFormControls["financialYear"]?.value?.toString(),
      orderNo: this.knittingDcSearchFormControls["orderNumber"]?.value || 0,
      stateId: Number(this.knittingDcSearchFormControls["stateSelect"]?.value) || 0,
      districtId: Number(this.knittingDcSearchFormControls["districtSelect"]?.value) || 0,
      mandalId: Number(this.knittingDcSearchFormControls["mandalSelect"]?.value) || 0,
      townId: Number(this.knittingDcSearchFormControls["townSelect"]?.value) || 0,
      schoolId: Number(this.knittingDcSearchFormControls["organizationSelect"]?.value) || 0,
      phoneNo: this.knittingDcSearchFormControls["MobileNo"]?.value?.toString(),
    };

    this.searchObj = obj;
    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    //method to send payload to service for add district
    this.customerService.getKnittingDcList(this.searchObj).subscribe({
      next: (res: any) => {
        /* Disable the loader if response is success */
        this.loaderService.isLoading.next(false);
        this.ordersList = res.result;
        this.recordsCount = this.ordersList.length;
        this.currentPage = 1;
      },
      error: (err: any) => {
        this.loaderService.isLoading.next(false);
        this.ordersList = [];
        this.recordsCount = 0;
      },
    });
  }

  /**
   * This method is used to navigate to knitting dc generate page
   * @param {*} cutting
   */
  onClickDCgenerate(cutting: any) {
    this.customerService.getKnittingDcById(cutting?.orderId).subscribe({
      next: (res: any) => {
        this.customerService.KnittingDcDetails.next(res.result);
        this.router.navigate(["/admin/customer-order/knittingdc/knittingDcGenerate"]);
      },
      error: (err: any) => {
        this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message || err, '', '', '');
      }
    });
  }
}

