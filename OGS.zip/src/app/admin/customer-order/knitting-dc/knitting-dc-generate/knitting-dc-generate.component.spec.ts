import { ComponentFixture, TestBed } from '@angular/core/testing';

import { KnittingDcGenerateComponent } from './knitting-dc-generate.component';

describe('KnittingDcGenerateComponent', () => {
  let component: KnittingDcGenerateComponent;
  let fixture: ComponentFixture<KnittingDcGenerateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ KnittingDcGenerateComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(KnittingDcGenerateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
