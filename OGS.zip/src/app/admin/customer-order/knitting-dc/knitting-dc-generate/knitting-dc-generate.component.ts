import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { Router } from '@angular/router';
import {
  AlignmentType,
  Document,
  FrameAnchorType,
  Header,
  HeightRule,
  HorizontalPositionAlign,
  ImageRun,
  Packer,
  Paragraph,
  Table,
  TableCell,
  TableRow,
  TextRun,
  VerticalAlign,
  VerticalPositionAlign,
  WidthType
} from 'docx';

import { ModalComponent } from 'src/app/core/Dialogues/Modal/modal.component';
import { SnackbarModalComponent } from 'src/app/core/Dialogues/snackbar-modal/snackbar-modal.component';
import { CustomersService } from 'src/app/core/Services/customers.service';

@Component({
  selector: 'app-knitting-dc-generate',
  templateUrl: './knitting-dc-generate.component.html',
  styleUrls: ['./knitting-dc-generate.component.scss'],
})
export class KnittingDcGenerateComponent implements OnInit {
  /**
   * Get Snackbar Modal Component
   * @type {SnackbarModalComponent}
   */
  @ViewChild("snackbarModalComponent") snackbarModalComponent!: SnackbarModalComponent;

  generateStatus: any;
  Size: any;
  sizesArray: any[] = []
  fromDate: any;

  /**
   * Get cutting program Dress item
   */

  knittingDcOrder: any;

  /**
   * Get Is Success Snackbar Flag
   */
  isSuccessSnackbar = false;

  /**
   * Get Is Overlay Visible Flag
   */
  isOverlayVisible = false;

  /**
   * Get Inner HTML Message
   */
  innerHTMLMessage = '';

  /**
   * Get order Details
   */
  dcGenerateDetails: any;

  /**
   * Get Pattern Details
   * @type {*}
   */
  patternDetails: any;

  /**
   * Creates an instance of KnittingDcGenerateComponent.
   * @param {Router} router
   * @param {MatDialog} matDialog
   * @param {CustomersService} customerService
   */
  constructor(
    private router: Router,
    private matDialog: MatDialog,
    private customerService: CustomersService
  ) {
    this.fromDate = new Date();
    this.customerService.KnittingDcDetails.subscribe((res: any) => {
      if (Object.keys(res).length > 0) {
        this.dcGenerateDetails = res;
        this.getIsDCExist();
        this.knittingDcOrder = res.dressItem;
        this.patternDetails = this.dcGenerateDetails?.patternDetails;
      } else {
        this.onClickNavigateToSearch();
      }
    });

    /* Get snackbar details from behavior subject */
    this.customerService.snackbarDetails.subscribe((res: any) => {
      if (res) {
        this.snackbarModalComponent.onOpenSnackbarModal(res?.flag, res?.message, '', '', '');
      }
    })
  }

  /**
   * Life Cycle Hook Initialization
   */
  ngOnInit(): void { }

  /**
   * This method is used to get the is dc exists
   */
  getIsDCExist() {
    /* To call the service to get the is dc exists by passing the Id */
    this.customerService.getIsDCExist(this.dcGenerateDetails?.orderId).subscribe(
      (res: any) => {
        this.generateStatus = res.result;
      },
      (err: any) => { }
    );
  }

  /**
   * This method is used for navigate to knitting dc list
   */
  onClickNavigateToSearch() {
    this.router.navigate(['/admin/customer-order/knittingdc/knittingDcList']);
  }

  /**
   * This method is used to generate the DC
   */
  onClickGenerateDC() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.data = {
      name: 'knittingDcGenerate',
      title: 'Generate Knitting DC',
      payload: this.dcGenerateDetails?.orderId,
      description: 'Do you want to Generate Knitting DC?',
      cancelButtonText: 'No',
      submitButtonText: 'Yes',
    };
    this.matDialog.open(ModalComponent, dialogConfig);
  }

  /**
   * This method is used to get the unique sizes for the table
   * @return {*}  {Array<{ size: string, value: string }>}
   */
  getUniqueSizes(): Array<{ size: string, value: string }> {
    return Array.from(
      new Set(
        this.patternDetails.map((item: any) => {
          let sizeObj: { size: string, value: string } | undefined;

          // This condition checks for preparing size.
          if (
            ['Xl', '2Xl', '3Xl', '4Xl', '38', '40', '42', '44'].includes(item?.size)
          ) {
            this.Size = '16 X 3.5';
            sizeObj = { size: this.Size, value: item.size };
          } else if (
            ['S', 'M', 'L', '26', '28', '30', '32', '34', '36'].includes(item?.size)
          ) {
            this.Size = '14 X 3';
            sizeObj = { size: this.Size, value: item.size };
          } else if (
            ['4', '5', '6', '18', '20', '22', '24'].includes(item?.size)
          ) {
            this.Size = '12 X 3';
            sizeObj = { size: this.Size, value: item.size };
          } else if (item?.size === 'Corporate') {
            this.Size = '17 X 3.5';
            sizeObj = { size: this.Size, value: item.size };
          }

          return sizeObj;
        }).filter((obj: any) => obj !== undefined) // Filter out undefined objects
      )
    );
  }

  /**
   * This method is used to get the unique colors for the table
   * @return {*}  {string[]}
   */
  getUniqueColors(): string[] {
    return Array.from(
      new Set(this.patternDetails.map((item: any) => item.collarColour))
    );
  }

  /**
   * This method is used to get the unique colors for the table
   * @return {*}  {string[]}
   */
  getUniqueStripColors(): string[] {
    return Array.from(
      new Set(this.patternDetails.map((item: any) => item.stripeColour))
    );
  }

  getColors() {
    const uniqueColors = this.getUniqueColors();
    const uniqueStripColors = this.getUniqueStripColors();

    const color = [];

    for (let index = 0; index < Math.min(uniqueColors.length, uniqueStripColors.length); index++) {
      const element = uniqueColors[index];
      const element2 = uniqueStripColors[index];
      color.push({
        collar: element,
        stripeColour: element2
      });
    }
    return color;
  }

  /**
   * This method is used to get the quantity for the table
   * @param {string} color
   * @param {string} size
   * @return {*}  {number}
   */
  getQuantity(color: string, size: any): number {
    const item = this.patternDetails.find(
      (item: any) => item.collarColour === color && item.size === size.value
    );
    return item ? parseInt(item.quantity?.toString(), 10) : 0;
  }

  /**
   * This method is used to get the row total for the table
   * @param {string} color
   * @return {*}  {number}
   */
  getRowTotal(color: string): number {
    return this.getUniqueSizes().reduce(
      (total: any, size: any) => total + this.getQuantity(color, size),
      0
    );
  }

  /**
   * This method is used to get the column total for the table
   * @param {string} size
   * @return {*}  {number}
   */
  getColumnTotal(size: any): number {
    return this.getUniqueColors().reduce(
      (total: any, color: any) => total + this.getQuantity(color, size),
      0
    );
  }

  /**
   * This method is used to get the grand total for the table
   * @return {*}  {number}
   */
  getGrandTotal(): number {
    return this.getUniqueSizes().reduce(
      (total, value) => total + this.getColumnTotal(value),
      0
    );
  }

  /**
   * This method is used to get the collar colors for the table
   * @return {*}  {string[]}
   */
  getCollarColours(): string[] {
    return Array.from(this.getUniqueColorCombinations(), (combination: any) => combination.collarColour);
  }

  /**
   * This method is used to get the stripe colors for the table
   * @return {*}  {string[]}
   */
  getStripeColours(): string[] {
    return Array.from(this.getUniqueColorCombinations(), (combination: any) => combination.stripeColour);
  }

  /**
   * This method is used to get the unique combinations colors for the table
   * @return {*}  {any[]}
   */
  getUniqueColorCombinations(): any[] {
    const uniqueCombinations: any[] = [];
    this.patternDetails.forEach((detail: any) => {
      const existingCombination = uniqueCombinations.find(
        (combo: any) =>
          combo.collarColour.trim() === detail.collarColour.trim() &&
          combo.stripeColour.trim() === detail.stripeColour.trim()
      );

      if (!existingCombination) {
        uniqueCombinations.push({ ...detail });
      }
    });
    return uniqueCombinations;
  }

  /**
   * This method is to check the stripe colour is present or not
   * @return {*}  {boolean}
   */
  hasStripeColour(): boolean {
    return this.getUniqueColorCombinations().some(combination => !!combination.stripeColour);
  }

  /**
   * This method is used to get the size values for the table
   * @return {*}  {string[]}
   */
  getSizeValues(): string[] {
    const uniqueCategories: Set<string> = new Set<string>();

    this.patternDetails.forEach((detail: any) => {
      const sizeCategory = this.getHeaderForSize(detail.size);
      uniqueCategories.add(sizeCategory);
    });

    return Array.from(uniqueCategories);
  }

  /**
   * This method is used to get the size values for the table
   * @param {string} size
   * @return {*}  {string}
   */
  getHeaderForSize(size: string): any {
    if (this.dcGenerateDetails?.orderTypeId === 1 || this.dcGenerateDetails?.orderTypeId === 0) {
      if (['XL', '2XL', '3XL', '4XL', '38', '40', '42', '44'].includes(size.toUpperCase())) {
        return '16 X 3.5';
      } else if (['S', 'M', 'L', '26', '28', '30', '32', '34', '36'].includes(size.toUpperCase())) {
        return '14 X 3';
      } else if (['4', '5', '6', '18', '20', '22', '24'].includes(size)) {
        return '12 X 3';
      } else {
        return size; // Default to the size itself if not matched
      }
    } else if (this.dcGenerateDetails?.orderTypeId === 2) {
      return '17 X 3.5';
    }
  }

  /**
   * This method is used to get the total quantity values for the table
   * @param {string} collarColour
   * @param {string} stripeColour
   * @param {string} size
   * @return {*}  {number}
   */
  calculateTotalQuantity(collarColour: string, stripeColour: string, size: string): number {
    const sizeCategory = this.getHeaderForSize(size);

    if (sizeCategory === 'Total') {
      return this.patternDetails
        .filter((detail: any) => detail.collarColour === collarColour && detail.stripeColour === stripeColour)
        .reduce((total: any, detail: any) => total + detail.quantity, 0);
    } else {
      return this.patternDetails
        .filter((detail: any) =>
          detail.collarColour === collarColour &&
          detail.stripeColour === stripeColour &&
          this.getHeaderForSize(detail.size) === sizeCategory
        )
        .reduce((total: any, detail: any) => total + detail.quantity, 0);
    }
  }

  /**
   * This method is used to get the column total quantity values for the table
   * @param {string} size
   * @return {*}  {number}
   */
  calculateColumnTotal(size: string): number {
    return this.getUniqueColorCombinations().reduce(
      (total, combination) => total + this.calculateTotalQuantity(combination.collarColour, combination.stripeColour, size),
      0
    );
  }

  /**
   * This method is used to get the grand total quantity values for the table
   * @return {*}  {number}
   */
  calculateGrandTotal(): number {
    return this.patternDetails.reduce((total: any, detail: any) => total + detail.quantity, 0);
  }

  /**
   * This method fired on click of exportToWord
   * @param {*} dcGenerateDetails
   */
  ExportToWord(dcGenerateDetails: any) {
    const tableRows: TableRow[] = [];
    const IMAGE_PATH =
      '/9j/4AAQSkZJRgABAQEAYABgAAD/2wBDAAIBAQIBAQICAgICAgICAwUDAwMDAwYEBAMFBwYHBwcGBwcICQsJCAgKCAcHCg0KCgsMDAwMBwkODw0MDgsMDAz/2wBDAQICAgMDAwYDAwYMCAcIDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAz/wAARCAAuAKADASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD9/K+eP2wv+CqfwM/YYuzYePvG9pB4g2CRdD06J77UiCMqWijB8oEcgylAexrwn/gvd/wVKvv2A/gXp/hnwVdJB8TPHySpZXO0OdFsk+WW7APHmFiEjzxne3Pl4P8AOpK+tfEjxTNM51PXtb1OV55nbzLq6u5DlndjyzseSScnqTX0mUZD9Zh7as7R6d3/AMA8TMc29hL2VJXl+R++t3/wdXfs7W9y6J4T+Mc6qcCSPSNOCv7jdfA/mBUf/EVr+zx/0Jvxn/8ABTpn/wAn1+CGu+BNc8LwiTU9G1XTo2OA11aSQgn6sBVbQ/DuoeJ737NptjeahcbS3lW0LSvgdThQTivf/wBXMDa+v3nj/wBt4u/T7j9+P+IrX9nj/oTfjP8A+CnTP/k+j/iK1/Z4/wChN+M//gp0z/5Pr8H/APhTXjD/AKFTxJ/4LJv/AImqlj8OPEOp3tzbW2g61cXFkwW4iisZXeAnoHAXKk+9H+ruA8/vD+2sX5fcfvX/AMRWv7PH/Qm/Gf8A8FOmf/J9en/s/wD/AAcV/sxfHfXYdNuPEus+Ary5YJF/wlWni0gZj2aeJ5YY/rI6j3r+b7TPB+pat4st9DjtJI9VurhbRLeYeSwlYhQrbsbeSOuK9V/ap/Yi8S/sbGy0/wAb6ho9r4mu4knfRrafz57VGGQJGHyhgCCRnjcuCcnGdTh3A6QTab21NIZzi/isml5H9Zum6lb6xp8F3aTw3VpdRrNDNC4eOZGGVZWHBUgggjgg1PX89/8Awb/f8FZtb/Zs+OOi/CHxrrFxe/DTxldJp+m/apdw8OX8rbYmjZj8kEjkK652qWDjGH3f0IV8hmWXzwdX2ctV0fc+jwWMhiafPHfqgor8Xf8AgqF8N/j1+xt+0j8G9D0v9qj4r6hZfHDxRc6cU8+S2XQY/tVmiiNRMRIFF4cA7f8AVj14+6dI+NfhD/gj18DdM0z9oL48+JPGN14m1e6l03Xtc0m9u7mQLHDutgtutwVRMbgWIBMhxVVMutThOnLmctkk7u2/ToTDG3nKM48qju21byPrmivyq/4LV/8ABRfxbr/7Mfwb8Z/A3xp4l0T4M/EHUryDxF440DTbiG+s44Z44FRfMWKaElhdEDMbSNAAHA+95n+zR+0l8QNE/Zc/aUvvCH7VkXxm8HaN4EudV0WbVLvUbXxz4ev1WPExiuYyywhmlQslxImVhZdpYrWtPJ6kqKqt2u7Ws+9tdLJ+TInmUFUdNK+l76dr6d15n7Q0V+Qn7D//AAXu1z4S/Bn4FaB8T/h78Qde0bxlLJpd38TNTvG8q9uzeyoxhR4j9pSAPEjt5ysNjhUbYN3T+Ev+Ci3hD9lL9pX9tvxzZ+GviFrup+Cb/T21ey1LxWkun3ZXUF05PscX2cG3AM2752lwqhF2iplk+IjKUWvTbX3uXvoOOZUZJST9fLS/zP1Uor8r/wBpH/gtz8V/H/8AwTw8b/E34cfB7xn8Pba1bRE0fxff+TdW4S5eT7XcJFPbGKWKKWBbUMC283iPhNuK2PBv/BdjxB8Ff2Dfg74i+Ifw713xB8UPibcNpmiW8t9a6XbeJliS036m84jENrFI92iqojIBVs7VBIn+yMTy3sr3ta6vtf0/HTqV/aVC9r6WveztvY/Tiivn/wDYH/bZ1r9srwzr83iH4UeM/hZq3h26S3kh1aMz6fqStvAksr0IkV0oMbBjGMDKHJDg19AVwVacqcnCe6OunUjOPNHY/mx/4OQ/H174x/4KueMtOundoPCmlaVpdmGPCRPZRXZA9vMupD9Sa+af2D9UuNH/AG2fhJNazPBL/wAJhpSbkODta7iVh9CpIPsa+8f+Dpf9lTUPAH7WegfFi2tnfQfH+mRWF1OBxFqNouzYx7brfySuevlyY+6a+Cv2Hhbw/tg/DS7vL2206x0vxJY6jdXNxu2QwwTpNIcKrMTtQ4ABr9KwE4zy6Lj/AC2+dtfxPh8ZGUcbLm/m/XQ/Rf8AaP8A2z/FHgb/AILHN8N9Wlt/EXw08U+IxoOpeHtRt0ntHt7m+e3IVSPlKqFwR0wfWuE0n9jC6/Zj/wCC+fhTwx8OoWt/Duk+J9N1C4Q3ccS22mzXixSxMZGG8MhKbBlm3YAJrf8AidoPw38bf8FXJvjf4g+InhuH4eeG9WbX44k85b3U3jupp4Yo0kjRckmMnLZxnAJ4rxnSP2xrD9pv/gtB4W+Kd/q9v4c8M2Piqx1S4lm850Fla3S3BjCxozudoIHyjJGfl7efShLltTVlya6denzOupOPN77159PT/I+p/wBqz4jftBfB/wDae+KXjXw34t0C18F/Dea71WTS5tQs7xr5W1SW3jt2t43aVFEcsX31ULtA6jFfH3/BNj/goDf/AA//AOCnOleNvE175eh+PNTbTtfSQgxCG5YqJHzwfLdlkJ68E969L/aT+E3hj9pT9vXW/Eq/F/RPDXgDxBqV22o3UVtqX2mezl1C4nKCJbbBYxyJwxxn6V8Y/tO/B/S/gT8XrrT/AA34hh8SaGkzNp2oojxNOitgOUdVdc8Hle5GTgmunB0KU6bpTWso9rf076mOJq1IzVSL0T73Ppr4+/sh6j4c/wCCuuo6Fq7yXGmafqUmu39zIf8AVWdqnnuXboC0aIw9RNH3NfMf7XHx7v8A9pT9oHxJ4sv5nmOoXcnklj0jDHH0zycdBnA4Ar9GP24v2lPC3xP/AGHNE8YeH9Y068+MGueC7LQ/FMMSSq6RQFWeQSMiqzsFRmIbJ8iNfm6V+TtdOXOVSPPUWsVy/wCb+ZhjVGD5YPR6/wCQ+3uJLS4SWJ3jljYOjocMjDkEHsa/sF/Zv8b3XxM/Z38BeJL7JvfEHhzT9SuMj/lpNbRyN+rGv5Mf2ZfgBrf7U/x/8JfD3w7C0ureLNSisYiFyIEJzJM3+xHGHkb/AGUNf14eD/Ctn4F8JaXomnIY9P0ezisbZCclIokCIP8AvlRXg8WTj+7h11+7Q9fh6Mvfl00PkP8A4Kkf8E7PG37bnx6/Z18U+FNU8Lafp/wi8Ry6xrEerXM8U1zC1xp8oW3EcMgZ9tpJw5QZZeeSR9hav4esPECIt/Y2d6sZJQXEKyBCeuNwOKwPjh8VYPgj8J9c8VXFpLfx6Nb+aLaNwhmcsFRSzcICzLljwoycHFcPqX7XMHw6uLnT/HOjLpGtWsF1eGHSNQTVbaS3gm0+IsJCsLq5bUrf5JIkb5XPK7Gf5Sdec4RpvaN7fN3PoY0oxnKa3lv8tDy7/go9+xV8XPjmngzXPgT8UH+HWueD5pPP0C7up4vDXiGF2V9l3bxB0fBDDDxOrrIwOMA18n/Cj/ghJ8XNRu/jh438d+Ivhdp/j34neDLvwzpek+F7SSw0S0luEhQzT+XbpsAEK5EcTlmdnLFuv3Jd/wDBQ/wxFq9pFHomvCzGo3tlqdxObeJ9KjtrK5vGneHzTLgx2spCMqyYUnbkory3H/BRHwdaXUVrJonjJdRM629zZDT42msHeSxjiEuJSv7xtSstu0t/rxnG1tvVRzHEUqfs4W+5X3va5hUwVKpPnlf79Ox8YfE7/giL8VvGn7AP7N/wqtfEHw9j8Q/B/Xr3VNZuJb68FlcxTXks6i3YWpdmCuAQ6IM55I5pvxU/4Ih/Ffxxrv7X11aeIPh7HH8f7q2m8PCa+vAbNYtYivm+14tTsPlIQPL8z5iB0+avs34iftwS6T4Z8K6z4V8Lwa5p2v8Ah3VvFF1/amrHSprG0042wmjVRBMsk5NwQFZ40zGcyYOQ9v8Agov4El/t37LY+KLxdB2CWSOxRIpCZo4ZB5jyKkXlSSqHacxrwxUsFJGizbEra299u8ub80Q8uoP7rfhb8jzvx1/wTn8R/EL/AII2W37ONzrWiWfiuDwpYaQdRiaWXTjd2ksMy/MUWTymeEKW8vcAxO0kYPgHiL/glf8AtF+P/wBgH4X/AA71uf4A6trvwyu5baLSNZ02a+03UtMWOEQZu/IFzb3I2TI/kbVkR0O9GWvr+2/4KIeEDeXaGy1q8SG4jw9jbpKILaRNP8ueUl1GGk1GFMRlz1bG1SwD/wAFH/Aq+HpNSbTfFUUEbWrHzrOGFRBcJdNHcmR5RGsRNlcJ8zhy6AKrbl3ZU8wrw2t8XNt1Zc8FSnv2t8jxj/gjT/wS58Yf8E9br4i614t13w5HN8QLqK4i8LeGHu5NF0JUaVh5b3JMrsBKIxuyQsYy8mcj7npFcOoIIIIyCO9LXNicROvUdWpuzejRjSgqcNkeeftT/sueDv2yfghrPw/8dab/AGjoOsoMlCFns5V5juIXwdkqHkNg9wQVJU/z7/tvf8G+Xx4/ZV8U31z4S0K++KXg0OzWeo6BAZr9I+yz2a5lV8ZyYxInH3hnA/pLorty7Nq+DdoaxfRnLjcupYnWej7n8gF7+zL8T7Sdobj4fePI5EOGjk0K7DKfcFKhX9mz4kIcjwD43B9Rod1/8RX9gtFe1/rZP/n2vv8A+AeX/q9H+f8AA/j9/wCGc/iX/wBCJ45/8El1/wDEU1/2bfiRIfm8A+Nz9dDuv/iK/sEoo/1sn/z7X3/8AP8AV6P8/wCH/BP4/P8AhnH4lbcf8IH44x0x/Yl1/wDEV6X+z9/wSo/aF/aX16Cy8NfCnxfHBM4VtR1WwfTNPiHdjPcBEOByQpZvRSSBX9XFFTPiuq17tNJ+v/DFR4ep396bPh3/AIJBf8EYPDv/AATZ0CfxDrl3Z+KviprEHkXeqxRn7LpcJwTb2gYBsEgb5GAZ8AYUZB+4qKK+axGIqV6jq1Xds9yjRhSgoU1ZFXWtFs/Emj3Wn6ha219YX0LW9zbXEQkiuI2BVkdSCGUgkEEYINcPD+yd8MoNE0/TU8BeE1sdJnlurOEaZFtt5ZdvmSL8vDNsTJ6ny0/ujHoVFYGpxFp+zZ8P7BiYfBnhqIm8/tA7dPiH7/ZJHv6f3JZVx0xI4xhjldG/Zt8AeHbO3t7Dwb4cs4bUgxJDYRoEInhuARgdRNbwP9YY/wC6K7aii4HD+JP2aPh94w07RrTVfBnhzUrTw75n9mwXNhHLFZeYyvIEUggBmRCRjB2jNP1n9nHwD4h1TVL298HeHbm81pke+newjMlyysrKzNjO7ciHPXKKewrtaKLsDyHx7+w78O/Ht9oMjaNb6Xb6BcLcxWun2tvDFMVNrtViYmdAFsrdMwtG2yPbnbxXR6n+zD8O9a09bS78FeGrm2WGK3EUthGyiOIThEwR90C5uBjpieQdGNd3RRdgIqhFAAwBwAO1LRRQB//Z';

    const stripeHeading = this.hasStripeColour()
    const grandTotal = this.calculateGrandTotal();
    const formattedGrandTotal = grandTotal.toLocaleString('en-IN')

    //Logo
    const image = new Header({
      children: [
        new Paragraph({
          children: [
            new ImageRun({
              data: IMAGE_PATH,
              transformation: {
                width: 130,
                height: 40,
              },
            }),
          ],
        }),
      ],
    });

    // Header
    const additionalInfo = new Paragraph({
      alignment: AlignmentType.CENTER,

      children: [
        new TextRun({
          text: `DEV T-SHIRTS Pvt. Ltd.`,
          bold: true,
          font: 'Arial Black',
          color: '#000000',
          size: 40,
        }),
      ],
    });

    const emptypara = new Paragraph({
      alignment: AlignmentType.CENTER,
      children: [
        new TextRun({
          text: ``,
        }),
      ],
    });

    // Header
    const subhead = new Paragraph({
      alignment: AlignmentType.CENTER,

      children: [
        new TextRun({
          text: `Knitting Unit DC`,
          bold: true,
          font: 'Arial Black',
          color: '#000000',
          size: 32,
        }),
      ],
    });
    //dc Name
    const DcNo = new Paragraph({

      frame: {
        position: {
          x: 7380,
          y: 800,
        },
        width: 3000,
        height: 400,
        anchor: {
          horizontal: FrameAnchorType.MARGIN,
          vertical: FrameAnchorType.MARGIN,
        },
        alignment: {
          x: HorizontalPositionAlign.LEFT,
          y: VerticalPositionAlign.TOP,
        },
      },

      children: [
        new TextRun({
          text: 'DC No: ',
          bold: true,
          font: 'Arial',
        }),
        new TextRun({
          text: `${dcGenerateDetails?.kdcName}`,
          font: 'Arial',
        }),
      ],
    });
    //unit name
    const UnitName = new Paragraph({
      frame: {
        position: {
          x: 0,
          y: 1200,
        },
        width: 6900,
        height: 350,
        anchor: {
          horizontal: FrameAnchorType.MARGIN,
          vertical: FrameAnchorType.MARGIN,
        },
        alignment: {
          x: HorizontalPositionAlign.LEFT,
          y: VerticalPositionAlign.TOP,
        },
      },

      children: [
        new TextRun({
          text: 'Unit Name: ',
          bold: true,
          font: 'Arial',
        }),
        new TextRun({
          text: `__________`,
          font: 'Arial',
        }),
      ],
    });
    //Date
    const Date = new Paragraph({
      frame: {
        position: {
          x: 7380,
          y: 1200,
        },
        width: 4500,
        height: 250,
        anchor: {
          horizontal: FrameAnchorType.MARGIN,
          vertical: FrameAnchorType.MARGIN,
        },
        alignment: {
          x: HorizontalPositionAlign.CENTER,
          y: VerticalPositionAlign.TOP,
        },
      },

      children: [
        new TextRun({
          text: 'Date: ',
          bold: true,
          font: 'Arial',
        }),
        new TextRun({
          // text: dcGenerateDetails?.kdcDate,
          text: '',

          font: 'Arial',
        }),
        new TextRun({
          text: dcGenerateDetails?.kdcDate,
          font: 'Arial',
        }),
      ],
    });
    //orderNo
    const OrderNo = new Paragraph({
      frame: {
        position: {
          x: 0,
          y: 800,
        },
        width: 6500,
        height: 400,
        anchor: {
          horizontal: FrameAnchorType.MARGIN,
          vertical: FrameAnchorType.MARGIN,
        },
        alignment: {
          x: HorizontalPositionAlign.RIGHT,
          y: VerticalPositionAlign.TOP,
        },
      },

      children: [
        new TextRun({
          style: AlignmentType.END,
          text: 'Order No: ',
          bold: true,
          font: 'Arial',
        }),
        new TextRun({
          style: AlignmentType.END,
          text: dcGenerateDetails?.orderNo,
          font: 'Arial',
        }),
      ],
    });


    // Create table headers if stripecolor present
    const tableHeader = new TableRow({
      height: {
        value: 400,
        rule: HeightRule.EXACT,
      },
      children: [
        new TableCell({
          width: {
            size: 3505,
            type: WidthType.DXA,
          },
          verticalAlign: VerticalAlign.CENTER,
          shading: {
            fill: 'DBDBDB', // Specifying the background color
          },
          children: [
            new Paragraph({
              children: [
                new TextRun({
                  text: 'Collar Colour',
                  bold: true,
                  color: '#000000',
                  font: 'Arial',
                }),
              ],
              alignment: AlignmentType.CENTER, // Center align the text vertically
            }),
          ],
        }),
        new TableCell({
          width: {
            size: 3505,
            type: WidthType.DXA,
          },
          verticalAlign: VerticalAlign.CENTER,
          shading: {
            fill: 'DBDBDB', // Specifying the background color
          },
          children: [
            new Paragraph({
              children: [
                new TextRun({
                  text: 'Stripe Colour',
                  bold: true,
                  color: '#000000',
                  font: 'Arial',
                }),
              ],
              alignment: AlignmentType.CENTER, // Center align the text vertically
            }),
          ],
        }),
        // Dynamically generate cells for each unique size
        ...this.getSizeValues().map(
          (size) =>
            new TableCell({
              width: {
                size: 2000, // Adjust the width as needed
                type: WidthType.DXA,
              },
              verticalAlign: VerticalAlign.CENTER,
              shading: {
                fill: 'DBDBDB', // Specifying the background color
              },
              children: [
                new Paragraph({
                  children: [
                    new TextRun({
                      text: `${this.getHeaderForSize(size)}`,
                      bold: true,
                      font: 'Arial',
                      color: '#000000',
                    }),
                  ],
                  alignment: AlignmentType.CENTER, // Center align the text vertically
                }),
              ],
            })
        ),
        // Last cell for "Total"
        new TableCell({
          width: {
            size: 2000,
            type: WidthType.DXA,
          },
          verticalAlign: VerticalAlign.CENTER,
          shading: {
            fill: 'DBDBDB', // Specifying the background color
          },
          children: [
            new Paragraph({
              children: [
                new TextRun({
                  text: 'Total Quantity',
                  bold: true,
                  font: 'Arial',
                  color: '#000000',
                }),
              ],
              alignment: AlignmentType.CENTER, // Center align the text vertically
            }),
          ],
        }),
      ],
    });


    // Create table headers if stripecolor not present
    const tableHeaderStripe = new TableRow({
      height: {
        value: 400,
        rule: HeightRule.EXACT,
      },
      children: [
        new TableCell({
          width: {
            size: 3505,
            type: WidthType.DXA,
          },
          verticalAlign: VerticalAlign.CENTER,
          shading: {
            fill: 'DBDBDB', // Specifying the background color
          },
          children: [
            new Paragraph({
              children: [
                new TextRun({
                  text: 'Collar Colour',
                  bold: true,
                  color: '#000000',
                  font: 'Arial',
                }),
              ],
              alignment: AlignmentType.CENTER, // Center align the text vertically
            }),
          ],
        }),

        // Dynamically generate cells for each unique size
        ...this.getSizeValues().map(
          (size) =>
            new TableCell({
              width: {
                size: 2000, // Adjust the width as needed
                type: WidthType.DXA,
              },
              verticalAlign: VerticalAlign.CENTER,
              shading: {
                fill: 'DBDBDB', // Specifying the background color
              },
              children: [
                new Paragraph({
                  children: [
                    new TextRun({
                      text: `${this.getHeaderForSize(size)}`,
                      bold: true,
                      font: 'Arial',
                      color: '#000000',
                    }),
                  ],
                  alignment: AlignmentType.CENTER, // Center align the text vertically
                }),
              ],
            })
        ),
        // Last cell for "Total"
        new TableCell({
          width: {
            size: 2000,
            type: WidthType.DXA,
          },
          verticalAlign: VerticalAlign.CENTER,
          shading: {
            fill: 'DBDBDB', // Specifying the background color
          },
          children: [
            new Paragraph({
              children: [
                new TextRun({
                  text: 'Total Quantity',
                  bold: true,
                  font: 'Arial',
                  color: '#000000',
                }),
              ],
              alignment: AlignmentType.CENTER, // Center align the text vertically
            }),
          ],
        }),
      ],
    });

    //adding header to table rows if stripecolor present
    if (stripeHeading) {
      tableRows.push(tableHeader);
    }

    //adding header to table rows if stripecolor not present
    if (!stripeHeading) {
      tableRows.push(tableHeaderStripe);
    }

    //Create table body rows if stripecolor present
    if (stripeHeading) {
      this.getUniqueColorCombinations().forEach((item: any, index: number) => {
        const rowTotal = this.calculateTotalQuantity(item.collarColour, item.stripeColour, 'Total');
        let RowTotal = rowTotal.toLocaleString('en-IN')
        const row = new TableRow({
          height: {
            value: 300,
            rule: HeightRule.EXACT,
          },
          children: [
            // Dynamically generate cells for each unique size
            new TableCell({
              margins: {
                left: 100,
              },
              width: {
                size: 2000, // Adjust the width as needed
                type: WidthType.DXA,
              },
              verticalAlign: VerticalAlign.CENTER,
              children: [
                new Paragraph({
                  children: [
                    new TextRun({
                      text: `${item.collarColour}`,
                      font: 'Arial',
                      color: '#000000',
                    }),
                  ],
                  alignment: AlignmentType.LEFT, // Center align the text vertically
                }),
              ],
            }),
            new TableCell({
              margins: {
                left: 100,
              },
              width: {
                size: 2000, // Adjust the width as needed
                type: WidthType.DXA,
              },
              verticalAlign: VerticalAlign.CENTER,
              children: [
                new Paragraph({
                  children: [
                    new TextRun({
                      text: `${item.stripeColour}`,
                      font: 'Arial',
                      color: '#000000',
                    }),
                  ],
                  alignment: AlignmentType.LEFT, // Center align the text vertically
                }),
              ],
            }),
            ...this.getSizeValues().map((size) => {
              const quantity = this.calculateTotalQuantity(item.collarColour, item.stripeColour, size);
              const Quantity = quantity.toLocaleString('en-IN')
              return new TableCell({
                margins: {
                  right: 100,
                },
                width: {
                  size: 2000, // Adjust the width as needed
                  type: WidthType.DXA,
                },
                verticalAlign: VerticalAlign.CENTER,
                children: [
                  new Paragraph({
                    children: [
                      new TextRun({
                        text: `${Quantity}`,
                        font: 'Arial',
                        color: '#000000',
                      }),
                    ],
                    alignment: AlignmentType.RIGHT, // Center align the text vertically
                  }),
                ],
              });
            }),
            new TableCell({
              margins: {
                right: 100,
              },
              width: {
                size: 2000, // Adjust the width as needed
                type: WidthType.DXA,
              },
              verticalAlign: VerticalAlign.CENTER,
              children: [
                new Paragraph({
                  children: [
                    new TextRun({
                      text: `${RowTotal}`,
                      font: 'Arial',
                      color: '#000000',
                    }),
                  ],
                  alignment: AlignmentType.RIGHT, // Center align the text vertically
                }),
              ],
            }),
          ],
        });
        tableRows.push(row);
      });
    }
    //Create table body rows if stripecolor not present
    if (!stripeHeading) {
      //Create data rows from the inwardFabricList array
      this.getUniqueColorCombinations().forEach((item: any, index: number) => {
        const rowTotal = this.calculateTotalQuantity(item.collarColour, item.stripeColour, 'Total');
        let RowTotal = rowTotal.toLocaleString('en-IN')
        const row = new TableRow({
          height: {
            value: 300,
            rule: HeightRule.EXACT,
          },
          children: [
            // Dynamically generate cells for each unique size
            new TableCell({
              margins: {
                left: 100,
              },
              width: {
                size: 2000, // Adjust the width as needed
                type: WidthType.DXA,
              },
              verticalAlign: VerticalAlign.CENTER,
              children: [
                new Paragraph({
                  children: [
                    new TextRun({
                      text: `${item.collarColour}`,
                      font: 'Arial',
                      color: '#000000',
                    }),
                  ],
                  alignment: AlignmentType.LEFT, // Center align the text vertically
                }),
              ],
            }),

            ...this.getSizeValues().map((size) => {
              const quantity = this.calculateTotalQuantity(item.collarColour, item.stripeColour, size);
              let Quantity = quantity.toLocaleString('en-IN');
              return new TableCell({
                margins: {
                  right: 100,
                },
                width: {
                  size: 2000, // Adjust the width as needed
                  type: WidthType.DXA,
                },
                verticalAlign: VerticalAlign.CENTER,
                children: [
                  new Paragraph({
                    children: [
                      new TextRun({
                        text: `${Quantity}`,
                        font: 'Arial',
                        color: '#000000',
                      }),
                    ],
                    alignment: AlignmentType.RIGHT, // Center align the text vertically
                  }),
                ],
              });
            }),
            new TableCell({
              margins: {
                right: 100,
              },
              width: {
                size: 2000, // Adjust the width as needed
                type: WidthType.DXA,
              },
              verticalAlign: VerticalAlign.CENTER,
              children: [
                new Paragraph({
                  children: [
                    new TextRun({
                      text: `${RowTotal}`,
                      font: 'Arial',
                      color: '#000000',
                    }),
                  ],
                  alignment: AlignmentType.RIGHT, // Center align the text vertically
                }),
              ],
            }),
          ],
        });
        tableRows.push(row);
      });
    }

    //Create table Footer
    const tableFooter = new TableRow({
      height: {
        value: 300,
        rule: HeightRule.EXACT,
      },
      children: [
        new TableCell({
          margins: {
            right: 100,
          },
          width: {
            size: 3505, // Adjust the width as needed
            type: WidthType.DXA,
          }, columnSpan: stripeHeading ? 2 : 1,
          verticalAlign: VerticalAlign.CENTER,
          children: [
            new Paragraph({
              alignment: AlignmentType.RIGHT,
              children: [
                new TextRun({
                  text: `\u00A0Total: `,
                  color: '#000000',
                  size: 20,
                  font: 'Arial',
                  bold: true,
                }),
              ],
            }),

          ],
        }),

        ...this.getSizeValues().map((size) => {
          const columnTotal = this.calculateColumnTotal(size);
          let ColumnTotal = columnTotal.toLocaleString('en-IN');
          return new TableCell({
            margins: {
              right: 100,
            },
            verticalAlign: VerticalAlign.CENTER,
            children: [
              new Paragraph({
                children: [
                  new TextRun({
                    text: `${ColumnTotal}`,
                    font: 'Arial',
                    color: '#000000',
                    bold: true,
                  }),
                ],
                alignment: AlignmentType.RIGHT, // Center align the text vertically
              }),
            ],
          });
        }),
        new TableCell({
          margins: {
            right: 100,
          },
          width: {
            size: 2000, // Adjust the width as needed
            type: WidthType.DXA,
          },
          verticalAlign: VerticalAlign.CENTER,
          children: [
            new Paragraph({
              children: [
                new TextRun({
                  text: `${formattedGrandTotal}`,
                  font: 'Arial',
                  color: '#000000',
                  bold: true,
                }),
              ],
              alignment: AlignmentType.RIGHT, // Center align the text vertically
            }),
          ],
        }),
      ],
    });

    //adding footer to table rows
    tableRows.push(tableFooter);

    //preparing table
    const table = new Table({
      width: {
        size: 9100, // Adjust the width size as needed
        type: WidthType.DXA,
      },
      rows: tableRows,
    });

    //creating footer
    const footersection = new Paragraph({
      children: [
        new TextRun({
          text: '',
          bold: true,
          font: 'Arial',
        }),
        new TextRun({
          text: '',
          font: 'Arial',
        }),
        new TextRun({
          text: '                                                                                                                                               '
        }),
        new TextRun({
          text: 'Manager: ',
          font: 'Arial',

          bold: true,
        }),
        new TextRun({
          text: '',
          font: 'Arial',
        }),
      ],
    });


    const collarCuff = new Paragraph({
      frame: {
        position: {
          x: 0,
          y: 1500,
        },
        width: 6900,
        height: 450,
        anchor: {
          horizontal: FrameAnchorType.MARGIN,
          vertical: FrameAnchorType.MARGIN,
        },
        alignment: {
          x: HorizontalPositionAlign.LEFT,
          y: VerticalPositionAlign.TOP,
        },
      },
      children: [
        new TextRun({
          text: dcGenerateDetails?.cuff == '1' ? 'Collar & Cuff' : '',
          bold: true,
          font: 'Arial',
          size: 24
        }),
        new TextRun({
          text: '',
          font: 'Arial',
        }),
      ],
    });

    //condition wise table display
    const tableContent = dcGenerateDetails?.patternDetails?.length > 0 ? table : emptypara;

    //preparing document
    const doc = new Document({
      sections: [
        {
          headers: {
            default: image,
          },
          children: [
            subhead,
            DcNo,
            UnitName,
            Date,
            OrderNo,
            emptypara,
            emptypara,
            collarCuff,
            tableContent,
            emptypara,
            emptypara,
            footersection,
          ],
        },
      ],
    });


    const Year = this.fromDate.getFullYear();
    const Month = (this.fromDate.getMonth() + 1).toString().padStart(2, '0'); // Months are zero-based
    const Day = this.fromDate.getDate().toString().padStart(2, '0');

    // Create the readable format

    const monthNames = [
      "Jan", "Feb", "Mar", "Apr", "May", "Jun",
      "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
    ];
    const Mont = monthNames[(+Month - 1)];
    const readableFormat = `${Day}-${Mont}-${Year}`;


    // Generate the document and offer it for download
    Packer.toBlob(
      doc
    ).then((blob) => {
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `Knitting_Unit_Dc_${readableFormat}.docx`;
      a.click();
      window.URL.revokeObjectURL(url);
    });
  }
}
