import { ComponentFixture, TestBed } from '@angular/core/testing';

import { KnittingDcComponent } from './knitting-dc.component';

describe('KnittingDcComponent', () => {
  let component: KnittingDcComponent;
  let fixture: ComponentFixture<KnittingDcComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ KnittingDcComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(KnittingDcComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
