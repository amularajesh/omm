import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-knitting-dc',
  templateUrl: './knitting-dc.component.html',
  styleUrls: ['./knitting-dc.component.scss']
})
export class KnittingDcComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
