import { Component } from '@angular/core';

/**
 * Cutting Program Component
 * @export
 * @class CuttingProgramComponent
 */
@Component({
  selector: 'app-cutting-program',
  templateUrl: './cutting-program.component.html',
  styleUrls: ['./cutting-program.component.scss']
})
export class CuttingProgramComponent { }