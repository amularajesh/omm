import { Component, OnInit, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { MatDialog, MatDialogConfig } from "@angular/material/dialog";
import { Router } from "@angular/router";

import { ModalComponent } from "src/app/core/Dialogues/Modal/modal.component";
import { SnackbarModalComponent } from "src/app/core/Dialogues/snackbar-modal/snackbar-modal.component";
import { CustomersService } from "src/app/core/Services/customers.service";
import { LoaderService } from "src/app/core/Services/loader.service";
import { MastersService } from "src/app/core/Services/masters.service";
import { SampleOrderService } from "src/app/core/Services/sample-order.service";
import { ValidationService } from "src/app/core/Services/validation.service";

/**
 * Add Cutting Program Component
 * @export
 * @class AddCuttingProgramComponent
 * @implements {OnInit}
 */
@Component({
  selector: 'app-add-cutting-program',
  templateUrl: './add-cutting-program.component.html',
  styleUrls: ['./add-cutting-program.component.scss']
})
export class AddCuttingProgramComponent implements OnInit {
  /**
   * Get Snackbar Modal Component
   * @type {SnackbarModalComponent}
   */
  @ViewChild("snackbarModalComponent") snackbarModalComponent!: SnackbarModalComponent;

  /**
   * Declare Search Object
   */
  searchObj = {
    dressItemID: 0,
    qualityID: 0,
    patternID: 0,
    methodID: 0
  }

  /**
   * Add Cutting Program Form Declaration
   */
  addCuttingProgramForm!: FormGroup;

  /**
   * Get Dress Items List
   */
  dressItemsList: any;

  /**
   * Get Quality List
   */
  qualityList: any;

  /**
   * Get Methods List
   */
  methodsList: any;

  /**
   * Get Patterns List
   */
  patternsList: any;

  /**
   * Get Selected Dress Item
   */
  selectedDressItem: any;

  /**
   * Get Selected Quality
   */
  selectedQuality: any;

  /**
   * Get Selected Pattern
   */
  selectedPattern: any;

  /**
   * Get Selected Method
   */
  selectedMethod: any;

  /**
   * Declare the Pattern Dress Items List
   */
  patternDressItemsList = ['T-Shirts', 'Middy', 'Nicker', 'Pant', 'Pinofers', 'Shots'];

  /**
   * Declare the Method Dress Items List
   */
  methodDressItemsList = ['T-Shirts', 'Pinofers'];

  /**
   * Get Is Pattern Dress Item Flag
   */
  isPatternDressItem = true;

  /**
   * Get Is Method Dress Item Flag
   */
  isMethodDressItem = true;

  /**
   * Get Is Save Clicked Flag
   */
  isSaveClicked = false;

  /**
   * Get Cutting Program List
   */
  availableOrdersList: any[] = [];

  /**
   * Get Selected Orders List
   */
  selectedOrdersList: any;

  /**
   * Get Cutting Program Form Validations
   */
  CuttingProgramValidation = this.validationService.addCuttingProgram;

  /**
   * Creates an instance of AddCuttingProgramComponent.
   * @param {MatDialog} matDialog
   * @param {LoaderService} loaderService
   * @param {CustomersService} customerService
   * @param {Router} router
   * @param {ValidationService} validationService
   * @param {FormBuilder} formBuilder
   * @param {MastersService} mastersService
   * @param {SampleOrderService} sampleOrderService
   */
  constructor(
    private matDialog: MatDialog,
    private loaderService: LoaderService,
    private customerService: CustomersService,
    private router: Router,
    private validationService: ValidationService,
    private formBuilder: FormBuilder,
    private mastersService: MastersService,
    private sampleOrderService: SampleOrderService
  ) {
    /* Get snackbar details from behavior subject */
    this.customerService.snackbarDetails.subscribe((res: any) => {
      if (res) {
        this.snackbarModalComponent.onOpenSnackbarModal(res?.flag, res?.message, '', res?.cpNo || '', res?.navigatePage || '');
      }
    });
  }

  /**
   * Life Cycle Hook Initialization
   */
  ngOnInit(): void {
    this.addCuttingProgramFormValidations();
    this.getDressItemsList();
    this.getQualityList()
  }

  /**
   * Initialize Add Cutting Program Form Validations
   */
  addCuttingProgramFormValidations() {
    this.addCuttingProgramForm = this.formBuilder.group({
      dressItemSelect: ["", [Validators.required]],
      qualitySelect: [""],
      patternTypeSelect: [""],
      methodSelect: [""]
    });
  }

  /**
   * Add Cutting Program Form Controls Initialized
   * @readonly
   */
  get addCuttingProgramFormControls() {
    return this.addCuttingProgramForm.controls;
  }

  /**
   * This method is used to get Dress Items list
   */
  getDressItemsList() {
    this.mastersService.getDressItems().subscribe({
      next: (res: any) => {
        this.dressItemsList = res.result;
      },
      error: (err: any) => {
        this.dressItemsList = [];
      }
    });
  }

  /**
   * This method is used to get the quality List
   */
  getQualityList() {
    this.mastersService.getQualities().subscribe({
      next: (res: any) => {
        this.qualityList = res.result;
      },
      error: (err: any) => {
        this.qualityList = [];
      }
    });
  }

  /**
   * This method is used to get the methods List
   */
  getMethodList() {
    this.mastersService.getMethodsByDressItemId(this.selectedDressItem?.dressItemId?.toString()).subscribe({
      next: (res: any) => {
        this.methodsList = res.result;
      },
      error: (err: any) => {
        this.methodsList = [];
      }
    });
  }

  /**
   * This method is used to get the patterns list
   */
  getPatternsList() {
    this.sampleOrderService.getPatternTypesByDressItemId(this.selectedDressItem.dressItemId?.toString()).subscribe({
      next: (res: any) => {
        this.patternsList = res.result;
      },
      error: (err: any) => {
        this.patternsList = [];
      }
    });
  }

  /**
   * This method is used to reset Cutting Program Form
   */
  resetCuttingProgramForm() {
    this.addCuttingProgramForm.reset();
    this.addCuttingProgramFormValidations();
    this.isPatternDressItem = true;
    this.isMethodDressItem = true;
    this.selectedDressItem = '';
    this.selectedQuality = '';
    this.selectedMethod = '';
    this.selectedPattern = '';
  }

  /**
   * This method is used to add validators
   * @param {*} formControls
   * @param {*} controls
   */
  onAddValidators(formControls: any, controls: any) {
    controls?.forEach((control: any) => {
      formControls[control].addValidators([Validators.required]);
      formControls[control].updateValueAndValidity({ onlySelf: true });
    });
  }

  /**
   * This method is used to remove validators
   * @param {*} formControls
   */
  onRemoveValidators(formControls: any, controls: any) {
    controls?.forEach((control: any) => {
      formControls[control].removeValidators([Validators.required]);
    });
  }

  /**
   * This method is used to update value and validity
   * @param {*} formControls
   */
  onUpdateValueAndValidity(formControls: any, controls: any) {
    controls?.forEach((control: any) => {
      formControls[control].setValue('');
      formControls[control].markAsUntouched({ onlySelf: true });
      formControls[control].updateValueAndValidity({ onlySelf: true });
    });
  }

  /**
   * This method is used to change the Dress Item
   * @param {*} event
   */
  onChangeDressItem(event: any) {
    let dressItemSizeValue = event ? event?.target?.value : event;
    this.onUpdateValueAndValidity(this.addCuttingProgramFormControls, ['patternTypeSelect']);
    this.onUpdateValueAndValidity(this.addCuttingProgramFormControls, ['methodSelect']);
    this.onUpdateValueAndValidity(this.addCuttingProgramFormControls, ['qualitySelect']);
    this.selectedMethod = '';
    this.selectedPattern = '';
    this.selectedQuality = '';
    this.isSaveClicked = false;
    this.isPatternDressItem = true;
    this.isMethodDressItem = true;
    this.selectedOrdersList = [];

    if (dressItemSizeValue == '') {
      this.onUpdateValueAndValidity(this.addCuttingProgramFormControls, ['dressItemSelect']);
      return;
    }
    for (const element of this.dressItemsList) {
      if (+(element.dressItemId) === +(dressItemSizeValue)) {
        this.selectedDressItem = element;
        this.getMethodList();
        this.getPatternsList();
      }
    }

    const isDressItemContainsPattern = this.patternDressItemsList.includes(this.selectedDressItem?.dressItemName);
    const isDressItemContainsMethod = this.methodDressItemsList.includes(this.selectedDressItem?.dressItemName);
    if (isDressItemContainsPattern) {
      this.isPatternDressItem = true;
    } else {
      this.isPatternDressItem = false;
    }
    if (isDressItemContainsMethod) {
      this.isMethodDressItem = true;
    } else {
      this.isMethodDressItem = false;
    }
  }

  /**
   * This method is used to change the Pattern
   * @param {*} event
   */
  onChangePatternType(event: any) {
    let patternTypeValue = event ? event?.target?.value : event;
    if (patternTypeValue == '') {
      this.onUpdateValueAndValidity(this.addCuttingProgramFormControls, ['patternTypeSelect']);
      this.selectedPattern = '';
      return;
    }
    for (const element of this.patternsList) {
      if (+(element.patternTypeId) === +(patternTypeValue)) {
        this.selectedPattern = element;
      }
    }
  }

  /**
   * This method is used to change the quality
   * @param {*} event
   */
  qualityChange(event: any) {
    let qualityValue = event ? event?.target?.value : event;
    if (qualityValue == '') {
      this.onUpdateValueAndValidity(this.addCuttingProgramFormControls, ['qualitySelect']);
      this.selectedQuality = '';
      return;
    }
    for (const element of this.qualityList) {
      if (+(element.qualityId) === (+qualityValue)) {
        this.selectedQuality = element;
      }
    }
  }

  /**
   * This method is used to change the quality
   * @param {*} event
   */
  onChangeMethod(event: any) {
    let methodValue = event ? event?.target?.value : event;
    if (methodValue == '') {
      this.onUpdateValueAndValidity(this.addCuttingProgramFormControls, ['methodSelect']);
      this.selectedMethod = '';
      return;
    }
    for (const element of this.methodsList) {
      if (+(element.methodId) === +(methodValue)) {
        this.selectedMethod = element;
      }
    }
  }

  /**
   * This method is used to change the check box
   * @param {*} event
   * @param {number} index
   */
  onCheckboxChange(event: any, index: number) {
    this.availableOrdersList.forEach((item: any) => {
      if (item?.orderId === index) {
        item.selected = event.target.checked;
      }
    });
  }

  /**
   * This method is used to submit the add cutting form
   */
  onSubmitCuttingProgramForm() {
    /** This will return false if form fields are invalid and stop the service calling */
    if (this.addCuttingProgramForm.invalid) {
      this.validationService.validateAllFormFields(this.addCuttingProgramForm);
      return;
    }

    const obj: any = {
      dressItemID: this.selectedDressItem?.dressItemId || 0,
      qualityID: this.selectedQuality?.qualityId || 0,
    };

    if (this.isPatternDressItem) {
      obj.patternID = this.selectedPattern?.patternTypeId || 0;
    }
    if (this.isMethodDressItem) {
      obj.methodID = this.selectedMethod?.methodId || 0;
    }
    this.isSaveClicked = true;

    this.searchObj = obj;

    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    //method to send payload to service for add district
    this.customerService.getCuttingProgramOrderAvailable(this.searchObj).subscribe({
      next: (res: any) => {
        /* Disable the loader if response is success */
        this.loaderService.isLoading.next(false);
        this.availableOrdersList = res.result;
      },
      error: (err: any) => {
        /* Disable the loader if response is error */
        this.loaderService.isLoading.next(false);
        this.availableOrdersList = [];
        this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
      }
    })
  }

  /**
   * This method is used to add to the cutting program
   */
  onClickAddToCuttingProgram() {
    const selectedOrders: any[] = [];
    this.availableOrdersList.filter((item: any) => item.selected).forEach((item: any) => {
      selectedOrders.push(item);
    });

    if (selectedOrders.length === 0) {
      this.snackbarModalComponent.onOpenSnackbarModal(false, "Select at least one Order", '', '', '');
      return;
    }

    if (selectedOrders.length > 10) {
      this.snackbarModalComponent.onOpenSnackbarModal(false, "Select Maximum 10 Orders", '', '', '');
      return;
    }

    const uniqueSelectedQualities = new Set(selectedOrders.map(item => `${item.quality}-${item.pattern}-${item.method}`));

    if (uniqueSelectedQualities.size !== 1) {
      this.snackbarModalComponent.onOpenSnackbarModal(false, "Quality, Pattern & Method must be same for the selected Orders", '', '', '');
      return;
    }

    if (this.selectedOrdersList.length > 0) {
      if (this.selectedOrdersList.length + selectedOrders.length > 10) {
        this.snackbarModalComponent.onOpenSnackbarModal(false, "Select Maximum 10 Orders", '', '', '');
        return;
      }

      const uniqueExistingQualities = new Set(this.selectedOrdersList.map((item: any) => `${item.quality}-${item.pattern}-${item.method}`));

      if (uniqueExistingQualities.size !== 1) {
        this.snackbarModalComponent.onOpenSnackbarModal(false, "Quality, Pattern & Method must be same for the selected Orders", '', '', '');
        return;
      }

      if (uniqueExistingQualities.values().next().value !== uniqueSelectedQualities.values().next().value) {
        this.snackbarModalComponent.onOpenSnackbarModal(false, "Quality, Pattern & Method must be same for the selected Orders", '', '', '');
        return;
      }
    }
    selectedOrders.forEach((item: any) => this.selectedOrdersList.push(item));
    const filterIds = this.selectedOrdersList.map((item: any) => item.orderId);
    this.availableOrdersList = this.availableOrdersList.filter(item => !filterIds.includes(item.orderId));
  }

  /**
   * This method is used to delete the cutting program
   * @param {*} orderItem
   */
  onClickDeleteOrderItem(orderItem: any) {
    orderItem.selected = false;
    this.selectedOrdersList = this.selectedOrdersList.filter((item: any) => item.orderId !== orderItem?.orderId);
    this.availableOrdersList.push(orderItem);
  }

  /**
   * This method is used to generate the cutting program
   */
  onClickGenerateCuttingProgram() {
    let obj: any = {
      dressItemID: this.selectedOrdersList[0]?.dressItemID,
      qualityID: this.selectedOrdersList[0]?.qualityID,
      patternID: this.selectedOrdersList[0]?.patternID || 0,
      methodID: this.selectedOrdersList[0]?.methodID || 0
    };

    const selectedOrders = [];
    for (const element of this.selectedOrdersList) {
      selectedOrders.push({ orderId: element.orderId });
    }
    obj.cuttingProgramsList = selectedOrders;
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.data = {
      name: "cuttingProgram",
      title: "Generate Cutting Program",
      payload: obj,
      description: "Do you want to Generate Cutting Program?",
      cancelButtonText: "No",
      submitButtonText: "Yes",
    };
    this.matDialog.open(ModalComponent, dialogConfig);
  }

  /**
   * This method is used to navigate to cutting program list
   */
  onNavigateToCuttingProgramList() {
    this.router.navigate(["/admin/customer-order/cuttingprogram/cutting-program-list"]);
  }
}
