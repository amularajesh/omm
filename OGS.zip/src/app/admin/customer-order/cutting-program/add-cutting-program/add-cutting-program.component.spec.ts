import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddCuttingProgramComponent } from './add-cutting-program.component';

describe('AddCuttingProgramComponent', () => {
  let component: AddCuttingProgramComponent;
  let fixture: ComponentFixture<AddCuttingProgramComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddCuttingProgramComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddCuttingProgramComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
