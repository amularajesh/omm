import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatTooltipModule } from '@angular/material/tooltip';
import { NgSelectModule } from '@ng-select/ng-select';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { AutosizeModule } from 'ngx-autosize';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { OrderModule } from 'ngx-order-pipe';
import { NgxPaginationModule } from 'ngx-pagination';

import { ComponentModule } from 'src/app/core/Modules/component.module';
import { AddCuttingProgramComponent } from './add-cutting-program/add-cutting-program.component';
import { CpLayoutComponent } from './cp-layout/cp-layout.component';
import { CuttingProgramListComponent } from './cutting-program-list/cutting-program-list.component';
import { CuttingProgramRoutingModule } from './cutting-program-routing.module';
import { EditCuttingProgramComponent } from './edit-cutting-program/edit-cutting-program.component';
import { FabricDetailsComponent } from './fabric-details/fabric-details.component';

/**
 * Cutting Program Module
 * @export
 * @class CuttingProgramModule
 */
@NgModule({
  declarations: [
    AddCuttingProgramComponent,
    CuttingProgramListComponent,
    EditCuttingProgramComponent,
    CpLayoutComponent,
    FabricDetailsComponent
  ],
  imports: [
    CommonModule,
    CuttingProgramRoutingModule,
    FormsModule,
    OrderModule,
    ComponentModule,
    NgSelectModule,
    NgxPaginationModule,
    Ng2SearchPipeModule,
    ReactiveFormsModule,
    BsDatepickerModule.forRoot(),
    MatTooltipModule,
    AutosizeModule
  ]
})
export class CuttingProgramModule { }
