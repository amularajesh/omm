import { DatePipe, Location } from "@angular/common";
import { Component, OnInit, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";

import { SnackbarModalComponent } from "src/app/core/Dialogues/snackbar-modal/snackbar-modal.component";
import { CustomersService } from "src/app/core/Services/customers.service";
import { LoaderService } from "src/app/core/Services/loader.service";
import { MastersService } from "src/app/core/Services/masters.service";
import { ValidationService } from "src/app/core/Services/validation.service";

/**
 * Cutting Program List Component
 * @export
 * @class CuttingProgramListComponent
 * @implements {OnInit}
 */
@Component({
  selector: 'app-cutting-program-list',
  templateUrl: './cutting-program-list.component.html',
  styleUrls: ['./cutting-program-list.component.scss']
})
export class CuttingProgramListComponent implements OnInit {
  /**
   * Get Snackbar Modal Component
   * @type {SnackbarModalComponent}
   */
  @ViewChild("snackbarModalComponent") snackbarModalComponent!: SnackbarModalComponent;

  /**
   * Declare Search Object
   */
  searchObj = {
    orderNo: 0,
    dressItemID: 0,
    date: ''
  };

  /**
   * Get Dress Items List
   * @type {*}
   */
  dressItemsList: any;

  /**
   * Set Min From Date
   * @type {Date}
   */
  minFromDate: Date;

  /**
   * Set Max From Date
   * @type {Date}
   */
  maxFromDate: Date;

  /**
   * Get cutting program  List
   * @type {*}
   */
  cuttingProgramList: any[] = [];

  /**
   * Get Sorting Order Flag
   */
  sortingOrder = false;

  /**
   * Get Sorting Key Column
   */
  sortingKeyColumn = "cpNo";

  /**
   * Records Count
   */
  recordsCount = 0;

  /**
   * Default Page Number
   */
  currentPage = 1;

  /**
   * Search Term
   */
  searchTerm = "";

  /**
   * Create search CuttingProgram Form Declaration
   */
  searchCuttingProgramForm!: FormGroup;

  /**
   * Get search search CuttingProgram Form Validations
   */
  searchCuttingProgramValidation = this.validationService.searchCuttingProgram;

  /**
   * Get Create search CuttingProgram Patterns
   * @private
   */
  private patterns = this.validationService.patterns;

  /**
   * Creates an instance of CuttingProgramListComponent.
   * @param {Router} router
   * @param {LoaderService} loaderService
   * @param {ValidationService} validationService
   * @param {FormBuilder} formBuilder
   * @param {DatePipe} datePipe
   * @param {CustomersService} customerService
   * @param {MastersService} mastersService
   * @param {Location} location
   */
  constructor(
    private router: Router,
    private loaderService: LoaderService,
    private validationService: ValidationService,
    private formBuilder: FormBuilder,
    private datePipe: DatePipe,
    private customerService: CustomersService,
    private mastersService: MastersService,
    private location: Location
  ) {
    /* set Min Date */
    this.minFromDate = new Date();
    this.maxFromDate = new Date();
    const d = new Date();
    d.setDate(1);
    d.setMonth(0);
    d.setFullYear(2012);
    this.minFromDate = d;
  }

  /**
   * Life Cycle Hook Initialization
   */
  ngOnInit(): void {
    this.searchCuttingProgramFormValidations();
    this.getDressItemList();
    this.getCuttingProgramList();
  }

  /**
   * Create search CuttingProgram Controls Initialized
   * @readonly
   */
  get searchCuttingProgramFormControls() {
    return this.searchCuttingProgramForm.controls;
  }

  /**
   * Initialize Create search CuttingProgram Form Validations
   */
  searchCuttingProgramFormValidations() {
    this.searchCuttingProgramForm = this.formBuilder.group({
      orderNumber: [
        '',
        [

          Validators.minLength(this.searchCuttingProgramValidation.orderNumber.minLength),
          Validators.maxLength(this.searchCuttingProgramValidation.orderNumber.maxLength),
          Validators.pattern(this.patterns.number),
        ],
      ],
      SelectDate: [''],
      dressItemSelect: [""]
    });
  }

  /**
   * This method is used to get the active cutting program List
   */
  getCuttingProgramList() {
    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    /* To call the service to get the cutting program list */
    this.customerService.getCuttingProgramList(this.searchObj).subscribe({
      next: (res: any) => {
        /* Disable the loader if response is success */
        this.loaderService.isLoading.next(false);
        this.cuttingProgramList = res.result;
        this.recordsCount = this.cuttingProgramList.length;
      },
      error: (err: any) => {
        /* Disable the loader if response is error */
        this.loaderService.isLoading.next(false);
        this.cuttingProgramList = [];
        this.recordsCount = 0;
      }
    });
  }

  /**
   * This method is used to get the Dress Item List
   */
  getDressItemList() {
    this.mastersService.getDressItems().subscribe({
      next: (res: any) => {
        this.dressItemsList = res.result;
      },
      error: () => {
        this.dressItemsList = [];
      }
    });
  }

  /**
   * This method is used to reset search cutting program form
   */
  resetSampleOrder() {
    this.searchCuttingProgramForm.reset();
    this.searchCuttingProgramFormValidations();
  }

  /**
   * This method is used to change the pagination controls
   * @param {*} event
   */
  onPageChange(event: any) {
    this.currentPage = event;
  }

  /**
   * This method is used to submit the search cutting program
   */
  onSearchCuttingProgramFormSubmit() {
    /* Prepare the request payload */
    const obj = {
      orderNo: this.searchCuttingProgramFormControls["orderNumber"]?.value || 0,
      date: this.datePipe.transform(this.searchCuttingProgramFormControls["SelectDate"].value, "YYYY-MM-dd") || '',
      dressItemID: +this.searchCuttingProgramFormControls["dressItemSelect"].value
    };

    this.searchObj = obj;

    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    //method to send payload to service for add district
    this.customerService.getCuttingProgramList(this.searchObj).subscribe({
      next: (res: any) => {
        /* Disable the loader if response is success */
        this.loaderService.isLoading.next(false);
        this.cuttingProgramList = res.result;
        this.recordsCount = this.cuttingProgramList.length;
        this.currentPage = 1;
      },
      error: (err: any) => {
        /* Disable the loader if response is error */
        this.loaderService.isLoading.next(false);
        this.cuttingProgramList = [];
        this.recordsCount = 0;
      }
    });
  }

  /**
   * This method is used to show search results
   */
  navigateToSearchResult() {
    this.currentPage = 1;
  }

  /**
   * This method is used to sort column
   * @param key : value of which column based we need to sort the rows
   */
  sort(key: string) {
    const componentName = this.location.path();
    let value = key;
    sessionStorage.setItem(`${componentName}_property`, value);
    this.sortingKeyColumn = key;
    if (sessionStorage.getItem(componentName + "_order") == "desc") {
      this.sortingOrder = false;
    } else {
      this.sortingOrder = true;
    }
  }

  /**
   * This method is used for navigate to create cutting order page when user clicked on add cutting program
   */
  onClickCreateCuttingProgram() {
    this.router.navigate(["/admin/customer-order/cuttingprogram/add-cutting-program"]);
  }

  /**
   * This method is used to navigate to CP Layout page
   * @param {*} cutting
   */
  onClickCPlayout(cutting: any) {
    this.customerService.getCuttingProgramById(cutting?.cuttingProgramID).subscribe({
      next: (res: any) => {
        this.customerService.CuttingProgramDetails.next(res.result);
        this.router.navigate(["/admin/customer-order/cuttingprogram/cp-layout"]);
      },
      error: (err: any) => {
        this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
      }
    });
  }
}
