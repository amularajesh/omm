import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CuttingProgramListComponent } from './cutting-program-list.component';

describe('CuttingProgramListComponent', () => {
  let component: CuttingProgramListComponent;
  let fixture: ComponentFixture<CuttingProgramListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CuttingProgramListComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CuttingProgramListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
