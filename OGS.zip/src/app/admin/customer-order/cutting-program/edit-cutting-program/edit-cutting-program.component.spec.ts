import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditCuttingProgramComponent } from './edit-cutting-program.component';

describe('EditCuttingProgramComponent', () => {
  let component: EditCuttingProgramComponent;
  let fixture: ComponentFixture<EditCuttingProgramComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EditCuttingProgramComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EditCuttingProgramComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
