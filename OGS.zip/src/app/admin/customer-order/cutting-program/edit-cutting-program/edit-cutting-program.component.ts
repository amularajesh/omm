import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-cutting-program',
  templateUrl: './edit-cutting-program.component.html',
  styleUrls: ['./edit-cutting-program.component.scss']
})
export class EditCuttingProgramComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
