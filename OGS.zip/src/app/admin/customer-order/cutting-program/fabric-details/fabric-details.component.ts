import { Component, OnInit } from "@angular/core";
import { FormBuilder, FormGroup } from "@angular/forms";
import { Router } from "@angular/router";
import {
  AlignmentType,
  Document,
  FrameAnchorType,
  Header,
  HeightRule,
  HorizontalPositionAlign,
  ImageRun,
  Packer,
  Paragraph,
  Table,
  TableCell,
  TableRow,
  TextRun,
  VerticalAlign,
  VerticalPositionAlign,
  WidthType,
} from "docx";
import { CustomersService } from "src/app/core/Services/customers.service";

/**
 * Fabric Details Component
 * @export
 * @class FabricDetailsComponent
 * @implements {OnInit}
 */
@Component({
  selector: "app-fabric-details",
  templateUrl: "./fabric-details.component.html",
  styleUrls: ["./fabric-details.component.scss"],
})
export class FabricDetailsComponent implements OnInit {
  /**
   * Get Fabric Details
   * @type {*}
   */
  fabricDetails: any;

  /**
   * Get From Date
   * @type {Date}
   */
  fromDate: Date;

  /**
   * Create model Form Declaration
   */
  createModelForm!: FormGroup;

  /**
   * Creates an instance of FabricDetailsComponent.
   * @param {Router} router
   * @param {FormBuilder} formBuilder
   * @param {CustomersService} customerService
   */
  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private customerService: CustomersService
  ) {
    this.fromDate = new Date();
    this.customerService.CuttingProgramDetails.subscribe((res: any) => {
      if (Object.keys(res).length > 0) {
        this.fabricDetails = res;
        console.log(this.fabricDetails);
      } else {
        this.onClickNavigateToCPlayout();
      }
    });
  }

  /**
   * Life Cycle Hook Initialization
   */
  ngOnInit(): void {
    this.createModelFormValidations();
  }

  /**
   * Initialize Create model Validations
   */
  createModelFormValidations() {
    this.createModelForm = this.formBuilder.group({
      cuttingNo: [this.fabricDetails?.cpNo],
      dressItem: [this.fabricDetails?.dressItem],
      quality: [this.fabricDetails?.quality],
      orderNumbers: [this.fabricDetails?.orderNo],
    });
  }

  /**
   * This method is for print fabric
   */
  onClickFabricPrint() {
    console.log(this.fabricDetails);
    const tableRows: TableRow[] = [];

    const imagePath =
      "/9j/4AAQSkZJRgABAQEAYABgAAD/2wBDAAIBAQIBAQICAgICAgICAwUDAwMDAwYEBAMFBwYHBwcGBwcICQsJCAgKCAcHCg0KCgsMDAwMBwkODw0MDgsMDAz/2wBDAQICAgMDAwYDAwYMCAcIDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAz/wAARCAAuAKADASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD9/K+eP2wv+CqfwM/YYuzYePvG9pB4g2CRdD06J77UiCMqWijB8oEcgylAexrwn/gvd/wVKvv2A/gXp/hnwVdJB8TPHySpZXO0OdFsk+WW7APHmFiEjzxne3Pl4P8AOpK+tfEjxTNM51PXtb1OV55nbzLq6u5DlndjyzseSScnqTX0mUZD9Zh7as7R6d3/AMA8TMc29hL2VJXl+R++t3/wdXfs7W9y6J4T+Mc6qcCSPSNOCv7jdfA/mBUf/EVr+zx/0Jvxn/8ABTpn/wAn1+CGu+BNc8LwiTU9G1XTo2OA11aSQgn6sBVbQ/DuoeJ737NptjeahcbS3lW0LSvgdThQTivf/wBXMDa+v3nj/wBt4u/T7j9+P+IrX9nj/oTfjP8A+CnTP/k+j/iK1/Z4/wChN+M//gp0z/5Pr8H/APhTXjD/AKFTxJ/4LJv/AImqlj8OPEOp3tzbW2g61cXFkwW4iisZXeAnoHAXKk+9H+ruA8/vD+2sX5fcfvX/AMRWv7PH/Qm/Gf8A8FOmf/J9en/s/wD/AAcV/sxfHfXYdNuPEus+Ary5YJF/wlWni0gZj2aeJ5YY/rI6j3r+b7TPB+pat4st9DjtJI9VurhbRLeYeSwlYhQrbsbeSOuK9V/ap/Yi8S/sbGy0/wAb6ho9r4mu4knfRrafz57VGGQJGHyhgCCRnjcuCcnGdTh3A6QTab21NIZzi/isml5H9Zum6lb6xp8F3aTw3VpdRrNDNC4eOZGGVZWHBUgggjgg1PX89/8Awb/f8FZtb/Zs+OOi/CHxrrFxe/DTxldJp+m/apdw8OX8rbYmjZj8kEjkK652qWDjGH3f0IV8hmWXzwdX2ctV0fc+jwWMhiafPHfqgor8Xf8AgqF8N/j1+xt+0j8G9D0v9qj4r6hZfHDxRc6cU8+S2XQY/tVmiiNRMRIFF4cA7f8AVj14+6dI+NfhD/gj18DdM0z9oL48+JPGN14m1e6l03Xtc0m9u7mQLHDutgtutwVRMbgWIBMhxVVMutThOnLmctkk7u2/ToTDG3nKM48qju21byPrmivyq/4LV/8ABRfxbr/7Mfwb8Z/A3xp4l0T4M/EHUryDxF440DTbiG+s44Z44FRfMWKaElhdEDMbSNAAHA+95n+zR+0l8QNE/Zc/aUvvCH7VkXxm8HaN4EudV0WbVLvUbXxz4ev1WPExiuYyywhmlQslxImVhZdpYrWtPJ6kqKqt2u7Ws+9tdLJ+TInmUFUdNK+l76dr6d15n7Q0V+Qn7D//AAXu1z4S/Bn4FaB8T/h78Qde0bxlLJpd38TNTvG8q9uzeyoxhR4j9pSAPEjt5ysNjhUbYN3T+Ev+Ci3hD9lL9pX9tvxzZ+GviFrup+Cb/T21ey1LxWkun3ZXUF05PscX2cG3AM2752lwqhF2iplk+IjKUWvTbX3uXvoOOZUZJST9fLS/zP1Uor8r/wBpH/gtz8V/H/8AwTw8b/E34cfB7xn8Pba1bRE0fxff+TdW4S5eT7XcJFPbGKWKKWBbUMC283iPhNuK2PBv/BdjxB8Ff2Dfg74i+Ifw713xB8UPibcNpmiW8t9a6XbeJliS036m84jENrFI92iqojIBVs7VBIn+yMTy3sr3ta6vtf0/HTqV/aVC9r6WveztvY/Tiivn/wDYH/bZ1r9srwzr83iH4UeM/hZq3h26S3kh1aMz6fqStvAksr0IkV0oMbBjGMDKHJDg19AVwVacqcnCe6OunUjOPNHY/mx/4OQ/H174x/4KueMtOundoPCmlaVpdmGPCRPZRXZA9vMupD9Sa+af2D9UuNH/AG2fhJNazPBL/wAJhpSbkODta7iVh9CpIPsa+8f+Dpf9lTUPAH7WegfFi2tnfQfH+mRWF1OBxFqNouzYx7brfySuevlyY+6a+Cv2Hhbw/tg/DS7vL2206x0vxJY6jdXNxu2QwwTpNIcKrMTtQ4ABr9KwE4zy6Lj/AC2+dtfxPh8ZGUcbLm/m/XQ/Rf8AaP8A2z/FHgb/AILHN8N9Wlt/EXw08U+IxoOpeHtRt0ntHt7m+e3IVSPlKqFwR0wfWuE0n9jC6/Zj/wCC+fhTwx8OoWt/Duk+J9N1C4Q3ccS22mzXixSxMZGG8MhKbBlm3YAJrf8AidoPw38bf8FXJvjf4g+InhuH4eeG9WbX44k85b3U3jupp4Yo0kjRckmMnLZxnAJ4rxnSP2xrD9pv/gtB4W+Kd/q9v4c8M2Piqx1S4lm850Fla3S3BjCxozudoIHyjJGfl7efShLltTVlya6denzOupOPN77159PT/I+p/wBqz4jftBfB/wDae+KXjXw34t0C18F/Dea71WTS5tQs7xr5W1SW3jt2t43aVFEcsX31ULtA6jFfH3/BNj/goDf/AA//AOCnOleNvE175eh+PNTbTtfSQgxCG5YqJHzwfLdlkJ68E969L/aT+E3hj9pT9vXW/Eq/F/RPDXgDxBqV22o3UVtqX2mezl1C4nKCJbbBYxyJwxxn6V8Y/tO/B/S/gT8XrrT/AA34hh8SaGkzNp2oojxNOitgOUdVdc8Hle5GTgmunB0KU6bpTWso9rf076mOJq1IzVSL0T73Ppr4+/sh6j4c/wCCuuo6Fq7yXGmafqUmu39zIf8AVWdqnnuXboC0aIw9RNH3NfMf7XHx7v8A9pT9oHxJ4sv5nmOoXcnklj0jDHH0zycdBnA4Ar9GP24v2lPC3xP/AGHNE8YeH9Y068+MGueC7LQ/FMMSSq6RQFWeQSMiqzsFRmIbJ8iNfm6V+TtdOXOVSPPUWsVy/wCb+ZhjVGD5YPR6/wCQ+3uJLS4SWJ3jljYOjocMjDkEHsa/sF/Zv8b3XxM/Z38BeJL7JvfEHhzT9SuMj/lpNbRyN+rGv5Mf2ZfgBrf7U/x/8JfD3w7C0ureLNSisYiFyIEJzJM3+xHGHkb/AGUNf14eD/Ctn4F8JaXomnIY9P0ezisbZCclIokCIP8AvlRXg8WTj+7h11+7Q9fh6Mvfl00PkP8A4Kkf8E7PG37bnx6/Z18U+FNU8Lafp/wi8Ry6xrEerXM8U1zC1xp8oW3EcMgZ9tpJw5QZZeeSR9hav4esPECIt/Y2d6sZJQXEKyBCeuNwOKwPjh8VYPgj8J9c8VXFpLfx6Nb+aLaNwhmcsFRSzcICzLljwoycHFcPqX7XMHw6uLnT/HOjLpGtWsF1eGHSNQTVbaS3gm0+IsJCsLq5bUrf5JIkb5XPK7Gf5Sdec4RpvaN7fN3PoY0oxnKa3lv8tDy7/go9+xV8XPjmngzXPgT8UH+HWueD5pPP0C7up4vDXiGF2V9l3bxB0fBDDDxOrrIwOMA18n/Cj/ghJ8XNRu/jh438d+Ivhdp/j34neDLvwzpek+F7SSw0S0luEhQzT+XbpsAEK5EcTlmdnLFuv3Jd/wDBQ/wxFq9pFHomvCzGo3tlqdxObeJ9KjtrK5vGneHzTLgx2spCMqyYUnbkory3H/BRHwdaXUVrJonjJdRM629zZDT42msHeSxjiEuJSv7xtSstu0t/rxnG1tvVRzHEUqfs4W+5X3va5hUwVKpPnlf79Ox8YfE7/giL8VvGn7AP7N/wqtfEHw9j8Q/B/Xr3VNZuJb68FlcxTXks6i3YWpdmCuAQ6IM55I5pvxU/4Ih/Ffxxrv7X11aeIPh7HH8f7q2m8PCa+vAbNYtYivm+14tTsPlIQPL8z5iB0+avs34iftwS6T4Z8K6z4V8Lwa5p2v8Ah3VvFF1/amrHSprG0042wmjVRBMsk5NwQFZ40zGcyYOQ9v8Agov4El/t37LY+KLxdB2CWSOxRIpCZo4ZB5jyKkXlSSqHacxrwxUsFJGizbEra299u8ub80Q8uoP7rfhb8jzvx1/wTn8R/EL/AII2W37ONzrWiWfiuDwpYaQdRiaWXTjd2ksMy/MUWTymeEKW8vcAxO0kYPgHiL/glf8AtF+P/wBgH4X/AA71uf4A6trvwyu5baLSNZ02a+03UtMWOEQZu/IFzb3I2TI/kbVkR0O9GWvr+2/4KIeEDeXaGy1q8SG4jw9jbpKILaRNP8ueUl1GGk1GFMRlz1bG1SwD/wAFH/Aq+HpNSbTfFUUEbWrHzrOGFRBcJdNHcmR5RGsRNlcJ8zhy6AKrbl3ZU8wrw2t8XNt1Zc8FSnv2t8jxj/gjT/wS58Yf8E9br4i614t13w5HN8QLqK4i8LeGHu5NF0JUaVh5b3JMrsBKIxuyQsYy8mcj7npFcOoIIIIyCO9LXNicROvUdWpuzejRjSgqcNkeeftT/sueDv2yfghrPw/8dab/AGjoOsoMlCFns5V5juIXwdkqHkNg9wQVJU/z7/tvf8G+Xx4/ZV8U31z4S0K++KXg0OzWeo6BAZr9I+yz2a5lV8ZyYxInH3hnA/pLorty7Nq+DdoaxfRnLjcupYnWej7n8gF7+zL8T7Sdobj4fePI5EOGjk0K7DKfcFKhX9mz4kIcjwD43B9Rod1/8RX9gtFe1/rZP/n2vv8A+AeX/q9H+f8AA/j9/wCGc/iX/wBCJ45/8El1/wDEU1/2bfiRIfm8A+Nz9dDuv/iK/sEoo/1sn/z7X3/8AP8AV6P8/wCH/BP4/P8AhnH4lbcf8IH44x0x/Yl1/wDEV6X+z9/wSo/aF/aX16Cy8NfCnxfHBM4VtR1WwfTNPiHdjPcBEOByQpZvRSSBX9XFFTPiuq17tNJ+v/DFR4ep396bPh3/AIJBf8EYPDv/AATZ0CfxDrl3Z+KviprEHkXeqxRn7LpcJwTb2gYBsEgb5GAZ8AYUZB+4qKK+axGIqV6jq1Xds9yjRhSgoU1ZFXWtFs/Emj3Wn6ha219YX0LW9zbXEQkiuI2BVkdSCGUgkEEYINcPD+yd8MoNE0/TU8BeE1sdJnlurOEaZFtt5ZdvmSL8vDNsTJ6ny0/ujHoVFYGpxFp+zZ8P7BiYfBnhqIm8/tA7dPiH7/ZJHv6f3JZVx0xI4xhjldG/Zt8AeHbO3t7Dwb4cs4bUgxJDYRoEInhuARgdRNbwP9YY/wC6K7aii4HD+JP2aPh94w07RrTVfBnhzUrTw75n9mwXNhHLFZeYyvIEUggBmRCRjB2jNP1n9nHwD4h1TVL298HeHbm81pke+newjMlyysrKzNjO7ciHPXKKewrtaKLsDyHx7+w78O/Ht9oMjaNb6Xb6BcLcxWun2tvDFMVNrtViYmdAFsrdMwtG2yPbnbxXR6n+zD8O9a09bS78FeGrm2WGK3EUthGyiOIThEwR90C5uBjpieQdGNd3RRdgIqhFAAwBwAO1LRRQB//Z";

    /* Logo */
    const image = new Header({
      children: [
        new Paragraph({
          children: [
            new ImageRun({
              data: imagePath,
              transformation: {
                width: 130,
                height: 40,
              },
            }),
          ],
        }),
      ],
    });

    /* Header */
    const additionalInfo = new Paragraph({
      alignment: AlignmentType.CENTER,
      children: [
        new TextRun({
          text: `Fabric Details`,
          bold: true,
          font: "Arial",
          color: "#000000",
          size: 27,
        }),
      ],
    });

    /* Cutting No */
    const cuttingNo = new Paragraph({
      frame: {
        position: {
          x: 7500,
          y: 600,
        },
        width: 3000,
        height: 300,
        anchor: {
          horizontal: FrameAnchorType.MARGIN,
          vertical: FrameAnchorType.MARGIN,
        },
        alignment: {
          x: HorizontalPositionAlign.LEFT,
          y: VerticalPositionAlign.TOP,
        },
      },

      children: [
        new TextRun({
          text: "Cutting No: ",
          bold: true,
          font: "Arial",
        }),
        new TextRun({
          text: this.fabricDetails?.cpNo?.toString(),
          font: "Arial",
        }),
      ],
    });

    /* Dress Item */
    const dressItem = new Paragraph({
      frame: {
        position: {
          x: 0,
          y: 600,
        },
        width: 3000,
        height: 300,
        anchor: {
          horizontal: FrameAnchorType.MARGIN,
          vertical: FrameAnchorType.MARGIN,
        },
        alignment: {
          x: HorizontalPositionAlign.RIGHT,
          y: VerticalPositionAlign.TOP,
        },
      },

      children: [
        new TextRun({
          style: AlignmentType.END,
          text: "Dress Item: ",
          bold: true,
          font: "Arial",
        }),
        new TextRun({
          style: AlignmentType.END,
          text: this.fabricDetails?.dressItem,
          font: "Arial",
        }),
      ],
    });

    /* Quality */
    const quality = new Paragraph({
      frame: {
        position: {
          x: 3500,
          y: 600,
        },
        width: 3000,
        height: 500,
        anchor: {
          horizontal: FrameAnchorType.MARGIN,
          vertical: FrameAnchorType.MARGIN,
        },
        alignment: {
          x: HorizontalPositionAlign.RIGHT,
          y: VerticalPositionAlign.TOP,
        },
      },

      children: [
        new TextRun({
          style: AlignmentType.END,
          text: "Quality: ",
          bold: true,
          font: "Arial",
        }),
        new TextRun({
          style: AlignmentType.END,
          text: this.fabricDetails?.quality,
          font: "Arial",
        }),
      ],
    });

    /* Order No */
    const orderNo = new Paragraph({
      frame: {
        position: {
          x: 0,
          y: 1100,
        },
        width: 3000,
        height: 550,
        anchor: {
          horizontal: FrameAnchorType.MARGIN,
          vertical: FrameAnchorType.MARGIN,
        },
        alignment: {
          x: HorizontalPositionAlign.CENTER,
          y: VerticalPositionAlign.TOP,
        },
      },

      children: [
        new TextRun({
          style: AlignmentType.END,
          text: "Order No(s): ",
          bold: true,
          font: "Arial",
        }),
        new TextRun({
          style: AlignmentType.END,
          text: this.fabricDetails?.orderNo,
          font: "Arial",
        }),
      ],
    });

    /* Create table headers */
    const tableHeader = new TableRow({
      height: {
        value: 400,
        rule: HeightRule.EXACT,
      },
      children: [
        new TableCell({
          width: {
            size: 4000,
            type: WidthType.DXA,
          },
          verticalAlign: VerticalAlign.CENTER,
          shading: {
            fill: "D3D3D3", // Specifying the background color
          },
          children: [
            new Paragraph({
              children: [
                new TextRun({
                  text: "Colour",
                  bold: true,
                  color: "#000000",
                  font: "Arial",
                }),
              ],
              alignment: AlignmentType.CENTER,
            }),
          ],
        }),
        new TableCell({
          width: {
            size: 2000,
            type: WidthType.DXA,
          },
          verticalAlign: VerticalAlign.CENTER,
          shading: {
            fill: "D3D3D3", // Specifying the background color
          },
          children: [
            new Paragraph({
              children: [
                new TextRun({
                  text: "Quantity",
                  bold: true,
                  color: "#000000",
                  font: "Arial",
                }),
              ],
              alignment: AlignmentType.CENTER, // Center align the text vertically
            }),
          ],
        }),
        new TableCell({
          width: {
            size: 2000,
            type: WidthType.DXA,
          },
          verticalAlign: VerticalAlign.CENTER,
          shading: {
            fill: "D3D3D3", // Specifying the background color
          },
          children: [
            new Paragraph({
              children: [
                new TextRun({
                  text: "Fabric (Kgs)",
                  bold: true,
                  font: "Arial",
                  color: "#000000",
                }),
              ],
              alignment: AlignmentType.CENTER, // Center align the text vertically
            }),
          ],
        }),
      ],
    });

    /* push header to table rows*/
    tableRows.push(tableHeader);

    /* Create data rows from the inwardFabricList array  */
    this.fabricDetails?.fabricColoursList.forEach(
      (item: any, index: number) => {
        const fabric = Number(item.fabric)
          .toFixed(3)
          .replace(/\d(?=(\d{3})+\.)/g, "$&,");

        const row = new TableRow({
          height: {
            value: 300,
            rule: HeightRule.EXACT,
          },
          children: [
            new TableCell({
              width: {
                size: 4000,
                type: WidthType.DXA,
              },
              verticalAlign: VerticalAlign.CENTER,
              children: [
                new Paragraph({
                  alignment: AlignmentType.LEFT,

                  children: [
                    new TextRun({
                      text: `\u00A0\u00A0${item.colour}`,
                      color: "#000000",
                      font: "Arial",
                    }),
                  ],
                }),
              ],
            }),
            new TableCell({
              margins: { right: 100 },
              width: {
                size: 2000,
                type: WidthType.DXA,
              },
              verticalAlign: VerticalAlign.CENTER,
              children: [
                new Paragraph({
                  alignment: AlignmentType.END,

                  children: [
                    new TextRun({
                      text: `${item.quantity}`,
                      color: "#000000",
                      font: "Arial",
                    }),
                  ],
                }),
              ],
            }),
            new TableCell({
              // width: {
              //   size: 2000,
              //   type: WidthType.DXA,
              // },
              verticalAlign: VerticalAlign.CENTER,
              children: [
                new Paragraph({
                  alignment: AlignmentType.RIGHT,

                  children: [
                    new TextRun({
                      text: `${fabric}\u00A0\u00A0`,
                      color: "#000000",
                      font: "Arial",
                    }),
                  ],
                }),
              ],
            }),
          ],
        });
        tableRows.push(row);
      }
    );

    /* Preparing table */
    const table = new Table({
      width: {
        size: 9100, // Adjust the width size as needed
        type: WidthType.DXA,
      },
      rows: tableRows,
    });

    const doc = new Document({
      sections: [
        {
          headers: {
            default: image,
          },
          children: [
            additionalInfo,
            cuttingNo,
            dressItem,
            quality,
            orderNo,
            table,
          ],
        },
      ],
    });

    const Year = this.fromDate.getFullYear();
    const Month = (this.fromDate.getMonth() + 1).toString().padStart(2, "0"); // Months are zero-based
    const Day = this.fromDate.getDate().toString().padStart(2, "0");

    const monthNames = [
      "Jan", "Feb", "Mar", "Apr", "May", "Jun",
      "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
    ];
    const Mont = monthNames[(+Month - 1)];
    // Create the readable format
    const readableFormat = `${Year}-${Mont}-${Day}`;
    // Generate the document and offer it for download
    Packer.toBlob(doc).then((blob) => {
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `Fabric_Details_${readableFormat}.docx`;
      a.click();
      window.URL.revokeObjectURL(url);
    });
  }

  /**
  * This method is used for navigate to cp layout list
  */
  onClickNavigateToCPlayout() {
    this.router.navigate([
      "/admin/customer-order/cuttingprogram/cp-layout",
    ]);
  }
}
