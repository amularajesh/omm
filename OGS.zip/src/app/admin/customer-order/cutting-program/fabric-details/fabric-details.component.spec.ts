import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FabricDetailsComponent } from './fabric-details.component';

describe('FabricDetailsComponent', () => {
  let component: FabricDetailsComponent;
  let fixture: ComponentFixture<FabricDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FabricDetailsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FabricDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
