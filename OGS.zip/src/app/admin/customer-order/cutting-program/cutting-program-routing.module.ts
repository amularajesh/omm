import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AddCuttingProgramComponent } from './add-cutting-program/add-cutting-program.component';
import { CpLayoutComponent } from './cp-layout/cp-layout.component';
import { CuttingProgramListComponent } from './cutting-program-list/cutting-program-list.component';
import { CuttingProgramComponent } from './cutting-program.component';
import { EditCuttingProgramComponent } from './edit-cutting-program/edit-cutting-program.component';
import { FabricDetailsComponent } from './fabric-details/fabric-details.component';

const routes: Routes = [
  {
    path: '',
    component: CuttingProgramComponent,
    children: [
      { path: '', redirectTo: "cutting-program-list", pathMatch: 'full' },
      { path: 'cutting-program-list', component: CuttingProgramListComponent },
      { path: 'add-cutting-program', component: AddCuttingProgramComponent },
      { path: 'edit-cutting-program', component: EditCuttingProgramComponent },
      { path: 'fabric-details', component: FabricDetailsComponent },
      { path: 'cp-layout', component: CpLayoutComponent },
    ]
  }
];

/**
 * Cutting Program Routing Module
 * @export
 * @class CuttingProgramRoutingModule
 */
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CuttingProgramRoutingModule { }
