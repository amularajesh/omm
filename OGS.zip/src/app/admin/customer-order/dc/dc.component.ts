import { Component } from '@angular/core';

/**
 * Dc Component
 * @export
 * @class DcComponent
 */
@Component({
  selector: 'app-dc',
  templateUrl: './dc.component.html',
  styleUrls: ['./dc.component.scss']
})
export class DcComponent { }
