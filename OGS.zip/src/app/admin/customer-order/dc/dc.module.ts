import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatTooltipModule } from '@angular/material/tooltip';
import { NgSelectModule } from '@ng-select/ng-select';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { AutosizeModule } from 'ngx-autosize';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { OrderModule } from 'ngx-order-pipe';
import { NgxPaginationModule } from 'ngx-pagination';

import { ComponentModule } from 'src/app/core/Modules/component.module';
import { DcGenerateComponent } from './dc-generate/dc-generate.component';
import { DcListComponent } from './dc-list/dc-list.component';
import { DcRoutingModule } from './dc-routing.module';
import { DcComponent } from './dc.component';

/**
 * Dc Module
 * @export
 * @class DcModule
 */
@NgModule({
  declarations: [
    DcListComponent,
    DcGenerateComponent,
    DcComponent
  ],
  imports: [
    CommonModule,
    DcRoutingModule,
    FormsModule,
    OrderModule,
    ComponentModule,
    NgSelectModule,
    NgxPaginationModule,
    Ng2SearchPipeModule,
    ReactiveFormsModule,
    BsDatepickerModule.forRoot(),
    MatTooltipModule,
    AutosizeModule
  ]
})
export class DcModule { }
