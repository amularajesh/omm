import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DcGenerateComponent } from './dc-generate.component';

describe('DcGenerateComponent', () => {
  let component: DcGenerateComponent;
  let fixture: ComponentFixture<DcGenerateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DcGenerateComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DcGenerateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
