import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { Router } from '@angular/router';
import {
  AlignmentType,
  BorderStyle,
  Document,
  FrameAnchorType,
  Header,
  HeightRule,
  HorizontalPositionAlign,
  ImageRun,
  Packer,
  Paragraph,
  Table,
  TableCell,
  TableRow,
  TextRun,
  VerticalAlign,
  VerticalPositionAlign,
  WidthType,
} from 'docx';

import { ModalComponent } from 'src/app/core/Dialogues/Modal/modal.component';
import { SnackbarModalComponent } from 'src/app/core/Dialogues/snackbar-modal/snackbar-modal.component';
import { CustomersService } from 'src/app/core/Services/customers.service';

/**
 * Dc Generate Component
 * @export
 * @class DcGenerateComponent
 * @implements {OnInit}
 */
@Component({
  selector: 'app-dc-generate',
  templateUrl: './dc-generate.component.html',
  styleUrls: ['./dc-generate.component.scss'],
})
export class DcGenerateComponent implements OnInit {
  /**
   * Get Snackbar Modal Component
   * @type {SnackbarModalComponent}
   */
  @ViewChild("snackbarModalComponent") snackbarModalComponent!: SnackbarModalComponent;

  fromDate: any;

  generateStatus: any;
  /**
   * Get order Details
   */
  dcGenerateDetails: any;

  /**
   * Get Pattern Details
   * @type {*}
   */
  patternData: any;
  src: any;
  http: any;

  /**
   * Get Is Success Snackbar Flag
   */
  isSuccessSnackbar = false;

  /**
   * Get Is Overlay Visible Flag
   */
  isOverlayVisible = false;

  /**
   * Get Inner HTML Message
   */
  innerHTMLMessage = '';

  /**
   * Creates an instance of DcGenerateComponent.
   * @param {Router} router
   * @param {CustomersService} customerService
   */
  constructor(
    private router: Router,
    private customerService: CustomersService,
    private matDialog: MatDialog
  ) {
    this.fromDate = new Date();
    /* Get DC Generate details from behavior subject */
    this.customerService.KnittingDcDetails.subscribe((res: any) => {
      if (Object.keys(res).length > 0) {
        this.dcGenerateDetails = res;
        this.getIsDCExist();
        if (this.dcGenerateDetails?.imageBase64 !== '') {
          this.src = "data:image/png;base64," + this.dcGenerateDetails?.imageBase64;
        }
        else if (this.dcGenerateDetails?.imageBase64 === '' && this.dcGenerateDetails?.imageFileFullName === '') { this.src = '' }
        this.patternData = res.patternData?.split(',');
      } else {
        this.onClickNavigateToSearch();
      }
    });

    /* Get snackbar details from behavior subject */
    this.customerService.snackbarDetails.subscribe((res: any) => {
      if (res) {
        this.snackbarModalComponent.onOpenSnackbarModal(res?.flag, res?.message, '', '', '');
      }
    });
  }

  /**
   * Life Cycle Hook Initialization
   */
  ngOnInit(): void { }

  /**
   * This method is used to get the unique sizes for the table
   * @return {*}  {string[]}
   */
  getUniqueSizes(): string[] {
    return Array.from(
      new Set(
        this.dcGenerateDetails?.colourDetails.map((item: any) => item.size)
      )
    );
  }

  /**
   * This method is used to get the unique colors for the table
   * @return {*}  {string[]}
   */
  getUniqueColors(): string[] {
    return Array.from(
      new Set(
        this.dcGenerateDetails?.colourDetails.map((item: any) => item.color)
      )
    );
  }

  /**
   * This method is used to get the quantity for the table
   * @param {string} color
   * @param {string} size
   * @return {*}  {number}
   */
  getQuantity(color: string, size: string): number {
    const item = this.dcGenerateDetails?.colourDetails.find(
      (item: any) => item.color === color && item.size === size
    );
    return item ? parseInt(item.quantity?.toString(), 10) : 0;
  }

  /**
   * This method is used to get the row total for the table
   * @param {string} color
   * @return {*}  {number}
   */
  getRowTotal(color: string): number {
    return this.getUniqueSizes().reduce(
      (total: any, size: any) => total + this.getQuantity(color, size),
      0
    );
  }

  /**
   * This method is used to get the column total for the table
   * @param {string} size
   * @return {*}  {number}
   */
  getColumnTotal(size: string): number {
    return this.getUniqueColors().reduce(
      (total: any, color: any) => total + this.getQuantity(color, size),
      0
    );
  }

  /**
   * This method is used to get the grand total for the table
   * @return {*}  {number}
   */
  getGrandTotal(): number {
    return this.getUniqueSizes().reduce(
      (total, size) => total + this.getColumnTotal(size),
      0
    );
  }

  /**
   * This method is used for navigate to knitting dc list
   */
  onClickNavigateToSearch() {
    this.router.navigate(['/admin/customer-order/dc/dcList']);
  }

  /**
   * This method is used to generate the DC
   */
  onClickGenerateDC() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.data = {
      name: 'StitchingDcGenerate',
      title: 'Generate Stitching  DC',
      payload: this.dcGenerateDetails?.orderId,
      description: 'Do you want to Generate Stitching DC?',
      cancelButtonText: 'No',
      submitButtonText: 'Yes',
    };
    this.matDialog.open(ModalComponent, dialogConfig);
  }

  /**
   * This method is used to get the is dc exists
   */
  getIsDCExist() {
    /* To call the service to get the is dc exists by passing the Id */
    this.customerService.getIsStitchingDCExist(this.dcGenerateDetails?.orderId).subscribe({
      next: (res: any) => {
        this.generateStatus = res.result;
      },
      error: (err: any) => {
      }
    });
  }

  /**
   * This method fired on click of exportToWord
   * @param {*} dcGenerateDetails
   */
  ExportToWord(dcGenerateDetails: any) {
    const tableRows: TableRow[] = [];
    const tableTwoRows: TableRow[] = [];
    const PatternTableRows: TableRow[] = [];
    const inputString = dcGenerateDetails?.patternData;

    // Replace <b> and </b> tags with an empty string
    const withoutBoldTags = inputString?.replace(/<\/?b>/g, '');
    // Replace <br \\> with <br>
    const convertedString = withoutBoldTags?.replace(/<br \\>/g, '<br>');
    const data = convertedString?.split('<br>');
    let panelArray = data.filter((item: any) => item !== "");
    // const src = `../../../../../ assets / Images / DressImages / ${dcGenerateDetails?.imageFileFullName}`
    // Fetch the image as a blob

    const IMAGE_PATH =
      '/9j/4AAQSkZJRgABAQEAYABgAAD/2wBDAAIBAQIBAQICAgICAgICAwUDAwMDAwYEBAMFBwYHBwcGBwcICQsJCAgKCAcHCg0KCgsMDAwMBwkODw0MDgsMDAz/2wBDAQICAgMDAwYDAwYMCAcIDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAz/wAARCAAuAKADASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD9/K+eP2wv+CqfwM/YYuzYePvG9pB4g2CRdD06J77UiCMqWijB8oEcgylAexrwn/gvd/wVKvv2A/gXp/hnwVdJB8TPHySpZXO0OdFsk+WW7APHmFiEjzxne3Pl4P8AOpK+tfEjxTNM51PXtb1OV55nbzLq6u5DlndjyzseSScnqTX0mUZD9Zh7as7R6d3/AMA8TMc29hL2VJXl+R++t3/wdXfs7W9y6J4T+Mc6qcCSPSNOCv7jdfA/mBUf/EVr+zx/0Jvxn/8ABTpn/wAn1+CGu+BNc8LwiTU9G1XTo2OA11aSQgn6sBVbQ/DuoeJ737NptjeahcbS3lW0LSvgdThQTivf/wBXMDa+v3nj/wBt4u/T7j9+P+IrX9nj/oTfjP8A+CnTP/k+j/iK1/Z4/wChN+M//gp0z/5Pr8H/APhTXjD/AKFTxJ/4LJv/AImqlj8OPEOp3tzbW2g61cXFkwW4iisZXeAnoHAXKk+9H+ruA8/vD+2sX5fcfvX/AMRWv7PH/Qm/Gf8A8FOmf/J9en/s/wD/AAcV/sxfHfXYdNuPEus+Ary5YJF/wlWni0gZj2aeJ5YY/rI6j3r+b7TPB+pat4st9DjtJI9VurhbRLeYeSwlYhQrbsbeSOuK9V/ap/Yi8S/sbGy0/wAb6ho9r4mu4knfRrafz57VGGQJGHyhgCCRnjcuCcnGdTh3A6QTab21NIZzi/isml5H9Zum6lb6xp8F3aTw3VpdRrNDNC4eOZGGVZWHBUgggjgg1PX89/8Awb/f8FZtb/Zs+OOi/CHxrrFxe/DTxldJp+m/apdw8OX8rbYmjZj8kEjkK652qWDjGH3f0IV8hmWXzwdX2ctV0fc+jwWMhiafPHfqgor8Xf8AgqF8N/j1+xt+0j8G9D0v9qj4r6hZfHDxRc6cU8+S2XQY/tVmiiNRMRIFF4cA7f8AVj14+6dI+NfhD/gj18DdM0z9oL48+JPGN14m1e6l03Xtc0m9u7mQLHDutgtutwVRMbgWIBMhxVVMutThOnLmctkk7u2/ToTDG3nKM48qju21byPrmivyq/4LV/8ABRfxbr/7Mfwb8Z/A3xp4l0T4M/EHUryDxF440DTbiG+s44Z44FRfMWKaElhdEDMbSNAAHA+95n+zR+0l8QNE/Zc/aUvvCH7VkXxm8HaN4EudV0WbVLvUbXxz4ev1WPExiuYyywhmlQslxImVhZdpYrWtPJ6kqKqt2u7Ws+9tdLJ+TInmUFUdNK+l76dr6d15n7Q0V+Qn7D//AAXu1z4S/Bn4FaB8T/h78Qde0bxlLJpd38TNTvG8q9uzeyoxhR4j9pSAPEjt5ysNjhUbYN3T+Ev+Ci3hD9lL9pX9tvxzZ+GviFrup+Cb/T21ey1LxWkun3ZXUF05PscX2cG3AM2752lwqhF2iplk+IjKUWvTbX3uXvoOOZUZJST9fLS/zP1Uor8r/wBpH/gtz8V/H/8AwTw8b/E34cfB7xn8Pba1bRE0fxff+TdW4S5eT7XcJFPbGKWKKWBbUMC283iPhNuK2PBv/BdjxB8Ff2Dfg74i+Ifw713xB8UPibcNpmiW8t9a6XbeJliS036m84jENrFI92iqojIBVs7VBIn+yMTy3sr3ta6vtf0/HTqV/aVC9r6WveztvY/Tiivn/wDYH/bZ1r9srwzr83iH4UeM/hZq3h26S3kh1aMz6fqStvAksr0IkV0oMbBjGMDKHJDg19AVwVacqcnCe6OunUjOPNHY/mx/4OQ/H174x/4KueMtOundoPCmlaVpdmGPCRPZRXZA9vMupD9Sa+af2D9UuNH/AG2fhJNazPBL/wAJhpSbkODta7iVh9CpIPsa+8f+Dpf9lTUPAH7WegfFi2tnfQfH+mRWF1OBxFqNouzYx7brfySuevlyY+6a+Cv2Hhbw/tg/DS7vL2206x0vxJY6jdXNxu2QwwTpNIcKrMTtQ4ABr9KwE4zy6Lj/AC2+dtfxPh8ZGUcbLm/m/XQ/Rf8AaP8A2z/FHgb/AILHN8N9Wlt/EXw08U+IxoOpeHtRt0ntHt7m+e3IVSPlKqFwR0wfWuE0n9jC6/Zj/wCC+fhTwx8OoWt/Duk+J9N1C4Q3ccS22mzXixSxMZGG8MhKbBlm3YAJrf8AidoPw38bf8FXJvjf4g+InhuH4eeG9WbX44k85b3U3jupp4Yo0kjRckmMnLZxnAJ4rxnSP2xrD9pv/gtB4W+Kd/q9v4c8M2Piqx1S4lm850Fla3S3BjCxozudoIHyjJGfl7efShLltTVlya6denzOupOPN77159PT/I+p/wBqz4jftBfB/wDae+KXjXw34t0C18F/Dea71WTS5tQs7xr5W1SW3jt2t43aVFEcsX31ULtA6jFfH3/BNj/goDf/AA//AOCnOleNvE175eh+PNTbTtfSQgxCG5YqJHzwfLdlkJ68E969L/aT+E3hj9pT9vXW/Eq/F/RPDXgDxBqV22o3UVtqX2mezl1C4nKCJbbBYxyJwxxn6V8Y/tO/B/S/gT8XrrT/AA34hh8SaGkzNp2oojxNOitgOUdVdc8Hle5GTgmunB0KU6bpTWso9rf076mOJq1IzVSL0T73Ppr4+/sh6j4c/wCCuuo6Fq7yXGmafqUmu39zIf8AVWdqnnuXboC0aIw9RNH3NfMf7XHx7v8A9pT9oHxJ4sv5nmOoXcnklj0jDHH0zycdBnA4Ar9GP24v2lPC3xP/AGHNE8YeH9Y068+MGueC7LQ/FMMSSq6RQFWeQSMiqzsFRmIbJ8iNfm6V+TtdOXOVSPPUWsVy/wCb+ZhjVGD5YPR6/wCQ+3uJLS4SWJ3jljYOjocMjDkEHsa/sF/Zv8b3XxM/Z38BeJL7JvfEHhzT9SuMj/lpNbRyN+rGv5Mf2ZfgBrf7U/x/8JfD3w7C0ureLNSisYiFyIEJzJM3+xHGHkb/AGUNf14eD/Ctn4F8JaXomnIY9P0ezisbZCclIokCIP8AvlRXg8WTj+7h11+7Q9fh6Mvfl00PkP8A4Kkf8E7PG37bnx6/Z18U+FNU8Lafp/wi8Ry6xrEerXM8U1zC1xp8oW3EcMgZ9tpJw5QZZeeSR9hav4esPECIt/Y2d6sZJQXEKyBCeuNwOKwPjh8VYPgj8J9c8VXFpLfx6Nb+aLaNwhmcsFRSzcICzLljwoycHFcPqX7XMHw6uLnT/HOjLpGtWsF1eGHSNQTVbaS3gm0+IsJCsLq5bUrf5JIkb5XPK7Gf5Sdec4RpvaN7fN3PoY0oxnKa3lv8tDy7/go9+xV8XPjmngzXPgT8UH+HWueD5pPP0C7up4vDXiGF2V9l3bxB0fBDDDxOrrIwOMA18n/Cj/ghJ8XNRu/jh438d+Ivhdp/j34neDLvwzpek+F7SSw0S0luEhQzT+XbpsAEK5EcTlmdnLFuv3Jd/wDBQ/wxFq9pFHomvCzGo3tlqdxObeJ9KjtrK5vGneHzTLgx2spCMqyYUnbkory3H/BRHwdaXUVrJonjJdRM629zZDT42msHeSxjiEuJSv7xtSstu0t/rxnG1tvVRzHEUqfs4W+5X3va5hUwVKpPnlf79Ox8YfE7/giL8VvGn7AP7N/wqtfEHw9j8Q/B/Xr3VNZuJb68FlcxTXks6i3YWpdmCuAQ6IM55I5pvxU/4Ih/Ffxxrv7X11aeIPh7HH8f7q2m8PCa+vAbNYtYivm+14tTsPlIQPL8z5iB0+avs34iftwS6T4Z8K6z4V8Lwa5p2v8Ah3VvFF1/amrHSprG0042wmjVRBMsk5NwQFZ40zGcyYOQ9v8Agov4El/t37LY+KLxdB2CWSOxRIpCZo4ZB5jyKkXlSSqHacxrwxUsFJGizbEra299u8ub80Q8uoP7rfhb8jzvx1/wTn8R/EL/AII2W37ONzrWiWfiuDwpYaQdRiaWXTjd2ksMy/MUWTymeEKW8vcAxO0kYPgHiL/glf8AtF+P/wBgH4X/AA71uf4A6trvwyu5baLSNZ02a+03UtMWOEQZu/IFzb3I2TI/kbVkR0O9GWvr+2/4KIeEDeXaGy1q8SG4jw9jbpKILaRNP8ueUl1GGk1GFMRlz1bG1SwD/wAFH/Aq+HpNSbTfFUUEbWrHzrOGFRBcJdNHcmR5RGsRNlcJ8zhy6AKrbl3ZU8wrw2t8XNt1Zc8FSnv2t8jxj/gjT/wS58Yf8E9br4i614t13w5HN8QLqK4i8LeGHu5NF0JUaVh5b3JMrsBKIxuyQsYy8mcj7npFcOoIIIIyCO9LXNicROvUdWpuzejRjSgqcNkeeftT/sueDv2yfghrPw/8dab/AGjoOsoMlCFns5V5juIXwdkqHkNg9wQVJU/z7/tvf8G+Xx4/ZV8U31z4S0K++KXg0OzWeo6BAZr9I+yz2a5lV8ZyYxInH3hnA/pLorty7Nq+DdoaxfRnLjcupYnWej7n8gF7+zL8T7Sdobj4fePI5EOGjk0K7DKfcFKhX9mz4kIcjwD43B9Rod1/8RX9gtFe1/rZP/n2vv8A+AeX/q9H+f8AA/j9/wCGc/iX/wBCJ45/8El1/wDEU1/2bfiRIfm8A+Nz9dDuv/iK/sEoo/1sn/z7X3/8AP8AV6P8/wCH/BP4/P8AhnH4lbcf8IH44x0x/Yl1/wDEV6X+z9/wSo/aF/aX16Cy8NfCnxfHBM4VtR1WwfTNPiHdjPcBEOByQpZvRSSBX9XFFTPiuq17tNJ+v/DFR4ep396bPh3/AIJBf8EYPDv/AATZ0CfxDrl3Z+KviprEHkXeqxRn7LpcJwTb2gYBsEgb5GAZ8AYUZB+4qKK+axGIqV6jq1Xds9yjRhSgoU1ZFXWtFs/Emj3Wn6ha219YX0LW9zbXEQkiuI2BVkdSCGUgkEEYINcPD+yd8MoNE0/TU8BeE1sdJnlurOEaZFtt5ZdvmSL8vDNsTJ6ny0/ujHoVFYGpxFp+zZ8P7BiYfBnhqIm8/tA7dPiH7/ZJHv6f3JZVx0xI4xhjldG/Zt8AeHbO3t7Dwb4cs4bUgxJDYRoEInhuARgdRNbwP9YY/wC6K7aii4HD+JP2aPh94w07RrTVfBnhzUrTw75n9mwXNhHLFZeYyvIEUggBmRCRjB2jNP1n9nHwD4h1TVL298HeHbm81pke+newjMlyysrKzNjO7ciHPXKKewrtaKLsDyHx7+w78O/Ht9oMjaNb6Xb6BcLcxWun2tvDFMVNrtViYmdAFsrdMwtG2yPbnbxXR6n+zD8O9a09bS78FeGrm2WGK3EUthGyiOIThEwR90C5uBjpieQdGNd3RRdgIqhFAAwBwAO1LRRQB//Z';

    const imageModelPath = dcGenerateDetails?.imageBase64 ? `data:image/png;base64,${dcGenerateDetails?.imageBase64}` : this.src;

    //preparing unique sizes Array
    const uniqueSizesSet = this.getUniqueSizes();

    //preparing unique colours Array
    const uniqueColoursSet = this.getUniqueColors();
    const grandTotal = this.getGrandTotal();
    const formattedGrandTotal = grandTotal.toLocaleString('en-IN');
    const GrandTotal = grandTotal
      .toFixed(3)
      .replace(/\d(?=(\d{3})+\.)/g, '$&,');
    let printValue = '';
    if (dcGenerateDetails?.printType === 1) {
      printValue = 'pocket';
    } else if (dcGenerateDetails?.printType === 2) {
      printValue = 'Chest';
    } else {
      printValue = '-';
    }

    //Logo
    const image = new Header({
      children: [
        new Paragraph({
          children: [
            new ImageRun({
              data: IMAGE_PATH,
              transformation: {
                width: 130,
                height: 40,
              },
            }),
          ],
        }),
      ],
    });

    // Header
    const additionalInfo = new Paragraph({
      alignment: AlignmentType.CENTER,
      children: [
        new TextRun({
          text: `DEV T-SHIRTS Pvt. Ltd.`,
          bold: true,
          font: 'Arial Black',
          color: '#000000',
          size: 40,
        }),
      ],
    });

    //creating empty para
    const emptyPara = new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: {
        line: 150,
      },
      children: [
        new TextRun({
          text: ``,
        }),
      ],
    });

    // subHeader
    const subhead = new Paragraph({
      alignment: AlignmentType.CENTER,
      children: [
        new TextRun({
          text: `Stitching Unit DC`,
          bold: true,
          font: 'Arial Black',
          color: '#000000',
          size: 32,
        }),
      ],
    });

    //creating dc no
    const DcNo = new Paragraph({
      frame: {
        position: {
          x: 0,
          y: 800,
        },
        width: 2800,
        height: 400,
        anchor: {
          horizontal: FrameAnchorType.MARGIN,
          vertical: FrameAnchorType.MARGIN,
        },
        alignment: {
          x: HorizontalPositionAlign.LEFT,
          y: VerticalPositionAlign.TOP,
        },
      },

      children: [
        new TextRun({
          text: 'DC No: ',
          bold: true,
          font: 'Arial',
        }),
        new TextRun({
          text: `${dcGenerateDetails?.sdcName}`,
          font: 'Arial',
        }),
      ],
    });

    //creating unit name
    const unitName = new Paragraph({
      frame: {
        position: {
          x: 0,
          y: 2400,
        },
        width: 6500,
        height: 350,
        anchor: {
          horizontal: FrameAnchorType.MARGIN,
          vertical: FrameAnchorType.MARGIN,
        },
        alignment: {
          x: HorizontalPositionAlign.LEFT,
          y: VerticalPositionAlign.TOP,
        },
      },

      children: [
        new TextRun({
          text: 'Unit Name: ',
          bold: true,
          font: 'Arial',
        }),
        new TextRun({
          text: `${dcGenerateDetails?.unitName ? dcGenerateDetails?.unitName : '_______________'}`,
          font: 'Arial',
        }),
      ],
    });

    //creating order no
    const OrderNo = new Paragraph({
      frame: {
        position: {
          x: 6800,
          y: 1200,
        },
        width: 2500,
        height: 350,
        anchor: {
          horizontal: FrameAnchorType.MARGIN,
          vertical: FrameAnchorType.MARGIN,
        },
        alignment: {
          x: HorizontalPositionAlign.RIGHT,
          y: VerticalPositionAlign.TOP,
        },
      },

      children: [
        new TextRun({
          style: AlignmentType.END,
          text: 'Order No: ',
          bold: true,
          font: 'Arial',
        }),
        new TextRun({
          style: AlignmentType.END,
          text: dcGenerateDetails?.orderNo,
          font: 'Arial',
        }),
      ],
    });

    //creating organization
    const organization = new Paragraph({
      frame: {
        position: {
          x: 0,
          y: 2800,
        },
        width: 6500,
        height: 450,
        anchor: {
          horizontal: FrameAnchorType.MARGIN,
          vertical: FrameAnchorType.MARGIN,
        },
        alignment: {
          x: HorizontalPositionAlign.RIGHT,
          y: VerticalPositionAlign.TOP,
        },
      },

      children: [
        new TextRun({
          style: AlignmentType.END,
          text: 'Organization: ',
          bold: true,
          font: 'Arial',
        }),
        new TextRun({
          style: AlignmentType.END,
          text: dcGenerateDetails?.schoolName.charAt(0).toUpperCase() + dcGenerateDetails.schoolName?.slice(1),
          font: 'Arial',
        }),
      ],
    });

    //creating quality
    const Quality = new Paragraph({
      frame: {
        position: {
          x: 0,
          y: 2000,
        },
        width: 6500,
        height: 350,
        anchor: {
          horizontal: FrameAnchorType.MARGIN,
          vertical: FrameAnchorType.MARGIN,
        },
        alignment: {
          x: HorizontalPositionAlign.RIGHT,
          y: VerticalPositionAlign.TOP,
        },
      },

      children: [
        new TextRun({
          style: AlignmentType.END,
          text: 'Quality: ',
          bold: true,
          font: 'Arial',
        }),
        new TextRun({
          style: AlignmentType.END,
          text: dcGenerateDetails?.quality,
          font: 'Arial',
        }),
      ],
    });

    //creating date
    const Date = new Paragraph({
      frame: {
        position: {
          x: 0,
          y: 1600,
        },
        width: 4500,
        height: 400,
        anchor: {
          horizontal: FrameAnchorType.MARGIN,
          vertical: FrameAnchorType.MARGIN,
        },
        alignment: {
          x: HorizontalPositionAlign.CENTER,
          y: VerticalPositionAlign.TOP,
        },
      },

      children: [
        new TextRun({
          text: 'Date: ',
          bold: true,
          font: 'Arial',
        }),
        new TextRun({
          // text: dcGenerateDetails?.sdcDate,
          text: '__________',

          font: 'Arial',
        }),
      ],
    });

    //creating dress item
    const DressItem = new Paragraph({
      frame: {
        position: {
          x: 6800,
          y: 800,
        },
        width: 2200,
        height: 400,
        anchor: {
          horizontal: FrameAnchorType.MARGIN,
          vertical: FrameAnchorType.MARGIN,
        },
        alignment: {
          x: HorizontalPositionAlign.RIGHT,
          y: VerticalPositionAlign.TOP,
        },
      },

      children: [
        new TextRun({
          style: AlignmentType.END,
          text: 'Dress Item: ',
          bold: true,
          font: 'Arial',
        }),
        new TextRun({
          style: AlignmentType.END,
          text: dcGenerateDetails?.dressItem,
          font: 'Arial',
        }),
      ],
    });

    //creating printType
    const printType = new Paragraph({
      frame: {
        position: {
          x: 0,
          y: 1200,
        },
        width: 3000,
        height: 400,
        anchor: {
          horizontal: FrameAnchorType.MARGIN,
          vertical: FrameAnchorType.MARGIN,
        },
        alignment: {
          x: HorizontalPositionAlign.RIGHT,
          y: VerticalPositionAlign.TOP,
        },
      },

      children: [
        new TextRun({
          style: AlignmentType.END,
          text: 'Print Type: ',
          bold: true,
          font: 'Arial',
        }),
        new TextRun({
          style: AlignmentType.END,
          text: `${printValue}`,
          font: 'Arial',
        }),
      ],
    });

    //creating patternType
    const PatternType = new Paragraph({
      alignment: AlignmentType.LEFT,

      children: [
        new TextRun({
          text: `Pattern Type: `,
          bold: true,
          font: 'Arial',
          color: '#000000',
        }),
        new TextRun({
          text: `${dcGenerateDetails?.pattern}`,
          font: 'Arial',
          color: '#000000',
        }),
      ],
    });

    //creating imageModel
    const imageModel = new Paragraph({
      children: [
        new TextRun({
          style: AlignmentType.END,
          text: '',
          bold: true,
          font: 'Arial',
        }),
        new ImageRun({
          data: imageModelPath,
          transformation: {
            width: 120,
            height: 90,
          },
        }),
      ],
    })

    //creating noImageModel
    const noImageModel = new Paragraph({
      children: [
        new TextRun({
          style: AlignmentType.END,
          text: 'Image Model: ',
          bold: true,
          font: 'Arial',
        }),
        new TextRun({
          style: AlignmentType.END,
          text: '  -',
          font: 'Arial',
        }),
      ],
    })

    /* Creating Pattern Details */
    const PatternDetails = new Paragraph({
      alignment: AlignmentType.LEFT,
      children: [
        new TextRun({
          text: ``,
          bold: true,
          font: 'Arial',
          color: '#000000',
        }),
        ...panelArray?.map((data: any, index: any) => {
          const [label, value] = data?.split(':');
          let before = 0;
          if (index !== 0) {
            before = 1500;
          }

          const paragraph = new Paragraph({
            indent: { left: before },
            spacing: {
              line: 300,
            },
            children: [
              new TextRun({
                text: `${label}: `,
                font: 'Arial',
                color: '#000000',
                bold: true,
              }),
              new TextRun({
                text: `${value ? value : '-'} `,
                font: 'Arial',
                color: '#000000',
              }),
            ],
          });

          return paragraph;
        }),
      ],
    });

    // Create table headers
    const tableHeader = new TableRow({
      children: [
        new TableCell({
          margins: { top: 100, bottom: 100 },
          width: {
            size: 3505,
            type: WidthType.DXA,
          },
          verticalAlign: VerticalAlign.CENTER,
          shading: {
            fill: 'DBDBDB', // Specifying the background color
          },
          children: [
            new Paragraph({
              children: [
                new TextRun({
                  text: 'Colour',
                  bold: true,
                  color: '#000000',
                  font: 'Arial',
                }),
              ],
              alignment: AlignmentType.CENTER, // Center align the text vertically
            }),
          ],
        }),
        // Dynamically generate cells for each unique size
        ...uniqueSizesSet?.map(
          (size) =>
            new TableCell({
              margins: { top: 100, bottom: 100 },
              width: {
                size: 2000, // Adjust the width as needed
                type: WidthType.DXA,
              },
              verticalAlign: VerticalAlign.CENTER,
              shading: {
                fill: 'DBDBDB', // Specifying the background color
              },
              children: [
                new Paragraph({
                  children: [
                    new TextRun({
                      text: `${size}`,
                      bold: true,
                      font: 'Arial',
                      color: '#000000',
                    }),
                  ],
                  alignment: AlignmentType.CENTER, // Center align the text vertically
                }),
              ],
            })
        ),
        // Last cell for "Total"
        new TableCell({
          margins: { top: 100, bottom: 100 },
          width: {
            size: 2000,
            type: WidthType.DXA,
          },
          verticalAlign: VerticalAlign.CENTER,
          shading: {
            fill: 'DBDBDB', // Specifying the background color
          },
          children: [
            new Paragraph({
              children: [
                new TextRun({
                  text: 'Total Quantity',
                  bold: true,
                  font: 'Arial',
                  color: '#000000',
                }),
              ],
              alignment: AlignmentType.CENTER, // Center align the text vertically
            }),
          ],
        }),
      ],
    });

    //adding header to table rows
    tableRows.push(tableHeader);

    //Create data rows from the inwardFabricList array
    uniqueColoursSet?.forEach((item: any, index: number) => {
      const rowTotal = this.getRowTotal(item);
      let RowTotal = rowTotal.toLocaleString('en-IN')
      const row = new TableRow({

        children: [
          // Dynamically generate cells for each unique size
          new TableCell({

            margins: {
              left: 100, top: 100, bottom: 100
            },
            width: {
              size: 2000, // Adjust the width as needed
              type: WidthType.DXA,
            },
            verticalAlign: VerticalAlign.CENTER,
            children: [
              new Paragraph({
                children: [
                  new TextRun({
                    text: `${item}`,
                    font: 'Arial',
                    color: '#000000',
                  }),
                ],
                alignment: AlignmentType.LEFT,
                // Center align the text vertically
              }),
            ],
          }),
          ...uniqueSizesSet.map((size) => {
            const quantity = this.getQuantity(item, size);
            const Quantity = quantity.toLocaleString('en-IN')
            return new TableCell({
              margins: {
                right: 100, top: 100, bottom: 100
              },
              width: {
                size: 2000, // Adjust the width as needed
                type: WidthType.DXA,
              },
              verticalAlign: VerticalAlign.CENTER,
              children: [
                new Paragraph({
                  children: [
                    new TextRun({
                      text: `${Quantity}`,
                      font: 'Arial',
                      color: '#000000',
                    }),
                  ],
                  alignment: AlignmentType.RIGHT, // Center align the text vertically
                }),
              ],
            });
          }),
          new TableCell({
            margins: {
              right: 100, top: 100, bottom: 100
            },
            width: {
              size: 2000, // Adjust the width as needed
              type: WidthType.DXA,
            },
            verticalAlign: VerticalAlign.CENTER,
            children: [
              new Paragraph({
                children: [
                  new TextRun({
                    text: `${RowTotal}`,
                    font: 'Arial',
                    color: '#000000',
                  }),
                ],
                alignment: AlignmentType.RIGHT, // Center align the text vertically
              }),
            ],
          }),
        ],
      });
      tableRows.push(row);
    });

    //table Footer
    const tableFooter = new TableRow({

      children: [
        new TableCell({
          margins: {
            right: 100, top: 100, bottom: 100
          },
          width: {
            size: 3505, // Adjust the width as needed
            type: WidthType.DXA,
          },
          verticalAlign: VerticalAlign.CENTER,
          children: [
            new Paragraph({
              alignment: AlignmentType.RIGHT,
              children: [
                new TextRun({
                  text: `Total: `,
                  color: '#000000',
                  size: 20,
                  font: 'Arial',
                  bold: true,
                }),
              ],
            }),
          ],
        }),
        ...uniqueSizesSet.map((size) => {
          const columnTotal = this.getColumnTotal(size);
          let ColumnTotal = columnTotal.toLocaleString('en-IN')
          return new TableCell({
            margins: {
              right: 100, top: 100, bottom: 100
            },
            verticalAlign: VerticalAlign.CENTER,
            children: [
              new Paragraph({

                children: [
                  new TextRun({
                    text: `${ColumnTotal}`,
                    font: 'Arial',
                    color: '#000000',
                    bold: true,
                  }),
                ],
                alignment: AlignmentType.RIGHT, // Center align the text vertically
              }),
            ],
          });
        }),
        new TableCell({
          margins: {
            right: 100, top: 100, bottom: 100
          },
          width: {
            size: 2000, // Adjust the width as needed
            type: WidthType.DXA,
          },
          verticalAlign: VerticalAlign.CENTER,
          children: [
            new Paragraph({
              children: [
                new TextRun({
                  text: `${formattedGrandTotal}`,
                  font: 'Arial',
                  color: '#000000',
                  bold: true,
                }),
              ],
              alignment: AlignmentType.RIGHT, // Center align the text vertically
            }),
          ],
        }),
      ],
    });

    //adding footer to table rows
    tableRows.push(tableFooter);

    //preparing table
    const table = new Table({
      width: {
        size: 9100, // Adjust the width size as needed
        type: WidthType.DXA,
      },
      rows: tableRows,
    });

    const footerSection = new Paragraph({
      children: [
        new TextRun({
          text: 'Manager: ',
          bold: true,
          font: 'Arial',
        }),
        new TextRun({
          text: '',
          font: 'Arial',
        }),
        new TextRun({
          text: '                                                                                                      ', // Add space between "Quality" and "Colour"
        }),
        new TextRun({
          text: 'Order Processed by: ',
          font: 'Arial',

          bold: true,
        }),
        new TextRun({
          text: '',
          font: 'Arial',
        }),
      ],
    });

    // Create table headers

    const tableTwoHeader = new TableRow({
      height: {
        value: 450,
        rule: HeightRule.EXACT,
      },
      children: [
        new TableCell({
          width: {
            size: 2000,
            type: WidthType.DXA,
          },
          verticalAlign: VerticalAlign.CENTER,
          shading: {
            fill: 'DBDBDB', // Specifying the background color
          },
          children: [
            new Paragraph({
              children: [
                new TextRun({
                  text: 'Body',
                  bold: true,
                  color: '#000000',
                  font: 'Arial',
                }),
              ],
              alignment: AlignmentType.CENTER, // Center align the text vertically
            }),
          ],
        }),

        // Last cell for "Total"
        new TableCell({
          width: {
            size: 2000,
            type: WidthType.DXA,
          },
          verticalAlign: VerticalAlign.CENTER,
          shading: {
            fill: 'DBDBDB', // Specifying the background color
          },
          children: [
            new Paragraph({
              children: [
                new TextRun({
                  text: 'Panel',
                  bold: true,
                  font: 'Arial',
                  color: '#000000',
                }),
              ],
              alignment: AlignmentType.CENTER, // Center align the text vertically
            }),
          ],
        }),
      ],
    });

    // //adding header to table rows
    tableTwoRows.push(tableTwoHeader);

    dcGenerateDetails?.panelData.forEach((item: any, index: number) => {
      const row = new TableRow({
        height: {
          value: 450,
          rule: HeightRule.EXACT,
        },
        children: [
          new TableCell({
            margins: {
              left: 100,
            },
            width: {
              size: 2000,
              type: WidthType.DXA,
            },
            verticalAlign: VerticalAlign.CENTER,
            children: [
              new Paragraph({
                alignment: AlignmentType.LEFT,

                children: [
                  new TextRun({
                    text: `${item?.bodyColor}`,
                    color: '#000000',
                    font: 'Arial',
                  }),
                ],
              }),
            ],
          }),
          new TableCell({
            margins: {
              left: 100,
            },
            width: {
              size: 2000,
              type: WidthType.DXA,
            },
            verticalAlign: VerticalAlign.CENTER,
            children: [
              new Paragraph({
                alignment: AlignmentType.LEFT,

                children: [
                  new TextRun({
                    text: `${item?.panelColor}`,
                    color: '#000000',
                    font: 'Arial',
                  }),
                ],
              }),
            ],
          }),
        ],
      });
      tableTwoRows.push(row);
    });

    const tableTwo = new Table({
      width: {
        size: 9100, // Adjust the width size as needed
        type: WidthType.DXA,
      },
      rows: tableTwoRows,
    });

    //conditional table two show
    const tableTwoShow = dcGenerateDetails?.panelData?.length > 0
      ? tableTwo
      : emptyPara;

    //conditional pattern details show
    const pattern = dcGenerateDetails?.patternData?.length > 0
      ? PatternDetails
      : emptyPara;

    const patternType = dcGenerateDetails?.pattern?.length > 0
      ? PatternType
      : emptyPara;

    // const imageShow = dcGenerateDetails?.imageBase64.length !== 0
    //   ? imageModel
    //   : noImageModel;

    const tablePatternRow1 = new TableRow({
      // height: {
      //   value: 650,
      //   rule: HeightRule.EXACT,
      // },
      children: [
        new TableCell({
          borders: {
            top: { style: BorderStyle.NIL, color: '#FFFFFF' },
            bottom: { style: BorderStyle.NIL, color: '#FFFFFF' },
            left: { style: BorderStyle.NIL, color: '#FFFFFF' },
            right: { style: BorderStyle.NIL, color: '#FFFFFF' },
          },
          // width: {
          //   size: 2000,
          //   type: WidthType.DXA,
          // },
          verticalAlign: VerticalAlign.CENTER,
          children: [
            new Paragraph({
              alignment: AlignmentType.RIGHT,
              children: [
                new TextRun({
                  text: `Pattern Details: `,
                  color: '#000000',
                  font: 'Arial',
                  bold: true,
                }),
                PatternDetails // Adding the PatternDetails paragraph here
              ],
            }),
          ],
        }),
        new TableCell({
          borders: {
            top: { style: BorderStyle.NIL, color: '#FFFFFF' },
            bottom: { style: BorderStyle.NIL, color: '#FFFFFF' },
            left: { style: BorderStyle.NIL, color: '#FFFFFF' },
            right: { style: BorderStyle.NIL, color: '#FFFFFF' },
          },

          verticalAlign: VerticalAlign.TOP,
          children: [
            new Paragraph({
              alignment: AlignmentType.LEFT,
              children: [
                new TextRun({
                  text: '\u00A0\u00A0\u00A0\u00A0',
                  bold: true,
                  font: 'Arial',
                }),
              ],
            }),
            dcGenerateDetails?.imageBase64 !== '' ? imageModel : noImageModel,  // This will appear below 'Image Model:'
          ],
        })

      ],
    });

    PatternTableRows.push(tablePatternRow1);

    const PatternTable = new Table({
      borders: {
        top: { style: BorderStyle.NONE },
        bottom: { style: BorderStyle.NONE },
        left: { style: BorderStyle.NONE },
        right: { style: BorderStyle.NONE },
      },
      alignment: AlignmentType.CENTER,
      width: {
        size: 9100, // Adjust the width size as needed
        type: WidthType.DXA,
      },
      rows: PatternTableRows,
    });

    const doc = new Document({
      sections: [
        {
          headers: {
            default: image,
          },
          children: [
            subhead,
            DcNo,
            unitName,
            Date,
            OrderNo,
            organization,
            Quality,
            DressItem,
            printType,
            // imageShow,
            table,
            emptyPara,
            emptyPara,
            patternType,
            emptyPara,
            PatternTable,
            emptyPara,
            emptyPara,
            tableTwoShow,
            emptyPara,
            emptyPara,
            emptyPara,
            emptyPara,
            emptyPara,
            emptyPara,
            emptyPara,
            emptyPara,
            emptyPara,
            emptyPara,
            emptyPara,
            footerSection,
          ],
        },
      ],
    });

    const Year = this.fromDate.getFullYear();
    const Month = (this.fromDate.getMonth() + 1).toString().padStart(2, '0'); // Months are zero-based
    const Day = this.fromDate.getDate().toString().padStart(2, '0');
    // Create the readable format

    const monthNames = [
      "Jan", "Feb", "Mar", "Apr", "May", "Jun",
      "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
    ];
    const Mont = monthNames[(+Month - 1)];
    const readableFormat = `${Day}-${Mont}-${Year}`;
    // Generate the document and offer it for download
    Packer.toBlob(doc).then((blob) => {
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `Stitching_Unit_DC_${readableFormat}.docx`;
      a.click();
      window.URL.revokeObjectURL(url);
    });
  }
}
