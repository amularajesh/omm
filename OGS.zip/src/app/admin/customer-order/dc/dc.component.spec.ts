import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DcComponent } from './dc.component';

describe('DcComponent', () => {
  let component: DcComponent;
  let fixture: ComponentFixture<DcComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DcComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DcComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
