import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { DcGenerateComponent } from './dc-generate/dc-generate.component';
import { DcListComponent } from './dc-list/dc-list.component';
import { DcComponent } from './dc.component';

const routes: Routes = [
  {
    path: '',
    component: DcComponent,
    children: [
      { path: '', redirectTo: "dcList", pathMatch: 'full' },
      { path: 'dcList', component: DcListComponent },
      { path: 'dcGenerate', component: DcGenerateComponent },
    ]
  }
];

/**
 * Dc Routing Module
 * @export
 * @class DcRoutingModule
 */
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DcRoutingModule { }
