import { Component } from '@angular/core';

/**
 * Customer Order Component
 * @export
 * @class CustomerOrderComponent
 */
@Component({
  selector: 'app-customer-order',
  templateUrl: './customer-order.component.html',
  styleUrls: ['./customer-order.component.scss']
})
export class CustomerOrderComponent { }