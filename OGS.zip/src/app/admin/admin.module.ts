import { CommonModule, DatePipe } from "@angular/common";
import { NgModule } from "@angular/core";

import { ComponentModule } from "../core/Modules/component.module";
import { AdminRoutingModule } from "./admin-routing.module";
import { AdminComponent } from "./admin.component";

/**
 * Admin Module
 * @export
 * @class AdminModule
 */
@NgModule({
  declarations: [AdminComponent],
  imports: [CommonModule, AdminRoutingModule, ComponentModule],
  providers: [DatePipe]
})
export class AdminModule { }
