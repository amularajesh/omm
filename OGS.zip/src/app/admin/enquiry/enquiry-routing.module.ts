import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { EnquiryComponent } from './enquiry.component';

const routes: Routes = [
  {
    path: "",
    component: EnquiryComponent,
    children: [
      { path: '', redirectTo: `${localStorage.getItem('enquiryModule')}`, pathMatch: 'full' },
      { path: "", component: EnquiryComponent, pathMatch: "full" },
      {
        path: "customerenquiry",
        loadChildren: () => import("./customer-enquiry/customer-enquiry.module").then((m) => m.CustomerEnquiryModule)
      },
    ]
  },
];

/**
 * Enquiry Routing Module
 * @export
 * @class EnquiryRoutingModule
 */
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class EnquiryRoutingModule { }
