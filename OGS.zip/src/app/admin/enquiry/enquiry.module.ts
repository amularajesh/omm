import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatTooltipModule } from '@angular/material/tooltip';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { AutosizeModule } from 'ngx-autosize';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { OrderModule } from 'ngx-order-pipe';
import { NgxPaginationModule } from 'ngx-pagination';

import { ComponentModule } from 'src/app/core/Modules/component.module';
import { CustomerEnquiryComponent } from './customer-enquiry/customer-enquiry.component';
import { EnquiryRoutingModule } from './enquiry-routing.module';
import { EnquiryComponent } from './enquiry.component';

/**
 * Enquiry Module
 * @export
 * @class EnquiryModule
 */
@NgModule({
  declarations: [
    EnquiryComponent,
    CustomerEnquiryComponent
  ],
  imports: [
    CommonModule,
    EnquiryRoutingModule,
   
  ]
})
export class EnquiryModule { }
