import { DatePipe } from '@angular/common';
import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { Router } from '@angular/router';

import { ModalComponent } from 'src/app/core/Dialogues/Modal/modal.component';
import { SnackbarModalComponent } from 'src/app/core/Dialogues/snackbar-modal/snackbar-modal.component';
import { CustomersService } from 'src/app/core/Services/customers.service';
import { FeedbackService } from 'src/app/core/Services/feedback.service';
import { LoaderService } from 'src/app/core/Services/loader.service';
import { MastersService } from 'src/app/core/Services/masters.service';
import { ValidationService } from 'src/app/core/Services/validation.service';

/**
 * Edit Enquiry Component
 * @export
 * @class EditEnquiryComponent
 * @implements {OnInit}
 */
@Component({
  selector: 'app-edit-enquiry',
  templateUrl: './edit-enquiry.component.html',
  styleUrls: ['./edit-enquiry.component.scss']
})
export class EditEnquiryComponent implements OnInit {
  /**
   * Get Snackbar Modal Component
   * @type {SnackbarModalComponent}
   */
  @ViewChild("snackbarModalComponent") snackbarModalComponent!: SnackbarModalComponent;

  /**
   * Get Is Admin Or Manager Flag
   */
  isAdminOrManager = false;

  /**
   * Get Min Date.
   * @type {Date}
   */
  minDate: Date;

  /**
   * Get Max Date.
   * @type {Date}
   */
  maxDate: Date;

  /**
   * Get Courier Min Date.
   * @type {Date}
   */
  courierMinDate: Date;

  /**
   * Get Couriers List
   * @type {*}
   */
  couriersList: any;

  /**
   * Get Selected Courier
   * @type {*}
   */
  selectedCourier: any;

  /**
   * Get States List
   * @type {*}
   */
  statesList: any;

  /**
   * Get Districts List
   * @type {*}
   */
  districtsList: any;

  /**
   * Get Mandals List
   * @type {*}
   */
  mandalsList: any;

  /**
   * Get towns list
   * @type {*}
   */
  townList: any;

  /**
   * Declaring Edit Enquiry Form
   * @type {FormGroup}
   */
  editEnquiryForm!: FormGroup;

  /**
   * Courier Invoice Form Declaration
   */
  courierFormArray: FormGroup[] = [];

  /**
   * Get Courier Details
   * @type {*}
   */
  courierDetails: any = [];

  /**
   * Get Staffs List
   * @type {*}
   */
  staffList: any;

  /**
   * Get Is Add Clicked Flag
   */
  isAddClicked = false;

  /**
   * Get Is Courier Details Added Flag
   */
  courierDetailsLength = 0;

  /**
   * Get Edit Enquiry Details
   * @type {*}
   */
  editEnquiryDetails: any;

  /**
   * Get Enquiry Form Validations
   */
  addEnquiryValidation = this.validationService?.editEnquiry;

  /**
   * Get Patterns
   */
  enquiryValidationPattern = this.validationService?.patterns;

  /**
   * Get Location Validations
   */
  locationValidation = this.validationService.locationSelect;

  /**
   * Creates an instance of EditEnquiryComponent.
   * @param {Router} router
   * @param {FormBuilder} formBuilder
   * @param {ValidationService} validationService
   * @param {MastersService} mastersService
   * @param {LoaderService} loaderService
   * @param {FeedbackService} feedbackService
   * @param {CustomersService} customerService
   * @param {DatePipe} datePipe
   * @param {MatDialog} matDialog
   */
  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private validationService: ValidationService,
    private mastersService: MastersService,
    private loaderService: LoaderService,
    private feedbackService: FeedbackService,
    private customerService: CustomersService,
    private datePipe: DatePipe,
    private matDialog: MatDialog,
  ) {
    if (localStorage.getItem('userTypeId') == '1' || localStorage.getItem('userTypeId') == '4') {
      this.isAdminOrManager = true;
    }

    /* Get Order Details from behavior subject*/
    this.feedbackService.enquiryDetails.subscribe((val: any) => {
      if (Object.keys(val).length !== 0) {
        this.editEnquiryDetails = val;
        this.courierDetails = val.enquiryDetailsList || [];
        this.courierDetailsLength = this.courierDetails.length;
      } else {
        this.editEnquiryDetails = null;
        this.onNavigateToList();
      }
    });

    this.minDate = new Date("2000-01-01");
    this.maxDate = new Date();
    this.courierMinDate = new Date();

    /* Get snackbar details from behavior subject */
    this.customerService.snackbarDetails.subscribe((res: any) => {
      if (res) {
        this.snackbarModalComponent?.onOpenSnackbarModal(res?.flag, res?.message, '', '', res?.navigatePage || '');
      }
    });
  }

  /**
   * Life Cycle Hook Initialization
   */
  ngOnInit(): void {
    if (this.courierDetails?.length == 0) {
      this.isAddClicked = true;
      this.courierDetails.push(
        {
          enquiryDetailId: 0,
          docketNo: "",
          courierId: '',
          courierSendDate: "",
          remarks: "",
          courieredReceivedDate: ""
        }
      );
    }
    this.editEnquiryFormValidation();
    this.courierFormValidations();
    this.getStates();
    this.getCouriersList();
    this.getStaffsList();
  }

  /**
   * Initialize Enquiry form validations
   */
  editEnquiryFormValidation() {
    this.editEnquiryForm = this.formBuilder.group({
      OrganizationName: [
        this.editEnquiryDetails ? this.editEnquiryDetails?.organizationName : '',
        [
          Validators.required,
          Validators.minLength(this.addEnquiryValidation.OrganizationName.minLength),
          Validators.maxLength(this.addEnquiryValidation.OrganizationName.maxLength),
        ],
      ],
      stateSelect: ['', [Validators.required]],
      districtSelect: ['', [Validators.required]],
      mandalSelect: ['', [Validators.required]],
      townSelect: ['', [Validators.required]],
      staff: ['', [Validators.required]],
      EnquiryDetails: [
        this.editEnquiryDetails ? this.editEnquiryDetails?.enquiryDetails : '',
        [
          Validators.required,
          Validators.minLength(this.addEnquiryValidation?.EnquiryDetails.minLength),
          Validators.maxLength(this.addEnquiryValidation?.EnquiryDetails.maxLength),
        ],
      ],
      Address: [
        this.editEnquiryDetails ? this.editEnquiryDetails?.address : '',
        [
          Validators.required,
          Validators.minLength(this.addEnquiryValidation?.Address.minLength),
          Validators.maxLength(this.addEnquiryValidation?.Address.maxLength),
        ],
      ],
      PhoneNo: [
        this.editEnquiryDetails ? this.editEnquiryDetails?.mobileNo : '',
        [
          Validators.required,
          Validators.minLength(this.addEnquiryValidation?.PhoneNo.minLength),
          Validators.maxLength(this.addEnquiryValidation?.PhoneNo.maxLength),
          Validators.pattern(this.enquiryValidationPattern?.mobileNo),
        ],
      ],
      Pin: [
        this.editEnquiryDetails ? this.editEnquiryDetails?.pinCode : '',
        [
          Validators.required,
          Validators.minLength(this.addEnquiryValidation.Pin.minLength),
          Validators.maxLength(this.addEnquiryValidation.Pin.maxLength),
          Validators.pattern(this.enquiryValidationPattern.number),
        ],
      ],
      Date: [this.editEnquiryDetails ? new Date(this.editEnquiryDetails?.enquiryDate) : '', [Validators.required]],
    });
  }

  /**
   * Initialize Courier Form Validations
   */
  courierFormValidations() {
    this.courierFormArray = this.courierDetails?.map((courier: any) =>
      this.formBuilder.group({
        courier: [courier?.courierId || ''],
        docketNo: [courier?.docketNo || '',
        [
          Validators.minLength(this.addEnquiryValidation.docketNo.minLength),
          Validators.maxLength(this.addEnquiryValidation.docketNo.maxLength),
          Validators.pattern(this.enquiryValidationPattern.alphaNumeric)
        ]
        ],
        courierSendDate: [courier?.courierSendDate ? new Date(courier?.courierSendDate) : ''],
        courierReceivedDate: [courier?.courieredReceivedDate ? new Date(courier?.courieredReceivedDate) : ''],
        remarks: [courier?.remarks || ''],
      })
    );

    for (let index = 0; index < this.courierDetails.length; index++) {
      let ele = this.courierDetails[index];
      if (ele.courierId != '') {
        this.courierFormControls(index)['courier'].disable({ onlySelf: true });
        this.courierFormControls(index)['docketNo'].disable({ onlySelf: true });
        this.courierFormControls(index)['courierSendDate'].disable({ onlySelf: true });
        this.courierMinDate = new Date(ele?.courierSendDate);
        if (ele?.courieredReceivedDate) {
          this.courierFormControls(index)['courierReceivedDate'].disable({ onlySelf: true });
        }
        this.courierFormControls(index)['remarks'].disable({ onlySelf: true });
      } else {
        this.courierFormControls(index)['docketNo'].disable({ onlySelf: true });
        this.courierFormControls(index)['courierSendDate'].disable({ onlySelf: true });
        this.courierFormControls(index)['courierReceivedDate'].disable({ onlySelf: true });
        this.courierFormControls(index)['remarks'].disable({ onlySelf: true });
      }
    }
  }

  /**
   * enquiry Controls Initialized
   * @readonly
   */
  get editEnquiryFormControls() {
    return this.editEnquiryForm.controls;
  }

  /**
   * Create Courier Controls Initialized
   * @readonly
   */
  courierFormControls(index: number) {
    return this.courierFormArray[index].controls;
  }

  /**
   * This method is used to update value and validity
   * @param {*} formControls
   */
  onUpdateValueAndValidity(formControls: any, controls: any) {
    controls?.forEach((control: any) => {
      formControls[control].setValue("");
      formControls[control].markAsUntouched({ onlySelf: true });
      formControls[control].updateValueAndValidity({ onlySelf: true });
    });
  }

  /**
   * This method is used to get staff list
   */
  getStaffsList() {
    /* To call the service to get the staff list */
    this.mastersService.getStaffs().subscribe({
      next: (res: any) => {
        this.staffList = res.result?.filter((item: any) => item.isStaff == '1');
        if (this.editEnquiryDetails) {
          let staffValue = this.editEnquiryDetails?.staffId;
          this.editEnquiryFormControls['staff'].setValue(staffValue?.toString());
          this.onChangeStaff(staffValue);
        }
      },
      error: () => {
        this.staffList = [];
      }
    });
  }

  /**
   * This method fired on change of from date
   */
  DateChange(newValue: any) {
    console.log("Date changed to:", newValue);
  }

  /**
   * This method fired on change of to date
   * @param {*} event
   */
  ToDateChange(event: any) { }

  /**
   * This method is used to navigate to enquiry list page.
   */
  onNavigateToList() {
    this.router.navigate(['/admin/enquiry/customerenquiry/list']);
  }

  /**
   * This method fired on click of reset
   */
  onResetEditEnquiryForm() {
    this.districtsList = [];
    this.mandalsList = [];
    this.townList = [];
    this.editEnquiryForm.reset();
    this.onNavigateToList();
  }

  /**
   * This method is used to get states list
   */
  getStates() {
    this.mastersService.getStates().subscribe({
      next: (res: any) => {
        this.statesList = res.result;
        if (this.editEnquiryDetails) {
          let stateValue = this.editEnquiryDetails?.stateId || '';
          this.editEnquiryFormControls['stateSelect'].setValue(stateValue?.toString());
          this.onChangeState(stateValue);
        }
      },
      error: () => {
        this.statesList = [];
      }
    });
  }

  /**
   * This method is used to get the Couriers list
   */
  getCouriersList() {
    /* To call the service to get the colors list */
    this.mastersService.getCouriers().subscribe({
      next: (res: any) => {
        this.couriersList = res.result;
      },
      error: (err: any) => {
        this.couriersList = [];
      },
    });
  }

  /**
   * This method will fired when user selects state
   * @param {*} event
   */
  onChangeState(event: any) {
    if (event?.target) {
      this.onUpdateValueAndValidity(this.editEnquiryFormControls, ['districtSelect', 'mandalSelect', 'townSelect']);
      this.districtsList = [];
      this.mandalsList = [];
      this.townList = [];
    }

    const stateValue = event?.target ? event.target?.value : event;
    const eventFlag = event?.target;

    if (stateValue == '') {
      this.editEnquiryFormControls['stateSelect'].markAsUntouched({ onlySelf: true });
      return;
    }

    /* To call the service to get the districts details by passing stateId */
    this.mastersService.getDistrictsByStateId(stateValue).subscribe({
      next: (res: any) => {
        this.districtsList = res.result;
        if (!eventFlag) {
          let districtValue = this.editEnquiryDetails?.districtId || '';
          this.editEnquiryFormControls['districtSelect'].setValue(districtValue?.toString());
          this.onChangeDistrict(districtValue);
        }
      },
      error: () => {
        this.districtsList = [];
      }
    });
  }

  /**
   * This method will fired when user selects district
   * @param {*} event
   */
  onChangeDistrict(event: any) {
    if (event?.target) {
      this.onUpdateValueAndValidity(this.editEnquiryFormControls, ['mandalSelect', 'townSelect']);
      this.mandalsList = [];
      this.townList = [];
    }

    const districtValue = event?.target ? event.target?.value : event;
    const eventFlag = event?.target;

    if (districtValue == '') {
      this.editEnquiryFormControls['districtSelect'].markAsUntouched({ onlySelf: true });
      return;
    }

    /* To call the service to get the mandals details by passing districtId */
    this.mastersService.getMandalsByDistrictId(districtValue).subscribe({
      next: (res: any) => {
        this.mandalsList = res.result;
        if (!eventFlag) {
          let mandalValue = this.editEnquiryDetails?.mandalId || '';
          this.editEnquiryFormControls['mandalSelect'].setValue(mandalValue?.toString());
          this.onChangeMandal(mandalValue);
        }
      },
      error: () => {
        this.mandalsList = [];
      }
    });
  }

  /**
   * This method will fired when user selects mandal
   * @param {*} event
   */
  onChangeMandal(event: any) {
    if (event?.target) {
      this.onUpdateValueAndValidity(this.editEnquiryFormControls, ['townSelect']);
      this.townList = [];
    }

    let mandalValue = event?.target ? event.target?.value : event;
    const eventFlag = event?.target;

    if (mandalValue == '') {
      this.editEnquiryFormControls['mandalSelect'].markAsUntouched({ onlySelf: true });
      return;
    }

    /* To call the service to get the towns details by passing mandalId */
    this.mastersService.getTownsByMandalId(mandalValue).subscribe({
      next: (res: any) => {
        this.townList = res.result;
        if (!eventFlag) {
          let townValue = this.editEnquiryDetails?.townId || '';
          this.editEnquiryFormControls['townSelect'].setValue(townValue?.toString());
        }
      },
      error: () => {
        this.townList = [];
      }
    });
  }

  /**
   * This method will fired when user selects town
   * @param {*} event
   */
  onChangeTown(event: any) {
    if (event.target?.value == '') {
      this.editEnquiryFormControls['townSelect'].markAsUntouched({ onlySelf: true });
    }
  }

  /**
   * This method is used to change the staff select
   * @param {*} event
   */
  onChangeStaff(event: any) {
    if (event.target?.value == '') {
      this.editEnquiryFormControls['staff'].markAsUntouched({ onlySelf: true });
    }
  }

  /**
   * This method is used to change the courier send date
   * @param {*} event
   */
  onChangeCourierSendDate(event: any) {
    this.courierFormControls(this.courierDetails.length - 1)['courierReceivedDate'].setValue('');
    this.courierFormControls(this.courierDetails.length - 1)['courierReceivedDate'].markAsUntouched({ onlySelf: true });
    this.courierMinDate = new Date(event);
  }

  /**
   * This method is used to change the courier
   * @param {*} event
   */
  onChangeCourier(event: any) {
    if (event.target?.value == '') {
      this.courierFormControls(this.courierDetails.length - 1)['courier'].markAsUntouched({ onlySelf: true });
      this.selectedCourier = '';
      this.courierFormControls(this.courierDetails.length - 1)['docketNo'].disable({ onlySelf: true });
      this.courierFormControls(this.courierDetails.length - 1)['courierSendDate'].disable({ onlySelf: true });
      this.courierFormControls(this.courierDetails.length - 1)['courierReceivedDate'].disable({ onlySelf: true });
      this.courierFormControls(this.courierDetails.length - 1)['remarks'].disable({ onlySelf: true });
      this.onRemoveValidators(this.courierFormControls(this.courierDetails.length - 1), ['courier', 'docketNo', 'courierSendDate']);
      this.onUpdateValueAndValidity(this.courierFormControls(this.courierDetails.length - 1), ['courier', 'docketNo', 'courierSendDate']);
      return;
    }

    for (const element of this.couriersList) {
      if (+element.courierId === +event.target?.value) {
        this.selectedCourier = element;
      }
    }

    if (this.selectedCourier) {
      this.courierFormControls(this.courierDetails.length - 1)['docketNo'].enable({ onlySelf: true });
      this.courierFormControls(this.courierDetails.length - 1)['courierSendDate'].enable({ onlySelf: true });
      this.courierFormControls(this.courierDetails.length - 1)['courierReceivedDate'].enable({ onlySelf: true });
      this.courierFormControls(this.courierDetails.length - 1)['remarks'].enable({ onlySelf: true });
      this.onAddValidators(this.courierFormControls(this.courierDetails.length - 1), ['courier', 'docketNo', 'courierSendDate']);
    }
  }

  /**
   * This method is used to add validators
   * @param {*} formControls
   * @param {*} controls
   */
  onAddValidators(formControls: any, controls: any) {
    controls?.forEach((control: any) => {
      formControls[control].addValidators([Validators.required]);
      formControls[control].updateValueAndValidity({ onlySelf: true });
    });
  }

  /**
   * This method is used to add validators
   * @param {*} formControls
   * @param {*} controls
   */
  onRemoveValidators(formControls: any, controls: any) {
    controls?.forEach((control: any) => {
      formControls[control].removeValidators([Validators.required]);
      formControls[control].updateValueAndValidity({ onlySelf: true });
    });
  }

  /**
   * This method is used to add the courier
   */
  onClickAddCourier() {
    if (!this.editEnquiryDetails?.enquiryDetailsList[this.courierDetails.length - 1].courieredReceivedDate) {
      this.onAddValidators(this.courierFormControls(this.courierDetails.length - 1), ['courierReceivedDate']);
      this.courierFormControls(this.courierDetails.length - 1)['courierReceivedDate'].markAsTouched({ onlySelf: true });
      this.isAddClicked = true;
      return;
    } else {
      this.onRemoveValidators(this.courierFormControls(this.courierDetails.length - 1), ['courierReceivedDate']);
    }
    if (!this.isAddClicked) {
      this.courierDetails.push({
        enquiryDetailId: 0,
        docketNo: "",
        courierId: '',
        courierSendDate: "",
        remarks: "",
        courieredReceivedDate: ""
      });
      this.courierFormValidations();
    }
    this.isAddClicked = true;
  }

  /**
   * This method is used to submit the edit enquiry form
   * @param {string} finishFlag
   */
  onSubmitEditEnquiryForm(finishFlag: string) {
    /** This will return false if form fields are invalid and stop the service calling */
    if (this.editEnquiryForm.invalid) {
      this.validationService.validateAllFormFields(this.editEnquiryForm);
      return;
    }

    if (this.selectedCourier) {
      if (
        this.courierFormControls(this.courierDetails.length - 1)['docketNo'].errors ||
        this.courierFormControls(this.courierDetails.length - 1)['courierSendDate'].errors
      ) {
        this.courierFormControls(this.courierDetails.length - 1)['docketNo'].markAsTouched({ onlySelf: true });
        this.courierFormControls(this.courierDetails.length - 1)['courierSendDate'].markAsTouched({ onlySelf: true });
        return;
      }
    }

    if (finishFlag) {
      if (this.courierFormControls(this.courierDetails.length - 1)['courier'].value == '') {
        this.onAddValidators(this.courierFormControls(this.courierDetails.length - 1), ['courier']);
        this.courierFormControls(this.courierDetails.length - 1)['courier'].markAsTouched({ onlySelf: true });
        this.isAddClicked = true;
        return;
      }
      if (this.courierFormControls(this.courierDetails.length - 1)['courier'].value &&
        this.courierFormControls(this.courierDetails.length - 1)['courierReceivedDate'].value == '') {
        this.onAddValidators(this.courierFormControls(this.courierDetails.length - 1), ['courierReceivedDate']);
        this.courierFormControls(this.courierDetails.length - 1)['courierReceivedDate'].markAsTouched({ onlySelf: true });
        this.isAddClicked = true;
        return;
      }
    } else {
      this.onRemoveValidators(this.courierFormControls(this.courierDetails.length - 1), ['courierReceivedDate']);
    }

    let enquiryArray = this.editEnquiryDetails?.enquiryDetailsList || [];
    enquiryArray = enquiryArray.filter((item: any) => item.courierId);

    for (let index = 0; index < enquiryArray.length; index++) {
      enquiryArray[index].courierSendDate = this.datePipe.transform(this.courierFormControls(index)['courierSendDate'].value, "yyyy-MM-dd", 'en-US') || "";
      enquiryArray[index].courieredReceivedDate = this.datePipe.transform(this.courierFormControls(index)['courierReceivedDate'].value, "yyyy-MM-dd", 'en-US') || "";
    }

    if (this.selectedCourier) {
      enquiryArray.push({
        enquiryDetailId: 0,
        docketNo: this.courierFormControls(this.courierDetails.length - 1)['docketNo'].value,
        courierId: +this.selectedCourier?.courierId,
        courierSendDate: this.datePipe.transform(this.courierFormControls(this.courierDetails.length - 1)['courierSendDate'].value, "yyyy-MM-dd", 'en-US') || "",
        remarks: this.courierFormControls(this.courierDetails.length - 1)['remarks'].value || "",
        courieredReceivedDate: this.datePipe.transform(this.courierFormControls(this.courierDetails.length - 1)['courierReceivedDate'].value, "yyyy-MM-dd", 'en-US') || "",
      });
    }

    /* Prepare request payload */
    const obj = {
      enquiryId: this.editEnquiryDetails?.enquiryId,
      enquiryNo: this.editEnquiryDetails?.enquiryNo,
      organizationName: this.editEnquiryFormControls['OrganizationName']?.value || '',
      staffId: this.editEnquiryFormControls['staff']?.value || '',
      address: this.editEnquiryFormControls['Address']?.value || '',
      stateId: +this.editEnquiryFormControls['stateSelect']?.value || '',
      districtId: +this.editEnquiryFormControls['districtSelect']?.value || '',
      mandalId: +this.editEnquiryFormControls['mandalSelect']?.value || '',
      townId: +this.editEnquiryFormControls['townSelect']?.value || '',
      pinCode: this.editEnquiryFormControls["Pin"]?.value?.toString(),
      mobileNo: this.editEnquiryFormControls['PhoneNo']?.value || '',
      enquiryDate: this.datePipe.transform(this.editEnquiryFormControls["Date"].value || "", "yyyy-MM-dd", 'en-US') || "",
      enquiryDetails: this.editEnquiryFormControls['EnquiryDetails']?.value,
      statusId: finishFlag ? 3 : this.editEnquiryDetails?.statusId,
      enquiryDetailsList: enquiryArray.length > 0 ? enquiryArray : null,
      isNewCourierDetails: this.courierDetailsLength != enquiryArray.length ? 1 : 0
    };

    console.log(obj);

    if (finishFlag) {
      const dialogConfig = new MatDialogConfig();
      dialogConfig.disableClose = true;
      dialogConfig.data = {
        name: "finishEnquiry",
        title: "Finish Enquiry",
        payload: obj,
        description: "Do you want to Finish Enquiry?",
        cancelButtonText: "No",
        submitButtonText: "Yes",
      };
      this.matDialog.open(ModalComponent, dialogConfig);
    } else {

      /* Enable the loader */
      this.loaderService.isLoading.next(true);

      /* To call the service to update the enquiry by passing the obj */
      this.feedbackService.editEnquiry(obj).subscribe({
        next: (res: any) => {
          /* Disable the loader if response is success */
          this.loaderService.isLoading.next(false);
          this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', 'enquiry');
        },
        error: (err: any) => {
          /* Disable the loader if response is error */
          this.loaderService.isLoading.next(false);
          this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message || err, '', '', '');
        }
      });
    }
  }
}


