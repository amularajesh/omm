import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatTooltipModule } from '@angular/material/tooltip';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { AutosizeModule } from 'ngx-autosize';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { OrderModule } from 'ngx-order-pipe';
import { NgxPaginationModule } from 'ngx-pagination';

import { ComponentModule } from 'src/app/core/Modules/component.module';
import { AddEnquiryComponent } from './add-enquiry/add-enquiry.component';
import { CustomerEnquiryRoutingModule } from './customer-enquiry-routing.module';
import { EditEnquiryComponent } from './edit-enquiry/edit-enquiry.component';
import { EnquiryListComponent } from './enquiry-list/enquiry-list.component';

/**
 * Customer Enquiry Module
 * @export
 * @class CustomerEnquiryModule
 */
@NgModule({
  declarations: [
    EnquiryListComponent,
    AddEnquiryComponent,
    EditEnquiryComponent
  ],
  imports: [
    CommonModule,
    CustomerEnquiryRoutingModule,
    FormsModule,
    MatTooltipModule,
    ReactiveFormsModule,
    NgxPaginationModule,
    ComponentModule,
    OrderModule,
    BsDatepickerModule.forRoot(),
    NgMultiSelectDropDownModule,
    AutosizeModule,
    Ng2SearchPipeModule
  ]
})
export class CustomerEnquiryModule { }
