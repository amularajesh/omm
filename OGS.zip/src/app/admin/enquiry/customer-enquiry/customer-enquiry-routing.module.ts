import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AddEnquiryComponent } from './add-enquiry/add-enquiry.component';
import { CustomerEnquiryComponent } from './customer-enquiry.component';
import { EditEnquiryComponent } from './edit-enquiry/edit-enquiry.component';
import { EnquiryListComponent } from './enquiry-list/enquiry-list.component';

const routes: Routes = [
  {
    path: "",
    component: CustomerEnquiryComponent,
    children: [
      { path: "", redirectTo: "list", pathMatch: "full" },
      { path: "list", component: EnquiryListComponent },
      { path: "add-enquiry", component: AddEnquiryComponent },
      { path: "edit-enquiry", component: EditEnquiryComponent }
    ]
  },
];

/**
 * Customer Enquiry Routing Module
 * @export
 * @class CustomerEnquiryRoutingModule
 */
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CustomerEnquiryRoutingModule { }
