import { DatePipe } from '@angular/common';
import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

import { SnackbarModalComponent } from 'src/app/core/Dialogues/snackbar-modal/snackbar-modal.component';
import { FeedbackService } from 'src/app/core/Services/feedback.service';
import { LoaderService } from 'src/app/core/Services/loader.service';
import { MastersService } from 'src/app/core/Services/masters.service';
import { ValidationService } from 'src/app/core/Services/validation.service';

/**
 * Add Enquiry Component
 * @export
 * @class AddEnquiryComponent
 * @implements {OnInit}
 */
@Component({
  selector: 'app-add-enquiry',
  templateUrl: './add-enquiry.component.html',
  styleUrls: ['./add-enquiry.component.scss']
})
export class AddEnquiryComponent implements OnInit {
  /**
   * Get Snackbar Modal Component
   * @type {SnackbarModalComponent}
   */
  @ViewChild("snackbarModalComponent") snackbarModalComponent!: SnackbarModalComponent;

  /**
   * Declare Add Enquiry Form
   * @type {FormGroup}
   */
  addEnquiryForm!: FormGroup;

  /**
   * Get Min Date.
   * @type {Date}
   */
  minDate: Date;

  /**
   * Get Max Date.
   * @type {Date}
   */
  maxDate: Date;

  /**
   * Get States List
   * @type {*}
   */
  statesList: any;

  /**
   * Get Districts List
   * @type {*}
   */
  districtsList: any;

  /**
   * Get Mandals List
   * @type {*}
   */
  mandalsList: any;

  /**
   * Get Towns list
   * @type {*}
   */
  townsList: any;

  /**
   * Get Staffs List
   * @type {*}
   */
  staffList: any;

  /**
   * Get Enquiry Form Validations
   */
  addEnquiryValidation = this.validationService?.addEnquiry;

  /**
   * Get Patterns
   */
  enquiryValidationPattern = this.validationService?.patterns;

  /**
   * Get Location Validations
   */
  locationValidation = this.validationService.locationSelect;

  /**
   * Creates an instance of AddEnquiryComponent.
   * @param {Router} router
   * @param {FormBuilder} formBuilder
   * @param {ValidationService} validationService
   * @param {MastersService} mastersService
   * @param {FeedbackService} feedbackService
   * @param {LoaderService} loaderService
   * @param {DatePipe} datePipe
   */
  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private validationService: ValidationService,
    private mastersService: MastersService,
    private feedbackService: FeedbackService,
    private loaderService: LoaderService,
    private datePipe: DatePipe
  ) {
    this.minDate = new Date("2000-01-01");
    this.maxDate = new Date();
  }

  /**
   * Life Cycle Hook Initialization
   */
  ngOnInit(): void {
    this.addEnquiryFormValidation();
    this.getStates();
    this.getStaffsList();
  }

  /**
   * Initialize Add Enquiry Form Validations
   */
  addEnquiryFormValidation() {
    this.addEnquiryForm = this.formBuilder.group({
      OrganizationName: [
        "",
        [
          Validators.required,
          Validators.minLength(this.addEnquiryValidation.OrganizationName.minLength),
          Validators.maxLength(this.addEnquiryValidation.OrganizationName.maxLength),
        ],
      ],
      stateSelect: ['', [Validators.required]],
      districtSelect: ['', [Validators.required]],
      mandalSelect: ['', [Validators.required]],
      townSelect: ['', [Validators.required]],
      staff: ['', [Validators.required]],
      EnquiryDetails: [
        '',
        [
          Validators.required,
          Validators.minLength(this.addEnquiryValidation?.EnquiryDetails.minLength),
          Validators.maxLength(this.addEnquiryValidation?.EnquiryDetails.maxLength),
        ],
      ],
      Address: [
        '',
        [
          Validators.required,
          Validators.minLength(this.addEnquiryValidation?.Address.minLength),
          Validators.maxLength(this.addEnquiryValidation?.Address.maxLength),
        ],
      ],
      PhoneNo: [
        '',
        [
          Validators.required,
          Validators.minLength(this.addEnquiryValidation?.PhoneNo.minLength),
          Validators.maxLength(this.addEnquiryValidation?.PhoneNo.maxLength),
          Validators.pattern(this.enquiryValidationPattern?.mobileNo),
        ],
      ],
      Pin: [
        '',
        [
          Validators.required,
          Validators.minLength(this.addEnquiryValidation.Pin.minLength),
          Validators.maxLength(this.addEnquiryValidation.Pin.maxLength),
          Validators.pattern(this.enquiryValidationPattern.number),
        ],
      ],
      Date: ["", [Validators.required]],
    });
  }

  /**
   * Create enquiry Controls Initialized
   * @readonly
   */
  get addEnquiryFormControls() {
    return this.addEnquiryForm.controls;
  }

  /**
   * This method is used to reset enquiry form
   */
  onResetEnquiryForm() {
    this.districtsList = [];
    this.mandalsList = [];
    this.townsList = [];
    this.addEnquiryForm.reset();
    this.addEnquiryFormValidation();
  }

  /**
   * This method is used to update value and validity
   * @param {*} formControls
   */
  onUpdateValueAndValidity(formControls: any, controls: any) {
    controls?.forEach((control: any) => {
      formControls[control].setValue("");
      formControls[control].markAsUntouched({ onlySelf: true });
      formControls[control].updateValueAndValidity({ onlySelf: true });
    });
  }

  /**
   * This method is used to get states list
   */
  getStates() {
    this.mastersService.getStates().subscribe({
      next: (res: any) => {
        this.statesList = res.result;
      },
      error: () => {
        this.statesList = [];
      }
    });
  }

  /**
   * This method is used to get staffs list
   */
  getStaffsList() {
    /* To call the service to get the staff list */
    this.mastersService.getStaffs().subscribe({
      next: (res: any) => {
        this.staffList = res.result?.filter((item: any) => item.isStaff == '1');
      },
      error: () => {
        this.staffList = [];
      }
    });
  }

  /**
   * This method will fired when user selects state
   * @param {*} event
   */
  onChangeState(event: any) {
    this.onUpdateValueAndValidity(this.addEnquiryFormControls, ['districtSelect', 'mandalSelect', 'townSelect']);
    this.districtsList = [];
    this.mandalsList = [];
    this.townsList = [];

    if (event?.target?.value == '') {
      this.addEnquiryFormControls['stateSelect'].markAsUntouched({ onlySelf: true });
      return;
    }

    /* To call the service to get the districts details by passing stateId */
    this.mastersService.getDistrictsByStateId(event?.target?.value).subscribe({
      next: (res: any) => {
        this.districtsList = res.result;
      },
      error: () => {
        this.districtsList = [];
      }
    });
  }

  /**
   * This method will fired when user selects  district
   * @param {*} event
   */
  onChangeDistrict(event: any) {
    this.onUpdateValueAndValidity(this.addEnquiryFormControls, ['mandalSelect', 'townSelect']);
    this.mandalsList = [];
    this.townsList = [];

    if (event?.target?.value == '') {
      this.addEnquiryFormControls['districtSelect'].markAsUntouched({ onlySelf: true });
      return;
    }

    /* To call the service to get the mandal details by passing districtId */
    this.mastersService.getMandalsByDistrictId(event.target?.value).subscribe({
      next: (res: any) => {
        this.mandalsList = res.result;
      },
      error: () => {
        this.mandalsList = [];
      }
    });
  }

  /**
   * This method will fired when user selects mandal
   * @param {*} event
   */
  onChangeMandal(event: any) {
    this.onUpdateValueAndValidity(this.addEnquiryFormControls, ['townSelect']);
    this.townsList = [];

    if (event?.target?.value == '') {
      this.addEnquiryFormControls['mandalSelect'].markAsUntouched({ onlySelf: true });
      return;
    }

    /* To call the service to get the town details by passing mandalId */
    this.mastersService.getTownsByMandalId(event?.target?.value).subscribe({
      next: (res: any) => {
        this.townsList = res.result;
      },
      error: () => {
        this.townsList = [];
      }
    });
  }

  /**
   * This method will fired when user selects town
   * @param {*} event
   */
  onChangeTown(event: any) {
    if (event?.target?.value == '') {
      this.addEnquiryFormControls['townSelect'].markAsUntouched({ onlySelf: true });
    }
  }

  /**
   * This method is used to change the staff select
   * @param {*} event
   */
  onChangeStaff(event: any) {
    if (event?.target?.value == '') {
      this.addEnquiryFormControls['staff'].markAsUntouched({ onlySelf: true });
    }
  }

  /**
   * This method is used to navigate to enquiry list page.
   */
  onNavigateToList() {
    this.router.navigate(['/admin/enquiry/customerenquiry/list']);
  }

  /**
   * This method is used to submit the add enquiry form
   */
  onSubmitAddEnquiry() {
    /** This will return false if form fields are invalid and stop the service calling */
    if (this.addEnquiryForm.invalid) {
      this.validationService.validateAllFormFields(this.addEnquiryForm);
      return;
    }

    /* Prepare request payload */
    const obj = {
      organizationName: this.addEnquiryFormControls["OrganizationName"]?.value?.toString(),
      townId: this.addEnquiryFormControls['townSelect']?.value || '',
      pinCode: this.addEnquiryFormControls["Pin"]?.value?.toString(),
      mobileNo: this.addEnquiryFormControls['PhoneNo']?.value || '',
      address: this.addEnquiryFormControls['Address']?.value,
      enquiryDate: this.datePipe.transform(this.addEnquiryFormControls["Date"].value || "", "yyyy-MM-dd") || "",
      enquiryDetails: this.addEnquiryFormControls['EnquiryDetails']?.value,
      staffId: this.addEnquiryFormControls['staff']?.value || '',
      mandalId: this.addEnquiryFormControls['mandalSelect']?.value || '',
      districtId: this.addEnquiryFormControls['districtSelect']?.value || '',
      stateId: this.addEnquiryFormControls['stateSelect']?.value || '',
      enquiryDetailsList: null,
      statusId: 0
    };

    console.log(obj);

    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    /* To call the service to add the enquiry by passing the obj */
    this.feedbackService.addEnquiry(obj).subscribe({
      next: (res: any) => {
        /* Disable the loader if response is success */
        this.loaderService.isLoading.next(false);
        this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', 'enquiry');
      },
      error: (err: any) => {
        /* Disable the loader if response is error */
        this.loaderService.isLoading.next(false);
        this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message || err, '', '', '');
      }
    });
  }
}
