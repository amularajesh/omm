import { Component, OnInit } from "@angular/core";

/**
 * Inventory Component
 * @export
 * @class InventoryComponent
 * @implements {OnInit}
 */
@Component({
  selector: "app-inventory",
  templateUrl: "./inventory.component.html",
  styleUrls: ["./inventory.component.scss"],
})
export class InventoryComponent implements OnInit {
  /**
   * Creates an instance of InventoryComponent.
   */
  constructor() { }

  /**
   * Life Cycle Hook Initialization
   */
  ngOnInit(): void { }
}
