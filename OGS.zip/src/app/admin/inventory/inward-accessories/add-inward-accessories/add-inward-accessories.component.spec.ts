import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddInwardAccessoriesComponent } from './add-inward-accessories.component';

describe('AddInwardAccessoriesComponent', () => {
  let component: AddInwardAccessoriesComponent;
  let fixture: ComponentFixture<AddInwardAccessoriesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddInwardAccessoriesComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddInwardAccessoriesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
