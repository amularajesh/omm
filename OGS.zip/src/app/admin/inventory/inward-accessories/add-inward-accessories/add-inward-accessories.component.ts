import { DatePipe, Location } from "@angular/common";
import { Component, OnInit, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";

import { SnackbarModalComponent } from "src/app/core/Dialogues/snackbar-modal/snackbar-modal.component";
import { InventoryService } from "src/app/core/Services/inventory.service";
import { LoaderService } from "src/app/core/Services/loader.service";
import { MastersService } from "src/app/core/Services/masters.service";
import { ValidationService } from "src/app/core/Services/validation.service";

/**
 * Add Inward Accessories Component
 * @export
 * @class AddInwardAccessoriesComponent
 * @implements {OnInit}
 */
@Component({
  selector: "app-add-inward-accessories",
  templateUrl: "./add-inward-accessories.component.html",
  styleUrls: ["./add-inward-accessories.component.scss"],
})
export class AddInwardAccessoriesComponent implements OnInit {
  /**
   * Get Snackbar Modal Component
   * @type {SnackbarModalComponent}
   */
  @ViewChild("snackbarModalComponent") snackbarModalComponent!: SnackbarModalComponent;

  /**
   * Get Measurement for accessory type
   * @type {*}
   */
  measurement: any;

  /**
   * Get Inward Fabric Accessory Type List
   * @type {*}
   */
  inwardFabricAccessoryTypeList: any = [];

  /**
   * Get Accessory Name
   * @type {*}
   */
  accessoryName: any;

  /**
   * Get Inward Fabric Accessory Company List
   * @type {*}
   */
  inwardFabricCompanyList: any = [];

  /**
   * Get Company Name
   * @type {*}
   */
  companyName: any;

  /**
   * Default Sorting Key
   */
  sortingKeyColumn = "accessory";

  /**
   * Default Sort Order
   */
  sortingOrder = true;

  /**
   * Default Page Number
   */
  currentPage = 1;

  /**
   * Declaring Var To store Inward fabric min date.
   * @type {*}
   */
  inwardFabricMinDate: Date;

  /**
   * Get Date
   * @type {Date}
   */
  minDate: Date;

  /**
   * Get Inward Type Name
   * @type {*}
   */
  inwardTypeName: any;

  /**
   * Declaring var to store records length
   */
  recordsCount = 0;

  /**
   * Creates an instance of AddInwardAccessoriesComponent.
   * @param {Router} router
   * @param {FormBuilder} formBuilder
   * @param {ValidationService} validationService
   * @param {DatePipe} datePipe
   * @param {MastersService} mastersService
   * @param {LoaderService} loader
   * @param {InventoryService} inventory
   * @param {Location} location
   */
  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private validationService: ValidationService,
    private datePipe: DatePipe,
    private mastersService: MastersService,
    private loaderService: LoaderService,
    private inventory: InventoryService,
    private location: Location
  ) {
    this.inwardFabricMinDate = new Date();
    this.minDate = new Date("2000-01-01");
  }

  /**
   * Declaring inwardFabric search Form
   * @type {FormGroup}
   */
  addInwardAccessoryForm!: FormGroup;

  /**
   * Get inward fabric search Form Validations
   */
  addInwardAccessoryValidation = this.validationService?.addInwardAccessorySearch;

  /**
   * Get inward fabric Validations Patterns
   */
  addInwardAccessoryValidationPattern = this.validationService?.patterns;

  /**
   * Life Cycle Hook Initialization
   */
  ngOnInit(): void {
    this.addInwardAccessoryFormValidation();
    this.getCompanies();
    this.getAccessoryTypes();
  }

  /**
   * This method for initialize form validations
   */
  addInwardAccessoryFormValidation() {
    this.addInwardAccessoryForm = this.formBuilder.group({
      company: ["", [Validators.required]],
      invoiceNo: [
        "",
        [
          Validators.required,
          Validators.minLength(
            this.addInwardAccessoryValidation?.invoiceNo?.minLength
          ),
          Validators.maxLength(
            this.addInwardAccessoryValidation?.invoiceNo?.maxLength
          ),
          Validators.pattern(this.addInwardAccessoryValidationPattern?.invoice),
        ],
      ],
      Date: ["", [Validators.required]],
      accossoryType: ["", [Validators.required]],
      quantity: [
        "",
        [
          Validators.required,
          Validators.minLength(
            this.addInwardAccessoryValidation?.quantity?.minLength
          ),
          Validators.maxLength(
            this.addInwardAccessoryValidation?.quantity?.maxLength
          ),
          Validators.pattern(
            this.addInwardAccessoryValidationPattern?.quantity
          ),
        ],
      ],
    });
  }

  /**
   * Get Add Inward Accessory Form Controls Initialized
   * @readonly
   */
  get addInwardAccessoryFormControls() {
    return this.addInwardAccessoryForm.controls;
  }

  /**
   * This method fired on change of from date
   * @param {*} newValue
   */
  DateChange(newValue: any) {
    console.log("Date changed to:", newValue);
  }

  /**
   *This method fired on chage of to date
   *
   * @param {*} event
   * @memberof InwardFabricListComponent
   */
  ToDateChange(event: any) { }

  /**
   *This method fired on click of pagination
   *
   * @memberof InwardFabricListComponent
   */
  onPageChange(event: any) { this.currentPage = event; }

  /**
   * This Method Used To Navigate  Inward fabric List page.
   */
  navigate() {
    this.router.navigate([
      "/admin/inventory/inwardaccessories/inwardaccessorieslist",
    ]);
  }

  /**
   * This method is used to sort column
   * @param key : value of which column based we need to sort the rows
   */
  sort(key: string) {
    const componentName = this.location.path();
    let value = key;
    sessionStorage.setItem(`${componentName}_property`, value);
    this.sortingKeyColumn = key;
    if (sessionStorage.getItem(componentName + "_order") == "desc") {
      this.sortingOrder = false;
    } else {
      this.sortingOrder = true;
    }
  }

  /**
   * This method fired on click of reset
   */
  reset() {
    this.addInwardAccessoryForm.reset();
    this.addInwardAccessoryFormValidation();
  }

  /**
   * This method fired on click of exportToWord
   * @param {*} event
   */
  ExportToWord(event: any) { }

  /**
   * This method fired on click Add button
   */
  Submit() {
    /** This will return false if form fields are invalid and stop the service calling */
    if (this.addInwardAccessoryForm.invalid) {
      this.validationService.validateAllFormFields(this.addInwardAccessoryForm);
      return;
    }

    //preparing obj
    const finalObj = {
      inwardAccessoriesId: 0,
      inwardCompanyId: Number(this.addInwardAccessoryFormControls["company"].value) || "",
      inwardAccessoryTypeId: Number(this.addInwardAccessoryFormControls["accossoryType"].value) || "",
      invoiceNo: this.addInwardAccessoryFormControls["invoiceNo"].value || "",
      date: this.datePipe.transform(this.addInwardAccessoryFormControls["Date"].value || "", "yyyy-MM-dd") || "",
      quantity: this.addInwardAccessoryFormControls["quantity"].value || "",
      userId: 0,
    };

    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    this.inventory.addInwradAccessories(finalObj).subscribe({
      next: (res: any) => {
        /* Disable the loader */
        this.loaderService.isLoading.next(false);

        this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', 'inwardAccessory');
        this.reset();
      },
      error: (err: any) => {
        /* Disable the loader */
        this.loaderService.isLoading.next(false);

        this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
      },
    });
  }

  /**
   * This Method fired on Change of inward Fabric type
   * @param {*} event
   */
  comapanyChange(event: any) {
    for (const item of this.inwardFabricCompanyList) {
      if (item?.companyId === Number(event.target.value)) {
        this.companyName = item?.companyName;
      }
    }
  }

  /**
   * This Method fired on Change of accessory
   * @param {*} event
   */
  onChangeAccessoryType(event: any) {
    this.inventory.getInwardMeasurementById(event.target.value).subscribe({
      next: (res: any) => {
        this.measurement = res?.result?.measurement;
      },
      error: (err: any) => {
        this.measurement = "";
      }
    });
    for (const item of this.inwardFabricAccessoryTypeList) {
      if (item?.accessoryId === Number(event.target.value)) {
        this.accessoryName = item?.accessoryName;
      }
    }
    this.addInwardAccessoryFormControls['quantity'].setValue('');
    this.addInwardAccessoryFormControls['quantity'].markAsUntouched({ onlySelf: true });
  }

  /**
   * This Method for get Companies
   */
  getCompanies() {
    this.mastersService.getCompanies().subscribe({
      next: (res: any) => {
        this.inwardFabricCompanyList = res?.result;
      },
      error: (err: any) => {
        this.inwardFabricCompanyList = [];
      },
    });
  }

  /**
   * This Method for get Qualities
   */
  getAccessoryTypes() {
    this.inventory.getAccessoryTypes().subscribe({
      next: (res: any) => {
        this.inwardFabricAccessoryTypeList = res?.result;
      },
      error: (err: any) => {
        this.inwardFabricAccessoryTypeList = [];
      }
    });
  }

  onInput(event: any): void {
    const inputValue = this.addInwardAccessoryForm.get('quantity')?.value;

    if (this.measurement === 'Pcs.' || this.measurement === 'Gross.') {
      this.addInwardAccessoryForm.patchValue({ quantity: inputValue.replace(/[^0-9]/g, '') });
    } else {
      this.addInwardAccessoryForm.patchValue({ quantity: inputValue.replace(/[^0-9.]/g, '') });
    }
  }
}
