import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { InwardAccessoriesComponent } from "./inward-accessories.component";
import { AddInwardAccessoriesComponent } from "./add-inward-accessories/add-inward-accessories.component";
import { EditInwardAccessoriesComponent } from "./edit-inward-accessories/edit-inward-accessories.component";
import { InwardAccessoriesListComponent } from "./inward-accessories-list/inward-accessories-list.component";

const routes: Routes = [
  {
    path: "",
    component: InwardAccessoriesComponent,
    children: [
      { path: "", redirectTo: "inwardaccessorieslist", pathMatch: "full" },
      {
        path: "addinwardaccessorie",
        component: AddInwardAccessoriesComponent,
      },
      {
        path: "editinwardaccessorie",
        component: EditInwardAccessoriesComponent,
      },
      {
        path: "inwardaccessorieslist",
        component: InwardAccessoriesListComponent,
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class InwardwardAccessoriesRoutingModule {}
