import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-inward-accessories',
  templateUrl: './inward-accessories.component.html',
  styleUrls: ['./inward-accessories.component.scss']
})
export class InwardAccessoriesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
