import { DatePipe, Location } from "@angular/common";
import { Component, OnInit, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";

import { SnackbarModalComponent } from "src/app/core/Dialogues/snackbar-modal/snackbar-modal.component";
import { InventoryService } from "src/app/core/Services/inventory.service";
import { LoaderService } from "src/app/core/Services/loader.service";
import { MastersService } from "src/app/core/Services/masters.service";
import { ValidationService } from "src/app/core/Services/validation.service";

@Component({
  selector: "app-edit-inward-accessories",
  templateUrl: "./edit-inward-accessories.component.html",
  styleUrls: ["./edit-inward-accessories.component.scss"],
})
export class EditInwardAccessoriesComponent implements OnInit {
  /**
   * Get Snackbar Modal Component
   * @type {SnackbarModalComponent}
   */
  @ViewChild("snackbarModalComponent") snackbarModalComponent!: SnackbarModalComponent;

  mesurement: any;
  /**
   *var to store edit inward accessory data
   *
   * @type {*}
   * @memberof EditInwardAccessoriesComponent
   */
  editInwardAccessoryData: any;
  /**
   *
   *Var declared to store data of  accessory list
   * @type {any[]}
   * @memberof EditInwardAccessoryComponent
   */
  inwardAccossoryTypeList: any[] = [];
  accessoryName: any;

  /**
   *
   *Var declared to store data of Comapny list
   * @type {any[]}
   * @memberof EditInwardAccessoryComponent
   */
  inwardAccessoryCompanyList: any[] = [];
  comapanyName: any;

  /**
   * Default Sorting Key
   */
  sortingKeyColumn = "accessory";

  /**
   * Default Sort Order
   */
  sortingOrder = true;
  /**
   * Default Page Number
   */
  currentPage = 1;

  /**
   *Declaring Var To store Inward fabric min date.
   *
   * @type {*}
   * @memberof inwardListComponent
   */
  inwardAccessoryMinDate: Date;
  inwardAccessoryMaxDate: Date | undefined;
  mindate: Date | undefined;

  inwardTypeName: any;

  /**
   * Declaring var to store records length
   */
  recordsCount = 0;

  /**
   * Creates an instance of EditInwardAccessoriesComponent.
   * @param {Router} router
   * @param {FormBuilder} formBuilder
   * @param {ValidationService} validationService
   * @param {DatePipe} datePipe
   * @param {MastersService} mastersService
   * @param {LoaderService} loaderService
   * @param {InventoryService} inventory
   * @param {Location} location
   */
  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private validationService: ValidationService,
    private datePipe: DatePipe,
    private mastersService: MastersService,
    private loaderService: LoaderService,
    private inventory: InventoryService,
    private location: Location
  ) {
    this.inwardAccessoryMinDate = new Date();
    this.inventory.inwardAccessory.subscribe((res: any) => {
      this.editInwardAccessoryData = res;
      console.log(this.editInwardAccessoryData);
      this.mesurement = this.editInwardAccessoryData?.measurement;
      this.mindate = new Date("2000-01-01");
    });
  }

  /**
   * Declaring inward Accessory Form
   * @type {FormGroup}
   * @memberof inwardListComponent
   */
  editinwardAccessoryForm!: FormGroup;

  /**
   * Get inward Accessory Form Validations
   */
  EditInwardAccessoryValidation = this.validationService
    ?.addInwardAccessorySearch;
  EditInwardAccessoryValidationPattern = this.validationService?.patterns;

  ngOnInit(): void {
    this.getCompanies();
    this.getAccessoryTypes();
    this.inwardAccessoryMinDate = new Date(this.editInwardAccessoryData?.date);
    this.inwardAccessoryMaxDate = new Date();
    this.editinwardAccessoryFormValiadation();
  }

  /**
   *This method for intialize form validations
   *
   * @memberof EditInwardAccessoryComponent
   */
  editinwardAccessoryFormValiadation() {
    this.editinwardAccessoryForm = this.formBuilder.group({
      company: [
        this.editInwardAccessoryData?.inwardCompanyId || "",
        [Validators.required],
      ],
      invoiceNo: [
        this.editInwardAccessoryData?.invoiceNo || "",
        [
          Validators.required,
          Validators.minLength(
            this.EditInwardAccessoryValidation?.invoiceNo?.minLength
          ),
          Validators.maxLength(
            this.EditInwardAccessoryValidation?.invoiceNo?.maxLength
          ),
          Validators.pattern(
            this.EditInwardAccessoryValidationPattern?.invoice
          ),
        ],
      ],
      Date: [
        new Date(this.editInwardAccessoryData?.date) || "",
        [Validators.required],
      ],
      accossoryType: [
        this.editInwardAccessoryData?.inwardAccessoryTypeId || "",
        [Validators.required],
      ],
      quantity: [
        this.editInwardAccessoryData?.quantity || "",
        [
          Validators.required,
          Validators.minLength(
            this.EditInwardAccessoryValidation?.quantity?.minLength
          ),
          Validators.maxLength(
            this.EditInwardAccessoryValidation?.quantity?.maxLength
          ),
          Validators.pattern(
            this.EditInwardAccessoryValidationPattern?.quantity
          ),
        ],
      ],
    });
  }

  /**
   * editinwardAccessory Controls Initialized
   * @readonly
   */
  get editinwardAccessoryFormControls() {
    return this.editinwardAccessoryForm.controls;
  }

  /**
   *This method fired on chage of from date
   *
   * @param {*} event
   * @memberof inwardListComponent
   */
  DateChange(newValue: any) {
    console.log("Date changed to:", newValue);
  }

  /**
   *This method fired on chage of to date
   *
   * @param {*} event
   * @memberof inwardListComponent
   */
  ToDateChange(event: any) { }

  /**
   *This method fired on click of pagination
   *
   * @memberof inwardListComponent
   */
  onPageChange(event: any) { this.currentPage = event; }

  /**
   * This Method Used To Navigate  editinwardAccessory List page.
   */
  navigate() {
    this.router.navigate([
      "/admin/inventory/inwardaccessories/inwardaccessorieslist",
    ]);
  }

  /**
   * This method is used to sort column
   * @param key : value of which column based we need to sort the rows
   */
  sort(key: string) {
    const componentName = this.location.path();
    let value = key;
    sessionStorage.setItem(`${componentName}_property`, value);
    this.sortingKeyColumn = key;
    if (sessionStorage.getItem(componentName + "_order") == "desc") {
      this.sortingOrder = false;
    } else {
      this.sortingOrder = true;
    }
  }

  /**
   * This method fired on click of reset
   */
  reset() {
    this.navigate();
  }

  /**
   *This method fired on click save button
   * @param {*} event
   * @memberof EditInwardAccessoryComponent
   */
  Submit(event: any) {
    /** This will return false if form fields are invalid and stop the service calling */
    if (this.editinwardAccessoryForm.invalid) {
      this.validationService.validateAllFormFields(
        this.editinwardAccessoryForm
      );
      return;
    }

    //preparing obj
    const finalObj = {
      inwardAccessoriesId:
        this.editInwardAccessoryData?.inwardAccessoriesId || 0,
      inwardCompanyId:
        Number(this.editinwardAccessoryFormControls["company"].value) || 0,
      date:
        this.datePipe.transform(
          this.editinwardAccessoryFormControls["Date"].value || "",
          "yyyy-MM-dd"
        ) || "",
      inwardAccessoryTypeId:
        Number(this.editinwardAccessoryFormControls["accossoryType"].value) ||
        0,
      invoiceNo: this.editinwardAccessoryFormControls["invoiceNo"].value || "",

      quantity: this.editinwardAccessoryFormControls["quantity"].value || "",
      userId: 0,
    };

    console.log(finalObj, "finalObj");

    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    this.inventory.EditInwradAccessories(finalObj).subscribe({
      next: (res: any) => {
        //* Disable the loader */
        this.loaderService.isLoading.next(false);

        this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', 'inwardAccessory');
      },
      error: (err: any) => {
        /* Disable the loader */
        this.loaderService.isLoading.next(false);

        this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
      },
    });
  }

  /**
   *This Method fired on Change of inward Fabric type
   * @param {*} event
   * @memberof EditInwardAccessoryComponent
   */
  comapanyChange(event: any) {
    for (const item of this.inwardAccessoryCompanyList) {
      if (item?.companyId === Number(event.target.value)) {
        this.comapanyName = item?.companyName;
      }
    }
  }

  /**
   * This Method fired on Change of accessory
   * @param {*} event
   */
  accossoryTypeChange(event: any) {
    this.inventory.getInwardMeasurementById(event.target.value).subscribe({
      next: (res: any) => {
        this.mesurement = res?.result?.measurement;
      },
      error: (err: any) => {
        this.mesurement = "";
      },
    });
    for (const item of this.inwardAccossoryTypeList) {
      if (item?.accessoryId === Number(event.target.value)) {
        this.accessoryName = item?.accessoryName;
      }
    }
  }

  /**
   *This Method for get Companies
   *
   * @memberof inwardListComponent
   */
  getCompanies() {
    this.mastersService.getCompanies().subscribe({
      next: (res: any) => {
        this.inwardAccessoryCompanyList = res?.result;
      },
      error: (err: any) => {
        this.inwardAccessoryCompanyList = [];
      },
    });
  }

  /**
   *This Method for get Qualities
   *
   * @memberof inwardListComponent
   */
  getAccessoryTypes() {
    this.inventory.getAccessoryTypes().subscribe({
      next: (res: any) => {
        this.inwardAccossoryTypeList = res?.result;
      },
      error: (err: any) => {

        this.inwardAccossoryTypeList = [];
      },
    });
  }

  onInput(event: any): void {
    const inputValue = this.editinwardAccessoryForm.get('quantity')?.value;

    if (this.mesurement === 'Pcs.' || this.mesurement === 'Gross.') {
      this.editinwardAccessoryForm.patchValue({ quantity: inputValue.replace(/[^0-9]/g, '') });
    } else {
      this.editinwardAccessoryForm.patchValue({ quantity: inputValue.replace(/[^0-9.]/g, '') });
    }
  }
}
