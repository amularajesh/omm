import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditInwardAccessoriesComponent } from './edit-inward-accessories.component';

describe('EditInwardAccessoriesComponent', () => {
  let component: EditInwardAccessoriesComponent;
  let fixture: ComponentFixture<EditInwardAccessoriesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EditInwardAccessoriesComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EditInwardAccessoriesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
