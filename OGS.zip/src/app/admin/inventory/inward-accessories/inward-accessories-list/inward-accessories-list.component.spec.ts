import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InwardAccessoriesListComponent } from './inward-accessories-list.component';

describe('InwardAccessoriesListComponent', () => {
  let component: InwardAccessoriesListComponent;
  let fixture: ComponentFixture<InwardAccessoriesListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InwardAccessoriesListComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(InwardAccessoriesListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
