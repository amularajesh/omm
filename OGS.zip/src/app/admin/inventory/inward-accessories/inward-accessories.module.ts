import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";

import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { BsDatepickerModule } from "ngx-bootstrap/datepicker";
import { NgxPaginationModule } from "ngx-pagination";
import { ComponentModule } from "src/app/core/Modules/component.module";
import { OrderModule } from "ngx-order-pipe";
import { MatTooltipModule } from "@angular/material/tooltip";
import { InwardwardAccessoriesRoutingModule } from "./inward-accessories-routing.module";
import { InwardAccessoriesListComponent } from "./inward-accessories-list/inward-accessories-list.component";
import { AddInwardAccessoriesComponent } from "./add-inward-accessories/add-inward-accessories.component";
import { EditInwardAccessoriesComponent } from "./edit-inward-accessories/edit-inward-accessories.component";

@NgModule({
  declarations: [
    InwardAccessoriesListComponent,
    AddInwardAccessoriesComponent,
    EditInwardAccessoriesComponent,
  ],
  imports: [
    CommonModule,
    InwardwardAccessoriesRoutingModule,
    FormsModule,
    MatTooltipModule,
    ReactiveFormsModule,
    NgxPaginationModule,
    ComponentModule,
    OrderModule,
    BsDatepickerModule.forRoot(),
  ],
})
export class InwardAccessoriesModule {}
