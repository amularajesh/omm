import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";

import { InventoryComponent } from "./inventory.component";

const routes: Routes = [
  {
    path: "",
    component: InventoryComponent,
    children: [
      { path: '', redirectTo: `${localStorage.getItem('inventoryModule')}`, pathMatch: 'full' },
      {
        path: "inwardaccessories",
        loadChildren: () => import("./inward-accessories/inward-accessories.module").then((m) => m.InwardAccessoriesModule)
      },
      {
        path: "outwardaccessories",
        loadChildren: () => import("./outward-accessories/outward-accessories.module").then((m) => m.OutwardAccessoriesModule)
      },
      {
        path: "inwardfabric",
        loadChildren: () => import("./inward-fabric/inward-fabric.module").then((m) => m.InwardFabricModule)
      },
      {
        path: "outwardfabric",
        loadChildren: () => import("./outward-fabric/outward-fabric.module").then((m) => m.OutwardFabricModule)
      }
    ]
  }
];

/**
 * Inventory Routing Module
 * @export
 * @class InventoryRoutingModule
 */
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class InventoryRoutingModule { }
