import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";

import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { BsDatepickerModule } from "ngx-bootstrap/datepicker";
import { NgxPaginationModule } from "ngx-pagination";
import { ComponentModule } from "src/app/core/Modules/component.module";
import { OrderModule } from "ngx-order-pipe";
import { MatTooltipModule } from "@angular/material/tooltip";
import { OutwardAccessoriesRoutingModule } from "./outward-accessories-routing.module";
import { OutwardAccessoriesListComponent } from './outward-accessories-list/outward-accessories-list.component';
import { AddOutwardAccessoriesComponent } from './add-outward-accessories/add-outward-accessories.component';
import { EditOutwardAccessoriesComponent } from './edit-outward-accessories/edit-outward-accessories.component';

@NgModule({
  declarations: [
    OutwardAccessoriesListComponent,
    AddOutwardAccessoriesComponent,
    EditOutwardAccessoriesComponent
  ],
  imports: [
    CommonModule,
    OutwardAccessoriesRoutingModule,
    FormsModule,
    MatTooltipModule,
    ReactiveFormsModule,
    NgxPaginationModule,
    ComponentModule,
    OrderModule,
    BsDatepickerModule.forRoot(),
  ],
})
export class OutwardAccessoriesModule {}
