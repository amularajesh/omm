import { DatePipe, Location } from "@angular/common";
import { Component, OnInit, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";

import { SnackbarModalComponent } from "src/app/core/Dialogues/snackbar-modal/snackbar-modal.component";
import { InventoryService } from "src/app/core/Services/inventory.service";
import { LoaderService } from "src/app/core/Services/loader.service";
import { MastersService } from "src/app/core/Services/masters.service";
import { ValidationService } from "src/app/core/Services/validation.service";

/**
 * Add Outward Accessories Component
 * @export
 * @class AddOutwardAccessoriesComponent
 * @implements {OnInit}
 */
@Component({
  selector: "app-add-outward-accessories",
  templateUrl: "./add-outward-accessories.component.html",
  styleUrls: ["./add-outward-accessories.component.scss"],
})
export class AddOutwardAccessoriesComponent implements OnInit {
  /**
   * Get Snackbar Modal Component
   * @type {SnackbarModalComponent}
   */
  @ViewChild("snackbarModalComponent") snackbarModalComponent!: SnackbarModalComponent;

  show: boolean = false;
  /**
   * Get Accessory measurement
   */
  measurement = '';

  /**
   * Get Outward Accessory Type List
   * @type {*}
   */
  outwardAccessoryTypeList: any;

  /**
   * Get Unit Names List
   * @type {any[]}
   */
  UnitNameList: any[] = [];

  /**
   * Get Accessory Qty
   * @type {*}
   */
  accessoryQty: any;

  /**
   * Get Local Outward Accessory List
   * @type {any[]}
   */
  localOutwardAccessoryList: any[] = [];

  /**
   * Get selected Unit Name
   * @type {*}
   */
  selectedUnitName: any;

  /**
   * Get selected Accessory Type
   * @type {*}
   */
  selectedAccessoryType: any;

  /**
   * Default Sorting Key
   */
  sortingKeyColumn = "quality";

  /**
   * Default Sort Order
   */
  sortingOrder = true;
  /**
   * Default Page Number
   */
  currentPage = 1;

  /**
   *Declaring Var To store Inward fabric min date.
   *
   * @type {*}
   * @memberof outwardAccessoryListComponent
   */
  outwardAccessoryMinDate: Date;
  mindate: Date;
  /**
   *Declaring Var To store Inward fabric list.
   * @type {*}
   * @memberof outwardAccessoryListComponent
   */
  outwardAccessoryList: any[] = [];

  inwardTypeName: any;

  /**
   *Declaring var to store records length
   * @type {*}
   * @memberof outwardAccessoryListComponent
   */
  recordsCount = 0;

  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private validationService: ValidationService,
    private datePipe: DatePipe,
    private mastersService: MastersService,
    private loaderService: LoaderService,
    private inventory: InventoryService,
    private location: Location
  ) {
    this.outwardAccessoryMinDate = new Date();
    this.mindate = new Date("2000-01-01");
  }

  /**
   * Declaring outwardAccessory Form
   * @type {FormGroup}
   */
  addOutwardAccessoryForm!: FormGroup;

  /**
   * Get outward accessory  Form Validations
   */
  addOutwardAccessoryValidation = this.validationService?.addOutwardAccessory;

  addOutwardAccessoryValidationPattern = this.validationService?.patterns;

  ngOnInit(): void {
    this.addOutwardAccessoryFormValidation();
    this.getAccessoryList();
    this.getUnitNameList();
  }

  /**
   * This method for initialize form validations
   */
  addOutwardAccessoryFormValidation() {
    this.addOutwardAccessoryForm = this.formBuilder.group({
      dcNo: [
        "",
        [
          Validators.required,
          Validators.minLength(
            this.addOutwardAccessoryValidation?.dcNo?.minLength
          ),
          Validators.maxLength(
            this.addOutwardAccessoryValidation?.dcNo?.maxLength
          ),
          Validators.pattern(
            this.addOutwardAccessoryValidationPattern?.alphaNumeric
          ),
        ],
      ],
      Date: ["", [Validators.required]],
      unitName: ["", [Validators.required]],
      accessoryType: ["", [Validators.required]],
      quantity: [
        "",
        [
          Validators.required,
          Validators.minLength(
            this.addOutwardAccessoryValidation?.quantity?.minLength
          ),
          Validators.maxLength(
            this.addOutwardAccessoryValidation?.quantity?.maxLength
          ),
          Validators.pattern(
            this.addOutwardAccessoryValidationPattern?.quantity
          ),
        ],
      ],
    });
  }

  /**
   * This method is used to get the accessory types list
   */
  getAccessoryList() {
    this.inventory.getAccessoryTypes().subscribe({
      next: (res: any) => {
        this.outwardAccessoryTypeList = res?.result;
      },
      error: (err: any) => {
        this.outwardAccessoryTypeList = [];
      },
    });
  }

  /**
   * This method is used to get unit names
   */
  getUnitNameList() {
    this.mastersService.getUnits().subscribe({
      next: (res: any) => {
        this.UnitNameList = res?.result;
      },
      error: (err: any) => {
        this.UnitNameList = [];
      },
    });
  }

  /**
   * add outward Accessory Controls Initialized
   * @readonly
   */
  get addOutwardAccessoryFormControls() {
    return this.addOutwardAccessoryForm.controls;
  }

  /**
   * This method fired on click of Delete icon
   * @param {*} fabric
   * @param {*} i
   */
  onClickDeleteOutwardAccessory(fabric: any, i: any) {
    this.show = false;
    this.localOutwardAccessoryList.splice(i - 1, 1);
  }

  /**
   * This method fired on click of pagination
   */
  onPageChange(event: any) { this.currentPage = event; }

  /**
   * This Method Used To Navigate  Inward fabric List page.
   */
  navigate() {
    this.router.navigate([
      "/admin/inventory/outwardaccessories/outwardaccessorieslist",
    ]);
  }

  /**
   * This method is used to sort column
   * @param key : value of which column based we need to sort the rows
   */
  sort(key: string) {
    const componentName = this.location.path();
    let value = key;
    sessionStorage.setItem(`${componentName}_property`, value);
    this.sortingKeyColumn = key;
    if (sessionStorage.getItem(componentName + "_order") == "desc") {
      this.sortingOrder = false;
    } else {
      this.sortingOrder = true;
    }
  }

  /**
   * This method fired on click of reset
   * @param {*} event
   */
  reset(event: any) {
    this.localOutwardAccessoryList = [];
    this.addOutwardAccessoryForm.reset();
    this.addOutwardAccessoryFormValidation();
  }

  /**
   * This method fired on click of exportToWord
   * @param {*} event
   */
  ExportToWord(event: any) { }

  /**
   *This Method fired on Change of unit name
   * @param {*} event
   */
  unitChange(event: any) {
    for (const item of this.UnitNameList) {
      if (item?.unitId === Number(event.target.value)) {
        this.selectedUnitName = item?.unitNames;
      }
    }
  }

  /**
   * This method is used to change the accessory type
   * @param {*} event
   */
  accessoryTypeChange(event: any) {
    if (this.addOutwardAccessoryFormControls["Date"].value) {
      /* Prepare the request payload */
      const obj = {
        accessoryId: Number(
          this.addOutwardAccessoryFormControls["accessoryType"].value
        ),
        outwardDate: this.datePipe.transform(
          this.addOutwardAccessoryFormControls["Date"].value || "",
          "yyyy-MM-dd"
        ),
      };

      this.inventory.getOutwardAccessoryQty(obj).subscribe({
        next: (res: any) => {
          if (this.localOutwardAccessoryList.length > 0) {
            for (const item of this.localOutwardAccessoryList) {
              if (Number(obj["accessoryId"]) === item["accessoryTypeId"]) {
                this.accessoryQty =
                  res?.result?.availableQty - item["quantity"];
                this.measurement = res?.result?.measurement?.trim();
                this.show = true;
                break;
              } else {
                this.accessoryQty = res?.result?.availableQty;
                this.measurement = res?.result?.measurement?.trim();
                this.show = true;
              }
            }
          } else {
            this.accessoryQty = res?.result?.availableQty;
            this.measurement = res?.result?.measurement?.trim();
            this.show = true;
          }
        },
        error: (err: any) => {
          this.accessoryQty = "";
          this.show = false;
        },
      });

      for (const item of this.outwardAccessoryTypeList) {
        if (item?.accessoryTypeId === Number(event.target.value)) {
          this.selectedAccessoryType = item?.accessoryTypeName;
        }
      }
    } else {
      this.addOutwardAccessoryFormControls["accessoryType"]?.setValue("");
      this.addOutwardAccessoryFormControls["accessoryType"]?.updateValueAndValidity({ onlySelf: true });
      this.snackbarModalComponent.onOpenSnackbarModal(false, "Please Select Date", '', '', '');
    }
  }

  /**
   * This method is used to change the date
   * @param {*} event
   */
  DateChange(event: any) {
    if (
      this.addOutwardAccessoryFormControls["accessoryType"].value &&
      this.addOutwardAccessoryFormControls["Date"].value
    ) {
      const obj = {
        accessoryId: Number(
          this.addOutwardAccessoryFormControls["accessoryType"].value
        ),
        outwardDate: this.datePipe.transform(
          this.addOutwardAccessoryFormControls["Date"].value || "",
          "yyyy-MM-dd"
        ),
      };

      this.inventory.getOutwardAccessoryQty(obj).subscribe({
        next: (res: any) => {
          this.accessoryQty = res?.result?.availableQty;
        },
        error: (err: any) => {
          this.accessoryQty = "";
        },
      });
    }
  }

  onInput(event: any): void {
    const inputValue = this.addOutwardAccessoryForm.get('quantity')?.value;

    if (this.measurement?.trim() === 'Pcs.' || this.measurement?.trim() === 'Gross.') {
      this.addOutwardAccessoryForm.patchValue({ quantity: inputValue.replace(/[^0-9]/g, '') });
    } else {
      this.addOutwardAccessoryForm.patchValue({ quantity: inputValue.replace(/[^0-9.]/g, '') });
    }
  }

  /**
   *This method fired on click Add button
   */
  LocalSave() {
    this.addOutwardAccessoryFormControls["accessoryType"].setValidators([
      Validators.required,
    ]);
    this.addOutwardAccessoryFormControls[
      "accessoryType"
    ].updateValueAndValidity();

    this.addOutwardAccessoryFormControls["quantity"].setValidators([
      Validators.required,
      Validators.minLength(
        this.addOutwardAccessoryValidation?.quantity?.minLength
      ),
      Validators.maxLength(
        this.addOutwardAccessoryValidation?.quantity?.maxLength
      ),
      Validators.pattern(this.addOutwardAccessoryValidationPattern?.quantity),
    ]);
    this.addOutwardAccessoryFormControls["quantity"].updateValueAndValidity();

    /** This will return false if form fields are invalid and stop the service calling */
    if (this.addOutwardAccessoryForm.invalid) {
      this.validationService.validateAllFormFields(
        this.addOutwardAccessoryForm
      );
      return;
    }

    /* Prepare the obj */
    const localObj = {
      outwardAccessoriesId: 0,
      accessoryTypeId:
        Number(this.addOutwardAccessoryFormControls["accessoryType"].value) ||
        "",
      accessoryType: this.selectedAccessoryType || "",
      quantity: this.addOutwardAccessoryFormControls["quantity"].value || "",
      status: 0,
    };

    // checking duplicates if any accessory match
    if (this.localOutwardAccessoryList.length > 0) {
      for (const item of this.localOutwardAccessoryList) {
        if (localObj["accessoryType"] === item["accessoryType"]) {
          this.snackbarModalComponent.onOpenSnackbarModal(false, "Record Already Exists", '', '', '');
          return;
        }
      }

      if (Number(localObj?.quantity) > this.accessoryQty) {
        this.snackbarModalComponent.onOpenSnackbarModal(false, `Available Quantity is ${this.accessoryQty.toFixed(3)} Kgs`, '', '', '');
        return;
      }

      this.localOutwardAccessoryList.push(localObj);
      this.recordsCount = this.localOutwardAccessoryList?.length;

      this.addOutwardAccessoryFormControls["accessoryType"]?.setValue("");
      this.addOutwardAccessoryFormControls["accessoryType"]?.markAsUntouched({
        onlySelf: true,
      });

      this.addOutwardAccessoryFormControls["quantity"]?.setValue("");
      this.addOutwardAccessoryFormControls["quantity"]?.markAsUntouched({
        onlySelf: true,
      });
      this.show = false;
    } else {
      if (Number(localObj?.quantity) > this.accessoryQty) {
        this.snackbarModalComponent.onOpenSnackbarModal(false, `Available Quantity is ${this.accessoryQty.toFixed(3)} ${this.measurement?.trim()}`, '', '', '');
        return;
      }
      this.localOutwardAccessoryList.push(localObj);
      this.recordsCount = this.localOutwardAccessoryList?.length;

      this.addOutwardAccessoryFormControls["accessoryType"]?.setValue("");
      this.addOutwardAccessoryFormControls["accessoryType"]?.markAsUntouched({
        onlySelf: true,
      });

      this.addOutwardAccessoryFormControls["quantity"]?.setValue("");
      this.addOutwardAccessoryFormControls["quantity"]?.markAsUntouched({
        onlySelf: true,
      });
      this.show = false;
    }
  }

  /**
   * This method fired on submit
   * @param {*} event
   */
  submit(event: any) {
    this.addOutwardAccessoryFormControls["accessoryType"].setValidators(null);
    this.addOutwardAccessoryFormControls[
      "accessoryType"
    ].updateValueAndValidity();

    this.addOutwardAccessoryFormControls["quantity"].setValidators(null);
    this.addOutwardAccessoryFormControls["quantity"].updateValueAndValidity();

    /** This will return false if form fields are invalid and stop the service calling */
    if (this.addOutwardAccessoryForm.invalid) {
      this.validationService.validateAllFormFields(
        this.addOutwardAccessoryForm
      );
      return;
    }

    const finalObj = {
      outwardAccessoriesId: 0,
      dcNo: this.addOutwardAccessoryFormControls["dcNo"].value || "",
      unitNameId:
        Number(this.addOutwardAccessoryFormControls["unitName"].value) || 0,
      date:
        this.datePipe.transform(
          this.addOutwardAccessoryFormControls["Date"].value || "",
          "yyyy-MM-dd"
        ) || "",
      userId: 0,
      outwardAccessoriesList: this.localOutwardAccessoryList,
    };

    this.inventory.AddOutWardAccessory(finalObj).subscribe({
      next: (res: any) => {
        /* Disable the loader if response is success*/
        this.loaderService.isLoading.next(false);
        this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', 'outwardAccessory');
        this.reset(event);
      },
      error: (err: any) => {
        /* Disable the loader if response is error */
        this.loaderService.isLoading.next(false);

        this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
      },
    });
  }
}
