import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddOutwardAccessoriesComponent } from './add-outward-accessories.component';

describe('AddOutwardAccessoriesComponent', () => {
  let component: AddOutwardAccessoriesComponent;
  let fixture: ComponentFixture<AddOutwardAccessoriesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddOutwardAccessoriesComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddOutwardAccessoriesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
