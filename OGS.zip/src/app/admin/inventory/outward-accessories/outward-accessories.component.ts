import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-outward-accessories',
  templateUrl: './outward-accessories.component.html',
  styleUrls: ['./outward-accessories.component.scss']
})
export class OutwardAccessoriesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
