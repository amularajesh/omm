import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OutwardAccessoriesComponent } from './outward-accessories.component';

describe('OutwardAccessoriesComponent', () => {
  let component: OutwardAccessoriesComponent;
  let fixture: ComponentFixture<OutwardAccessoriesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OutwardAccessoriesComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(OutwardAccessoriesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
