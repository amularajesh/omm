import { DatePipe, Location } from "@angular/common";
import { Component, OnInit, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";

import { SnackbarModalComponent } from "src/app/core/Dialogues/snackbar-modal/snackbar-modal.component";
import { InventoryService } from "src/app/core/Services/inventory.service";
import { LoaderService } from "src/app/core/Services/loader.service";
import { MastersService } from "src/app/core/Services/masters.service";
import { ValidationService } from "src/app/core/Services/validation.service";

/**
 * Edit Outward Accessories Component
 * @export
 * @class EditOutwardAccessoriesComponent
 * @implements {OnInit}
 */
@Component({
  selector: "app-edit-outward-accessories",
  templateUrl: "./edit-outward-accessories.component.html",
  styleUrls: ["./edit-outward-accessories.component.scss"],
})
export class EditOutwardAccessoriesComponent implements OnInit {
  /**
   * Get Snackbar Modal Component
   * @type {SnackbarModalComponent}
   */
  @ViewChild("snackbarModalComponent") snackbarModalComponent!: SnackbarModalComponent;

  show: boolean = false;
  /**
   * Get Edit Outward Accessory Details
   * @type {*}
   */
  editOutwardAccessoryDetails: any;

  /**
   * Get Local Outward Accessory List
   * @type {any[]}
   */
  localOutwardAccessoryList: any[] = [];

  /**
   * Get Deleted Local Outward Accessory List
   * @type {any[]}
   */
  deletedLocalOutwardAccessoryList: any[] = [];

  /**
   * Get Outward Accessory List
   * @type {any[]}
   */
  outwardAccessoryTypeList: any[] = [];

  /**
   * Get Selected Accessory Type
   * @type {*}
   */
  selectedAccessoryType: any;

  /**
   * Get Accessory Qty
   * @type {*}
   */
  accessoryQty: any;

  /**
   *Get Accessory measurement
   *
   * @type {*}
   * @memberof EditOutwardAccessoriesComponent
   */
  mesurement: any;

  /**
   * Get Unit Name List
   * @type {any[]}
   */
  UnitNameList: any[] = [];

  /**
   * Get Selected Unit Name
   * @type {*}
   */
  selectedUnitName: any;

  /**
   * Default Sorting Key
   */
  sortingKeyColumn = "quality";

  /**
   * Default Sort Order
   */
  sortingOrder = true;

  /**
   * Default Page Number
   */
  currentPage = 1;

  /**
   * Declaring Var To store Outward Accessories min date.
   * @type {*}
   */
  outwardAccessoryMinDate: Date;
  mindate: Date | undefined;

  outwardAccessoryMaxDate: Date | undefined;

  /**
   *Declaring Var To store Outward Accessories list.
   * @type {*}
   * @memberof outwardAccessoryListComponent
   */
  outwardAccessoryList: any[] = [];

  inwardTypeName: any;

  /**
   *Declaring var to store records length
   * @type {*}
   * @memberof outwardAccessoryListComponent
   */
  recordsCount = 0;

  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private validationService: ValidationService,
    private datePipe: DatePipe,
    private mastersService: MastersService,
    private loaderService: LoaderService,
    private inventory: InventoryService,
    private location: Location
  ) {
    this.outwardAccessoryMinDate = new Date();
    this.inventory.OutwardAccessory.subscribe((res: any) => {
      this.editOutwardAccessoryDetails = res;
      this.localOutwardAccessoryList = res?.outwardAccessoriesList;
      for (
        let index = 0;
        index < this.localOutwardAccessoryList.length;
        index++
      ) {
        const element = this.localOutwardAccessoryList[index];
        element.isFromBackEnd = true;
      }
      this.recordsCount = this.localOutwardAccessoryList?.length;
      console.log(this.editOutwardAccessoryDetails, "fabric");
      console.log(this.localOutwardAccessoryList, "fabric1");
      this.mindate = new Date("2000-01-01");
    });
  }

  /**
   * Declaring outwardAccessory Form
   * @type {FormGroup}
   */
  editOutwardAccessoryForm!: FormGroup;

  /**
   * Get outward accessory  Form Validations
   */
  editOutwardAccessoryValidation = this.validationService?.addOutwardAccessory;
  editOutwardAccessoryValidationPattern = this.validationService?.patterns;

  ngOnInit(): void {
    this.getAccessoryList();
    this.getUnitNameList();
    this.outwardAccessoryMinDate = new Date(
      this.editOutwardAccessoryDetails?.date
    );
    this.outwardAccessoryMaxDate = new Date();
    this.editOutwardAccessoryFormValidation();
  }

  /**
   * This method for initialize form validations
   */
  editOutwardAccessoryFormValidation() {
    this.editOutwardAccessoryForm = this.formBuilder.group({
      dcNo: [
        this.editOutwardAccessoryDetails?.dcNo || "",
        [
          Validators.required,
          Validators.minLength(
            this.editOutwardAccessoryValidation?.dcNo?.minLength
          ),
          Validators.maxLength(
            this.editOutwardAccessoryValidation?.dcNo?.maxLength
          ),
          Validators.pattern(
            this.editOutwardAccessoryValidationPattern?.alphaNumeric
          ),
        ],
      ],
      Date: [
        new Date(this.editOutwardAccessoryDetails?.date) || "",
        [Validators.required],
      ],
      unitName: [
        this.editOutwardAccessoryDetails?.unitNameId || "",
        [Validators.required],
      ],
      accessoryType: ["", [Validators.required]],
      quantity: [
        "",
        [
          Validators.required,
          Validators.minLength(
            this.editOutwardAccessoryValidation?.quantity?.minLength
          ),
          Validators.maxLength(
            this.editOutwardAccessoryValidation?.quantity?.maxLength
          ),
          Validators.pattern(
            this.editOutwardAccessoryValidationPattern?.quantity
          ),
        ],
      ],
    });
  }

  /**
   * add outward Accessory Controls Initialized
   * @readonly
   */
  get editOutwardAccessoryFormControls() {
    return this.editOutwardAccessoryForm.controls;
  }

  /**
   * This Method for get accessory types
   */
  getAccessoryList() {
    this.inventory.getAccessoryTypes().subscribe({
      next: (res: any) => {
        this.outwardAccessoryTypeList = res?.result;
      },
      error: (err: any) => {
        this.outwardAccessoryTypeList = [];
      },
    });
  }

  /**
   * This Method for get unit names
   */
  getUnitNameList() {
    this.mastersService.getUnits().subscribe({
      next: (res: any) => {
        this.UnitNameList = res?.result;
      },
      error: (err: any) => {
        this.UnitNameList = [];
      },
    });
  }

  /**
   * This method fired on change of from date
   * @param {*} event
   */
  DateChange(event: any) {
    console.log("Date changed to:", event);
  }

  /**
   * This Method fired on Change of unit name
   * @param {*} event
   */
  unitChange(event: any) {
    for (const item of this.UnitNameList) {
      if (item?.unitId === Number(event.target.value)) {
        this.selectedUnitName = item?.unitNames;
      }
    }
  }

  /**
   * This Method fired on Change of accessory
   * @param {*} event
   */
  accessoryTypeChange(event: any) {
    for (const item of this.outwardAccessoryTypeList) {
      if (item?.accessoryTypeId === Number(event.target.value)) {
        this.selectedAccessoryType = item?.accessoryTypeName;
      }
    }
    if (this.editOutwardAccessoryFormControls["Date"].value) {
      /* Prepare the request payload */
      const obj = {
        accessoryId: Number(
          this.editOutwardAccessoryFormControls["accessoryType"].value
        ),
        outwardDate: this.datePipe.transform(
          this.editOutwardAccessoryFormControls["Date"].value || "",
          "yyyy-MM-dd"
        ),
      };

      this.inventory.getOutwardAccessoryQty(obj).subscribe({
        next: (res: any) => {
          this.accessoryQty = res?.result?.availableQty;
          this.mesurement = res?.result?.measurement;
          this.show = true;
          if (this.deletedLocalOutwardAccessoryList.length > 0) {
            for (const item of this.deletedLocalOutwardAccessoryList) {
              if (this.selectedAccessoryType === item["accessoryType"]) {
                if (item.isFromBackEnd) {
                  this.accessoryQty += +item.quantity;
                }
              }
            }
          }
        },
        error: (err: any) => {
          this.accessoryQty = "";
          this.show = false;
        },
      });
    }
  }

  /**
   * This method fired on click of Delete icon
   * @param {*} fabric
   */
  onClickDeleteOutwardAccessory(fabric: any, i: any) {
    this.localOutwardAccessoryList.splice(i - 1, 1);
    this.show = false;
    if (fabric.isFromBackEnd) {
      this.deletedLocalOutwardAccessoryList.push(fabric);
    }
  }

  /**
   * This method fired on click of pagination
   */
  onPageChange(event: any) { this.currentPage = event; }

  /**
   * This Method Used To Navigate  Outward Accessories List page.
   */
  navigate() {
    this.router.navigate([
      "/admin/inventory/outwardaccessories/outwardaccessorieslist",
    ]);
  }

  /**
   * This method is used to sort column
   * @param key : value of which column based we need to sort the rows
   */
  sort(key: string) {
    const componentName = this.location.path();
    let value = key;
    sessionStorage.setItem(`${componentName}_property`, value);
    this.sortingKeyColumn = key;
    if (sessionStorage.getItem(componentName + "_order") == "desc") {
      this.sortingOrder = false;
    } else {
      this.sortingOrder = true;
    }
  }

  onInput(event: any): void {
    const inputValue = this.editOutwardAccessoryForm.get('quantity')?.value;

    if (this.mesurement === 'Pcs.' || this.mesurement === 'Gross.') {
      this.editOutwardAccessoryForm.patchValue({ quantity: inputValue.replace(/[^0-9]/g, '') });
    } else {
      this.editOutwardAccessoryForm.patchValue({ quantity: inputValue.replace(/[^0-9.]/g, '') });
    }
  }

  /**
   * This method fired on click of reset
   */
  reset() {
    this.navigate();
  }

  /**
   * This method fired on click of exportToWord
   * @param {*} event
   */
  ExportToWord(event: any) { }

  /**
   * This method fired on click Add button
   * @param {*} event
   */
  LocalSave() {
    this.editOutwardAccessoryFormControls["accessoryType"].setValidators([
      Validators.required,
    ]);
    this.editOutwardAccessoryFormControls[
      "accessoryType"
    ].updateValueAndValidity();

    this.editOutwardAccessoryFormControls["quantity"].setValidators([
      Validators.required,
      Validators.minLength(
        this.editOutwardAccessoryValidation?.quantity?.minLength
      ),
      Validators.maxLength(
        this.editOutwardAccessoryValidation?.quantity?.maxLength
      ),
      Validators.pattern(this.editOutwardAccessoryValidationPattern?.quantity),
    ]);
    this.editOutwardAccessoryFormControls["quantity"].updateValueAndValidity();
    /** This will return false if form fields are invalid and stop the service calling */
    if (this.editOutwardAccessoryForm.invalid) {
      this.validationService.validateAllFormFields(
        this.editOutwardAccessoryForm
      );
      return;
    }

    /* Prepare the object */
    const localObj = {
      outwardAccessoriesId: 0,
      accessoryTypeId:
        Number(this.editOutwardAccessoryFormControls["accessoryType"].value) ||
        "",
      accessoryType: this.selectedAccessoryType || "",
      quantity: this.editOutwardAccessoryFormControls["quantity"].value || "",
      status: 0,
      isFromBackend: false,
    };

    if (Number(localObj?.quantity) > this.accessoryQty) {
      this.snackbarModalComponent.onOpenSnackbarModal(false, `Available Quantity is ${this.accessoryQty.toFixed(3)} ${this.mesurement}`, '', '', '');
      return;
    }

    // checking duplicates if both quality and color match
    if (this.localOutwardAccessoryList.length > 0) {
      for (const item of this.localOutwardAccessoryList) {
        if (localObj["accessoryType"] === item["accessoryType"]) {
          this.snackbarModalComponent.onOpenSnackbarModal(false, "Record Already Exists", '', '', '');
          return;
        }
      }

      this.localOutwardAccessoryList.push(localObj);

      this.recordsCount = this.localOutwardAccessoryList?.length;

      this.editOutwardAccessoryFormControls["accessoryType"]?.setValue("");
      this.editOutwardAccessoryFormControls["accessoryType"]?.markAsUntouched({
        onlySelf: true,
      });

      this.editOutwardAccessoryFormControls["quantity"]?.setValue("");
      this.editOutwardAccessoryFormControls["quantity"]?.markAsUntouched({
        onlySelf: true,
      });
      this.show = false;
      // this.reset(event);
    } else {
      this.localOutwardAccessoryList.push(localObj);

      this.recordsCount = this.localOutwardAccessoryList?.length;

      this.editOutwardAccessoryFormControls["accessoryType"]?.setValue("");
      this.editOutwardAccessoryFormControls["accessoryType"]?.markAsUntouched({
        onlySelf: true,
      });

      this.editOutwardAccessoryFormControls["quantity"]?.setValue("");
      this.editOutwardAccessoryFormControls["quantity"]?.markAsUntouched({
        onlySelf: true,
      });
      this.show = false;
    }
    console.log(this.localOutwardAccessoryList, 'localsave');

  }

  /**
   * This method fired on submit
   */
  submit() {
    this.editOutwardAccessoryFormControls["accessoryType"].setValidators(null);
    this.editOutwardAccessoryFormControls[
      "accessoryType"
    ].updateValueAndValidity();

    this.editOutwardAccessoryFormControls["quantity"].setValidators(null);
    this.editOutwardAccessoryFormControls["quantity"].updateValueAndValidity();

    /** This will return false if form fields are invalid and stop the service calling */
    if (this.editOutwardAccessoryForm.invalid) {
      this.validationService.validateAllFormFields(
        this.editOutwardAccessoryForm
      );
      return;
    }

    let newArray = this.localOutwardAccessoryList.map((obj) => {
      // Create a shallow copy of the object to avoid modifying the original
      let newObj = { ...obj };

      // Remove the specified key from the object
      delete newObj["isFromBackend"];
      return newObj;
    });

    /* Prepare the request payload */
    const finalObj = {
      outwardAccessoriesId:
        this.editOutwardAccessoryDetails?.outwardAccessoriesId || 0,
      dcNo: String(this.editOutwardAccessoryFormControls["dcNo"].value) || "",
      unitNameId:
        Number(this.editOutwardAccessoryFormControls["unitName"].value) || 0,
      date:
        this.datePipe.transform(
          this.editOutwardAccessoryFormControls["Date"].value || "",
          "yyyy-MM-dd"
        ) || "",
      userId: 0,
      outwardAccessoriesList: newArray,
    };

    this.inventory.EditOutWardAccessory(finalObj).subscribe({
      next: (res: any) => {
        /* Disable the loader if response is success*/
        this.loaderService.isLoading.next(false);
        this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', 'outwardAccessory');
      },
      error: (err: any) => {
        /* Disable the loader if response is error */
        this.loaderService.isLoading.next(false);

        this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
      },
    });
  }
}
