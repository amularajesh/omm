import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditOutwardAccessoriesComponent } from './edit-outward-accessories.component';

describe('EditOutwardAccessoriesComponent', () => {
  let component: EditOutwardAccessoriesComponent;
  let fixture: ComponentFixture<EditOutwardAccessoriesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EditOutwardAccessoriesComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EditOutwardAccessoriesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
