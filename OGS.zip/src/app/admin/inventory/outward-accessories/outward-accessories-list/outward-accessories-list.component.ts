import { DatePipe, Location } from "@angular/common";
import { Component, OnInit, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";
import {
  AlignmentType,
  Document,
  FrameAnchorType,
  Header,
  HeightRule,
  HorizontalPositionAlign,
  ImageRun,
  Packer,
  Paragraph,
  Table,
  TableCell,
  TableRow,
  TextRun,
  VerticalAlign,
  VerticalPositionAlign,
  WidthType,
} from "docx";

import { SnackbarModalComponent } from "src/app/core/Dialogues/snackbar-modal/snackbar-modal.component";
import { InventoryService } from "src/app/core/Services/inventory.service";
import { LoaderService } from "src/app/core/Services/loader.service";
import { MastersService } from "src/app/core/Services/masters.service";
import { ValidationService } from "src/app/core/Services/validation.service";

@Component({
  selector: "app-outward-accessories-list",
  templateUrl: "./outward-accessories-list.component.html",
  styleUrls: ["./outward-accessories-list.component.scss"],
})
export class OutwardAccessoriesListComponent implements OnInit {
  /**
   * Get Snackbar Modal Component
   * @type {SnackbarModalComponent}
   */
  @ViewChild("snackbarModalComponent") snackbarModalComponent!: SnackbarModalComponent;

  /**
   * Get Is Admin Or Manager Flag
   */
  isAdminOrManager = false;

  /**
   *Boolean for submit button click or not
   * @type {boolean}
   * @memberof OutwardAccessoryListComponent
   */
  isSubmit: boolean = false;

  /**
   *var to stor grand total
   *
   * @type {*}
   * @memberof OutwardAccessoryListComponent
   */
  grandTotal: any;

  /**
   * Default Sorting Key
   */
  sortingKeyColumn = "unitName";

  /**
   * Default Sort Order
   */
  sortingOrder = true;
  /**
   * Default Page Number
   */
  currentPage = 1;

  /**
   *Declaring Var To store Inward fabric min date.
   *
   * @type {*}
   * @memberof OutwardAccessoryListComponent
   */
  OutwardAccessoryMinDate: Date;
  fromDate: Date;
  mindate: Date;

  OutwardAccessoryfromDate: any;
  OutwardAccessoryMaxdate: Date;
  /**
   *Declaring Var To store Inward fabric list.
   * @type {*}
   * @memberof OutwardAccessoryListComponent
   */
  OutwardAccessoryList: any[] = [];

  /**
   *Declaring Var To store unitName list.
   * @type {*}
   * @memberof OutwardAccessoryListComponent
   */
  uintNameList: any[] = [
    {
      unitId: 1,
      unitName: "unitOne",
    },
    {
      unitId: 2,
      unitName: "unitTwo",
    },
  ];
  uintName: any;
  /**
   *Declaring Var To store acessory list.
   *
   * @type {any[]}
   * @memberof OutwardAccessoriesListComponent
   */
  accessoryTypeList: any[] = [];
  accessoryName: any;

  /**
   *Declaring var to store records length
   * @type {*}
   * @memberof OutwardAccessoryListComponent
   */
  recordsCount = 0;

  searchData: any;

  /**
   * Get Current Date Format
   */
  currentDateFormat = '';

  /**
   * Get From Date Format
   */
  fromDateFormat = '';

  /**
   * Get To Date Format
   */
  toDateFormat = '';

  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private validationService: ValidationService,
    private datePipe: DatePipe,
    private inventory: InventoryService,
    private mastersSerive: MastersService,
    private loader: LoaderService,
    private location: Location
  ) {
    if (localStorage.getItem('userTypeId') == '1' || localStorage.getItem('userTypeId') == '4') {
      this.isAdminOrManager = true;
    }

    this.currentDateFormat = this.datePipe.transform(new Date(), "dd-MMM-yyyy") || '';
    // preparing intial date to fromDate
    this.fromDate = new Date();
    const lastMonth = new Date(this.fromDate);
    this.OutwardAccessoryMaxdate = new Date();

    if (lastMonth.getMonth() % 2 !== 0) {
      lastMonth.setMonth(lastMonth.getMonth() - 1);
      lastMonth.setDate(lastMonth.getDate() - 1);
    } else {
      lastMonth.setMonth(lastMonth.getMonth() - 1);
    }
    this.OutwardAccessoryMinDate = lastMonth;
    this.mindate = new Date("2000-01-01");
  }

  /**
   * Declaring OutwardAccessory search Form
   * @type {FormGroup}
   * @memberof OutwardAccessoryListComponent
   */
  OutwardAccessorySearchForm!: FormGroup;

  /**
   * Get inward fabric search Form Validations
   */
  OutwardAccessorySearchValidation = this.validationService
    ?.OutwardAccessorySearch;

  ngOnInit(): void {
    this.OutwardAccessorySearchFormValiadation();
    this.getOutwardAccessoryList();
    this.getAccessoryList();
    this.getUnitNameList();
  }

  /**
   *This method for intializing form validations
   *
   * @memberof OutwardAccessoryListComponent
   */
  OutwardAccessorySearchFormValiadation() {
    this.OutwardAccessorySearchForm = this.formBuilder.group({
      dcNo: [""],
      unitName: [""],
      accessoryType: [""],
      fromDate: [new Date(this.OutwardAccessoryMinDate), [Validators.required]],
      toDate: [""]
    });
    this.fromDateChange(new Date(this.OutwardAccessoryMinDate));
  }

  /**
   * inwardSearch Controls Initialized
   * @readonly
   */
  get OutwardAccessorySearchFormControls() {
    return this.OutwardAccessorySearchForm.controls;
  }

  /**
   *This method fired on chage of from date
   *
   * @param {*} event
   * @memberof OutwardAccessoryListComponent
   */
  fromDateChange(newValue: Date) {
    this.OutwardAccessoryfromDate = newValue;
    this.OutwardAccessorySearchFormControls["toDate"]?.setValue("");
    this.OutwardAccessorySearchFormControls["toDate"]?.markAsUntouched({
      onlySelf: true,
    });
  }

  /**
   *This method fired on chage of to date
   *
   * @param {*} event
   * @memberof OutwardAccessoryListComponent
   */
  ToDateChange(event: any) { }

  /**
   *This method fired on click of edit icon
   *
   * @param {*} user
   * @memberof OutwardAccessoryListComponent
   */
  onClickEditOutwardAccessory(user: any) {
    this.loader.isLoading.next(true);
    this.inventory.getOutwardAccessoryById(user?.outwardAccssoriesId).subscribe({
      next: (res: any) => {
        this.loader.isLoading.next(false);
        this.inventory.OutwardAccessory.next(res?.result);
        this.navigateToEditOutwardAccessory(event);
      },
      error: (err: any) => {
        this.loader.isLoading.next(false);
        this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message || err, '', '', '');
      },
    });
  }

  /**
   *This method fired on click of pagination
   *
   * @memberof OutwardAccessoryListComponent
   */
  onPageChange(event: any) {
    this.currentPage = event;
  }

  /**
   * This Method Used To Navigate add Inward fabric page.
   * @param {*} event
   * @memberof OutwardAccessoryListComponent
   */
  navigate(event: any) {
    this.router.navigate([
      "/admin/inventory/outwardaccessories/addoutwardaccessorie",
    ]);
  }

  /**
   * This Method Used To Navigate edit Inward fabric page.
   * @param {*} event
   * @memberof OutwardAccessoryListComponent
   */
  navigateToEditOutwardAccessory(event: any) {
    this.router.navigate([
      "/admin/inventory/outwardaccessories/editoutwardaccessorie",
    ]);
  }

  /**
   * This method is used to sort column
   * @param key : value of which column based we need to sort the rows
   */
  sort(key: string) {
    const componentName = this.location.path();
    let value = key;
    sessionStorage.setItem(`${componentName}_property`, value);
    this.sortingKeyColumn = key;
    if (sessionStorage.getItem(componentName + "_order") == "desc") {
      this.sortingOrder = false;
    } else {
      this.sortingOrder = true;
    }
  }

  /**
   *This method fired on submit
   *
   * @param {*} event
   * @memberof OutwardAccessoryListComponent
   */
  submit(event: any) {
    this.isSubmit = true;
    /** This will return false if form fields are invalid and stop the service calling */
    if (this.OutwardAccessorySearchForm.invalid) {
      this.validationService.validateAllFormFields(
        this.OutwardAccessorySearchForm
      );
      return;
    }

    //preparing payload
    const obj = {
      dcNo: this.OutwardAccessorySearchFormControls["dcNo"].value || "",
      unitNameId:
        Number(this.OutwardAccessorySearchFormControls["unitName"].value) || 0,
      accessoryTypeId:
        Number(
          this.OutwardAccessorySearchFormControls["accessoryType"].value
        ) || 0,
      fromDate:
        this.datePipe.transform(
          this.OutwardAccessorySearchFormControls["fromDate"].value,
          "yyyy-MM-dd"
        ) || "",
      toDate:
        this.datePipe.transform(
          this.OutwardAccessorySearchFormControls["toDate"].value,
          "yyyy-MM-dd"
        ) || "",
    };
    console.log(obj, "finalObj");

    this.searchData = {
      fromDate: this.datePipe.transform(
        this.OutwardAccessorySearchFormControls["fromDate"].value || "",
        "dd-MM-yyyy"
      ),
      toDate:
        this.datePipe.transform(
          this.OutwardAccessorySearchFormControls["toDate"].value,
          "dd-MM-yyyy"
        ) || "",
    };

    // enable loader true
    this.loader.isLoading.next(true);
    this.inventory.getOutwardAccessoriesList(obj).subscribe({
      next: (res: any) => {
        console.log(res);
        //enable loader false
        this.loader.isLoading.next(false);
        this.OutwardAccessoryList = res?.result;
        this.recordsCount = this.OutwardAccessoryList.length;
        this.currentPage = 1;

        this.fromDateFormat = this.datePipe.transform(this.OutwardAccessorySearchFormControls["fromDate"].value, "dd-MMM-yyyy") || '';
        this.toDateFormat = this.datePipe.transform(this.OutwardAccessorySearchFormControls["toDate"].value, "dd-MMM-yyyy") || this.currentDateFormat;

        //calucalate toatal
        const total = this.OutwardAccessoryList.reduce((acc, item) => {
          const quantity = parseFloat(item.quantity);
          if (!isNaN(quantity)) {
            return acc + quantity;
          } else {
            return acc;
          }
        }, 0);
        this.grandTotal = total.toFixed(3).replace(/\d(?=(\d{3})+\.)/g, "$&,");
      },
      error: (err: any) => {
        this.OutwardAccessoryList = [];
        this.loader.isLoading.next(false);
        this.grandTotal = 0;
        this.currentPage = 1;
        this.recordsCount = 0;
      },
    });
  }

  /**
   *This method fired on click of reset
   *
   * @param {*} event
   * @memberof OutwardAccessoryListComponent
   */
  reset(event: any) {
    this.OutwardAccessorySearchForm.reset();
    this.OutwardAccessorySearchFormValiadation();
  }

  /**
   *This method fired on click of exportToWord
   *
   * @param {*} event
   * @memberof OutwardAccessoryListComponent
   */
  ExportToWord(OutwardAccessoryList: any[], grandTotal: any, searchData: any) {
    const tableRows: TableRow[] = [];

    const year = this.fromDate.getFullYear();
    const month = String(this.fromDate.getMonth() + 1).padStart(2, "0");
    const day = String(this.fromDate.getDate()).padStart(2, "0");

    const currentDate = `${day}-${month}-${year}`;
    const IMAGE_PATH =
      "/9j/4AAQSkZJRgABAQEAYABgAAD/2wBDAAIBAQIBAQICAgICAgICAwUDAwMDAwYEBAMFBwYHBwcGBwcICQsJCAgKCAcHCg0KCgsMDAwMBwkODw0MDgsMDAz/2wBDAQICAgMDAwYDAwYMCAcIDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAz/wAARCAAuAKADASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD9/K+eP2wv+CqfwM/YYuzYePvG9pB4g2CRdD06J77UiCMqWijB8oEcgylAexrwn/gvd/wVKvv2A/gXp/hnwVdJB8TPHySpZXO0OdFsk+WW7APHmFiEjzxne3Pl4P8AOpK+tfEjxTNM51PXtb1OV55nbzLq6u5DlndjyzseSScnqTX0mUZD9Zh7as7R6d3/AMA8TMc29hL2VJXl+R++t3/wdXfs7W9y6J4T+Mc6qcCSPSNOCv7jdfA/mBUf/EVr+zx/0Jvxn/8ABTpn/wAn1+CGu+BNc8LwiTU9G1XTo2OA11aSQgn6sBVbQ/DuoeJ737NptjeahcbS3lW0LSvgdThQTivf/wBXMDa+v3nj/wBt4u/T7j9+P+IrX9nj/oTfjP8A+CnTP/k+j/iK1/Z4/wChN+M//gp0z/5Pr8H/APhTXjD/AKFTxJ/4LJv/AImqlj8OPEOp3tzbW2g61cXFkwW4iisZXeAnoHAXKk+9H+ruA8/vD+2sX5fcfvX/AMRWv7PH/Qm/Gf8A8FOmf/J9en/s/wD/AAcV/sxfHfXYdNuPEus+Ary5YJF/wlWni0gZj2aeJ5YY/rI6j3r+b7TPB+pat4st9DjtJI9VurhbRLeYeSwlYhQrbsbeSOuK9V/ap/Yi8S/sbGy0/wAb6ho9r4mu4knfRrafz57VGGQJGHyhgCCRnjcuCcnGdTh3A6QTab21NIZzi/isml5H9Zum6lb6xp8F3aTw3VpdRrNDNC4eOZGGVZWHBUgggjgg1PX89/8Awb/f8FZtb/Zs+OOi/CHxrrFxe/DTxldJp+m/apdw8OX8rbYmjZj8kEjkK652qWDjGH3f0IV8hmWXzwdX2ctV0fc+jwWMhiafPHfqgor8Xf8AgqF8N/j1+xt+0j8G9D0v9qj4r6hZfHDxRc6cU8+S2XQY/tVmiiNRMRIFF4cA7f8AVj14+6dI+NfhD/gj18DdM0z9oL48+JPGN14m1e6l03Xtc0m9u7mQLHDutgtutwVRMbgWIBMhxVVMutThOnLmctkk7u2/ToTDG3nKM48qju21byPrmivyq/4LV/8ABRfxbr/7Mfwb8Z/A3xp4l0T4M/EHUryDxF440DTbiG+s44Z44FRfMWKaElhdEDMbSNAAHA+95n+zR+0l8QNE/Zc/aUvvCH7VkXxm8HaN4EudV0WbVLvUbXxz4ev1WPExiuYyywhmlQslxImVhZdpYrWtPJ6kqKqt2u7Ws+9tdLJ+TInmUFUdNK+l76dr6d15n7Q0V+Qn7D//AAXu1z4S/Bn4FaB8T/h78Qde0bxlLJpd38TNTvG8q9uzeyoxhR4j9pSAPEjt5ysNjhUbYN3T+Ev+Ci3hD9lL9pX9tvxzZ+GviFrup+Cb/T21ey1LxWkun3ZXUF05PscX2cG3AM2752lwqhF2iplk+IjKUWvTbX3uXvoOOZUZJST9fLS/zP1Uor8r/wBpH/gtz8V/H/8AwTw8b/E34cfB7xn8Pba1bRE0fxff+TdW4S5eT7XcJFPbGKWKKWBbUMC283iPhNuK2PBv/BdjxB8Ff2Dfg74i+Ifw713xB8UPibcNpmiW8t9a6XbeJliS036m84jENrFI92iqojIBVs7VBIn+yMTy3sr3ta6vtf0/HTqV/aVC9r6WveztvY/Tiivn/wDYH/bZ1r9srwzr83iH4UeM/hZq3h26S3kh1aMz6fqStvAksr0IkV0oMbBjGMDKHJDg19AVwVacqcnCe6OunUjOPNHY/mx/4OQ/H174x/4KueMtOundoPCmlaVpdmGPCRPZRXZA9vMupD9Sa+af2D9UuNH/AG2fhJNazPBL/wAJhpSbkODta7iVh9CpIPsa+8f+Dpf9lTUPAH7WegfFi2tnfQfH+mRWF1OBxFqNouzYx7brfySuevlyY+6a+Cv2Hhbw/tg/DS7vL2206x0vxJY6jdXNxu2QwwTpNIcKrMTtQ4ABr9KwE4zy6Lj/AC2+dtfxPh8ZGUcbLm/m/XQ/Rf8AaP8A2z/FHgb/AILHN8N9Wlt/EXw08U+IxoOpeHtRt0ntHt7m+e3IVSPlKqFwR0wfWuE0n9jC6/Zj/wCC+fhTwx8OoWt/Duk+J9N1C4Q3ccS22mzXixSxMZGG8MhKbBlm3YAJrf8AidoPw38bf8FXJvjf4g+InhuH4eeG9WbX44k85b3U3jupp4Yo0kjRckmMnLZxnAJ4rxnSP2xrD9pv/gtB4W+Kd/q9v4c8M2Piqx1S4lm850Fla3S3BjCxozudoIHyjJGfl7efShLltTVlya6denzOupOPN77159PT/I+p/wBqz4jftBfB/wDae+KXjXw34t0C18F/Dea71WTS5tQs7xr5W1SW3jt2t43aVFEcsX31ULtA6jFfH3/BNj/goDf/AA//AOCnOleNvE175eh+PNTbTtfSQgxCG5YqJHzwfLdlkJ68E969L/aT+E3hj9pT9vXW/Eq/F/RPDXgDxBqV22o3UVtqX2mezl1C4nKCJbbBYxyJwxxn6V8Y/tO/B/S/gT8XrrT/AA34hh8SaGkzNp2oojxNOitgOUdVdc8Hle5GTgmunB0KU6bpTWso9rf076mOJq1IzVSL0T73Ppr4+/sh6j4c/wCCuuo6Fq7yXGmafqUmu39zIf8AVWdqnnuXboC0aIw9RNH3NfMf7XHx7v8A9pT9oHxJ4sv5nmOoXcnklj0jDHH0zycdBnA4Ar9GP24v2lPC3xP/AGHNE8YeH9Y068+MGueC7LQ/FMMSSq6RQFWeQSMiqzsFRmIbJ8iNfm6V+TtdOXOVSPPUWsVy/wCb+ZhjVGD5YPR6/wCQ+3uJLS4SWJ3jljYOjocMjDkEHsa/sF/Zv8b3XxM/Z38BeJL7JvfEHhzT9SuMj/lpNbRyN+rGv5Mf2ZfgBrf7U/x/8JfD3w7C0ureLNSisYiFyIEJzJM3+xHGHkb/AGUNf14eD/Ctn4F8JaXomnIY9P0ezisbZCclIokCIP8AvlRXg8WTj+7h11+7Q9fh6Mvfl00PkP8A4Kkf8E7PG37bnx6/Z18U+FNU8Lafp/wi8Ry6xrEerXM8U1zC1xp8oW3EcMgZ9tpJw5QZZeeSR9hav4esPECIt/Y2d6sZJQXEKyBCeuNwOKwPjh8VYPgj8J9c8VXFpLfx6Nb+aLaNwhmcsFRSzcICzLljwoycHFcPqX7XMHw6uLnT/HOjLpGtWsF1eGHSNQTVbaS3gm0+IsJCsLq5bUrf5JIkb5XPK7Gf5Sdec4RpvaN7fN3PoY0oxnKa3lv8tDy7/go9+xV8XPjmngzXPgT8UH+HWueD5pPP0C7up4vDXiGF2V9l3bxB0fBDDDxOrrIwOMA18n/Cj/ghJ8XNRu/jh438d+Ivhdp/j34neDLvwzpek+F7SSw0S0luEhQzT+XbpsAEK5EcTlmdnLFuv3Jd/wDBQ/wxFq9pFHomvCzGo3tlqdxObeJ9KjtrK5vGneHzTLgx2spCMqyYUnbkory3H/BRHwdaXUVrJonjJdRM629zZDT42msHeSxjiEuJSv7xtSstu0t/rxnG1tvVRzHEUqfs4W+5X3va5hUwVKpPnlf79Ox8YfE7/giL8VvGn7AP7N/wqtfEHw9j8Q/B/Xr3VNZuJb68FlcxTXks6i3YWpdmCuAQ6IM55I5pvxU/4Ih/Ffxxrv7X11aeIPh7HH8f7q2m8PCa+vAbNYtYivm+14tTsPlIQPL8z5iB0+avs34iftwS6T4Z8K6z4V8Lwa5p2v8Ah3VvFF1/amrHSprG0042wmjVRBMsk5NwQFZ40zGcyYOQ9v8Agov4El/t37LY+KLxdB2CWSOxRIpCZo4ZB5jyKkXlSSqHacxrwxUsFJGizbEra299u8ub80Q8uoP7rfhb8jzvx1/wTn8R/EL/AII2W37ONzrWiWfiuDwpYaQdRiaWXTjd2ksMy/MUWTymeEKW8vcAxO0kYPgHiL/glf8AtF+P/wBgH4X/AA71uf4A6trvwyu5baLSNZ02a+03UtMWOEQZu/IFzb3I2TI/kbVkR0O9GWvr+2/4KIeEDeXaGy1q8SG4jw9jbpKILaRNP8ueUl1GGk1GFMRlz1bG1SwD/wAFH/Aq+HpNSbTfFUUEbWrHzrOGFRBcJdNHcmR5RGsRNlcJ8zhy6AKrbl3ZU8wrw2t8XNt1Zc8FSnv2t8jxj/gjT/wS58Yf8E9br4i614t13w5HN8QLqK4i8LeGHu5NF0JUaVh5b3JMrsBKIxuyQsYy8mcj7npFcOoIIIIyCO9LXNicROvUdWpuzejRjSgqcNkeeftT/sueDv2yfghrPw/8dab/AGjoOsoMlCFns5V5juIXwdkqHkNg9wQVJU/z7/tvf8G+Xx4/ZV8U31z4S0K++KXg0OzWeo6BAZr9I+yz2a5lV8ZyYxInH3hnA/pLorty7Nq+DdoaxfRnLjcupYnWej7n8gF7+zL8T7Sdobj4fePI5EOGjk0K7DKfcFKhX9mz4kIcjwD43B9Rod1/8RX9gtFe1/rZP/n2vv8A+AeX/q9H+f8AA/j9/wCGc/iX/wBCJ45/8El1/wDEU1/2bfiRIfm8A+Nz9dDuv/iK/sEoo/1sn/z7X3/8AP8AV6P8/wCH/BP4/P8AhnH4lbcf8IH44x0x/Yl1/wDEV6X+z9/wSo/aF/aX16Cy8NfCnxfHBM4VtR1WwfTNPiHdjPcBEOByQpZvRSSBX9XFFTPiuq17tNJ+v/DFR4ep396bPh3/AIJBf8EYPDv/AATZ0CfxDrl3Z+KviprEHkXeqxRn7LpcJwTb2gYBsEgb5GAZ8AYUZB+4qKK+axGIqV6jq1Xds9yjRhSgoU1ZFXWtFs/Emj3Wn6ha219YX0LW9zbXEQkiuI2BVkdSCGUgkEEYINcPD+yd8MoNE0/TU8BeE1sdJnlurOEaZFtt5ZdvmSL8vDNsTJ6ny0/ujHoVFYGpxFp+zZ8P7BiYfBnhqIm8/tA7dPiH7/ZJHv6f3JZVx0xI4xhjldG/Zt8AeHbO3t7Dwb4cs4bUgxJDYRoEInhuARgdRNbwP9YY/wC6K7aii4HD+JP2aPh94w07RrTVfBnhzUrTw75n9mwXNhHLFZeYyvIEUggBmRCRjB2jNP1n9nHwD4h1TVL298HeHbm81pke+newjMlyysrKzNjO7ciHPXKKewrtaKLsDyHx7+w78O/Ht9oMjaNb6Xb6BcLcxWun2tvDFMVNrtViYmdAFsrdMwtG2yPbnbxXR6n+zD8O9a09bS78FeGrm2WGK3EUthGyiOIThEwR90C5uBjpieQdGNd3RRdgIqhFAAwBwAO1LRRQB//Z";

    //Logo
    const image = new Header({
      children: [
        new Paragraph({
          children: [
            new ImageRun({
              data: IMAGE_PATH,
              transformation: {
                width: 130,
                height: 40,
              },
            }),
          ],
        }),
      ],
    });

    // Additional Information
    const additionalInfo = new Paragraph({
      alignment: AlignmentType.CENTER,
      children: [
        new TextRun({
          text: "Outward Accessories Details",
          bold: true,
          font: 'Arial Black',
          color: '#000000',
          size: 32,
        }),
      ],
    });
    const Date = new Paragraph({
      frame: {
        position: {
          x: 0,
          y: 800,
        },
        width: 9500,
        height: 500,
        anchor: {
          horizontal: FrameAnchorType.MARGIN,
          vertical: FrameAnchorType.MARGIN,
        },
        alignment: {
          x: HorizontalPositionAlign.CENTER,
          y: VerticalPositionAlign.TOP,
        },
      },

      children: [
        new TextRun({
          text: "From Date: ",
          bold: true,
          font: "Arial",
        }),
        new TextRun({
          text: this.fromDateFormat,
          font: "Arial",
        }),
        new TextRun({
          text:
            "                                                                                                 ", // Add space between "Quality" and "Colour"
        }),
        new TextRun({
          text: "To Date: ",
          font: "Arial",
          bold: true,
        }),
        new TextRun({
          text: this.toDateFormat,
          font: "Arial",
        }),
      ],
    });

    // Create table headers
    const tableHeader = new TableRow({
      height: {
        value: 400,
        rule: HeightRule.EXACT,
      },
      children: [
        new TableCell({
          width: {
            size: 1000,
            type: WidthType.DXA,
          },
          verticalAlign: VerticalAlign.CENTER,
          shading: {
            fill: "D3D3D3", // Specifying the background color
          },
          children: [
            new Paragraph({
              children: [
                new TextRun({
                  text: "S. No",
                  bold: true,
                  color: "#000000",
                  font: "Arial",
                }),
              ],
              alignment: AlignmentType.CENTER,
            }),
          ],
        }),
        new TableCell({
          width: {
            size: 2500,
            type: WidthType.DXA,
          },
          verticalAlign: VerticalAlign.CENTER,
          shading: {
            fill: "D3D3D3", // Specifying the background color
          },
          children: [
            new Paragraph({
              children: [
                new TextRun({
                  text: "DC No",
                  bold: true,
                  color: "#000000",
                  font: "Arial",
                }),
              ],
              alignment: AlignmentType.CENTER, // Center align the text vertically
            }),
          ],
        }),
        new TableCell({
          width: {
            size: 2000,
            type: WidthType.DXA,
          },
          verticalAlign: VerticalAlign.CENTER,
          shading: {
            fill: "D3D3D3", // Specifying the background color
          },
          children: [
            new Paragraph({
              children: [
                new TextRun({
                  text: "Date",
                  bold: true,
                  color: "#000000",
                  font: "Arial",
                }),
              ],
              alignment: AlignmentType.CENTER, // Center align the text vertically
            }),
          ],
        }),
        new TableCell({
          width: {
            size: 4000,
            type: WidthType.DXA,
          },
          verticalAlign: VerticalAlign.CENTER,
          shading: {
            fill: "D3D3D3", // Specifying the background color
          },
          children: [
            new Paragraph({
              children: [
                new TextRun({
                  text: "Unit Name",
                  bold: true,
                  font: "Arial",
                  color: "#000000",
                }),
              ],
              alignment: AlignmentType.CENTER, // Center align the text vertically
            }),
          ],
        }),
        new TableCell({
          width: {
            size: 2000,
            type: WidthType.DXA,
          },
          verticalAlign: VerticalAlign.CENTER,
          shading: {
            fill: "D3D3D3", // Specifying the background color
          },
          children: [
            new Paragraph({
              children: [
                new TextRun({
                  text: "Quantity",
                  font: "Arial",
                  color: "#000000",
                  bold: true,
                }),
              ],
              alignment: AlignmentType.CENTER, // Center align the text vertically
            }),
          ],
        }),
      ],
    });
    //adding header to table rows
    tableRows.push(tableHeader);

    // Create data rows from the OutwardAccessoryList array
    OutwardAccessoryList.forEach((item: any, index: number) => {
      const row = new TableRow({
        children: [
          new TableCell({
            margins: { top: 100, bottom: 100 },

            width: {
              size: 1000,
              type: WidthType.DXA,
            },
            verticalAlign: VerticalAlign.CENTER,
            children: [
              new Paragraph({
                alignment: AlignmentType.CENTER,

                children: [
                  new TextRun({
                    text: `${index + 1}`,
                    color: "#000000",
                    font: "Arial",
                  }),
                ],
              }),
            ],
          }),
          new TableCell({
            margins: { left: 50, right: 50, top: 100, bottom: 100 },

            width: {
              size: 2500,
              type: WidthType.DXA,
            },
            verticalAlign: VerticalAlign.CENTER,
            children: [
              new Paragraph({
                alignment: AlignmentType.LEFT,

                children: [
                  new TextRun({
                    text: `${item.dcNo}`,
                    color: "#000000",
                    font: "Arial",
                  }),
                ],
              }),
            ],
          }),
          new TableCell({
            margins: { top: 100, bottom: 100 },

            width: {
              size: 2000,
              type: WidthType.DXA,
            },
            verticalAlign: VerticalAlign.CENTER,
            children: [
              new Paragraph({
                alignment: AlignmentType.CENTER,

                children: [
                  new TextRun({
                    text: `${item.date}`,
                    color: "#000000",
                    font: "Arial",
                  }),
                ],
              }),
            ],
          }),
          new TableCell({
            margins: {
              left: 100,
              top: 100, bottom: 100

            },
            width: {
              size: 4000,
              type: WidthType.DXA,
            },
            verticalAlign: VerticalAlign.CENTER,
            children: [
              new Paragraph({
                alignment: AlignmentType.LEFT,

                children: [
                  new TextRun({
                    text: `${item.unitName}`,
                    color: "#000000",
                    font: "Arial",
                  }),
                ],
              }),
            ],
          }),
          new TableCell({
            margins: { top: 100, bottom: 100 },

            width: {
              size: 2000,
              type: WidthType.DXA,
            },
            verticalAlign: VerticalAlign.CENTER,
            children: [
              new Paragraph({
                alignment: AlignmentType.END,

                children: [
                  new TextRun({
                    text: `${(+item.quantity).toLocaleString('en-IN')}\u00A0\u00A0`,
                    color: "#000000",
                    font: "Arial",
                  }),
                ],
              }),
            ],
          }),
        ],
      });
      tableRows.push(row);
    });

    //preparing table
    const table = new Table({
      width: {
        size: 9100, // Adjust the width size as needed
        type: WidthType.DXA,
      },
      rows: tableRows,
    });

    const doc = new Document({
      sections: [
        {
          headers: {
            default: image,
          },
          // children: [additionalInfo, quality, Colour, fromdate, toDate, table],
          children: [additionalInfo, Date, table],
        },
      ],
    });
    const monthNames = [
      "Jan", "Feb", "Mar", "Apr", "May", "Jun",
      "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
    ];
    const Month = monthNames[(+month - 1)];
    const readableFormat = `${day}-${Month}-${year}`;
    // Generate the document and offer it for download
    Packer.toBlob(doc).then((blob) => {
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `Outward_Accessories_${readableFormat}.docx`;
      a.click();
      window.URL.revokeObjectURL(url);
    });
  }

  /**
   *
   *This Method to get inward fabric list
   * @memberof OutwardAccessoryListComponent
   */
  getOutwardAccessoryList() {
    if (this.isSubmit === false) {
      //preparing payload

      const obj = {
        dcNo: this.OutwardAccessorySearchFormControls["dcNo"].value || "",
        unitNameId:
          Number(this.OutwardAccessorySearchFormControls["unitName"].value) ||
          0,
        accessoryTypeId:
          Number(
            this.OutwardAccessorySearchFormControls["accessoryType"].value
          ) || 0,
        fromDate:
          this.datePipe.transform(
            this.OutwardAccessorySearchFormControls["fromDate"].value,
            "yyyy-MM-dd"
          ) || "",
        toDate:
          this.datePipe.transform(
            this.OutwardAccessorySearchFormControls["toDate"].value,
            "yyyy-MM-dd"
          ) || "",
      };
      //this obj for showing data in word file
      this.searchData = {
        fromDate: this.datePipe.transform(
          this.OutwardAccessorySearchFormControls["fromDate"].value || "",
          "dd-MM-yyyy"
        ),
        toDate:
          this.datePipe.transform(
            this.OutwardAccessorySearchFormControls["toDate"].value,
            "dd-MM-yyyy"
          ) || "",
      };

      // enable loader true
      this.loader.isLoading.next(true);
      this.inventory.getOutwardAccessoriesList(obj).subscribe({
        next: (res: any) => {
          //enable loader false
          this.loader.isLoading.next(false);
          this.OutwardAccessoryList = res?.result;
          this.recordsCount = this.OutwardAccessoryList.length;
          this.currentPage = 1;

          this.fromDateFormat = this.datePipe.transform(this.OutwardAccessorySearchFormControls["fromDate"].value, "dd-MMM-yyyy") || '';
          this.toDateFormat = this.datePipe.transform(this.OutwardAccessorySearchFormControls["toDate"].value, "dd-MMM-yyyy") || this.currentDateFormat;

          //calucalate toatal
          const total = this.OutwardAccessoryList.reduce((acc, item) => {
            const quantity = parseFloat(item.quantity);
            if (!isNaN(quantity)) {
              return acc + quantity;
            } else {
              return acc;
            }
          }, 0);
          this.grandTotal = total.toFixed(3);
        },
        error: (err: any) => {
          console.log(err, "list");
          this.loader.isLoading.next(false);
          this.currentPage = 1;
          this.OutwardAccessoryList = [];
          this.recordsCount = 0;
        },
      });
    }
  }

  /**
   *This Method fired on Change of unit
   * @param {*} event
   * @memberof AddOutwardAccessoryComponent
   */
  unitChange(event: any) {
    for (const item of this.uintNameList) {
      if (item?.unitId === event.target.value) {
        this.uintName = item?.uintName;
      }
    }
  }

  /**
   *This Method fired on Change of accessory
   * @param {*} event
   * @memberof AddOutwardAccessoryComponent
   */
  accessoryChange(event: any) {
    for (const item of this.accessoryTypeList) {
      if (item?.accessoryId === event.target.value) {
        this.accessoryName = item?.accessoryName;
      }
    }
  }

  /**
   *This Method for get Colours
   *
   * @memberof inwardAccessoryListComponent
   */
  getAccessoryList() {
    this.inventory.getAccessoryTypes().subscribe({
      next: (res: any) => {
        this.accessoryTypeList = res?.result;
      },
      error: (err: any) => {
        this.accessoryTypeList = [];
      },
    });
  }

  /**
   *This Method for get Colours
   *
   * @memberof inwardAccessoryListComponent
   */
  getUnitNameList() {
    this.mastersSerive.getUnits().subscribe({
      next: (res: any) => {
        this.uintNameList = res?.result;
      },
      error: (err: any) => {
        this.uintNameList = [];
      },
    });
  }
}
