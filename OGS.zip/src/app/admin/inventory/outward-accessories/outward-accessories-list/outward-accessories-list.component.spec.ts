import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OutwardAccessoriesListComponent } from './outward-accessories-list.component';

describe('OutwardAccessoriesListComponent', () => {
  let component: OutwardAccessoriesListComponent;
  let fixture: ComponentFixture<OutwardAccessoriesListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OutwardAccessoriesListComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(OutwardAccessoriesListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
