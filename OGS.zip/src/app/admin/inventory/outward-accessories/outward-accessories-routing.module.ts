import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { OutwardAccessoriesComponent } from "./outward-accessories.component";
import { OutwardAccessoriesListComponent } from "./outward-accessories-list/outward-accessories-list.component";
import { EditOutwardAccessoriesComponent } from "./edit-outward-accessories/edit-outward-accessories.component";
import { AddOutwardAccessoriesComponent } from "./add-outward-accessories/add-outward-accessories.component";

const routes: Routes = [
  {
    path: "",
    component: OutwardAccessoriesComponent,
    children: [
      { path: "", redirectTo: "outwardaccessorieslist", pathMatch: "full" },
      {
        path: "addoutwardaccessorie",
        component: AddOutwardAccessoriesComponent,
      },
      {
        path: "editoutwardaccessorie",
        component: EditOutwardAccessoriesComponent,
      },
      {
        path: "outwardaccessorieslist",
        component: OutwardAccessoriesListComponent,
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class OutwardAccessoriesRoutingModule {}
