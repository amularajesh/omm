import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";

import { InventoryRoutingModule } from "./inventory-routing.module";
import { InventoryComponent } from "./inventory.component";
import { InwardAccessoriesComponent } from "./inward-accessories/inward-accessories.component";
import { InwardFabricComponent } from "./inward-fabric/inward-fabric.component";
import { OutwardAccessoriesComponent } from "./outward-accessories/outward-accessories.component";
import { OutwardFabricComponent } from "./outward-fabric/outward-fabric.component";
import { Ng2SearchPipeModule } from "ng2-search-filter";

import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { MatTooltipModule } from "@angular/material/tooltip";
import { NgSelectModule } from "@ng-select/ng-select";
import { ComponentModule } from "src/app/core/Modules/component.module";
import { NgxPaginationModule } from "ngx-pagination";
import { BsDatepickerModule } from "ngx-bootstrap/datepicker";
import { OrderModule } from "ngx-order-pipe";

/**
 * Inventory Module
 * @export
 * @class InventoryModule
 */
@NgModule({
  declarations: [
    InventoryComponent,
    InwardFabricComponent,
    OutwardFabricComponent,
    InwardAccessoriesComponent,
    OutwardAccessoriesComponent,
  ],
  imports: [
    CommonModule,
    InventoryRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    MatTooltipModule,
    OrderModule,
    NgSelectModule,
    ComponentModule,
    NgxPaginationModule,
    Ng2SearchPipeModule,
    BsDatepickerModule.forRoot(),
  ],
})
export class InventoryModule {}
