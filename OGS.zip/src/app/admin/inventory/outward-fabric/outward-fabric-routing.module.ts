import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { OutwardFabricComponent } from "./outward-fabric.component";
import { AddOutwardFabricComponent } from "./add-outward-fabric/add-outward-fabric.component";
import { EditOutwardFabricComponent } from "./edit-outward-fabric/edit-outward-fabric.component";
import { OutwardFabricListComponent } from "./outward-fabric-list/outward-fabric-list.component";

const routes: Routes = [
  {
    path: "",
    component: OutwardFabricComponent,
    children: [
      { path: "", redirectTo: "outwardfabriclist", pathMatch: "full" },
      { path: "addoutwardfabric", component: AddOutwardFabricComponent },
      { path: "editoutwardfabric", component: EditOutwardFabricComponent },
      { path: "outwardfabriclist", component: OutwardFabricListComponent },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class OutwardFabricRoutingModule {}
