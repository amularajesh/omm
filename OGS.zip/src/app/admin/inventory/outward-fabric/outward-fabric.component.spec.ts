import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OutwardFabricComponent } from './outward-fabric.component';

describe('OutwardFabricComponent', () => {
  let component: OutwardFabricComponent;
  let fixture: ComponentFixture<OutwardFabricComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OutwardFabricComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(OutwardFabricComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
