import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";

import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { BsDatepickerModule } from "ngx-bootstrap/datepicker";
import { NgxPaginationModule } from "ngx-pagination";
import { ComponentModule } from "src/app/core/Modules/component.module";
import { OrderModule } from "ngx-order-pipe";
import { MatTooltipModule } from "@angular/material/tooltip";
import { OutwardFabricRoutingModule } from "./outward-fabric-routing.module";
import { AddOutwardFabricComponent } from './add-outward-fabric/add-outward-fabric.component';
import { EditOutwardFabricComponent } from './edit-outward-fabric/edit-outward-fabric.component';
import { OutwardFabricListComponent } from './outward-fabric-list/outward-fabric-list.component';
import { NgMultiSelectDropDownModule } from "ng-multiselect-dropdown";

@NgModule({
  declarations: [
    AddOutwardFabricComponent,
    EditOutwardFabricComponent,
    OutwardFabricListComponent
  ],
  imports: [
    CommonModule,
    OutwardFabricRoutingModule,
    FormsModule,
    MatTooltipModule,
    ReactiveFormsModule,
    NgxPaginationModule,
    ComponentModule,
    OrderModule,
    BsDatepickerModule.forRoot(),
    NgMultiSelectDropDownModule,
  ],
})
export class OutwardFabricModule {}
