import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-outward-fabric',
  templateUrl: './outward-fabric.component.html',
  styleUrls: ['./outward-fabric.component.scss']
})
export class OutwardFabricComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
