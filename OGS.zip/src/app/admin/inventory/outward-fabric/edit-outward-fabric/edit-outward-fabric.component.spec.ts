import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditOutwardFabricComponent } from './edit-outward-fabric.component';

describe('EditOutwardFabricComponent', () => {
  let component: EditOutwardFabricComponent;
  let fixture: ComponentFixture<EditOutwardFabricComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EditOutwardFabricComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EditOutwardFabricComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
