import { DatePipe, Location } from "@angular/common";
import { Component, OnInit, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";

import { SnackbarModalComponent } from "src/app/core/Dialogues/snackbar-modal/snackbar-modal.component";
import { InventoryService } from "src/app/core/Services/inventory.service";
import { LoaderService } from "src/app/core/Services/loader.service";
import { MastersService } from "src/app/core/Services/masters.service";
import { ValidationService } from "src/app/core/Services/validation.service";

@Component({
  selector: "app-edit-outward-fabric",
  templateUrl: "./edit-outward-fabric.component.html",
  styleUrls: ["./edit-outward-fabric.component.scss"],
})
export class EditOutwardFabricComponent implements OnInit {
  /**
   * Get Snackbar Modal Component
   * @type {SnackbarModalComponent}
   */
  @ViewChild("snackbarModalComponent") snackbarModalComponent!: SnackbarModalComponent;

  isDisable: boolean = true;
  cuttingNo: any;
  show: boolean = false;
  /**
   *Var declared to store available quantity
   * @type {any[]}
   *
    @type {}
   * @memberof AddOutwardFabricComponent
   */
  availabelQualntity: any;
  totalQty: any;

  editOutwardFabricDetails: any;
  /**
   *Var declared to store data of fabrics on click od edit button
   * @type {any[]}
   * @memberof editOutwardFabricComponent
   */
  localOutwardFabricList: any[] = [];
  localOutwardFabricDeleteList: any[] = [];

  /**
   *
   *Var declared to store data of fabrics COlors list
   * @type {any[]}
   * @memberof editOutwardFabricComponent
   */
  OutwardFabricColorList: any[] = [];
  colourName: any;
  /**
   *
   *Var declared to store data of fabrics quality list
   * @type {any[]}
   * @memberof editOutwardFabricComponent
   */
  OutwardFabricQualityList: any[] = [];
  qualiyName: any;

  /**
   *
   *Var declared to store data of fabrics quality list
   * @type {any[]}
   * @memberof AddOutwardFabricComponent
   */
  OutwardFabricCuttingNumberList: any[] = [];

  /**
   * Default Sorting Key
   */
  sortingKeyColumn = "quality";

  /**
   * Default Sort Order
   */
  sortingOrder = true;
  /**
   * Default Page Number
   */
  currentPage = 1;

  /**
   *Declaring Var To store Outward fabric min date.
   *
   * @type {*}
   * @memberof OutwardFabricListComponent
   */
  OutwardFabricMinDate: Date;
  OutwardFabricMaxDate: Date | undefined;
  mindate: Date | undefined;
  /**
   *Declaring Var To store Outward fabric list.
   * @type {*}
   * @memberof OutwardFabricListComponent
   */
  OutwardFabricList: any[] = [];

  OutwardTypeName: any;

  /**
   *Declaring var to store records length
   * @type {*}
   * @memberof OutwardFabricListComponent
   */
  recordsCount = 0;

  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private validationService: ValidationService,
    private datePipe: DatePipe,
    private inventory: InventoryService,
    private mastersSerive: MastersService,
    private loaderService: LoaderService,
    private location: Location
  ) {
    this.OutwardFabricMinDate = new Date();
    this.inventory.outwardFabric?.subscribe((res: any) => {
      this.editOutwardFabricDetails = res;
      this.localOutwardFabricList = res?.outwardFabricList;
      for (let index = 0; index < this.localOutwardFabricList?.length; index++) {
        const element = this.localOutwardFabricList[index];
        element.isFromBackEnd = true;
      }
      this.recordsCount = this.localOutwardFabricList?.length;
      this.mindate = new Date("2000-01-01");
    });
  }

  /**
   * Declaring OutwardFabric search Form
   * @type {FormGroup}
   * @memberof OutwardFabricListComponent
   */
  editOutwardFabricForm!: FormGroup;

  /**
   * Get Outward fabric search Form Validations
   */
  editOutwardFabricValidation = this.validationService?.addOutwardFabric;
  editOutwardFabricValidationPattern = this.validationService?.patterns;

  ngOnInit(): void {
    this.editOutwardFabricFormValiadation();
    this.OutwardFabricMinDate = new Date(this.editOutwardFabricDetails?.date);
    this.OutwardFabricMaxDate = new Date();

    this.getCuttongNo();
    this.getQualities();
  }

  /**
   *This Method for intialize form validations
   *
   * @memberof EditOutwardFabricComponent
   */
  editOutwardFabricFormValiadation() {
    console.log(this.editOutwardFabricDetails, "cutting edit");

    this.cuttingNo = this.editOutwardFabricDetails?.cuttingNo;
    this.editOutwardFabricForm = this.formBuilder.group({
      cuttingNo: [
        String(this.editOutwardFabricDetails?.cuttingNo) || "",
        [Validators.required],
      ],

      quality: ["", [Validators.required]],
      colour: ["", [Validators.required]],
      Date: [
        new Date(this.editOutwardFabricDetails?.date) || "",
        [Validators.required],
      ],
      quantity: [
        "",
        [
          Validators.required,
          Validators.minLength(
            this.editOutwardFabricValidation?.quantity?.minLength
          ),
          Validators.maxLength(
            this.editOutwardFabricValidation?.quantity?.maxLength
          ),
          Validators.pattern(this.editOutwardFabricValidationPattern?.quantity),
        ],
      ],
      consumed: [
        "",
        [
          Validators.required,
          Validators.minLength(
            this.editOutwardFabricValidation?.consumed?.minLength
          ),
          Validators.maxLength(
            this.editOutwardFabricValidation?.consumed?.maxLength
          ),
          Validators.pattern(this.editOutwardFabricValidationPattern?.quantity),
        ],
      ],
      sNo: [this.editOutwardFabricDetails?.factsno, [Validators.required]]
    });
  }

  /**
   * OutwardSearch Controls Initialized
   * @readonly
   */
  get editOutwardFabricFormControls() {
    return this.editOutwardFabricForm.controls;
  }

  /**
   *This method fired on chage of to date
   *
   * @param {*} event
   * @memberof OutwardFabricListComponent
   */
  ToDateChange(event: any) { }

  /**
   *This method fired on click of Delete icon
   *
   * @param {*} fabric
   * @memberof OutwardFabricListComponent
   */
  onClickDeleteOutwardFabric(fabric: any, i: any) {
    this.show = false;
    this.availabelQualntity = 0;
    this.localOutwardFabricList.splice(i - 1, 1);
    if (fabric.isFromBackEnd) {
      this.localOutwardFabricDeleteList.push(fabric);
    }

    this.editOutwardFabricFormControls["colour"]?.setValue("");
    this.editOutwardFabricFormControls["colour"]?.markAsUntouched({
      onlySelf: true,
    });
  }

  /**
   *This method fired on click of pagination
   *
   * @memberof OutwardFabricListComponent
   */
  onPageChange(event: any) { this.currentPage = event; }

  /**
   * This Method Used To Navigate  Outward fabric List page.
   * @param {*} event
   * @memberof OutwardFabricListComponent
   */
  navigate(event: any) {
    this.router.navigate(["/admin/inventory/outwardfabric/outwardfabriclist"]);
  }

  /**
   * This Method Used To Navigate edit Outward fabric page.
   * @param {*} event
   * @memberof OutwardFabricListComponent
   */
  navigateToEditOutwardFabric(event: any) {
    this.router.navigate(["/admin/inventory/outwardfabric/editoutwardfabric"]);
  }

  /**
   * This method is used to sort column
   * @param key : value of which column based we need to sort the rows
   */
  sort(key: string) {
    const componentName = this.location.path();
    let value = key;
    sessionStorage.setItem(`${componentName}_property`, value);
    this.sortingKeyColumn = key;
    if (sessionStorage.getItem(componentName + "_order") == "desc") {
      this.sortingOrder = false;
    } else {
      this.sortingOrder = true;
    }
  }

  /**
   *This method fired on submit
   *
   * @param {*} event
   * @memberof OutwardFabricListComponent
   */
  submit(event: any) {
    this.editOutwardFabricFormControls["quality"].setValidators(null);
    this.editOutwardFabricFormControls["quality"].updateValueAndValidity();

    this.editOutwardFabricFormControls["colour"].setValidators(null);
    this.editOutwardFabricFormControls["colour"].updateValueAndValidity();

    this.editOutwardFabricFormControls["quantity"].setValidators(null);
    this.editOutwardFabricFormControls["quantity"].updateValueAndValidity();
    this.editOutwardFabricFormControls["consumed"].setValidators(null);
    this.editOutwardFabricFormControls["consumed"].updateValueAndValidity();
    let newArray = this.localOutwardFabricList.map((obj) => {
      // Create a shallow copy of the object to avoid modifying the original
      let newObj = { ...obj };

      // Remove the specified key from the object
      delete newObj["isFromBackend"];
      return newObj;
    });
    const finalObj = {
      outwardFabricId: this.editOutwardFabricDetails?.outwardFabricId,
      cuttingNos: this.cuttingNo || 0,
      date:
        this.datePipe.transform(
          this.editOutwardFabricFormControls["Date"].value || "",
          "yyyy-MM-dd"
        ) || "",
      userId: 0,
      outwardFabricList: newArray,
      Factsno: this.editOutwardFabricFormControls["sNo"].value || "",
    };

    this.inventory.EditOutwardFabric(finalObj).subscribe({
      next: (res: any) => {
        /* Disable the loader if response is success*/
        this.loaderService.isLoading.next(false);
        this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', 'outwardFabric');
      },
      error: (err: any) => {
        /* Disable the loader if response is error */
        this.loaderService.isLoading.next(false);

        this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message ||err , '', '', '');
      },
    });
  }

  /**
   *This method fired on click of reset
   *
   * @param {*} event
   * @memberof OutwardFabricListComponent
   */
  reset(event: any) {
    // this.editOutwardFabricForm.reset();
    // this.editOutwardFabricFormValiadation();
    this.navigate(event);
  }

  /**
   *This method fired on click of exportToWord
   *
   * @param {*} event
   * @memberof OutwardFabricListComponent
   */
  ExportToWord(event: any) { }

  /**
   *This method fired on click edit button
   * @param {*} event
   * @memberof editOutwardFabricComponent
   */
  LocalSave(event: any) {
    console.log(this.editOutwardFabricFormControls);

    this.editOutwardFabricFormControls["quality"].setValidators([
      Validators.required,
    ]);
    this.editOutwardFabricFormControls["quality"].updateValueAndValidity();

    this.editOutwardFabricFormControls["colour"].setValidators([
      Validators.required,
    ]);
    this.editOutwardFabricFormControls["colour"].updateValueAndValidity();

    this.editOutwardFabricFormControls["quantity"].setValidators([
      Validators.required,
      Validators.minLength(
        this.editOutwardFabricValidation?.quantity?.minLength
      ),
      Validators.maxLength(
        this.editOutwardFabricValidation?.quantity?.maxLength
      ),
      Validators.pattern(this.editOutwardFabricValidationPattern?.quantity),
    ]);
    this.editOutwardFabricFormControls["quantity"].updateValueAndValidity();

    this.editOutwardFabricFormControls["consumed"].setValidators([
      Validators.required,
      Validators.minLength(
        this.editOutwardFabricValidation?.consumed?.minLength
      ),
      Validators.maxLength(
        this.editOutwardFabricValidation?.consumed?.maxLength
      ),
      Validators.pattern(this.editOutwardFabricValidationPattern?.quantity),
    ]);
    this.editOutwardFabricFormControls["consumed"].updateValueAndValidity();
    /** This will return false if form fields are invalid and stop the service calling */
    if (this.editOutwardFabricForm.invalid) {
      this.validationService.validateAllFormFields(this.editOutwardFabricForm);
      return;
    }
    //preparing obj
    const localObj = {
      qualityId:
        Number(this.editOutwardFabricFormControls["quality"].value) || "",
      quality: this.qualiyName || "",
      colorId: Number(this.editOutwardFabricFormControls["colour"].value) || "",
      colour: this.colourName || "",
      quantity: this.editOutwardFabricFormControls["quantity"].value || "",
      consumed: this.editOutwardFabricFormControls["consumed"].value || "",
      status: 0,
      isFromBackEnd: false,
    };

    // checking duplicates if both quality and color match
    if (this.localOutwardFabricList.length > 0) {
      for (const item of this.localOutwardFabricDeleteList) {
        console.log(item);
        if (
          Number(localObj["qualityId"]) === item["qualityId"] &&
          Number(localObj["colorId"]) === item["colourId"]
        ) {
          this.localOutwardFabricDeleteList.splice(
            item[Number(localObj["colorId"])],
            1
          );
        }
      }
      for (const item of this.localOutwardFabricList) {
        if (Number(localObj?.consumed) > this.availabelQualntity) {
          this.snackbarModalComponent.onOpenSnackbarModal(false, `Available Quantity is ${this.availabelQualntity.toFixed(3)} Kgs`, '', '', '');
          return;
        } else {
          for (const item of this.localOutwardFabricList) {
            if (
              localObj["quality"] === item["quality"] &&
              localObj["colour"] === item["colour"]
            ) {
              this.snackbarModalComponent.onOpenSnackbarModal(false, "Record Already Exists", '', '', '');
              return;
            }
          }
        }
      }
      this.localOutwardFabricList.push(localObj);
      this.recordsCount = this.localOutwardFabricList?.length;
      this.show = false;
      // this.reset(event);

      this.editOutwardFabricFormControls["quality"]?.setValue("");
      this.editOutwardFabricFormControls["quality"]?.markAsUntouched({
        onlySelf: true,
      });

      this.editOutwardFabricFormControls["colour"]?.setValue("");
      this.editOutwardFabricFormControls["colour"]?.markAsUntouched({
        onlySelf: true,
      });

      this.editOutwardFabricFormControls["quantity"]?.setValue("");
      this.editOutwardFabricFormControls["quantity"]?.markAsUntouched({
        onlySelf: true,
      });
      this.editOutwardFabricFormControls["consumed"]?.setValue("");
      this.editOutwardFabricFormControls["consumed"]?.markAsUntouched({
        onlySelf: true,
      });
      for (let i = 0; i < this.localOutwardFabricDeleteList.length; i++) {
        const item = this.localOutwardFabricDeleteList[i];

        if (
          Number(localObj["qualityId"]) === item["qualityId"] &&
          Number(localObj["colorId"]) === item["colorId"]
        ) {
          // Remove the item from the array
          this.localOutwardFabricDeleteList.splice(i, 1);
          // Decrement the loop variable to account for the removed item
        }
      }
      this.totalQty = this.availabelQualntity;
      console.log(this.localOutwardFabricList);
    } else {
      if (Number(localObj?.consumed) > this.availabelQualntity) {
        this.snackbarModalComponent.onOpenSnackbarModal(false, `Available Quantity is ${this.availabelQualntity.toFixed(3)} Kgs`, '', '', '');
        return;
      }
      this.localOutwardFabricList.push(localObj);
      this.show = false;

      this.recordsCount = this.localOutwardFabricList?.length;
      // this.reset(event);

      this.editOutwardFabricFormControls["quality"]?.setValue("");
      this.editOutwardFabricFormControls["quality"]?.markAsUntouched({
        onlySelf: true,
      });

      this.editOutwardFabricFormControls["colour"]?.setValue("");
      this.editOutwardFabricFormControls["colour"]?.markAsUntouched({
        onlySelf: true,
      });

      this.editOutwardFabricFormControls["quantity"]?.setValue("");
      this.editOutwardFabricFormControls["quantity"]?.markAsUntouched({
        onlySelf: true,
      });
      this.editOutwardFabricFormControls["consumed"]?.setValue("");
      this.editOutwardFabricFormControls["consumed"]?.markAsUntouched({
        onlySelf: true,
      });
    }
  }

  /**
   *This Method for get Colours
   *
   * @memberof InwardFabricListComponent
   */
  getColours() {
    this.mastersSerive.getColours().subscribe({
      next: (res: any) => {
        this.OutwardFabricColorList = res?.result;
      },
      error: (err: any) => {
        this.OutwardFabricColorList = [];
      },
    });
  }

  /**
   *This Method for get cuttingNo List
   *
   * @memberof InwardFabricListComponent
   */
  getCuttongNo() {
    this.inventory.getOutwardFabricCutttingNoList().subscribe({
      next: (res: any) => {
        this.OutwardFabricCuttingNumberList = res?.result;
      },
      error: (err: any) => {
        this.OutwardFabricCuttingNumberList = [];
      },
    });
  }

  /**
   *This Method for get Qualities
   *
   * @memberof InwardFabricListComponent
   */
  getQualities() {
    this.inventory.getInwardFabicQualities().subscribe({
      next: (res: any) => {
        this.OutwardFabricQualityList = res?.result;
      },
      error: (err: any) => {
        this.OutwardFabricQualityList = [];
      },
    });
  }

  /**
   *This Method fired on Change of Colour
   * @param {*} event
   * @memberof AddOutwardFabricComponent
   */
  colourChange(event: any) {
    //prepare obj to get quantity
    const obj = {
      qualityId: this.editOutwardFabricFormControls["quality"].value,
      colourId: this.editOutwardFabricFormControls["colour"].value,
      date: this.datePipe.transform(
        this.editOutwardFabricFormControls["Date"].value || "",
        "yyyy-MM-dd"
      ),
    };
    this.inventory.getOutwardFabricQuantity(obj).subscribe({
      next: (res: any) => {
        if (this.localOutwardFabricList.length > 0) {
          //deletelist greater to zero
          if (this.localOutwardFabricDeleteList.length > 0) {
            for (const item of this.localOutwardFabricDeleteList) {
              if (
                Number(obj["qualityId"]) === item["qualityId"] &&
                Number(obj["colourId"]) === item["colorId"] &&
                item["isFromBackEnd"]
              ) {
                this.availabelQualntity =
                  res?.result?.availableQty + Number(item["consumed"]);
                this.show = true;
                this.totalQty = this.availabelQualntity;
              }
            }
          } else {
            //when no data in deleted array
            for (const item of this.localOutwardFabricList) {
              if (
                Number(obj["qualityId"]) === item["qualityId"] &&
                Number(obj["colourId"]) === item["colorId"] &&
                item["isFromBackEnd"]
              ) {
                this.availabelQualntity = res?.result?.availableQty;
                this.show = true;
                console.log(this.totalQty);
                console.log(this.availabelQualntity);
                break;
              } else if (
                Number(obj["qualityId"]) === item["qualityId"] &&
                Number(obj["colourId"]) === item["colorId"] &&
                !item["isFromBackEnd"]
              ) {
                console.log(item["isFromBackEnd"]);

                this.availabelQualntity =
                  this.totalQty - Number(item["consumed"]);
                this.show = true;
                console.log(this.totalQty);
                console.log(this.availabelQualntity);
                break;
              } else {
                this.availabelQualntity = res?.result?.availableQty;
                this.show = true;
                console.log(this.totalQty);
                console.log(this.availabelQualntity);
              }
            }
          }
        } else {
          this.availabelQualntity = res?.result?.availableQty;
          this.show = true;
        }
      },
      error: (err: any) => {
        this.availabelQualntity = "";
        this.show = false;
      },
    });
    for (const item of this.OutwardFabricColorList) {
      if (item?.colourId === event.target.value) {
        this.colourName = item?.colourName;
      }
    }
  }

  /**
   *This method fired on chage of from date
   *
    @param {} event
   * @memberof OutwardFabricListComponent
   */
  DateChange(newValue: any) {
    if (this.editOutwardFabricFormControls["colour"].value) {
      const obj = {
        qualityId: this.editOutwardFabricFormControls["quality"].value,
        colourId: this.editOutwardFabricFormControls["colour"].value,
        date: this.datePipe.transform(
          this.editOutwardFabricFormControls["Date"].value || "",
          "yyyy-MM-dd"
        ),
      };
      this.inventory.getOutwardFabricQuantity(obj).subscribe({
        next: (res: any) => {
          if (this.localOutwardFabricList.length > 0) {
            //delelist greater to zero
            if (this.localOutwardFabricDeleteList.length > 0) {
              for (const item of this.localOutwardFabricDeleteList) {
                if (
                  Number(obj["qualityId"]) === item["qualityId"] &&
                  Number(obj["colourId"]) === item["colorId"] &&
                  item["isFromBackEnd"]
                ) {
                  this.availabelQualntity =
                    res?.result?.availableQty + Number(item["consumed"]);
                  this.show = true;
                  this.totalQty = this.availabelQualntity;
                  console.log(this.totalQty);
                  console.log(this.availabelQualntity);
                }
              }
            } else {
              //when no data in deleted array
              for (const item of this.localOutwardFabricList) {
                if (
                  Number(obj["qualityId"]) === item["qualityId"] &&
                  Number(obj["colourId"]) === item["colorId"] &&
                  item["isFromBackEnd"]
                ) {
                  this.availabelQualntity = res?.result?.availableQty;
                  this.show = true;
                  console.log(this.totalQty);
                  console.log(this.availabelQualntity);
                  break;
                } else if (
                  Number(obj["qualityId"]) === item["qualityId"] &&
                  Number(obj["colourId"]) === item["colorId"] &&
                  !item["isFromBackEnd"]
                ) {
                  console.log(item["isFromBackEnd"]);

                  this.availabelQualntity =
                    this.totalQty - Number(item["consumed"]);
                  this.show = true;
                  break;
                } else {
                  this.availabelQualntity = res?.result?.availableQty;
                  this.show = true;
                }
              }
            }
          } else {
            this.availabelQualntity = res?.result?.availableQty;
            this.show = true;
          }
        },
        error: (err: any) => {
          this.availabelQualntity = "";
          this.show = false;
        },
      });
    }
  }

  /**
   *This Method fired on Change of quality
   * @param {*} event
   * @memberof AddOutwardFabricComponent
   */
  qualityChange(event: any) {
    this.OutwardFabricColorList = [];
    this.editOutwardFabricFormControls["colour"]?.setValue("");
    this.editOutwardFabricFormControls["colour"]?.markAsUntouched({
      onlySelf: true,
    });
    this.getColours();
    this.availabelQualntity = 0;

    for (const item of this.OutwardFabricQualityList) {
      console.log(typeof item?.qualityId);

      if (item?.qualityId === Number(event.target.value)) {
        this.qualiyName = item?.qualityName;
        console.log(this.qualiyName, "qualityName");
      }
    }
  }
}
