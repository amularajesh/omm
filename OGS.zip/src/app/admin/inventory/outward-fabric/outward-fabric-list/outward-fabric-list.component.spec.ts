import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OutwardFabricListComponent } from './outward-fabric-list.component';

describe('OutwardFabricListComponent', () => {
  let component: OutwardFabricListComponent;
  let fixture: ComponentFixture<OutwardFabricListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OutwardFabricListComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(OutwardFabricListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
