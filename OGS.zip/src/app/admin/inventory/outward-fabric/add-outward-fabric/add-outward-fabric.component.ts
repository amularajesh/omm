import { DatePipe, Location } from "@angular/common";
import { Component, OnInit, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";

import { SnackbarModalComponent } from "src/app/core/Dialogues/snackbar-modal/snackbar-modal.component";
import { InventoryService } from "src/app/core/Services/inventory.service";
import { LoaderService } from "src/app/core/Services/loader.service";
import { MastersService } from "src/app/core/Services/masters.service";
import { ValidationService } from "src/app/core/Services/validation.service";

/**
 * Add Outward Fabric Component
 * @export
 * @class AddOutwardFabricComponent
 * @implements {OnInit}
 */
@Component({
  selector: "app-add-outward-fabric",
  templateUrl: "./add-outward-fabric.component.html",
  styleUrls: ["./add-outward-fabric.component.scss"],
})
export class AddOutwardFabricComponent implements OnInit {
  /**
   * Get Snackbar Modal Component
   * @type {SnackbarModalComponent}
   */
  @ViewChild("snackbarModalComponent") snackbarModalComponent!: SnackbarModalComponent;

  /**
   * Dropdown settings for Order List
   */
  dropdownSettingsForCuttingNosList = {
    idField: 'cuttingProgramId',
    textField: 'cpNo',
    // itemsShowLimit: 2,
    allowSearchFilter: true,
    clearSearchFilter: true,
    enableCheckAll: false,
    defaultOpen: false,
  };

  /**
   * Selected Cutting Nos
   * @type {*}
   */
  selectedCuttingNos: any = [];

  show: boolean = false;
  /**
   *Var declared to store available quantity
   * @type {any[]}
   *
    @type {}
   * @memberof AddOutwardFabricComponent
   */
  availabelQualntity: any;
  /**
   *Var declared to store data of fabrics on click od add button
   * @type {any[]}
   * @memberof AddOutwardFabricComponent
   */
  localOutwardFabricList: any[] = [];

  /**
   *
   *Var declared to store data of fabrics COlors list
   * @type {any[]}
   * @memberof AddOutwardFabricComponent
   */
  OutwardFabricColorList: any[] = [];
  colourName: any;

  /**
   *
   *Var declared to store data of fabrics quality list
   * @type {any[]}
   * @memberof AddOutwardFabricComponent
   */
  OutwardFabricQualityList: any[] = [];
  qualiyName: any;

  /**
   *
   *Var declared to store data of fabrics cuttingNo list
   * @type {any[]}
   * @memberof AddOutwardFabricComponent
   */
  OutwardFabricCuttingNumberList: any[] = [];
  cuttingNo: any;

  /**
   * Default Sorting Key
   */
  sortingKeyColumn = "userId";

  /**
   * Default Sort Order
   */
  sortingOrder = true;

  /**
   * Default Page Number
   */
  currentPage = 1;

  /**
   *Declaring Var To store Outward fabric min date.
   *
   * @type {*}
   * @memberof OutwardFabricListComponent
   */
  OutwardFabricMinDate: Date;
  mindate: Date;

  /**
   *Declaring var to store records length
   * @type {*}
   * @memberof OutwardFabricListComponent
   */
  recordsCount = 0;

  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private validationService: ValidationService,
    private datePipe: DatePipe,
    private mastersSerive: MastersService,
    private loaderService: LoaderService,
    private inventory: InventoryService,
    private location: Location
  ) {
    this.OutwardFabricMinDate = new Date();
    this.mindate = new Date("2000-01-01");
  }

  /**
   * Declaring OutwardFabric search Form
   * @type {FormGroup}
   * @memberof OutwardFabricListComponent
   */
  addOutwardFabricSearchForm!: FormGroup;

  /**
   * Get Outward fabric search Form Validations
   */
  addOutwardFabricSearchValidation = this.validationService?.addOutwardFabric;
  addOutwardFabricSearchValidationPattern = this.validationService?.patterns;

  ngOnInit(): void {
    this.addOutwardFabricSearchFormValiadation();
    this.getCuttongNo();
    // this.getColours();
    this.getQualities();
  }

  /**
   *This Method for intializing form Validations
   *
   * @memberof AddOutwardFabricComponent
   */
  addOutwardFabricSearchFormValiadation() {
    this.addOutwardFabricSearchForm = this.formBuilder.group({
      cuttingNo: ["", [Validators.required]],
      quality: ["", [Validators.required]],
      colour: ["", [Validators.required]],
      Date: ["", [Validators.required]],
      quantity: [
        "",
        [
          Validators.required,
          Validators.minLength(
            this.addOutwardFabricSearchValidation?.quantity?.minLength
          ),
          Validators.maxLength(
            this.addOutwardFabricSearchValidation?.quantity?.maxLength
          ),
          Validators.pattern(
            this.addOutwardFabricSearchValidationPattern?.quantity
          ),
        ],
      ],
      consumed: [
        "",
        [
          Validators.required,
          Validators.minLength(
            this.addOutwardFabricSearchValidation?.consumed?.minLength
          ),
          Validators.maxLength(
            this.addOutwardFabricSearchValidation?.consumed?.maxLength
          ),
          Validators.pattern(
            this.addOutwardFabricSearchValidationPattern?.quantity
          ),
        ],
      ],
      sNo: ['', [Validators.required]]
    });
  }

  /**
   * OutwardSearch Controls Initialized
   * @readonly
   */
  get addOutwardFabricSearchFormControls() {
    return this.addOutwardFabricSearchForm.controls;
  }
  /**
   *This method fired on chage of to date
   *
   * @param {*} event
   * @memberof OutwardFabricListComponent
   */
  ToDateChange(event: any) { }

  /**
   *This method fired on click of Delete icon
   *
   * @param {*} fabric
   * @memberof OutwardFabricListComponent
   */
  onClickDeleteOutwardFabric(fabric: any, i: any) {
    this.show = false;
    this.localOutwardFabricList.splice(i - 1, 1);
  }

  /**
   *This method fired on click of pagination
   *
   * @memberof OutwardFabricListComponent
   */
  onPageChange(event: any) { this.currentPage = event; }

  /**
   * This Method Used To Navigate  Outward fabric List page.
   * @param {*} event
   * @memberof OutwardFabricListComponent
   */
  navigate(event: any) {
    this.router.navigate(["/admin/inventory/outwardfabric/outwardfabriclist"]);
  }

  /**
   * This Method Used To Navigate edit Outward fabric page.
   * @param {*} event
   * @memberof OutwardFabricListComponent
   */
  navigateToEditOutwardFabric(event: any) {
    this.router.navigate(["/admin/inventory/outwardfabric/editoutwardfabric"]);
  }

  /**
   * This method is used to sort column
   * @param key : value of which column based we need to sort the rows
   */
  sort(key: string) {
    const componentName = this.location.path();
    let value = key;
    sessionStorage.setItem(`${componentName}_property`, value);
    this.sortingKeyColumn = key;
    if (sessionStorage.getItem(componentName + "_order") == "desc") {
      this.sortingOrder = false;
    } else {
      this.sortingOrder = true;
    }
  }

  /**
   *This method fired on submit
   *
   * @param {*} event
   * @memberof OutwardFabricListComponent
   */
  submit(event: any) {
    this.addOutwardFabricSearchFormControls["quality"].setValidators(null);
    this.addOutwardFabricSearchFormControls["quality"].updateValueAndValidity();

    this.addOutwardFabricSearchFormControls["colour"].setValidators(null);
    this.addOutwardFabricSearchFormControls["colour"].updateValueAndValidity();

    this.addOutwardFabricSearchFormControls["quantity"].setValidators(null);
    this.addOutwardFabricSearchFormControls[
      "quantity"
    ].updateValueAndValidity();
    this.addOutwardFabricSearchFormControls["consumed"].setValidators(null);
    this.addOutwardFabricSearchFormControls[
      "consumed"
    ].updateValueAndValidity();
    /** This will return false if form fields are invalid and stop the service calling */
    if (this.addOutwardFabricSearchForm.invalid) {
      this.validationService.validateAllFormFields(
        this.addOutwardFabricSearchForm
      );
      return;
    }

    // Extract cpNo values into an array
    const cpNosArray = this.selectedCuttingNos.map((item: any) => item.cpNo);

    const finalObj = {
      outwardFabricId: 0,
      cuttingNos: cpNosArray.join(','),
      date: this.datePipe.transform(this.addOutwardFabricSearchFormControls["Date"].value || "", "yyyy-MM-dd") || "",
      userId: 0,
      outwardFabricList: this.localOutwardFabricList,
      Factsno: this.addOutwardFabricSearchFormControls["sNo"].value || "",
    };

    this.inventory.AddOutwardFabric(finalObj).subscribe({
      next: (res: any) => {
        /* Disable the loader if response is success*/
        this.loaderService.isLoading.next(false);
        this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', 'outwardFabric');
      },
      error: (err: any) => {
        /* Disable the loader if response is error */
        this.loaderService.isLoading.next(false);

        this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message || err, '', '', '');
      },
    });
  }

  /**
   *This method fired on click of reset
   *
   * @param {*} event
   * @memberof OutwardFabricListComponent
   */
  reset(event: any) {
    this.localOutwardFabricList = [];
    this.addOutwardFabricSearchForm.reset();
    this.addOutwardFabricSearchFormValiadation();
  }

  /**
   *This method fired on click of exportToWord
   *
   * @param {*} event
   * @memberof OutwardFabricListComponent
   */
  ExportToWord(event: any) { }

  /**
   *This method fired on click Add button
   * @param {*} event
   * @memberof AddOutwardFabricComponent
   */
  LocalSave(event: any) {
    this.addOutwardFabricSearchFormControls["quality"].setValidators([
      Validators.required,
    ]);
    this.addOutwardFabricSearchFormControls["quality"].updateValueAndValidity();

    this.addOutwardFabricSearchFormControls["colour"].setValidators([
      Validators.required,
    ]);
    this.addOutwardFabricSearchFormControls["colour"].updateValueAndValidity();

    this.addOutwardFabricSearchFormControls["quantity"].setValidators([
      Validators.required,
      Validators.minLength(
        this.addOutwardFabricSearchValidation?.quantity?.minLength
      ),
      Validators.maxLength(
        this.addOutwardFabricSearchValidation?.quantity?.maxLength
      ),
      Validators.pattern(
        this.addOutwardFabricSearchValidationPattern?.quantity
      ),
    ]);
    this.addOutwardFabricSearchFormControls[
      "quantity"
    ].updateValueAndValidity();

    this.addOutwardFabricSearchFormControls["consumed"].setValidators([
      Validators.required,
      Validators.minLength(
        this.addOutwardFabricSearchValidation?.consumed?.minLength
      ),
      Validators.maxLength(
        this.addOutwardFabricSearchValidation?.consumed?.maxLength
      ),
      Validators.pattern(this.addOutwardFabricSearchValidationPattern?.quantity),
    ]);
    this.addOutwardFabricSearchFormControls[
      "consumed"
    ].updateValueAndValidity();
    /** This will return false if form fields are invalid and stop the service calling */
    if (this.addOutwardFabricSearchForm.invalid) {
      this.validationService.validateAllFormFields(
        this.addOutwardFabricSearchForm
      );
      return;
    }

    //preparing obj
    const localObj = {
      qualityId:
        Number(this.addOutwardFabricSearchFormControls["quality"].value) || "",
      quality: this.qualiyName || "",
      colorId:
        Number(this.addOutwardFabricSearchFormControls["colour"].value) || "",
      colour: this.colourName || "",
      Quantity: this.addOutwardFabricSearchFormControls["quantity"].value || "",
      Consumed: this.addOutwardFabricSearchFormControls["consumed"].value || "",
      status: 0,
    };

    //checking duplicates if quality and color both match

    if (this.localOutwardFabricList.length > 0) {
      if (Number(localObj?.Consumed) > this.availabelQualntity) {
        this.snackbarModalComponent.onOpenSnackbarModal(false, `Available Quantity is ${this.availabelQualntity.toFixed(3)} Kgs`, '', '', '');
        return;
      } else {
        for (const item of this.localOutwardFabricList) {
          if (
            localObj["quality"] === item["quality"] &&
            localObj["colour"] === item["colour"]
          ) {
            this.snackbarModalComponent.onOpenSnackbarModal(false, "Record Already Exists", '', '', '');
            return;
          }
        }
      }

      this.localOutwardFabricList.push(localObj);
      this.recordsCount = this.localOutwardFabricList?.length;
      this.show = false;
      // this.reset(event);

      this.addOutwardFabricSearchFormControls["quality"]?.setValue("");
      this.addOutwardFabricSearchFormControls["quality"]?.markAsUntouched({
        onlySelf: true,
      });

      this.addOutwardFabricSearchFormControls["colour"]?.setValue("");
      this.addOutwardFabricSearchFormControls["colour"]?.markAsUntouched({
        onlySelf: true,
      });

      this.addOutwardFabricSearchFormControls["quantity"]?.setValue("");
      this.addOutwardFabricSearchFormControls["quantity"]?.markAsUntouched({
        onlySelf: true,
      });
      this.addOutwardFabricSearchFormControls["consumed"]?.setValue("");
      this.addOutwardFabricSearchFormControls["consumed"]?.markAsUntouched({
        onlySelf: true,
      });
    } else {
      if (Number(localObj?.Consumed) > this.availabelQualntity) {
        this.snackbarModalComponent.onOpenSnackbarModal(false, `Available Quantity is ${this.availabelQualntity.toFixed(3)} Kgs`, '', '', '');
        return;
      }
      this.localOutwardFabricList.push(localObj);
      this.recordsCount = this.localOutwardFabricList?.length;
      this.show = false;
      // this.reset(event);

      this.addOutwardFabricSearchFormControls["quality"]?.setValue("");
      this.addOutwardFabricSearchFormControls["quality"]?.markAsUntouched({
        onlySelf: true,
      });

      this.addOutwardFabricSearchFormControls["colour"]?.setValue("");
      this.addOutwardFabricSearchFormControls["colour"]?.markAsUntouched({
        onlySelf: true,
      });

      this.addOutwardFabricSearchFormControls["quantity"]?.setValue("");
      this.addOutwardFabricSearchFormControls["quantity"]?.markAsUntouched({
        onlySelf: true,
      });
      this.addOutwardFabricSearchFormControls["consumed"]?.setValue("");
      this.addOutwardFabricSearchFormControls["consumed"]?.markAsUntouched({
        onlySelf: true,
      });
    }
  }

  /**
   *This Method for get Colours
   *
   * @memberof InwardFabricListComponent
   */
  getColours() {
    this.mastersSerive.getColours().subscribe({
      next: (res: any) => {
        this.OutwardFabricColorList = res?.result;
      },
      error: (err: any) => {
        this.OutwardFabricColorList = [];
      },
    });
  }

  /**
   *This Method for get cuttingNo List
   *
   * @memberof InwardFabricListComponent
   */
  getCuttongNo() {
    this.inventory.getOutwardFabricCutttingNoList().subscribe({
      next: (res: any) => {
        this.OutwardFabricCuttingNumberList = res?.result;
      },
      error: (err: any) => {
        this.OutwardFabricCuttingNumberList = [];
      },
    });
  }

  /**
   *This Method for get Qualities
   *
   * @memberof InwardFabricListComponent
   */
  getQualities() {
    this.inventory.getInwardFabicQualities().subscribe({
      next: (res: any) => {
        this.OutwardFabricQualityList = res?.result;
      },
      error: (err: any) => {
        this.OutwardFabricQualityList = [];
      },
    });
  }

  /**
   *This Method fired on Change of Colour
    @param {} event
   * @memberof AddOutwardFabricComponent
   */
  colourChange(event: any) {
    //prepare obj to get quantity
    const obj = {
      qualityId: this.addOutwardFabricSearchFormControls["quality"].value,
      colourId: this.addOutwardFabricSearchFormControls["colour"].value,
      date: this.datePipe.transform(
        this.addOutwardFabricSearchFormControls["Date"].value || "",
        "yyyy-MM-dd"
      ),
    };
    this.inventory.getOutwardFabricQuantity(obj).subscribe({
      next: (res: any) => {
        if (this.localOutwardFabricList.length > 0) {
          for (const item of this.localOutwardFabricList) {
            if (
              Number(obj["qualityId"]) === item["qualityId"] &&
              Number(obj["colourId"]) === item["colorId"]
            ) {
              this.availabelQualntity =
                res?.result?.availableQty - item["Consumed"];
              this.show = true;
              break;
            } else {
              this.availabelQualntity = res?.result?.availableQty;

              this.show = true;
            }
          }
        } else {
          this.availabelQualntity = res?.result?.availableQty;
          this.show = true;
        }
      },
      error: (err: any) => {
        this.availabelQualntity = "";
        this.show = false;
      },
    });
    for (const item of this.OutwardFabricColorList) {
      if (item?.colourId === event.target.value) {
        this.colourName = item?.colourName;
      }
    }
  }

  /**
   *This method fired on chage of from date
   *
    @param {} event
   * @memberof OutwardFabricListComponent
   */
  DateChange(newValue: any) {
    if (this.addOutwardFabricSearchFormControls["colour"].value) {
      const obj = {
        qualityId: this.addOutwardFabricSearchFormControls["quality"].value,
        colourId: this.addOutwardFabricSearchFormControls["colour"].value,
        date: this.datePipe.transform(
          this.addOutwardFabricSearchFormControls["Date"].value || "",
          "yyyy-MM-dd"
        ),
      };
      this.inventory.getOutwardFabricQuantity(obj).subscribe({
        next: (res: any) => {
          if (this.localOutwardFabricList.length > 0) {
            for (const item of this.localOutwardFabricList) {
              if (
                Number(obj["qualityId"]) === item["qualityId"] &&
                Number(obj["colourId"]) === item["colorId"]
              ) {
                this.availabelQualntity =
                  res?.result?.availableQty - item["Consumed"];
                this.show = true;
                break;
              } else {
                this.availabelQualntity = res?.result?.availableQty;
                this.show = true;
              }
            }
          } else {
            this.availabelQualntity = res?.result?.availableQty;
            this.show = true;
          }
        },
        error: (err: any) => {
          this.availabelQualntity = "";
          this.show = false;
        },
      });
    }
  }

  /**
   *This Method fired on Change of quality
    @param {} event
   * @memberof AddOutwardFabricComponent
   */
  qualityChange(event: any) {
    this.OutwardFabricColorList = [];
    this.addOutwardFabricSearchFormControls["colour"]?.setValue("");
    this.addOutwardFabricSearchFormControls["colour"]?.markAsUntouched({
      onlySelf: true,
    });
    this.getColours();
    this.availabelQualntity = 0;
    for (const item of this.OutwardFabricQualityList) {
      if (item?.qualityId === Number(event.target.value)) {
        this.qualiyName = item?.qualityName;
      }
    }
  }
  /**
   *This Method fired on Change of quality
   * @param {*} event
   * @memberof AddOutwardFabricComponent
   */
  cuttingNoChange(event: any) {
    for (const item of this.OutwardFabricCuttingNumberList) {
      console.log(item);

      if (+item?.cuttingProgramId === +event.target.value) {
        this.cuttingNo = item?.cpNo;
      }
    }
  }

  /**
   * This method will fired when user selects the OrderNo
   * @param {*} item
   */
  onOrderSelect(item: any) {
    this.selectedCuttingNos.push(item);
    this.selectedCuttingNos = Array.from(
      this.selectedCuttingNos.reduce((m: any, t: any) => m.set(t.cuttingProgramId, t), new Map()).values()
    );
    console.log(this.selectedCuttingNos);

  }

  /**
   * This method will fired when user de-selects the OrderNo
   * @param {*} item
   */
  onOrderDeSelect(item: any) {
    for (let index = 0; index < this.selectedCuttingNos.length; index++) {
      if (this.selectedCuttingNos[index].cuttingProgramId == item.cuttingProgramId) {
        this.selectedCuttingNos.splice(index, 1); // 2nd parameter means remove one item only
      }
    }
    console.log(this.selectedCuttingNos);

  }
}
