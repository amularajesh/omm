import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddOutwardFabricComponent } from './add-outward-fabric.component';

describe('AddOutwardFabricComponent', () => {
  let component: AddOutwardFabricComponent;
  let fixture: ComponentFixture<AddOutwardFabricComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddOutwardFabricComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddOutwardFabricComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
