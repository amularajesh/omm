import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-inward-fabric',
  templateUrl: './inward-fabric.component.html',
  styleUrls: ['./inward-fabric.component.scss']
})
export class InwardFabricComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
