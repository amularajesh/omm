import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";

import { InwardFabricRoutingModule } from "./inward-fabric-routing.module";
import { AddInwardFabricComponent } from "./add-inward-fabric/add-inward-fabric.component";
import { EditInwardFabricComponent } from "./edit-inward-fabric/edit-inward-fabric.component";
import { InwardFabricListComponent } from "./inward-fabric-list/inward-fabric-list.component";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { BsDatepickerModule } from "ngx-bootstrap/datepicker";
import { NgxPaginationModule } from "ngx-pagination";
import { ComponentModule } from "src/app/core/Modules/component.module";
import { OrderModule } from "ngx-order-pipe";
import { MatTooltipModule } from "@angular/material/tooltip";

@NgModule({
  declarations: [
    AddInwardFabricComponent,
    EditInwardFabricComponent,
    InwardFabricListComponent,
  ],
  imports: [
    CommonModule,
    InwardFabricRoutingModule,
    FormsModule,
    MatTooltipModule,
    ReactiveFormsModule,
    NgxPaginationModule,
    ComponentModule,
    OrderModule,
    BsDatepickerModule.forRoot(),
  ],
})
export class InwardFabricModule {}
