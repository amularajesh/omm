import { DatePipe, Location } from "@angular/common";
import { Component, OnInit, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";

import { SnackbarModalComponent } from "src/app/core/Dialogues/snackbar-modal/snackbar-modal.component";
import { InventoryService } from "src/app/core/Services/inventory.service";
import { LoaderService } from "src/app/core/Services/loader.service";
import { MastersService } from "src/app/core/Services/masters.service";
import { ValidationService } from "src/app/core/Services/validation.service";

/**
 * Edit Inward Fabric Component
 * @export
 * @class EditInwardFabricComponent
 * @implements {OnInit}
 */
@Component({
  selector: "app-edit-inward-fabric",
  templateUrl: "./edit-inward-fabric.component.html",
  styleUrls: ["./edit-inward-fabric.component.scss"],
})
export class EditInwardFabricComponent implements OnInit {
  /**
   * Get Snackbar Modal Component
   * @type {SnackbarModalComponent}
   */
  @ViewChild("snackbarModalComponent") snackbarModalComponent!: SnackbarModalComponent;

  isDisabled = true;

  /**
   * Var declared to store data of fabrics on click od add button
   * @type {any[]}
   */
  localInwardFabricList: any[] = [];

  editIwardFabricDetails: any;

  /**
   *
   *Var declared to store data of fabrics COlors list
   * @type {any[]}
   * @memberof AddInwardFabricComponent
   */
  inwardFabricColorList: any[] = [];
  colourName: any;
  /**
   *
   *Var declared to store data of fabrics quality list
   * @type {any[]}
   * @memberof AddInwardFabricComponent
   */
  inwardFabricQualityList: any[] = [];
  qualiyName: any;

  /**
   *
   *Var declared to store data of Comapny list
   * @type {any[]}
   * @memberof AddInwardFabricComponent
   */
  inwardFabricCompanyList: any[] = [];
  comapanyName: any;

  /**
   * Default Sorting Key
   */
  sortingKeyColumn = "quality";

  /**
   * Default Sort Order
   */
  sortingOrder = true;
  /**
   * Default Page Number
   */
  currentPage = 1;

  /**
   *Declaring Var To store Inward fabric dates.
   *
   * @type {*}
   * @memberof InwardFabricListComponent
   */
  inwardFabricMinDate: Date;
  inwardFabricmaxDate: Date | undefined;
  mindate: Date | undefined;
  /**
   *Declaring Var To store Inward fabric list.
   * @type {*}
   * @memberof InwardFabricListComponent
   */
  inwardFabricList: any[] = [];

  inwardTypeName: any;

  /**
   *Declaring var to store records length
   * @type {*}
   * @memberof InwardFabricListComponent
   */
  recordsCount = 0;

  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private validationService: ValidationService,
    private datePipe: DatePipe,
    private inventory: InventoryService,
    private mastersSerive: MastersService,
    private loaderService: LoaderService,
    private location: Location
  ) {
    this.inwardFabricMinDate = new Date();
    this.mindate = new Date("2000-01-01");
    this.inventory.inwardFabric.subscribe((val: any) => {
      if (Object.keys(val).length > 0) {
        this.editIwardFabricDetails = val;
        this.localInwardFabricList = val?.inwardFabricList;
        this.recordsCount = this.localInwardFabricList?.length;
        console.log(this.editIwardFabricDetails, "fabric");
        console.log(this.localInwardFabricList, "fabric1");
      } else {
        this.navigate(event);
      }
    });
    // this.inventory.inwardFabric.subscribe((res: any) => {
    //   this.editIwardFabricDetails = res;
    //   this.localInwardFabricList = res?.inwardFabricList;
    //   this.recordsCount = this.localInwardFabricList?.length;
    //   console.log(this.editIwardFabricDetails, "fabric");
    //   console.log(this.localInwardFabricList, "fabric1");
    //   this.mindate = new Date("2000-01-01");
    // });
  }

  /**
   * Declaring inwardFabric search Form
   * @type {FormGroup}
   * @memberof InwardFabricListComponent
   */
  editInwardFabricForm!: FormGroup;

  /**
   * Get inward fabric search Form Validations
   */
  editInwardFabricValidation = this.validationService?.addInwardFabricSearch;
  editInwardFabricValidationPattern = this.validationService?.patterns;

  ngOnInit(): void {
    this.editInwardFabricFormValiadation();
    this.getColours();
    this.getCompanies();
    this.getQualities();
    this.inwardFabricMinDate = new Date(this.editIwardFabricDetails?.date);
    this.inwardFabricmaxDate = new Date();
  }

  /**
   *This method for initialzing from validations
   *
   * @memberof EditInwardFabricComponent
   */
  editInwardFabricFormValiadation() {
    this.editInwardFabricForm = this.formBuilder.group({
      company: [
        this.editIwardFabricDetails?.inwardCompanyId || "",
        [Validators.required],
      ],
      invoiceNo: [
        this.editIwardFabricDetails?.invoiceNo || "",
        [
          Validators.required,
          Validators.minLength(
            this.editInwardFabricValidation?.invoiceNo?.minLength
          ),
          Validators.maxLength(
            this.editInwardFabricValidation?.invoiceNo?.maxLength
          ),
          Validators.pattern(this.editInwardFabricValidationPattern?.invoice),
        ],
      ],
      Date: [
        new Date(this.editIwardFabricDetails?.date) || "",
        [Validators.required],
      ],
      quality: ["", [Validators.required]],
      colour: ["", [Validators.required]],
      quantity: [
        "",
        [
          Validators.required,
          Validators.minLength(
            this.editInwardFabricValidation?.quantity?.minLength
          ),
          Validators.maxLength(
            this.editInwardFabricValidation?.quantity?.maxLength
          ),
          Validators.pattern(this.editInwardFabricValidationPattern?.quantity),
        ],
      ],
    });
  }

  /**
   * inwardSearch Controls Initialized
   * @readonly
   */
  get editInwardFabricFormControls() {
    return this.editInwardFabricForm.controls;
  }

  /**
   *This method fired on chage of from date
   *
   * @param {*} event
   * @memberof InwardFabricListComponent
   */
  DateChange(event: any) { }

  /**
   *This method fired on chage of to date
   *
   * @param {*} event
   * @memberof InwardFabricListComponent
   */
  ToDateChange(event: any) { }

  /**
   *This method fired on click of Delete icon
   *
   * @param {*} fabric
   * @memberof InwardFabricListComponent
   */
  onClickDeleteInwardFabric(fabric: any, i: any) {
    this.localInwardFabricList.splice(i - 1, 1);
  }

  /**
   *This method fired on click of pagination
   *
   * @memberof InwardFabricListComponent
   */
  onPageChange(event: any) {
    this.currentPage = event;
  }

  /**
   * This Method Used To Navigate  Inward fabric List page.
   * @param {*} event
   * @memberof InwardFabricListComponent
   */
  navigate(event: any) {
    this.router.navigate(["/admin/inventory/inwardfabric/inwardfabriclist"]);
  }

  /**
   * This Method Used To Navigate edit Inward fabric page.
   * @param {*} event
   * @memberof InwardFabricListComponent
   */
  navigateToEditInwardFabric(event: any) {
    this.router.navigate(["/admin/inventory/inwardfabric/editinwardfabric"]);
  }

  /**
   * This method is used to sort column
   * @param key : value of which column based we need to sort the rows
   */
  sort(key: string) {
    const componentName = this.location.path();
    let value = key;
    sessionStorage.setItem(`${componentName}_property`, value);
    this.sortingKeyColumn = key;
    if (sessionStorage.getItem(componentName + "_order") == "desc") {
      this.sortingOrder = false;
    } else {
      this.sortingOrder = true;
    }
  }

  /**
   * This method fired on submit
   * @memberof InwardFabricListComponent
   */
  submit() {
    this.editInwardFabricFormControls["quality"].setValidators(null);
    this.editInwardFabricFormControls["quality"].updateValueAndValidity();

    this.editInwardFabricFormControls["colour"].setValidators(null);
    this.editInwardFabricFormControls["colour"].updateValueAndValidity();

    this.editInwardFabricFormControls["quantity"].setValidators(null);
    this.editInwardFabricFormControls["quantity"].updateValueAndValidity();

    if (this.editInwardFabricForm.invalid) {
      this.validationService.validateAllFormFields(this.editInwardFabricForm);
      return;
    }
    const finalObj = {
      inwardFabricId: this.editIwardFabricDetails?.inwardFabricId || 0,
      inwardCompanyId:
        Number(this.editInwardFabricFormControls["company"].value) || 0,
      invoiceNo: this.editInwardFabricFormControls["invoiceNo"].value || "",
      date:
        this.datePipe.transform(
          this.editInwardFabricFormControls["Date"].value || "",
          "yyyy-MM-dd"
        ) || "",
      inwardFabricList: this.localInwardFabricList,
    };

    this.inventory.editInwardFabric(finalObj).subscribe({
      next: (res: any) => {
        /* Disable the loader */
        this.loaderService.isLoading.next(false);

        this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', 'inwardFabric');
        this.localInwardFabricList = [];
      },
      error: (err: any) => {
        /* Disable the loader */
        this.loaderService.isLoading.next(false);

        this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
      },
    });
  }

  /**
   *This method fired on click of reset
   *
   * @param {*} event
   * @memberof InwardFabricListComponent
   */
  reset() {
    // this.editInwardFabricForm.reset();
    // this.editInwardFabricFormValiadation();
    this.navigate(event);
  }

  /**
   *This method fired on click of exportToWord
   *
   * @param {*} event
   * @memberof InwardFabricListComponent
   */
  ExportToWord(event: any) { }

  /**
   * This method fired on click Add button
   */
  LocalSave() {
    this.editInwardFabricFormControls["quality"].setValidators([
      Validators.required,
    ]);
    this.editInwardFabricFormControls["quality"].updateValueAndValidity();

    this.editInwardFabricFormControls["colour"].setValidators([
      Validators.required,
    ]);
    this.editInwardFabricFormControls["colour"].updateValueAndValidity();

    this.editInwardFabricFormControls["quantity"].setValidators([
      Validators.required,
      Validators.minLength(
        this.editInwardFabricValidation?.quantity?.minLength
      ),
      Validators.maxLength(
        this.editInwardFabricValidation?.quantity?.maxLength
      ),
      Validators.pattern(this.editInwardFabricValidationPattern?.quantity),
    ]);
    this.editInwardFabricFormControls["quantity"].updateValueAndValidity();

    /** This will return false if form fields are invalid and stop the service calling */
    if (this.editInwardFabricForm.invalid) {
      this.validationService.validateAllFormFields(this.editInwardFabricForm);
      return;
    }

    //preparing obj
    const localObj = {
      qualityId:
        Number(this.editInwardFabricFormControls["quality"].value) || "",
      quality: this.qualiyName || "",
      colorId: Number(this.editInwardFabricFormControls["colour"].value) || "",
      colour: this.colourName || "",
      quantity: this.editInwardFabricFormControls["quantity"].value || "",
      status: 0,
    };

    //checking duplicates if both quality and color match
    if (this.localInwardFabricList.length > 0) {
      for (const item of this.localInwardFabricList) {
        if (
          localObj["quality"] === item["quality"] &&
          localObj["colour"] === item["colour"]
        ) {
          this.snackbarModalComponent.onOpenSnackbarModal(false, "This Quality Details Exist", '', '', '');
          return;
        }
      }
      this.localInwardFabricList.push(localObj);
      this.recordsCount = this.localInwardFabricList?.length;
      // this.reset(event);

      this.editInwardFabricFormControls["quality"]?.setValue("");
      this.editInwardFabricFormControls["quality"]?.markAsUntouched({
        onlySelf: true,
      });

      this.editInwardFabricFormControls["colour"]?.setValue("");
      this.editInwardFabricFormControls["colour"]?.markAsUntouched({
        onlySelf: true,
      });

      this.editInwardFabricFormControls["quantity"]?.setValue("");
      this.editInwardFabricFormControls["quantity"]?.markAsUntouched({
        onlySelf: true,
      });
    } else {
      this.localInwardFabricList.push(localObj);
      this.recordsCount = this.localInwardFabricList?.length;
      // this.reset(event);

      this.editInwardFabricFormControls["quality"]?.setValue("");
      this.editInwardFabricFormControls["quality"]?.markAsUntouched({
        onlySelf: true,
      });

      this.editInwardFabricFormControls["colour"]?.setValue("");
      this.editInwardFabricFormControls["colour"]?.markAsUntouched({
        onlySelf: true,
      });

      this.editInwardFabricFormControls["quantity"]?.setValue("");
      this.editInwardFabricFormControls["quantity"]?.markAsUntouched({
        onlySelf: true,
      });
    }
  }

  /**
   * This Method fired on Change of inward Fabric type
   * @param {*} event
   */
  comapanyChange(event: any) {
    for (const item of this.inwardFabricCompanyList) {
      if (item?.companyId === Number(event.target.value)) {
        this.comapanyName = item?.companyName;
      }
    }
  }

  /**
   * This Method fired on Change of Colour
   * @param {*} event
   */
  colourChange(event: any) {
    for (const item of this.inwardFabricColorList) {
      if (item?.colourId === event.target.value) {
        this.colourName = item?.colourName;
      }
    }
  }

  /**
   * This Method fired on Change of quality
   * @param {*} event
   */
  qualityChange(event: any) {
    for (const item of this.inwardFabricQualityList) {
      if (item?.qualityId === Number(event.target.value)) {
        this.qualiyName = item?.qualityName;
      }
    }
  }

  /**
   * This Method for get Colours
   */
  getColours() {
    this.mastersSerive.getColours().subscribe({
      next: (res: any) => {
        this.inwardFabricColorList = res?.result;
      },
      error: (err: any) => {
        this.inwardFabricColorList = [];
      },
    });
  }

  /**
   * This Method for get Companies
   */
  getCompanies() {
    this.mastersSerive.getCompanies().subscribe({
      next: (res: any) => {
        this.inwardFabricCompanyList = res?.result;
      },
      error: (err: any) => {
        this.inwardFabricCompanyList = [];
      },
    });
  }
  /**
   * This Method for get Qualities
   */
  getQualities() {
    this.inventory.getInwardFabicQualities().subscribe({
      next: (res: any) => {
        this.inwardFabricQualityList = res?.result;
      },
      error: (err: any) => {
        this.inwardFabricQualityList = [];
      },
    });
  }
}
