import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditInwardFabricComponent } from './edit-inward-fabric.component';

describe('EditInwardFabricComponent', () => {
  let component: EditInwardFabricComponent;
  let fixture: ComponentFixture<EditInwardFabricComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EditInwardFabricComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EditInwardFabricComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
