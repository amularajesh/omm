import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { InwardFabricComponent } from "./inward-fabric.component";
import { AddInwardFabricComponent } from "./add-inward-fabric/add-inward-fabric.component";
import { EditInwardFabricComponent } from "./edit-inward-fabric/edit-inward-fabric.component";
import { InwardFabricListComponent } from "./inward-fabric-list/inward-fabric-list.component";

const routes: Routes = [
  {
    path: "",
    component: InwardFabricComponent,
    children: [
      { path: "", redirectTo: "inwardfabriclist", pathMatch: "full" },
      { path: "addinwardfabric", component: AddInwardFabricComponent },
      { path: "editinwardfabric", component: EditInwardFabricComponent },
      { path: "inwardfabriclist", component: InwardFabricListComponent },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class InwardFabricRoutingModule {}
