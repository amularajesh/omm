import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InwardFabricListComponent } from './inward-fabric-list.component';

describe('InwardFabricListComponent', () => {
  let component: InwardFabricListComponent;
  let fixture: ComponentFixture<InwardFabricListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InwardFabricListComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(InwardFabricListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
