import { DatePipe, Location } from "@angular/common";
import { Component, OnInit, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";

import { SnackbarModalComponent } from "src/app/core/Dialogues/snackbar-modal/snackbar-modal.component";
import { InventoryService } from "src/app/core/Services/inventory.service";
import { LoaderService } from "src/app/core/Services/loader.service";
import { MastersService } from "src/app/core/Services/masters.service";
import { ValidationService } from "src/app/core/Services/validation.service";

/**
 * Add Inward Fabric Component
 * @export
 * @class AddInwardFabricComponent
 * @implements {OnInit}
 */
@Component({
  selector: "app-add-inward-fabric",
  templateUrl: "./add-inward-fabric.component.html",
  styleUrls: ["./add-inward-fabric.component.scss"],
})
export class AddInwardFabricComponent implements OnInit {
  /**
   * Get Snackbar Modal Component
   * @type {SnackbarModalComponent}
   */
  @ViewChild("snackbarModalComponent") snackbarModalComponent!: SnackbarModalComponent;

  /**
   *Var declared to store data of fabrics on click od add button
   * @type {any[]}
   * @memberof AddInwardFabricComponent
   */
  localInwardFabricList: any[] = [];

  /**
   *
   *Var declared to store data of fabrics COlors list
   * @type {any[]}
   * @memberof AddInwardFabricComponent
   */
  inwardFabricColorList: any[] = [];
  colourName: any;
  /**
   *
   *Var declared to store data of fabrics quality list
   * @type {any[]}
   * @memberof AddInwardFabricComponent
   */
  inwardFabricQualityList: any[] = [];
  qualiyName: any;

  /**
   *
   *Var declared to store data of Comapny list
   * @type {any[]}
   * @memberof AddInwardFabricComponent
   */
  inwardFabricCompanyList: any[] = [];
  comapanyName: any;

  /**
   * Default Sorting Key
   */
  sortingKeyColumn = "quality";

  /**
   * Default Sort Order
   */
  sortingOrder = true;
  /**
   * Default Page Number
   */
  currentPage = 1;

  /**
   *Declaring Var To store Inward fabric min date.
   *
   * @type {*}
   * @memberof InwardFabricListComponent
   */
  inwardFabricMinDate: Date;
  mindate: Date;
  /**
   *Declaring Var To store Inward fabric list.
   * @type {*}
   * @memberof InwardFabricListComponent
   */
  inwardFabricList: any[] = [
    { id: "1", fabricName: "collar" },
    { id: "2", fabricName: "pant" },
    { id: "3", fabricName: "shirt" },
    { id: "4", fabricName: "T-shirt" },
  ];

  inwardTypeName: any;

  /**
   * Declaring var to store records length
   */
  recordsCount = 0;

  /**
   * Declaring inwardFabric search Form
   * @type {FormGroup}
   */
  addInwardFabricSearchForm!: FormGroup;

  /**
   * Get inward fabric search Form Validations
   */
  addInwardFabricSearchValidation = this.validationService?.addInwardFabricSearch;
  addInwardFabricSearchValidationPattern = this.validationService?.patterns;

  /**
   * Creates an instance of AddInwardFabricComponent.
   * @param {Router} router
   * @param {FormBuilder} formBuilder
   * @param {ValidationService} validationService
   * @param {DatePipe} datePipe
   * @param {MastersService} mastersService
   * @param {LoaderService} loaderService
   * @param {InventoryService} inventory
   * @param {Location} location
   */
  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private validationService: ValidationService,
    private datePipe: DatePipe,
    private mastersService: MastersService,
    private loaderService: LoaderService,
    private inventory: InventoryService,
    private location: Location
  ) {
    this.inwardFabricMinDate = new Date();
    this.mindate = new Date("2000-01-01");
  }

  /**
   * Life Cycle Hook Initialization
   */
  ngOnInit(): void {
    this.addInwardFabricSearchFormValidation();
    this.getColours();
    this.getCompanies();
    this.getQualities();
  }

  /**
   * This method for initialize form validations
   */
  addInwardFabricSearchFormValidation() {
    this.addInwardFabricSearchForm = this.formBuilder.group({
      // inwardType: ["", [Validators.required]],
      company: ["", [Validators.required]],
      invoiceNo: [
        "",
        [
          Validators.required,
          Validators.minLength(
            this.addInwardFabricSearchValidation?.invoiceNo?.minLength
          ),
          Validators.maxLength(
            this.addInwardFabricSearchValidation?.invoiceNo?.maxLength
          ),
          Validators.pattern(
            this.addInwardFabricSearchValidationPattern?.invoice
          ),
        ],
      ],
      Date: ["", [Validators.required]],
      quality: ["", [Validators.required]],
      colour: ["", [Validators.required]],
      quantity: [
        "",
        [
          Validators.required,
          Validators.minLength(
            this.addInwardFabricSearchValidation?.quantity?.minLength
          ),
          Validators.maxLength(
            this.addInwardFabricSearchValidation?.quantity?.maxLength
          ),
          Validators.pattern(
            this.addInwardFabricSearchValidationPattern?.quantity
          ),
        ],
      ],
    });
  }

  /**
   * inwardSearch Controls Initialized
   * @readonly
   */
  get addInwardFabricSearchFormControls() {
    return this.addInwardFabricSearchForm.controls;
  }

  /**
   * This method fired on change of from date
   * @param {*} newValue
   */
  DateChange(newValue: any) {
    console.log("Date changed to:", newValue);
  }

  /**
   * This method fired on change of to date
   * @param {*} event
   */
  ToDateChange(event: any) { }

  /**
   * This method fired on click of Delete icon
   * @param {*} fabric
   * @param {*} i
   */
  onClickDeleteInwardFabric(fabric: any, i: any) {
    this.localInwardFabricList.splice(i - 1, 1);
  }

  /**
   * This method fired on click of pagination
   */
  onPageChange(event: any) {
    this.currentPage = event;
  }

  /**
   * This Method Used To Navigate  Inward fabric List page.
   * @param {*} event
   */
  navigate(event: any) {
    this.router.navigate(["/admin/inventory/inwardfabric/inwardfabriclist"]);
  }

  /**
   * This Method Used To Navigate edit Inward fabric page.
   * @param {*} event
   */
  navigateToEditInwardFabric(event: any) {
    this.router.navigate(["/admin/inventory/inwardfabric/editinwardfabric"]);
  }

  /**
   * This method is used to sort column
   * @param key : value of which column based we need to sort the rows
   */
  sort(key: string) {
    const componentName = this.location.path();
    let value = key;
    sessionStorage.setItem(`${componentName}_property`, value);
    this.sortingKeyColumn = key;
    if (sessionStorage.getItem(componentName + "_order") == "desc") {
      this.sortingOrder = false;
    } else {
      this.sortingOrder = true;
    }
  }

  /**
   * This method fired on submit
   */
  submit() {
    this.addInwardFabricSearchFormControls["quality"].setValidators(null);
    this.addInwardFabricSearchFormControls["quality"].updateValueAndValidity();

    this.addInwardFabricSearchFormControls["colour"].setValidators(null);
    this.addInwardFabricSearchFormControls["colour"].updateValueAndValidity();

    this.addInwardFabricSearchFormControls["quantity"].setValidators(null);
    this.addInwardFabricSearchFormControls["quantity"].updateValueAndValidity();

    if (this.addInwardFabricSearchForm.invalid) {
      this.validationService.validateAllFormFields(
        this.addInwardFabricSearchForm
      );
      return;
    }
    const finalObj = {
      inwardCompanyId:
        Number(this.addInwardFabricSearchFormControls["company"].value) || 0,
      invoiceNo:
        this.addInwardFabricSearchFormControls["invoiceNo"].value || "",
      date:
        this.datePipe.transform(
          this.addInwardFabricSearchFormControls["Date"].value || "",
          "yyyy-MM-dd"
        ) || "",
      inwardFabricList: this.localInwardFabricList,
    };
    console.log(finalObj, "finalObj");

    /* Enable the loader */
    this.loaderService.isLoading.next(true);

    this.inventory.addInwardFabric(finalObj).subscribe({
      next: (res: any) => {
        /* Disable the loader */
        this.loaderService.isLoading.next(false);

        this.snackbarModalComponent.onOpenSnackbarModal(true, res?.result?.message, '', '', 'inwardFabric');
        this.reset();
      },
      error: (err: any) => {
        /* Disable the loader */
        this.loaderService.isLoading.next(false);

        this.snackbarModalComponent.onOpenSnackbarModal(false, err?.error?.result?.message, '', '', '');
      },
    });
  }

  /**
   * This method fired on click of reset
   */
  reset() {
    this.localInwardFabricList = [];
    this.addInwardFabricSearchForm.reset();
    this.addInwardFabricSearchFormValidation();
  }

  /**
   * This method fired on click of exportToWord
   * @param {*} event
   */
  ExportToWord(event: any) { }

  /**
   * This method fired on click Add button
   */
  LocalSave() {
    this.addInwardFabricSearchFormControls["quality"].setValidators([
      Validators.required,
    ]);
    this.addInwardFabricSearchFormControls["quality"].updateValueAndValidity();

    this.addInwardFabricSearchFormControls["colour"].setValidators([
      Validators.required,
    ]);
    this.addInwardFabricSearchFormControls["colour"].updateValueAndValidity();

    this.addInwardFabricSearchFormControls["quantity"].setValidators([
      Validators.required,
      Validators.minLength(
        this.addInwardFabricSearchValidation?.quantity?.minLength
      ),
      Validators.maxLength(
        this.addInwardFabricSearchValidation?.quantity?.maxLength
      ),
      Validators.pattern(this.addInwardFabricSearchValidationPattern?.quantity),
    ]);

    this.addInwardFabricSearchFormControls["quantity"].updateValueAndValidity();
    /** This will return false if form fields are invalid and stop the service calling */
    if (this.addInwardFabricSearchForm.invalid) {
      this.validationService.validateAllFormFields(
        this.addInwardFabricSearchForm
      );
      return;
    }
    //preparing obj
    const localObj = {
      qualityId:
        Number(this.addInwardFabricSearchFormControls["quality"].value) || "",
      quality: this.qualiyName || "",
      colorId:
        Number(this.addInwardFabricSearchFormControls["colour"].value) || "",
      colour: this.colourName || "",
      quantity: this.addInwardFabricSearchFormControls["quantity"].value || "",
      status: 0,
    };

    // checking duplicates if both quality and color match
    if (this.localInwardFabricList.length > 0) {
      for (const item of this.localInwardFabricList) {
        if (
          localObj["quality"] === item["quality"] &&
          localObj["colour"] === item["colour"]
        ) {
          this.snackbarModalComponent.onOpenSnackbarModal(false, "This Quality Details Exist", '', '', '');
          return;
        }
      }
      this.localInwardFabricList.push(localObj);
      this.recordsCount = this.localInwardFabricList?.length;

      this.addInwardFabricSearchFormControls["quality"]?.setValue("");
      this.addInwardFabricSearchFormControls["quality"]?.markAsUntouched({
        onlySelf: true,
      });

      this.addInwardFabricSearchFormControls["colour"]?.setValue("");
      this.addInwardFabricSearchFormControls["colour"]?.markAsUntouched({
        onlySelf: true,
      });

      this.addInwardFabricSearchFormControls["quantity"]?.setValue("");
      this.addInwardFabricSearchFormControls["quantity"]?.markAsUntouched({
        onlySelf: true,
      });
    } else {
      this.localInwardFabricList.push(localObj);
      this.recordsCount = this.localInwardFabricList?.length;

      this.addInwardFabricSearchFormControls["quality"]?.setValue("");
      this.addInwardFabricSearchFormControls["quality"]?.markAsUntouched({
        onlySelf: true,
      });

      this.addInwardFabricSearchFormControls["colour"]?.setValue("");
      this.addInwardFabricSearchFormControls["colour"]?.markAsUntouched({
        onlySelf: true,
      });

      this.addInwardFabricSearchFormControls["quantity"]?.setValue("");
      this.addInwardFabricSearchFormControls["quantity"]?.markAsUntouched({
        onlySelf: true,
      });
    }
  }

  /**
   * This Method fired on Change of inward Fabric type
   * @param {*} event
   */
  comapanyChange(event: any) {
    for (const item of this.inwardFabricCompanyList) {
      if (item?.companyId === Number(event.target.value)) {
        this.comapanyName = item?.companyName;
      }
    }
  }

  /**
   * This Method fired on Change of Colour
   * @param {*} event
   */
  colourChange(event: any) {
    for (const item of this.inwardFabricColorList) {
      if (item?.colourId === event.target.value) {
        this.colourName = item?.colourName;
      }
    }
  }

  /**
   * This Method fired on Change of quality
   * @param {*} event
   */
  qualityChange(event: any) {
    for (const item of this.inwardFabricQualityList) {
      if (item?.qualityId === Number(event.target.value)) {
        this.qualiyName = item?.qualityName;
      }
    }
  }

  /**
   * This Method for get Colours
   */
  getColours() {
    this.mastersService.getColours().subscribe({
      next: (res: any) => {
        this.inwardFabricColorList = res?.result;
      },
      error: (err: any) => {
        this.inwardFabricColorList = [];
      },
    });
  }

  /**
   * This Method for get Companies
   */
  getCompanies() {
    this.mastersService.getCompanies().subscribe({
      next: (res: any) => {
        this.inwardFabricCompanyList = res?.result;
      },
      error: (err: any) => {
        this.inwardFabricCompanyList = [];
      },
    });
  }

  /**
   * This Method for get Qualities
   */
  getQualities() {
    this.inventory.getInwardFabicQualities().subscribe({
      next: (res: any) => {
        this.inwardFabricQualityList = res?.result;
      },
      error: (err: any) => {
        this.inwardFabricQualityList = [];
      }
    });
  }
}
