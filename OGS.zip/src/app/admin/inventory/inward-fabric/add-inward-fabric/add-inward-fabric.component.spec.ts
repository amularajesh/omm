import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddInwardFabricComponent } from './add-inward-fabric.component';

describe('AddInwardFabricComponent', () => {
  let component: AddInwardFabricComponent;
  let fixture: ComponentFixture<AddInwardFabricComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddInwardFabricComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddInwardFabricComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
