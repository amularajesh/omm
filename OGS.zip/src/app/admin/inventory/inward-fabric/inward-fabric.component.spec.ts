import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InwardFabricComponent } from './inward-fabric.component';

describe('InwardFabricComponent', () => {
  let component: InwardFabricComponent;
  let fixture: ComponentFixture<InwardFabricComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InwardFabricComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(InwardFabricComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
